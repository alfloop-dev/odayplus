---
doc_id: ODP-SD-09
title: "身分、權限、資安與個資設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Security Owner / IAM Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus 身分、權限、資安與個資設計

## 1. 文件目的

本文件定義 ODay Plus 的身分認證、授權、資料隔離、Service Account、Secret、個資保護、資安控制、威脅模型、資料匯出與稽核設計。此文件承接 SA-04 角色權限需求與 SA-08 NFR，並作為 Security Test 與資安查核的設計基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 安全設計原則

1. 預設拒絕，明確授權。
2. 權限判斷必須同時考慮角色與資料 scope。
3. 模型輸出、估值、營收、個資與決策紀錄都屬敏感資料。
4. 高風險決策需責任分離：提出、驗證、核准、執行不得全部由同一人完成。
5. 所有資料下載、匯出、估值查看、模型發布與 override 必須稽核。
6. Secret 不得出現在 repo、log、image 或前端 bundle。
7. 個資最小化：能用聚合或 pseudonymous ID 就不用原始個資。

## 3. Identity Provider

| 選項 | 用途 | 備註 |
|---|---|---|
| Keycloak | OSS IdP、RBAC、OIDC/SAML | 可自管，與平台一致 |
| Google Identity Platform / Workforce Identity | GCP 原生 | 若組織採 Google Workspace 可評估 |
| Enterprise SSO | 客戶或總部既有 IdP | 需 OIDC/SAML federation |

第一版可採 Keycloak 或既有企業 SSO；API 只信任經核准 IdP 發出的 JWT。

## 4. 角色與 Scope

### 4.1 Role

| Role | 說明 | 高風險能力 |
|---|---|---|
| `platform_admin` | 系統管理 | 管理設定，不代表可看所有商業敏感資料 |
| `architecture_owner` | 架構與 ADR | 無業務核准權 |
| `data_owner` | 資料契約與品質 | 可核准資料品質 override |
| `model_owner` | 模型驗證與發布 | 可送 model promotion |
| `release_owner` | 發布與回滾 | 可切換 model alias |
| `expansion_user` | 展店業務 | 查熱區、listing、候選點 |
| `site_reviewer` | 展店審查 | 核准 SiteScore 決策 |
| `operations_manager` | 營運主管 | 四燈、干預、任務管理 |
| `regional_supervisor` | 區域督導 | 區域門市處置與回報 |
| `pricing_manager` | 定價 | 價格方案核准 |
| `marketing_manager` | 行銷 | campaign/adlift 操作 |
| `finance_legal` | 財務法務 | AVM、交易、租約、Data Room |
| `executive` | 管理層 | NetPlan、MOVE/EXIT、重大 override |
| `franchisee` | 加盟主 | 僅自有門市資訊與任務 |
| `auditor` | 稽核 | 查 audit、decision、evidence，不改資料 |

### 4.2 Scope

| Scope | 說明 |
|---|---|
| `tenant_id` | 租戶／公司層 |
| `brand_id` | 品牌層 |
| `region_id` | 區域層 |
| `store_id` | 門市層 |
| `module` | 功能模組層 |
| `data_classification` | 資料分級 |
| `action_risk_level` | 動作風險層級 |

## 5. 授權模型

```text
Allow if:
  authenticated
  AND role permits action
  AND scope permits resource
  AND workflow state permits action
  AND policy constraints pass
  AND data classification permits visibility
```

### 5.1 ABAC 條件範例

| 情境 | 條件 |
|---|---|
| 加盟主看 Forecast | `user.store_ids contains store_id` AND no hidden finance fields |
| 區域督導處理 alert | `user.region_ids contains store.region_id` AND `alert.status in actionable` |
| 財務看 AVM | role `finance_legal` AND data room access granted |
| 模型發布 | role `model_owner` AND validation passed AND release workflow pending |
| NetPlan EXIT 核准 | role `executive` AND plan risk level high AND two-person approval complete |

## 6. 資料分級

| Classification | 資料例子 | 控制 |
|---|---|---|
| Public | 公開產品說明 | 無特殊 |
| Internal | 一般系統設定、非敏感 metadata | 登入可見 |
| Confidential | 營收、毛利、預測、模型指標、Listing | Role + scope |
| Restricted | 個資、估值、租約、交易條件、Data Room | 最小權限、audit、export approval |
| Highly Restricted | Secret、金鑰、弱點報告、管理員權限 | break-glass、MFA、SRE/Security only |

## 7. 個資設計

| 原則 | 設計 |
|---|---|
| 目的限制 | 會員資料只用於授權目的，例如會員行為、CRM、回訪分析 |
| 最小化 | 模型優先使用 pseudonymous customer_id、區段特徵，不使用姓名電話 |
| 去識別 | 分析與模型資料以 hashed/pseudonymous ID 表示 |
| 遮罩 | 前端只顯示必要部分，例如 phone last 3 digits |
| 保留期限 | 依資料類型與法務政策設定 |
| 下載／刪除 | 提供可追蹤流程；刪除需保留合法必要稽核資訊 |
| 匯出審批 | PII export 必須有理由、核准、有效期限與下載 audit |

## 8. Secret 與 Key Management

1. Secret 存放於 Secret Manager。
2. 每個服務使用不同 Service Account。
3. Production secret 不得被 dev/staging 讀取。
4. 金鑰 rotation 需有排程與 Runbook。
5. CI/CD 只取得部署所需最小權限。
6. signed URL 有效期限依資料分級設定。
7. 若使用 CMEK，需定義 key ring、rotation、break-glass procedure。

## 9. Network Security

| 控制 | 設計 |
|---|---|
| WAF | Cloud Armor 保護 public ingress |
| TLS | 全外部通訊 HTTPS/TLS |
| Private DB | Cloud SQL Private IP |
| Service-to-service | IAM-authenticated request 或 mTLS/service mesh candidate |
| Egress | 對外 connector 限制目的、記錄 API 呼叫 |
| Rate limit | Gateway/Cloud Armor/API layer |
| DDoS | Cloud Armor + Load Balancer |
| Internal admin | IAP/VPN/Zero Trust access |

## 10. 威脅模型摘要

| Threat | 風險 | 控制 |
|---|---|---|
| 橫向越權看其他加盟主門市 | 高 | ABAC store scope、contract test |
| 模型建議被誤當自動決策 | 高 | Decision/Approval 分離、UI 標示、audit |
| 價格方案繞過核准 | 高 | Workflow state check、API policy |
| Data Room 外洩 | 高 | short-lived URL、download audit、watermark optional |
| 上游資料污染 | 高 | Data quality gate、source lineage、quarantine |
| Event replay 重複執行 | 高 | idempotency key、execution lock |
| Secret 泄漏 | 高 | Secret Manager、scan、rotation |
| Prompt/LLM 資料外洩 | 中/高 | 若導入 LLM，需禁止傳入敏感原文或使用企業安全設定 |
| 供應鏈攻擊 | 中/高 | image scan、dependency pinning、SBOM、Binary Authorization candidate |

## 11. Audit 要求

下列動作必須 audit：

1. 登入、登出、權限變更、impersonation。
2. 查看或下載 Restricted 資料。
3. 建立、修改、核准、拒絕、override 任何決策。
4. 建立或執行價格、廣告、維修、促銷等干預。
5. AVM、Data Room、NetPlan 查看與核准。
6. 模型訓練、升版、回滾。
7. 資料品質 override、資料重送、backfill。
8. 匯出 CSV/JSON、報告或查核包。

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD09-001` | RBAC + ABAC 可限制 tenant/brand/region/store scope | Security Test |
| `ODP-AC-SD09-002` | 加盟主不可讀取其他門市或總部敏感欄位 | Access Test |
| `ODP-AC-SD09-003` | 高風險核准具責任分離與 workflow state check | Workflow/Security Test |
| `ODP-AC-SD09-004` | Secret 不存在 repo/image/log，且由 Secret Manager 注入 | CI/Security Scan |
| `ODP-AC-SD09-005` | PII export、Data Room download、model release 均寫入 audit | Audit Test |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
