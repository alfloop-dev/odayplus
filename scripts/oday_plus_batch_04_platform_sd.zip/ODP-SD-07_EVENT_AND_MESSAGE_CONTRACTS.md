---
doc_id: ODP-SD-07
title: "Event 與訊息契約"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Event Platform Owner / Backend Lead"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus Event 與訊息契約

## 1. 文件目的

本文件定義 ODay Plus 的事件驅動設計，包括 Event Envelope、Topic 命名、事件版本、Producer/Consumer、冪等性、Retry、Dead Letter、Schema Governance 與主要 Event Catalog。此文件是後續 AsyncAPI、Pub/Sub topic、worker、workflow 與 E2E 測試的基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. Event 使用原則

1. 事件用於模組解耦與非同步流程，不作為唯一資料庫。
2. Event payload 必須有 schema version 與 idempotency key。
3. Producer 必須保存可查的 business state；Consumer 不得只依賴事件重播重建所有狀態，除非明確設計 event sourcing。
4. Critical Event 必須有 DLQ、retry policy、correlation id 與 audit。
5. Event 不應包含過量 PII；必要 PII 以 reference id 取代。
6. Breaking change 必須新增 event version，不得破壞舊 consumer。

## 3. Event Envelope

```json
{
  "event_id": "evt_01HY...",
  "event_type": "sitescore.completed.v1",
  "event_version": "1.0.0",
  "occurred_at": "2026-06-26T10:00:00+08:00",
  "published_at": "2026-06-26T10:00:02+08:00",
  "producer": "sitescore-score-worker",
  "tenant_id": "tenant_oday",
  "correlation_id": "corr_01HY...",
  "causation_id": "evt_01HX...",
  "idempotency_key": "sitescore_run:ssr_123:completed:v1",
  "subject": {
    "entity_type": "site_score_run",
    "entity_id": "ssr_123"
  },
  "data_classification": "confidential",
  "payload": {}
}
```

## 4. Topic 命名

```text
odp.{env}.{domain}.{event_group}.v{major}
```

範例：

```text
odp.prod.sitescore.events.v1
odp.prod.intervention.events.v1
odp.prod.learninghub.model-events.v1
odp.prod.audit.events.v1
odp.prod.dlq.sitescore.v1
```

## 5. Delivery 與 Consumer 規範

| 項目 | 規範 |
|---|---|
| Ack | Consumer 完成持久化處理後才 ack |
| Retry | 指數退避；依事件類型設定最大 retry |
| DLQ | 超過 retry、schema invalid、permission denied 進 DLQ |
| Idempotency | Consumer 必須以 `event_id` 或 `idempotency_key` 去重 |
| Ordering | 只有需要同 entity 順序時使用 ordering key；不可濫用 |
| Replay | critical topic 必須保留 replay 方法與 replay audit |
| Schema | JSON Schema 或 Protobuf；需 CI contract test |

## 6. Event Catalog

### 6.1 Integration / Data

| Event Type | Producer | Consumer | Payload Summary |
|---|---|---|---|
| `source.ingested.v1` | source adapter | canonical mapper、audit | source_run_id、source_system、snapshot_id |
| `canonical.updated.v1` | canonical mapper | dbt trigger、DQ、Learning Hub | entity_type、date_range、snapshot_id |
| `data_quality.passed.v1` | dq worker | scheduler、release gate | dq_run_id、dataset、score |
| `data_quality.failed.v1` | dq worker | OpsBoard、Release Controller | failed_rules、severity、blocked_targets |
| `model_ready_view.refreshed.v1` | dbt pipeline | scoring jobs、Learning Hub | view_name、view_version、snapshot_id |

### 6.2 Expansion

| Event Type | Producer | Consumer | Payload Summary |
|---|---|---|---|
| `heatzone.scored.v1` | heatzone job | OpsBoard、Listing | run_id、area_count、top_k_ready |
| `listing.created.v1` | listing API/importer | geocoder、dedup | listing_id、source、address |
| `listing.geocoded.v1` | geocode worker | dedup、HeatZone filter | listing_id、lat、lng、h3、confidence |
| `listing.deduplicated.v1` | dedup worker | listing API、OpsBoard | listing_id、canonical_listing_id、match_confidence |
| `candidate_site.created.v1` | listing/user | SiteScore | candidate_site_id |
| `sitescore.requested.v1` | API/OpsBoard | sitescore worker | run_id、candidate_site_id |
| `sitescore.completed.v1` | sitescore worker | report worker、OpsBoard | run_id、status、summary |
| `site_decision.approved.v1` | approval workflow | store onboarding、Learning Hub | decision_id、candidate_site_id、approved_by |
| `site_decision.rejected.v1` | approval workflow | Learning Hub | decision_id、reason_code |
| `store.opened.v1` | store onboarding | ForecastOps、HeatZone realization | store_id、opened_on、site_score_run_id |

### 6.3 Forecast and Intervention

| Event Type | Producer | Consumer | Payload Summary |
|---|---|---|---|
| `forecast.scored.v1` | forecast job | alert engine、OpsBoard | forecast_run_id、store_count |
| `alert.created.v1` | alert engine | OpsBoard、InterventionOps | alert_id、store_id、light_status、severity |
| `alert.acknowledged.v1` | OpsBoard | audit、workflow | alert_id、actor_id |
| `intervention.candidate_created.v1` | InterventionOps | eligibility worker | intervention_id、store_id、type |
| `intervention.approved.v1` | approval workflow | execution coordinator、Learning Hub | intervention_id、approved_action_ids |
| `intervention.executed.v1` | execution coordinator | observation manager | intervention_id、execution_time |
| `intervention.observation_matured.v1` | observation manager | effect evaluation | intervention_id、window_id |
| `intervention.effect_evaluated.v1` | effect evaluation | Learning Hub、OpsBoard | intervention_id、effect_summary、evidence_level |
| `intervention.rollback_requested.v1` | OpsBoard/Policy | execution coordinator | intervention_id、reason |

### 6.4 Price and Ad

| Event Type | Producer | Consumer | Payload Summary |
|---|---|---|---|
| `price_action.proposed.v1` | pricing optimizer | InterventionOps、OpsBoard | price_action_id、expected_gm、constraints |
| `price_action.approved.v1` | approval workflow | execution coordinator | price_action_id |
| `price_action.rollback_requested.v1` | monitoring/OpsBoard | execution coordinator | price_action_id、reason |
| `campaign.created.v1` | AdLift/OpsBoard | control matcher | campaign_id、stores、period |
| `campaign.started.v1` | execution coordinator | observation manager | campaign_id、start_time |
| `adlift.controls_matched.v1` | control matcher | did estimator | campaign_id、control_set_id |
| `adlift.evaluated.v1` | did estimator | OpsBoard、Learning Hub | campaign_id、incremental_gm、iromi、evidence |

### 6.5 Asset / Network / Learning / Audit

| Event Type | Producer | Consumer | Payload Summary |
|---|---|---|---|
| `valuation.requested.v1` | API/OpsBoard | valuation worker | valuation_run_id、store_id |
| `valuation.completed.v1` | valuation worker | dataroom builder、OpsBoard | valuation_run_id、p10、p50、p90 |
| `dataroom.created.v1` | dataroom builder | OpsBoard、audit | dataroom_id、store_id |
| `netplan.solve_requested.v1` | API/OpsBoard | scenario builder、solver | plan_id、period |
| `netplan.solved.v1` | solver | solver explain、OpsBoard | plan_id、solver_status、objective_value |
| `netplan.infeasible.v1` | solver | infeasibility worker、OpsBoard | plan_id、binding_constraints |
| `model.registered.v1` | training pipeline | Learning Hub | model_id、version、metrics |
| `model.promoted.v1` | release controller | serving layer、audit | model_id、from_alias、to_alias |
| `model.rollback.v1` | release controller | serving layer、audit | model_id、rollback_to |
| `audit.event_recorded.v1` | audit logger | audit sink | audit_event_id、actor、entity |

## 7. Schema Governance

| 規則 | 要求 |
|---|---|
| Schema owner | 每個 event type 必須有 owner |
| Versioning | additive change 可 minor；breaking change 必須新增 major topic 或 event type |
| Required fields | envelope fields 不得移除 |
| Contract test | Producer 與 consumer CI 必須跑 schema test |
| Compatibility | 新 consumer 必須能忽略未知欄位 |
| Deprecation | 舊事件至少保留一個 release cycle 或依 ADR |

## 8. DLQ 與 Quarantine

| 類型 | 進入條件 | 處理 |
|---|---|---|
| Schema DLQ | payload schema invalid | 修 schema 或資料後 replay |
| Permission DLQ | consumer 無權讀必要資源 | 修 IAM 或資料 scope |
| Business DLQ | 狀態不允許、entity missing | 人工判斷或補資料 |
| Dependency DLQ | 下游不可用超過 retry | 等待恢復後 replay |
| Duplicate ignored | idempotency 重複 | 記錄並 ack，不進 DLQ |

## 9. Event 安全與資料保護

1. Event payload 不放會員 PII 原文，除非必要且 encrypted。
2. 估值、財務、交易、個資事件 topic 需限制 subscription 權限。
3. Event replay 必須需要授權並寫 audit。
4. DLQ 可能含敏感資料，權限不得比原 topic 寬。
5. Consumer log 不得記錄完整敏感 payload。

## 10. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD07-001` | Event envelope 被所有事件採用 | Contract Test |
| `ODP-AC-SD07-002` | Critical events 有 topic、DLQ、producer、consumer、owner | Event Catalog Review |
| `ODP-AC-SD07-003` | Consumer 支援 idempotency 與 retry | Integration Test |
| `ODP-AC-SD07-004` | Schema breaking change 必須新增版本 | CI Schema Compatibility Test |
| `ODP-AC-SD07-005` | Event replay 與 DLQ 操作有 audit | OPS Test |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
