---
doc_id: ODP-SD-11
title: "可觀測性與稽核設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "SRE Owner / Audit Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus 可觀測性與稽核設計

## 1. 文件目的

本文件定義 ODay Plus 的 Logs、Metrics、Traces、Business Events、Audit Trail、Dashboards、Alerts、SLO/SLI、Model Monitoring、Data Quality Monitoring 與補助查核證據設計。目標是讓系統狀態、業務決策、模型版本與資料品質都可被觀察、追蹤與驗證。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 可觀測性原則

1. 每個 API request、event、job、workflow 都必須有 correlation id。
2. Logs、Metrics、Traces 不只看服務健康，也要看業務流程健康。
3. 模型輸出、資料品質與決策採用情況必須可監控。
4. Audit Trail 必須 append-only，不可被一般管理員修改。
5. 補助查核所需證據應可從系統自動匯出。
6. Dashboard 要分 SRE、Business、Data、Model、Audit 五類。

## 3. Trace Context

| 欄位 | 用途 |
|---|---|
| `correlation_id` | 跨 API/Event/Job/Workflow 的主追蹤 ID |
| `request_id` | 單次 HTTP request |
| `event_id` | 單一事件 |
| `job_id` | 長任務 |
| `workflow_instance_id` | 業務流程 |
| `actor_id` | 使用者或 service account |
| `entity_type` / `entity_id` | 業務實體 |
| `model_version` | 模型版本 |
| `dataset_snapshot_id` | 資料快照 |

## 4. Logging 設計

### 4.1 Log 類型

| Log | 內容 | Sink |
|---|---|---|
| Application Log | API/worker 行為、錯誤、狀態 | Cloud Logging |
| Access Log | API access、user、resource | Cloud Logging + BigQuery audit sink |
| Audit Log | 決策、核准、資料匯出、模型發布 | Cloud SQL index + BigQuery append table |
| Data Pipeline Log | ingestion、dbt、DQ、backfill | Cloud Logging + BigQuery |
| Model Log | training、prediction、drift、release | MLflow + BigQuery |
| Security Log | auth fail、permission denied、suspicious access | Cloud Logging/Security dashboard |

### 4.2 Log 規範

1. JSON structured logging。
2. 不記錄完整 PII、secret、token、private signed URL。
3. Error log 必須含 error code、retryable、correlation_id。
4. Job log 必須含 job_id、task partition、run attempt。
5. 模型預測 log 必須含 model_version、feature_snapshot_time。

## 5. Metrics 設計

### 5.1 Technical Metrics

| Metric | Label | 用途 |
|---|---|---|
| `api_request_count` | service、route、status | API 流量 |
| `api_latency_ms` | service、route | P50/P95/P99 |
| `job_duration_seconds` | job_type、status | 批次耗時 |
| `job_failure_count` | job_type、error_class | 批次失敗 |
| `event_consumer_lag` | topic、subscription | event backlog |
| `dlq_message_count` | topic | DLQ 監控 |
| `db_query_latency_ms` | query_group | DB 性能 |
| `external_connector_failure_count` | source | 外部來源穩定性 |

### 5.2 Data / Model Metrics

| Metric | Label | 用途 |
|---|---|---|
| `data_freshness_hours` | source/view | 新鮮度 |
| `data_quality_score` | dataset/run | 品質 |
| `feature_null_rate` | feature/view | 特徵品質 |
| `prediction_count` | model/module | 預測量 |
| `model_error_metric` | model/horizon/segment | MAE/MAPE/RMSE 等 |
| `prediction_interval_coverage` | model/horizon | P80/P90 coverage |
| `drift_score` | feature/model | 漂移 |
| `model_alias_change_count` | model | 發布/回滾 |

### 5.3 Business Metrics

| Metric | 用途 |
|---|---|
| HeatZone Top-K 現勘採用率 | 展店流程有效性 |
| Listing 去重準確率 | 物件品質 |
| SiteScore M3/M6/M12 Realization | 新店預測有效性 |
| Forecast alert precision/recall/lead time | 預警有效性 |
| Intervention 14/28 日恢復率 | 干預成效 |
| Price hard constraint violation count | 定價安全 |
| AdLift incremental GM/iROMI | 廣告增量 |
| AVM interval coverage | 估值可靠性 |
| NetPlan plan adoption/outcome | 店網方案有效性 |
| Model adoption/override rate | 模型採用與治理 |

## 6. Trace 設計

OpenTelemetry instrumentation 應覆蓋：

1. API request。
2. DB query。
3. Pub/Sub publish/consume。
4. GCS read/write。
5. BigQuery query/job。
6. External API call。
7. Model serving call。
8. Workflow transition。
9. Report generation。

Sampling：Production 可採 head/tail sampling，但 P1/P2、error trace、高風險決策 trace 必須保留。

## 7. Audit Trail Schema

| 欄位 | 說明 |
|---|---|
| `audit_event_id` | audit ID |
| `occurred_at` | 發生時間 |
| `actor_type` | user/service/system |
| `actor_id` | actor |
| `actor_role_snapshot` | 當下角色 |
| `tenant_id` / `scope` | 資料範圍 |
| `action` | view/create/update/approve/reject/export/promote/rollback |
| `entity_type` / `entity_id` | 對象 |
| `before_ref` / `after_ref` | 變更前後 reference |
| `reason_code` / `comment` | 理由 |
| `policy_version` | 政策版本 |
| `correlation_id` | 追蹤 |
| `ip` / `user_agent` | 使用者來源 |
| `result` | success/failure |

## 8. Dashboard

| Dashboard | 使用者 | 內容 |
|---|---|---|
| Platform Health | SRE | API latency、error、job、queue、DB、GCS |
| Data Health | Data Owner | freshness、quality、coverage、lineage、DQ fail |
| Model Health | Model Owner | metrics、drift、calibration、release、rollback |
| Business Ops | 營運/管理層 | 熱區、listing、forecast、alerts、interventions、NetPlan |
| Audit & Compliance | Auditor | decision log、export、approval、model release、access |
| External Source | Integration Owner | source sync、connector failures、geocode quality |

## 9. Alert Rules

| Alert | Severity | 條件 |
|---|---|---|
| API availability drop | P1/P2 | 5xx 或 latency 超過 SLO |
| Forecast daily failed | P2 | 每日批次未在 cutoff 前完成 |
| Data quality P0 fail | P2 | P0 view DQ failed |
| DLQ spike | P2/P3 | critical topic DLQ 超閾值 |
| Unauthorized spike | P2 | 403/401 異常上升 |
| Model drift high | P2/P3 | drift 超 release policy |
| Price constraint violation | P1 | 任何已執行方案違反 hard constraint |
| Data Room abnormal download | P1/P2 | 短時間大量下載或非授權嘗試 |
| Solver repeated infeasible | P3 | 同場景連續無解 |
| External connector stale | P3 | 外部來源超過 freshness SLA |

## 10. 補助查核證據設計

系統需可輸出：

1. 功能上線證據：畫面、API、workflow、event、job run。
2. 模型驗證證據：backtest、metric、model card、release record。
3. 資安證據：IAM、Cloud Logging、audit、掃描報告、權限測試。
4. SLA 證據：availability、incident、RPO/RTO drill。
5. 資料可攜證據：CSV/JSON 匯出紀錄、API docs。
6. 導入效益證據：SiteScore realization、forecast alert、intervention outcome、AVM coverage、NetPlan outcome。

## 11. Retention

| 類型 | 保留 |
|---|---|
| Application logs | 依環境，Production 建議 90-365 天可查 |
| Audit logs | 至少 7 年或依法務/補助要求 |
| Model metrics | 保留所有 production release |
| Data quality history | 至少覆蓋模型訓練與驗證期間 |
| Trace | 短期高解析，錯誤與高風險 trace 長保留 |
| Export logs | 與 audit 同等保留 |

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD11-001` | API/Event/Job/Workflow 均有 correlation_id | E2E Trace Test |
| `ODP-AC-SD11-002` | P0 模組有 technical、data、model、business metrics | Observability Review |
| `ODP-AC-SD11-003` | 高風險操作與資料匯出有 audit event | Audit Test |
| `ODP-AC-SD11-004` | Dashboard 與 Alert 規則覆蓋 P1/P2 情境 | SRE Review |
| `ODP-AC-SD11-005` | 補助查核證據能由系統產出或匯出 | Compliance Review |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
