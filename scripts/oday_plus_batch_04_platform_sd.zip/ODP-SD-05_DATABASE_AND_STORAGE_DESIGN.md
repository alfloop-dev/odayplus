---
doc_id: ODP-SD-05
title: "資料庫與儲存設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Backend Lead"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus 資料庫與儲存設計

## 1. 文件目的

本文件將第 3 批 Canonical Data Model 與 Model-ready Views 轉為平台層級的資料庫與儲存設計。此文件不列出每張表的所有物理欄位；完整欄位由 migration、dbt schema、ERD 與模組設計文件承接。本文件定義儲存分工、schema 分區、table 類型、命名、索引、partition、retention、audit 與資料保護規範。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 儲存分工總覽

| 儲存 | 主要用途 | 不適合用途 |
|---|---|---|
| Cloud SQL PostgreSQL + PostGIS | 操作型資料、工作流狀態、任務、核准、Listing、地理 metadata、PostGIS 精確空間查詢 | 大量歷史訓練資料、全量時間序列分析 |
| BigQuery | Raw、Canonical facts、Model-ready Views、特徵、回測、稽核分析、KPI 報表 | 高頻交易型狀態更新 |
| Cloud Storage | 原始檔快照、外部資料包、模型 artifact、報告、資料室、匯出檔 | 查詢型 transactional source of truth |
| Redis / Memorystore | 短期 cache、job heartbeat、distributed lock、rate limit | 永久狀態、不可重建資料 |
| Search Index | Listing search、Comparable search、Audit full-text | 權威資料來源 |
| MLflow / Model Registry | experiment、model version、artifact metadata | 業務 transaction |

## 3. Logical Schema 分區

### 3.1 Cloud SQL Schemas

| Schema | 用途 |
|---|---|
| `core` | tenant、brand、store、machine、user、role、scope |
| `workflow` | job、task、approval、workflow instance、state transition |
| `expansion` | heatzone metadata、listing、candidate site、site score run summary |
| `operations` | alert、intervention、action、observation window、operational task |
| `pricing` | price policy、price action、safe action set、approval |
| `marketing` | campaign、ad action、control group metadata |
| `asset` | valuation run、data room metadata、asset register reference |
| `network` | scenario、network plan、solver run summary |
| `learning` | feature contract、label registry metadata、model release、drift status |
| `audit` | audit event index、decision log index、access log index |
| `geo` | geography metadata、h3 index、administrative boundary reference |

### 3.2 BigQuery Datasets

| Dataset | 用途 |
|---|---|
| `raw` | 來源原始資料與 landing snapshot |
| `canonical` | Source-to-Canonical 後的標準事實與主檔 |
| `feature_marts` | 可重建的特徵表 |
| `model_ready` | 模型正式讀取 View 或 table |
| `predictions` | 模型輸出、prediction log、score run details |
| `decisions` | decision/intervention/approval/outcome 分析表 |
| `audit` | 稽核、查核、匯出與 lineage |
| `ml_monitoring` | backtest、drift、model metrics、data quality history |
| `sandbox` | dev/staging 分析，不可連到 production workflow |

### 3.3 Cloud Storage Buckets

| Bucket | 用途 | 保護 |
|---|---|---|
| `odp-raw-snapshots-{env}` | 外部與上游原始檔 | versioning、retention、source metadata |
| `odp-model-artifacts-{env}` | 模型、encoder、feature config、explainers | versioning、restricted access |
| `odp-reports-{env}` | SiteScore、AVM、NetPlan、Audit 報告 | signed URL / API-gated |
| `odp-dataroom-{env}` | Data Room files | strong access control、watermark optional |
| `odp-exports-{env}` | CSV/JSON export | expiration lifecycle、download audit |
| `odp-backups-{env}` | DB export、manual backup | restricted SRE access |

## 4. Table 類型

| 類型 | 說明 | 例子 |
|---|---|---|
| Master | 相對穩定主檔，需 SCD 或歷史版本 | store、machine、brand、user |
| Fact | 高量事實資料 | transaction、machine_cycle、store_daily_fact |
| Event | 不可變事件 | source_ingested_event、machine_status_event、audit_event |
| Run | 一次模型、批次、報告或 Solver 執行 | sitescore_run、forecast_run、solver_run |
| Output | 模型、決策或報告輸出 | prediction_output、valuation_output |
| State | 可變 workflow 狀態 | job、approval、task、intervention_state |
| Registry | 版本與契約 | feature_contract、label_definition、model_version |
| Bridge | mapping 與對照 | identity_map、candidate_listing_match |
| Snapshot | point-in-time 資料 | dataset_snapshot、external_source_snapshot |

## 5. 核心資料表群

### 5.1 Core Master

| Table | Store | Grain | 說明 |
|---|---|---|---|
| `core.tenants` | Cloud SQL | tenant | 租戶／組織 |
| `core.brands` | Cloud SQL | brand | ODay、洗多屋、外部品牌 |
| `core.stores` | Cloud SQL | store | 門市主檔 |
| `core.store_versions` | Cloud SQL/BQ | store × effective period | 門市 SCD2 |
| `core.machines` | Cloud SQL | machine | 機台主檔 |
| `core.machine_versions` | Cloud SQL/BQ | machine × effective period | 機台配置歷史 |
| `core.users` | Cloud SQL | user | 使用者 |
| `core.role_assignments` | Cloud SQL | user × scope × role | 權限指派 |

### 5.2 Expansion

| Table | Store | Grain | 說明 |
|---|---|---|---|
| `geo.h3_cells` | Cloud SQL/PostGIS | h3 | H3 metadata |
| `model_ready.geo_grid_view` | BigQuery | h3 × snapshot | HeatZone input |
| `expansion.heatzone_scores` | Cloud SQL/BQ | h3 × run | 熱區分數摘要與詳情 |
| `expansion.listings` | Cloud SQL | listing | 物件 |
| `expansion.candidate_sites` | Cloud SQL | candidate site | 候選點 |
| `expansion.site_score_runs` | Cloud SQL | run | SiteScore run summary |
| `predictions.site_score_outputs` | BigQuery | run × horizon × quantile | M1/M3/M6/M12 P10/P50/P90 |
| `decisions.site_decisions` | Cloud SQL/BQ | decision | GO/WAIT/REJECT 與人工核准 |

### 5.3 Operations and Intervention

| Table | Store | Grain | 說明 |
|---|---|---|---|
| `canonical.transactions` | BigQuery | transaction | 交易事實 |
| `canonical.machine_cycles` | BigQuery | machine cycle | 機台使用 cycle |
| `canonical.work_orders` | BigQuery/Cloud SQL | work order | 維修工單 |
| `model_ready.store_machine_timeseries_view` | BigQuery | store/machine × time | Forecast input |
| `operations.forecast_runs` | Cloud SQL | run | forecast run summary |
| `predictions.forecast_outputs` | BigQuery | store × horizon × quantile | 預測輸出 |
| `operations.alerts` | Cloud SQL | alert | 四燈與根因證據 |
| `operations.interventions` | Cloud SQL | intervention | 干預主檔 |
| `operations.intervention_actions` | Cloud SQL | action | 價格／廣告／維修等 action |
| `decisions.intervention_outcomes` | BigQuery | intervention × outcome | 觀察結果 |

### 5.4 Asset and Network

| Table | Store | Grain | 說明 |
|---|---|---|---|
| `asset.valuation_runs` | Cloud SQL | run | 估值 run |
| `predictions.valuation_outputs` | BigQuery | store × valuation date | P10/P50/P90 |
| `asset.data_rooms` | Cloud SQL | data room | 資料室 metadata |
| `network.network_plans` | Cloud SQL | plan | 店網方案 |
| `network.network_plan_actions` | Cloud SQL | plan × action | OPEN/KEEP/MOVE/EXIT |
| `network.solver_runs` | Cloud SQL | run | 求解資訊 |
| `predictions.network_plan_outputs` | BigQuery | plan × scenario | 方案評估 |

## 6. ID 與 Identity Mapping

| 規範 | 要求 |
|---|---|
| 平台 ID | ODay Plus 內部使用穩定 UUID 或等效 ID |
| Source ID | 保存所有來源 `source_system` + `source_record_id` |
| Mapping | `identity_map` 必須保存 entity type、source、confidence、effective time |
| 不可直接用上游 ID | 上游 ID 可能改名、重編、重複或跨品牌不一致 |
| Merge/Split | 門市／機台合併或拆分必須留歷史 lineage |

## 7. 時間與版本

每個 critical table 必須支援至少以下欄位或等效語意：

| 欄位 | 用途 |
|---|---|
| `event_time` | 事件實際發生時間 |
| `observation_time` | 系統觀察／收到時間 |
| `decision_time` | 做決策時間 |
| `outcome_time` | 結果觀察時間 |
| `label_maturity_time` | 可作訓練標籤時間 |
| `ingested_at` | ODay Plus ingestion 時間 |
| `source_snapshot_id` | 來源快照 |
| `dataset_snapshot_id` | 訓練／推論資料快照 |
| `model_version` | 相關模型版本 |
| `policy_version` | 相關決策政策版本 |

## 8. Partition、Cluster 與 Index

| 資料 | Partition | Cluster/Index |
|---|---|---|
| transactions | `event_date` | `store_id`、`machine_id`、`brand_id` |
| machine_cycles | `event_date` | `machine_id`、`store_id` |
| forecasts | `prediction_origin_date` | `store_id`、`model_version` |
| interventions | `start_date` | `store_id`、`intervention_type` |
| audit events | `event_date` | `actor_id`、`entity_type`、`entity_id` |
| listing | n/a in SQL | PostGIS geom index、status、source |
| h3 cells | n/a in SQL | H3 index、geom index |
| decision log | `decision_date` in BQ | `decision_type`、`actor_id`、`entity_id` |

## 9. Retention 與 Archive

| 類型 | Retention | Archive |
|---|---|---|
| Raw source snapshots | 至少 3 年或依授權 | GCS lifecycle archive |
| Canonical facts | 至少 5 年 | BigQuery long-term storage |
| Audit / Decision | 至少 7 年或依補助查核要求 | 不可未授權刪除 |
| Reports | 依業務與法務核准 | GCS lifecycle + retention policy |
| Model artifacts | 保留所有 production release 與最近 N 個候選 | GCS versioning |
| PII export | 最短必要期間 | 過期自動刪除 |

## 10. PII 與敏感資料

| 資料 | 分級 | 控制 |
|---|---|---|
| 會員姓名、電話、Email | Sensitive PII | 遮罩、欄位權限、加密、匯出審批 |
| 交易資料 | Sensitive business | tenant/brand/store scope |
| 門市營收與毛利 | Confidential | 財務與授權營運角色可見 |
| 估值與交易 | Highly confidential | Data Room 權限、download audit |
| 模型特徵 | Internal/Confidential | 視是否含 PII 或商業敏感 |
| Audit logs | Restricted | 安全／稽核角色查閱 |

## 11. Migration 與 Schema Governance

1. Cloud SQL 變更必須使用 Alembic 或等效 migration。
2. BigQuery transformation 必須使用 dbt，並提交 schema tests。
3. Breaking schema change 必須產生新版 View 或 migration plan。
4. Production migration 必須先在 staging dry-run。
5. 回滾策略需在 PR 中說明。
6. 表與欄位必須有 owner 與 data classification。
7. 所有 Model-ready Views 必須有 freshness 與 row count monitor。

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD05-001` | Cloud SQL、BigQuery、GCS、Redis、Search 的責任分工清楚 | Data Architecture Review |
| `ODP-AC-SD05-002` | 所有 critical table 有時間語意、source lineage、audit 欄位設計 | Data Contract Review |
| `ODP-AC-SD05-003` | Model-ready Views 不直接依賴 Raw table 給 production model | dbt Lineage Review |
| `ODP-AC-SD05-004` | PII、估值、營收、Audit 資料有資料分級與權限策略 | Security Review |
| `ODP-AC-SD05-005` | Migration、backup、retention、archive 策略已定義 | OPS Review |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
