---
doc_id: ODP-SD-02
title: "GCP 實體部署架構"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Cloud Architect / Platform Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus GCP 實體部署架構

## 1. 文件目的

本文件定義 ODay Plus 在 Google Cloud Platform 上的實體部署架構，包括 Project、Network、Compute、Data、ML、Messaging、Security、Observability、Environment、IAM 與 DR 設計。此文件將第 2 批 NFR 與第 3 批資料契約轉為可由 Terraform 與 CI/CD 實作的雲端基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 部署原則

1. **正式環境以 GCP 為主**：BigQuery、Cloud SQL/PostGIS、Cloud Storage、Pub/Sub、Cloud Run、Vertex AI、Artifact Registry、Secret Manager、Cloud Logging/Monitoring 為基礎。
2. **Cloud Run 承載無狀態服務與可容器化 Job**：同步 API 用 Cloud Run Services；批次、評分、報告與部分 Solver 用 Cloud Run Jobs。
3. **IoT 不是本平台直接責任**：IoT 團隊可用既有裝置平台、MQTT broker、Webhook、Pub/Sub 或資料同步輸出；ODay Plus 只要求交換契約，不把 IoT Core 當作必備直接依賴。
4. **資料平面與控制平面分離**：資料存放、模型 Artifact、Workflow 狀態、Audit Log、API Runtime 不混用同一權限。
5. **多環境隔離**：Dev、Staging、Production 使用不同 Project 或至少不同 Dataset、Service Account、Secret、VPC 控制。
6. **最小權限與可追溯**：所有服務使用專屬 Service Account，禁止共用萬用權限。

## 3. Project 與環境結構

### 3.1 建議 Project

| Project | 用途 | 說明 |
|---|---|---|
| `oday-plus-dev` | 開發與整合測試 | 可使用低成本資源，資料應合成或去識別 |
| `oday-plus-stg` | UAT、模型候選、演練 | 與 Production 架構相同但規模較小 |
| `oday-plus-prod` | 正式服務 | 嚴格 IAM、資料保護、稽核與 DR |
| `oday-plus-shared` | Artifact Registry、共用監控、CI/CD 或 DNS | 視組織管理方式可拆或合併 |

若公司既有 GCP Organization 已有標準 Folder，應納入既有治理；若無，至少建立 `dev`、`staging`、`production` 三組隔離。

### 3.2 Region

| 類型 | 建議 | 備註 |
|---|---|---|
| Primary region | `asia-east1` 或企業指定台灣／亞太區域 | 需依資料主權、延遲、服務可用性與成本確認 |
| DR / backup | 與 primary 不同 region 或 multi-region bucket | 依 RPO/RTO 與成本設定 |
| BigQuery location | 需固定且不可輕易變更 | 需在 ADR 中決定 |

## 4. 網路架構

```mermaid
flowchart TB
  Internet[Internet / Users] --> LB[HTTPS Load Balancer]
  LB --> Armor[Cloud Armor]
  Armor --> IAP[IAP / OIDC Gateway]
  IAP --> RunWeb[Cloud Run opsboard-web]
  IAP --> RunAPI[Cloud Run core-api]

  subgraph VPC[Private VPC]
    SQL[(Cloud SQL Private IP)]
    Redis[(Memorystore Redis)]
    PrivateRun[Cloud Run VPC Access]
  end

  RunAPI --> PrivateRun
  PrivateRun --> SQL
  PrivateRun --> Redis
  RunAPI --> PubSub[Pub/Sub]
  RunAPI --> BQ[BigQuery]
  RunAPI --> GCS[Cloud Storage]
  RunAPI --> Secret[Secret Manager]
```

### 4.1 網路控制

| 控制項 | 設計 |
|---|---|
| Ingress | Production API 預設僅經 Load Balancer／IAP／API Gateway 進入 |
| Egress | 需要固定外連 IP 的 Connector 透過 NAT 或 Serverless VPC Access |
| Private DB | Cloud SQL 使用 Private IP，不對 Internet 開放 |
| VPC-SC | PII、模型資料與 BigQuery 高敏感資料可評估 VPC Service Controls |
| Cloud Armor | 對公開入口套用 WAF、Rate Limit、IP allow/deny、DDoS 防護 |
| TLS | 全部外部通訊使用 HTTPS/TLS；服務間使用 IAM/OIDC 驗證 |

## 5. Compute Mapping

| Workload | GCP 服務 | 第一版部署單元 | 備註 |
|---|---|---|---|
| Frontend | Cloud Run 或 Cloud Storage + CDN | `opsboard-web` | 若需 SSR/API proxy，採 Cloud Run；純靜態可用 GCS/CDN |
| API | Cloud Run Services | `core-api` | FastAPI，含 domain routers |
| Long-running workers | Cloud Run Jobs / Worker pools | `worker-*` | 依 queue 或 job type 執行 |
| Scheduled batch | Cloud Scheduler + Cloud Run Jobs / Workflows | `scheduler`、`batch-jobs` | 地理特徵、每日 forecast、資料品質 |
| Workflow | Workflows 或 Temporal on GKE/Cloud Run | `workflow-service` | 複雜人工核准與重試可用 Temporal |
| Training | Vertex AI Training / Custom Jobs | `training-*` | MLflow tracking 與 Model Registry 串接 |
| Model serving | Vertex AI Endpoint / Cloud Run | `model-serving` | 高 QPS 或 GCP 管理模型用 Vertex AI；輕量 batch 用 Cloud Run |
| Solver | Cloud Run Jobs / GKE Autopilot | `netplan-solver`、`pricing-optimizer` | 長時間、多 CPU、大記憶體可評估 GKE |
| Report/Data Room | Cloud Run Jobs + GCS | `report-worker` | 產出 PDF/HTML/CSV/JSON |

## 6. Data Plane

| 資料類型 | 服務 | 用途 |
|---|---|---|
| Operational | Cloud SQL PostgreSQL + PostGIS | 主檔、工作流、核准、任務、Listing、Spatial metadata |
| Analytical | BigQuery | Raw、Canonical、Feature Mart、Model-ready Views、Audit 分析 |
| Object | Cloud Storage | Raw snapshots、model artifacts、reports、data room、exports |
| Cache/Lock | Memorystore Redis | API cache、短期鎖、job heartbeat、rate limiter |
| Search | OpenSearch/Elastic 或 BigQuery Search | Listing 搜尋、Comparable 檢索、Audit 搜尋 |
| Model Registry | MLflow + Vertex AI / GCS | Experiment、Model Version、Artifacts、Model Cards |

## 7. Pub/Sub 與 Eventing

| 類型 | 服務 | 規範 |
|---|---|---|
| Domain Events | Pub/Sub topics | 使用事件 envelope、schema version、correlation_id、idempotency_key |
| DLQ | Pub/Sub dead-letter topics | 每個 critical topic 必須有 DLQ 或等效 quarantine |
| Scheduling | Cloud Scheduler | 只負責觸發，不直接承載業務邏輯 |
| Event routing | Eventarc / Pub/Sub push / pull | 視 Cloud Run 觸發方式選擇 |

## 8. ML/MLOps 部署

```mermaid
flowchart LR
  BQ[BigQuery Model-ready Views] --> TRAIN[Vertex AI Training]
  TRAIN --> ART[GCS Artifacts]
  TRAIN --> MLF[MLflow Tracking]
  MLF --> REG[Model Registry]
  REG --> RELEASE[Release Controller]
  RELEASE --> SHADOW[Shadow / Canary]
  SHADOW --> SERVE[Vertex AI Endpoint / Cloud Run Serving]
  SERVE --> LOG[Prediction Log]
  LOG --> MON[Drift / Performance Monitor]
```

### 8.1 模型部署策略

| 模型類型 | 推薦 serving | 備註 |
|---|---|---|
| SiteScore | Batch + On-demand API | 先批次評分候選點，必要時 API 觸發單點重算 |
| ForecastOps | Daily batch scoring | 前端查已完成結果，不同步等模型 |
| PriceOps | Batch simulation + approval | 高風險方案需人工核准 |
| AdLift | Campaign batch evaluation | 非即時；需 Observation Window 成熟 |
| AVM | On-demand async report | 回傳 job_id，完成後推通知 |
| NetPlan | Solver job | 長任務，需可取消、可重試、可解釋 |

## 9. Secret、Config 與 Artifact

| 類型 | 儲存位置 | 規範 |
|---|---|---|
| Secret | Secret Manager | 禁止寫入 repo、Docker image、環境檔 |
| Runtime config | env vars + config tables | 需有環境區分與版本 |
| Feature flag | DB/Config service | 高階模型與高風險功能以 flag 控制 |
| Model artifacts | GCS + MLflow | 不打包進 API image |
| Reports | GCS | 短期 signed URL 或經 API 權限控管下載 |
| Data export | GCS export bucket | 需權限、審批、保留期限 |

## 10. IAM 與 Service Account

| Service Account | 權限範圍 |
|---|---|
| `sa-opsboard-web` | 只呼叫 BFF/API，不直接讀資料庫 |
| `sa-core-api` | Cloud SQL、Pub/Sub publish、有限 BigQuery query、GCS signed URL |
| `sa-integration-worker` | Raw bucket、BigQuery raw/canonical write、Pub/Sub publish |
| `sa-geo-worker` | BigQuery geo dataset、GCS geo snapshots、PostGIS |
| `sa-model-training` | BigQuery model-ready read、GCS artifacts write、MLflow write |
| `sa-model-serving` | Model artifacts read、prediction log write |
| `sa-solver-job` | network_plan_view read、scenario output write |
| `sa-report-worker` | report data read、GCS report write |
| `sa-cicd-deployer` | 最小部署權限，不可讀 Production PII |

## 11. 環境 Promotion

```text
local → dev → staging → production
```

| Gate | 必須通過 |
|---|---|
| Dev deploy | Unit test、lint、container build、local migration |
| Staging deploy | Contract test、integration test、migration dry-run、seed data smoke test |
| Production candidate | Security scan、approval、rollback plan、release notes、DB migration plan |
| Production release | Canary/gradual rollout、monitoring watch、audit record |

## 12. DR、Backup 與 RPO/RTO

| 資源 | Backup | RPO | RTO | 備註 |
|---|---|---|---|---|
| Cloud SQL | automated backup + PITR | ≤ 1h 或依核准 SLA | ≤ 4h 或依 SLA | Production 必須定期 restore drill |
| BigQuery | snapshot/export/partition retention | 依資料集 | 依資料集 | 重要表保留 snapshot |
| GCS | versioning + retention + lifecycle | 依 bucket | 依 bucket | Reports/DataRoom/Artifacts 分 bucket |
| Pub/Sub | retention + DLQ | 依 topic | 依 replay 能力 | Critical events 需可 replay |
| Model artifacts | versioned GCS | 0 for released model artifact | < 1h | Model rollback 需演練 |

## 13. Cloud IoT 與 Connected Devices 邊界

ODay Plus 不直接要求 IoT 團隊使用特定 Google Cloud IoT 產品。平台只要求：

1. 上游可提供交易、設備狀態、使用 cycle、故障、遠端控制結果、會員與支付資料。
2. 每筆資料需有穩定主鍵、事件時間、觀察時間、來源 ID 與重送語意。
3. 若上游以 MQTT broker、第三方 IoT platform、Webhook、Pub/Sub 或批次檔案輸出，Integration Layer 皆應透過 adapter 接入。
4. ODay Plus 對設備控制只透過核准後的 command/event/API 契約，不直接繞過上游控制系統。

## 14. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD02-001` | Dev/Staging/Production 的 Project、Service Account、Dataset、Bucket 命名與隔離策略完成 | IaC Review |
| `ODP-AC-SD02-002` | API、Worker、Job、ML、Solver 均有對應 GCP runtime | Architecture Review |
| `ODP-AC-SD02-003` | Cloud SQL、BigQuery、GCS、Pub/Sub、Redis、Secret Manager 權限最小化 | Security Review |
| `ODP-AC-SD02-004` | 至少一條 E2E 流程可跨 Cloud Run、Pub/Sub、BigQuery、GCS、Audit Log 追蹤 | E2E Smoke Test |
| `ODP-AC-SD02-005` | Backup/Restore、Model Rollback、Job Retry、DLQ replay 有演練計畫 | OPS Review |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
