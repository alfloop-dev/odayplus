---
doc_id: ODP-SD-01
title: "系統總體架構設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Architecture Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus 系統總體架構設計

## 1. 文件目的

本文件定義 ODay Plus 全平台的系統總體架構。範圍涵蓋 Integration Layer、External Data Platform、HeatZone Radar、Listing Pipeline、SiteScore、ForecastOps、InterventionOps、PriceOps、AdLift、DealRoomAVM、NetPlan、Learning Hub、OpsBoard，以及跨模組共用的 API、Event、Workflow、Data、Model、Solver、Security、Observability 與 Audit 能力。

本文件不設計單一模組的演算法細節；模組內部設計由第 5 批模組詳細設計文件承接。本文件的重點是定義平台級邊界、責任分層、服務交互、資料流、事件流與部署原則。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 架構目標

ODay Plus 的目標不是單一報表系統，而是完整的決策閉環平台：

```text
展店發現
→ 物件蒐集
→ 店址評估
→ 開店核准
→ 開店後實績驗證
→ 營運預測與四燈預警
→ 干預建議、核准與執行
→ 干預效果驗證
→ 資產估值
→ 店網重配
→ Feature／Label／Model／Decision 回訓治理
```

架構必須同時滿足：

1. **完整模組覆蓋**：不以 MVP 刪減最終範圍，所有模組必須在平台骨架中有位置。
2. **上游解耦**：IoT 與內部資料底座是上游資料供應者，ODay Plus 透過 Integration Layer 與 Canonical Model 消化上游格式。
3. **有限服務數量**：功能元件不等於微服務；第一版以模組化單體與少量可部署服務為主，符合資源、發布頻率、執行型態或責任邊界時再拆分。
4. **Prediction／Decision／Execution 分離**：模型輸出不得直接等同於業務決策。
5. **Batch／Sync／Async 並存**：長時間地理運算、訓練、評分、報告與 Solver 必須非同步化。
6. **所有結果可追溯**：預測、建議、核准、執行、結果與回訓必須保留版本、時間、責任人與來源。
7. **GCP + OSS 混合設計**：使用 GCP 作正式雲端底座，搭配 FastAPI、React/Next.js、dbt Core、MLflow、H3、GeoPandas、OR-Tools、Evidently、OpenTelemetry 等 OSS 能力。

## 3. 架構分層

```mermaid
flowchart TB
  subgraph UX[Experience Layer]
    WEB[OpsBoard Web]
    MAP[Map Workspace]
    REPORT[Report / Data Room]
  end

  subgraph API[API / BFF Layer]
    BFF[OpsBoard BFF]
    CORE[Core API]
    DOMAINAPI[Domain APIs]
    OPENAPI[OpenAPI Contracts]
  end

  subgraph DOMAIN[Domain Services]
    INT[Integration]
    EXT[External Data]
    HZ[HeatZone]
    LST[Listing]
    SITE[SiteScore]
    FCT[ForecastOps]
    INTV[InterventionOps]
    PRICE[PriceOps]
    AD[AdLift]
    AVM[DealRoomAVM]
    NET[NetPlan]
    LH[Learning Hub]
  end

  subgraph ASYNC[Workflow / Event / Job Layer]
    WF[Workflow Engine]
    BUS[Event Bus]
    JOB[Job Controller]
    WORKER[Workers]
    SCHED[Scheduler]
  end

  subgraph DATA[Data / Storage Layer]
    SQL[(Cloud SQL / PostGIS)]
    BQ[(BigQuery)]
    GCS[(Cloud Storage)]
    REDIS[(Redis)]
    SEARCH[(Search Index)]
  end

  subgraph ML[ML / OR Layer]
    TRAIN[Training Jobs]
    SERVE[Model Serving]
    MLR[MLflow / Model Registry]
    SOLVER[OR Solver]
    DQ[Data Quality]
  end

  subgraph GOV[Governance / Security / Observability]
    IAM[Identity / IAM]
    AUDIT[Audit Trail]
    OBS[Logs / Metrics / Traces]
    POLICY[Policy / Approval]
  end

  WEB --> BFF
  MAP --> BFF
  REPORT --> BFF
  BFF --> CORE
  CORE --> DOMAINAPI
  DOMAINAPI --> DOMAIN
  DOMAIN --> ASYNC
  ASYNC --> DATA
  DOMAIN --> DATA
  DOMAIN --> ML
  ML --> DATA
  DOMAIN --> GOV
  ASYNC --> GOV
  DATA --> GOV
```

## 4. 平台 Context

| 外部／上游 | 關係 | ODay Plus 接入方式 | 備註 |
|---|---|---|---|
| IoT／內部資料底座 | 上游資料供應者 | Batch／CDC／API／Pub/Sub／檔案 | 不要求上游理解 ODay Plus 模型；透過 Integration Layer 轉換 |
| 門市／機台／交易／會員系統 | 上游主檔與事實資料 | Canonical Mapping | 需保留 source id、event time、observation time |
| 外部地理與商圈資料 | 外部資料來源 | Connector／Snapshot／Data Quality | 包含人口、POI、路網、租金、競店、天氣、學期、重大建設 |
| 廣告平台 | 外部活動與成效來源 | API／檔案／手動匯入 | AdLift 需要 campaign、spend、period、channel 與 attribution 原始欄位 |
| 通知渠道 | 外部執行渠道 | Email／LINE／Webhook | 用於任務、警示、核准與結果回報 |
| GCP 基礎設施 | 正式部署底座 | Cloud Run、BigQuery、Cloud SQL、GCS、Pub/Sub、Vertex AI、IAM、Cloud Logging | 由 `ODP-SD-02` 詳述 |

## 5. 領域與主要責任

| 領域 | 主要責任 | 不負責 |
|---|---|---|
| Integration Layer | 消化上游資料、外部資料、Identity Mapping、Canonical Model、Data Quality、重送與 Backfill | 不承擔上游 IoT 實作責任 |
| External Data Platform | 外部資料 Connector、Geocode、H3、路網、POI、租金、競店、天氣與 Snapshot | 不直接做 GO/REJECT 決策 |
| HeatZone Radar | 區域熱度、需求缺口、展店優先序、需求吸收狀態 | 不評估單一出租物件是否可開店 |
| Listing Pipeline | 出租物件取得、解析、去重、Hard Rules、工作台 | 不預測營收路徑 |
| SiteScore | 候選物件營收路徑、回本期、Feasibility、GO/WAIT/REJECT 建議 | 不自動核准開店 |
| ForecastOps | 成長軌跡、四燈、異常與根因證據 | 不直接執行價格、廣告、維修或退店 |
| InterventionOps | 干預生命週期、Eligibility、Conflict、Approval、Execution、Observation、Outcome | 不自行估計價格彈性或廣告增量 |
| PriceOps | 價格彈性、安全價格集合、需求模擬、受限制最佳化 | 不跳過人工核准執行高風險價格 |
| AdLift | 對照組、DiD、增量營收、增量毛利、iROMI | 不將 ROAS 當唯一成效指標 |
| DealRoomAVM | 正常化毛利、三鏡頭估值、資料室、價格區間 | 不決定是否強制出售 |
| NetPlan | OPEN/KEEP/IMPROVE/MOVE/EXIT 店網方案、Solver、Alternative Plan | 不任意放寬硬限制 |
| Learning Hub | Feature、Label、Dataset、Model、Release、Drift、Backtest、Rollback | 不取代業務最終核准 |
| OpsBoard | 工作台、核准、任務、稽核、治理視覺化 | 不把模型邏輯寫在前端 |

## 6. 主要端到端流程

### 6.1 展店決策流

```mermaid
sequenceDiagram
  participant Ext as External Data
  participant Int as Integration
  participant HZ as HeatZone
  participant L as Listing
  participant S as SiteScore
  participant O as OpsBoard
  participant A as Approval
  participant F as ForecastOps

  Ext->>Int: source snapshot / geocode / POI / rent / competitor
  Int->>HZ: geo_grid_view
  HZ->>O: heatzone ranks and confidence
  O->>L: assign area and listing search
  L->>S: candidate_site_view
  S->>O: revenue path, payback, risks, recommendation
  O->>A: human approval request
  A->>O: approved / wait / reject / override
  O->>F: approved site baseline after opening
```

### 6.2 營運預警與干預流

```mermaid
sequenceDiagram
  participant IoT as IoT / Internal Data
  participant Int as Integration
  participant F as ForecastOps
  participant O as OpsBoard
  participant I as InterventionOps
  participant P as PriceOps / AdLift / Ops Actions
  participant LH as Learning Hub

  IoT->>Int: transaction / machine / cost / cs / work order
  Int->>F: store_machine_timeseries_view
  F->>O: forecast, trajectory, four-light evidence
  O->>I: create intervention candidate
  I->>P: price/ad/promotion/maintenance action build
  P->>I: action plan and constraints
  I->>O: approval workflow
  O->>I: approved execution
  I->>LH: decision/intervention log
  I->>LH: outcome and label after observation window
```

### 6.3 資產與店網重配流

```mermaid
sequenceDiagram
  participant F as ForecastOps
  participant I as InterventionOps
  participant A as AVM
  participant N as NetPlan
  participant O as OpsBoard
  participant LH as Learning Hub

  F->>A: future gross margin and risk evidence
  I->>A: normalized intervention history
  A->>O: valuation card and data room
  A->>N: valuation_view
  N->>O: alternative plans and solver explanation
  O->>N: management approval
  N->>LH: decision and 90/180/365 outcome plan
```

## 7. 主要資料流

```text
Raw Sources
→ Landing / Raw Snapshot
→ Source-to-Canonical Mapping
→ Canonical Entities / Events
→ Data Quality Gate
→ Model-ready Views
→ Prediction / Optimization Output
→ Decision / Approval / Execution
→ Outcome / Label Registry
→ Dataset Snapshot / Model Retraining
```

### 7.1 Raw 不得直接給模型

模型、Solver、前端報表不得直接依賴上游 Raw Table。任何例外必須有 ADR，且必須定義：欄位語意、時間語意、資料品質、覆蓋率、來源授權、版本與回退方式。

### 7.2 Decision Log 是一級資料

所有模型建議與人工決策必須進入 Decision Log。Decision Log 不是單純操作紀錄，而是 Learning Hub、Audit、Outcome 分析與補助查核的核心資料。

## 8. 部署邏輯總覽

| 層 | 第一版建議部署單元 | 後續可拆條件 |
|---|---|---|
| Web | `opsboard-web` | 多入口或品牌入口差異化 |
| API | `core-api` + domain route modules | 單一 domain API 負載、權限、發布頻率或團隊獨立 |
| Worker | `worker` + named queues | Geo、Solver、Training 等資源差異變大 |
| Scheduler | `scheduler`／Workflow | 流程複雜需 Temporal／Camunda 管理 |
| ML Jobs | training/scoring jobs | GPU、長訓練或獨立模型發布週期 |
| Solver | solver jobs | CP-SAT、Pyomo、長求解或多情境排程 |

## 9. 關鍵架構決策

| ADR 候選 | 決策方向 | 理由 |
|---|---|---|
| `ADR-PLAT-001` | 採模組化平台，不採一框一微服務 | 降低初期維運、版本與網路複雜度 |
| `ADR-PLAT-002` | 模型讀 Model-ready Views，不讀 Raw | 避免語意混亂與資料洩漏 |
| `ADR-PLAT-003` | 長任務以 Job/Workflow 非同步化 | 避免 API 超時與難以重試 |
| `ADR-PLAT-004` | Prediction、Decision、Approval、Execution、Outcome 分表與分事件 | 滿足治理、稽核與回訓 |
| `ADR-PLAT-005` | IoT 上游只做交換契約，不共用程式碼庫 | 降低組織與技術耦合 |
| `ADR-PLAT-006` | GCP 正式部署、OSS 作應用層與 MLOps 能力 | 兼顧補助查核、雲端承諾與可攜性 |

## 10. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD01-001` | 架構圖能覆蓋全部 11 個業務模組與 Integration Layer | Architecture Review |
| `ODP-AC-SD01-002` | 每個模組均有明確輸入、輸出、責任邊界與共用治理依賴 | Design Review |
| `ODP-AC-SD01-003` | 至少三條端到端流程能從資料、模型、決策、核准、執行追到 Outcome | E2E Design Trace |
| `ODP-AC-SD01-004` | API、Event、Workflow、Data、ML、Audit 的後續 SD 文件可回溯本架構 | Document Trace |
| `ODP-AC-SD01-005` | 架構決策中的高風險項目均產生 ADR 或待決 ADR | Governance Review |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
