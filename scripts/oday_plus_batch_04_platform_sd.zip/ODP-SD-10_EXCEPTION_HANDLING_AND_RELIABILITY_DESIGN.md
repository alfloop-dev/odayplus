---
doc_id: ODP-SD-10
title: "例外處理與可靠性設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "SRE Owner / Backend Lead"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus 例外處理與可靠性設計

## 1. 文件目的

本文件定義 ODay Plus 的錯誤分類、重試、冪等、降級、補償、資料延遲、模型不可用、Solver 無解、外部來源中斷、備援、RPO/RTO 與可靠性策略。它是 Runbook、Incident、測試與 SLO 的設計基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. Reliability 原則

1. 使用者 API 不同步等待長任務。
2. 所有副作用動作必須可冪等或可補償。
3. Critical batch 必須可重跑，且結果可由 snapshot 重現。
4. 資料 stale 時系統應顯示 freshness，不得假裝最新。
5. 模型不可用時可降級到已發布上一版或已完成結果。
6. Solver 無可行解時輸出診斷，不得自動放寬硬限制。
7. 任何手動修復與 replay 必須 audit。

## 3. 錯誤分類

| Error Class | 例子 | Retry | User Message | Owner |
|---|---|---|---|---|
| Validation | 欄位缺漏、格式錯 | no | 請修正輸入 | API Owner |
| Authorization | scope 不足 | no | 無權限 | Security Owner |
| State Conflict | 狀態不可轉換 | no/manual | 目前狀態不可執行 | Workflow Owner |
| Dependency Transient | 外部 API timeout | yes | 稍後重試 | Integration Owner |
| Dependency Permanent | 外部資料授權失效 | no/manual | 資料來源不可用 | Data Owner |
| Data Quality | fresh/coverage/validity fail | no/manual override | 資料品質不足 | Data Owner |
| Model Unavailable | model endpoint error | yes/fallback | 模型暫不可用 | Model Owner |
| Model Invalid | validation failed/drift | no | 模型未通過驗證 | Model Owner |
| Solver Infeasible | hard constraints 無解 | no | 無可行方案，請查看限制 | OR Owner |
| Infrastructure | DB/queue/storage outage | yes/failover | 系統暫時異常 | SRE |
| Security | suspicious access | no/escalate | 操作已阻擋 | Security Owner |

## 4. Retry Policy

| Workload | Retry Policy | 注意 |
|---|---|---|
| API read | short retry client-side only for 503/timeout | 不重試 validation/403 |
| API mutation | server-side idempotency; client may retry same key | 避免重複建立 |
| Pub/Sub consumer | exponential backoff + max delivery + DLQ | Consumer 必須去重 |
| External connector | provider-specific backoff + rate limit | 保存 partial result |
| Batch job | task-level retry | 避免整批重跑造成重複 |
| Training job | retry infra error only | validation failed 不重試 |
| Solver job | retry infra error only | infeasible 不重試 |
| Report generation | retry render/storage transient | final output idempotent |

## 5. Idempotency 設計

| 動作 | Idempotency Key |
|---|---|
| Listing import | `source_system + source_record_id + source_snapshot_id` |
| Geocode | `normalized_address + provider + version` |
| SiteScore request | `candidate_site_id + feature_snapshot_time + model_alias + requested_by` |
| Approval | `approval_id + actor_id + decision_value` |
| Intervention execution | `intervention_id + action_id + execution_window` |
| Price apply | `price_action_id + target_store_id + effective_from` |
| Ad campaign start | `campaign_id + channel + start_at` |
| AVM report | `store_id + valuation_date + model_version` |
| NetPlan solve | `scenario_set_id + constraints_version + solver_version` |
| Model promotion | `model_id + version + target_alias` |

## 6. 降級策略

| 故障 | 降級 |
|---|---|
| HeatZone batch 未完成 | 顯示上一版分數與 freshness；禁止標示為最新 |
| Listing geocoder 故障 | 物件進入 pending_geocode；允許人工補座標 |
| SiteScore model unavailable | 回傳 job failed/retryable；可使用上一版 model alias 重試 |
| Forecast daily failed | 顯示上一日 forecast；警示 freshness；阻擋高風險自動建議 |
| Data Quality fail | 阻擋相關模型評分或 release；允許經核准 override |
| Price optimizer infeasible | 顯示 binding constraints，不產生價格方案 |
| AdLift evidence insufficient | 輸出 evidence insufficient，不宣稱因果 |
| AVM data missing | 降低 confidence 或要求財務補資料 |
| NetPlan infeasible | 產生 infeasibility report，不放寬硬限制 |
| OpsBoard partial outage | 核心 API 可降級只讀；高風險操作暫停 |

## 7. Compensation 與 Rollback

| 流程 | 可補償動作 |
|---|---|
| Listing merge 錯誤 | unmerge 並重建候選點 lineage |
| SiteScore approval 錯誤 | decision rollback；保留原紀錄，不刪除 |
| Price action 已執行 | 建立 rollback price action；記錄生效時間 |
| Ad campaign 已啟動 | stop campaign；保留 exposure 期間供效果分析 |
| Maintenance task 錯派 | cancel/reassign task |
| Model promotion | 切回上一個 production alias |
| NetPlan approval | business decision rollback；不得刪除原方案 |

## 8. 資料延遲與 Staleness

每個 API 或前端視圖若依賴資料，必須能揭露：

| 欄位 | 說明 |
|---|---|
| `data_as_of` | 資料截至時間 |
| `source_freshness` | 各來源新鮮度 |
| `quality_status` | passed/warn/failed/overridden |
| `blocked_reason` | 若阻擋模型或決策 |
| `confidence` | 資料信心 |

## 9. Solver 無解處理

NetPlan 與 Pricing Optimizer 不可在無解時自動放寬硬限制。必須輸出：

1. Solver status。
2. infeasible constraints。
3. binding constraints。
4. minimal relaxation suggestions（僅建議，不自動採用）。
5. input scenario version。
6. solver version。
7. run time、time limit、gap。

## 10. RPO/RTO 與備援

| 服務／資料 | 目標 | 備註 |
|---|---|---|
| OpsBoard availability | 99.5% baseline；若商務 SLA 要求更高需 ADR | 對外 SLA 另由契約決定 |
| Cloud SQL RPO | ≤ 1 hour target | PITR / automated backup |
| Cloud SQL RTO | ≤ 4 hours target | 定期 restore drill |
| BigQuery critical data | 依 dataset snapshot | 避免誤刪；重要表 snapshot |
| Model serving rollback | < 1 hour | alias rollback |
| Pub/Sub DLQ replay | 依事件量與 runbook | Critical topic 必須演練 |
| Reports/Data Room | 可重建或 versioned GCS | 若需不可變則 retention lock |

## 11. Incident 分級

| Level | 定義 | 例子 |
|---|---|---|
| P1 | 全平台不可用、資料外洩、高風險錯誤決策已執行 | API 全掛、個資外洩、錯誤價格大規模上線 |
| P2 | 核心模組不可用或重要批次失敗 | Forecast daily failed、SiteScore 無法評分 |
| P3 | 單一來源、單一區域或部分功能異常 | geocoder provider timeout |
| P4 | 低影響 bug 或文件/報表問題 | UI 欄位顯示錯誤 |

P1/P2 必須指定 Incident Commander，並在結束後產生 Postmortem。

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD10-001` | API mutation 與事件 consumer 支援冪等 | Contract/Integration Test |
| `ODP-AC-SD10-002` | Critical worker 具 retry、DLQ、manual replay 設計 | OPS Test |
| `ODP-AC-SD10-003` | Data stale、model unavailable、solver infeasible 皆有明確降級或阻擋 | Scenario Test |
| `ODP-AC-SD10-004` | Model rollback、price rollback、decision rollback 分開設計 | Workflow Test |
| `ODP-AC-SD10-005` | RPO/RTO、backup restore、incident 分級與 postmortem 流程存在 | SRE Review |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
