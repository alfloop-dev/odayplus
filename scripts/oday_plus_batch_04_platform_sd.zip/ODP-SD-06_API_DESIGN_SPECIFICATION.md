---
doc_id: ODP-SD-06
title: "API 設計規格"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Backend Lead / API Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus API 設計規格

## 1. 文件目的

本文件定義 ODay Plus 全平台 REST API 的設計規範、資源命名、認證授權、錯誤格式、分頁查詢、冪等性、長任務模式、版本治理與主要 API Catalog。詳細 OpenAPI schema 由程式碼與 CI 自動產生，本文件是設計準則與驗收基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. API 設計原則

1. API 以資源與工作流狀態為中心，不暴露內部模型檔案或資料表。
2. 長任務必須使用 job pattern，不得同步阻塞使用者。
3. 所有會產生副作用的 API 必須支援 idempotency。
4. Prediction、Recommendation、Decision、Approval、Execution、Outcome 必須是不同資源或明確欄位。
5. API 必須回傳可追蹤 `correlation_id`、`request_id`，並寫入 Audit。
6. API schema 需可由 OpenAPI 生成前端 client。
7. 高風險操作必須檢查權限與 workflow 狀態，不只檢查角色。

## 3. URL 與版本

| 項目 | 規範 | 例子 |
|---|---|---|
| Base path | `/api/v1` | `/api/v1/site-scores` |
| Resource | kebab-case plural | `/network-plans` |
| Action | 子資源或明確 action path | `/site-scores/{id}/approve` |
| Internal API | `/internal/v1` | 僅服務間呼叫 |
| Admin API | `/admin/v1` | 僅系統管理員 |
| Deprecated | 回傳 `Deprecation` header | 需提供 sunset date |

## 4. 認證與授權

| 項目 | 規範 |
|---|---|
| Authentication | OIDC/JWT；Production 需整合企業 IdP 或 Keycloak/Identity Platform |
| Authorization | RBAC + ABAC；至少檢查 role、tenant、brand、region、store scope |
| Service-to-service | 使用 service account identity、audience-bound token 或 API gateway policy |
| High-risk approval | 需檢查 `approval_policy_id`、workflow state、actor separation |
| Impersonation | 必須留痕並限制 support/admin use case |

## 5. 共用 Header

| Header | 必要性 | 說明 |
|---|---|---|
| `Authorization` | MUST | Bearer token |
| `X-Correlation-Id` | SHOULD | 沒有則 API 產生 |
| `X-Idempotency-Key` | MUST for mutation | POST/PUT/PATCH/approve/execute |
| `X-Request-Source` | SHOULD | web/api/import/system |
| `X-Client-Version` | SHOULD | 前端版本 |
| `Accept-Language` | SHOULD | zh-TW 預設 |

## 6. Error Format

```json
{
  "error": {
    "code": "ODP_API_VALIDATION_ERROR",
    "message": "輸入資料未通過驗證。",
    "details": [
      {"field": "rent_monthly", "reason": "must be greater than 0"}
    ],
    "correlation_id": "01HY...",
    "retryable": false,
    "doc_url": "https://docs.internal/errors/ODP_API_VALIDATION_ERROR"
  }
}
```

### 6.1 HTTP 狀態

| Status | 用途 |
|---|---|
| 200 | 查詢或同步成功 |
| 201 | 建立資源成功 |
| 202 | 已接受長任務，回傳 job |
| 400 | validation error |
| 401 | unauthenticated |
| 403 | unauthorized or scope denied |
| 404 | resource not found or not visible |
| 409 | state conflict、idempotency conflict、duplicate |
| 422 | business rule failed |
| 429 | rate limited |
| 500 | unexpected server error |
| 503 | dependency unavailable |

## 7. 分頁、排序與 Filter

| 參數 | 規範 |
|---|---|
| `page_size` | 預設 50，上限依資源定義 |
| `page_token` | cursor，不使用 offset 作 production 大表分頁 |
| `sort` | `field:asc|desc` |
| `filter` | 受控 filter expression 或 query params |
| `fields` | 可選欄位 projection，敏感欄位仍需權限 |

範例：

```http
GET /api/v1/listings?region_id=khh&page_size=50&sort=created_at:desc
```

## 8. 長任務 Job Pattern

### 8.1 建立長任務

```http
POST /api/v1/site-scores:score
X-Idempotency-Key: <key>
```

```json
{
  "candidate_site_id": "cs_123",
  "priority": "normal",
  "requested_output": ["score", "report"]
}
```

回應：

```json
{
  "job_id": "job_01H...",
  "job_type": "sitescore_score",
  "status": "queued",
  "submitted_at": "2026-06-26T00:00:00+08:00",
  "links": {
    "self": "/api/v1/jobs/job_01H...",
    "result": null
  }
}
```

### 8.2 Job 狀態

| 狀態 | 說明 |
|---|---|
| `queued` | 已建立，等待 worker |
| `running` | 執行中 |
| `waiting_approval` | 等待人工核准或外部依賴 |
| `succeeded` | 完成 |
| `failed` | 失敗，不一定可重試 |
| `retrying` | 重試中 |
| `cancelled` | 已取消 |
| `partial` | 部分成功 |

## 9. 主要 API Catalog

### 9.1 Platform

| API | Method | 用途 |
|---|---|---|
| `/api/v1/me` | GET | 取得目前使用者、角色、scope |
| `/api/v1/jobs` | GET/POST | Job 查詢與建立 |
| `/api/v1/jobs/{job_id}` | GET | Job 狀態 |
| `/api/v1/jobs/{job_id}:cancel` | POST | 取消可取消 Job |
| `/api/v1/tasks` | GET | 工作台任務 |
| `/api/v1/approvals/{id}:approve` | POST | 核准 |
| `/api/v1/approvals/{id}:reject` | POST | 拒絕 |
| `/api/v1/audit-events` | GET | 稽核查詢 |
| `/api/v1/exports` | POST | 建立資料匯出 |

### 9.2 Integration / External Data

| API | Method | 用途 |
|---|---|---|
| `/api/v1/sources` | GET | 資料來源清單 |
| `/api/v1/source-runs` | GET | ingestion run 查詢 |
| `/api/v1/source-runs:trigger` | POST | 觸發來源同步 |
| `/api/v1/geocodes:resolve` | POST | 地址解析 |
| `/api/v1/geo-cells` | GET | H3/地理單元查詢 |
| `/api/v1/data-quality/runs` | GET | DQ run 查詢 |

### 9.3 Expansion

| API | Method | 用途 |
|---|---|---|
| `/api/v1/heat-zones` | GET | 熱區查詢 |
| `/api/v1/heat-zones/{id}` | GET | 熱區細節 |
| `/api/v1/heat-zone-runs` | GET | 熱區評分 run |
| `/api/v1/listings` | GET/POST | 物件清單、建立 |
| `/api/v1/listings:import` | POST | 匯入 CSV/Excel/feed |
| `/api/v1/listings/{id}:deduplicate` | POST | 觸發去重 |
| `/api/v1/candidate-sites` | GET/POST | 候選點 |
| `/api/v1/site-scores:score` | POST | 建立 SiteScore job |
| `/api/v1/site-scores/{id}` | GET | SiteScore 結果 |
| `/api/v1/site-scores/{id}:approve` | POST | 核准開店建議 |
| `/api/v1/site-scores/{id}:override` | POST | 人工 override |

### 9.4 Operations and Intervention

| API | Method | 用途 |
|---|---|---|
| `/api/v1/stores/{id}/forecast` | GET | 店別預測 |
| `/api/v1/alerts` | GET | 四燈事件 |
| `/api/v1/alerts/{id}:acknowledge` | POST | 確認警示 |
| `/api/v1/interventions` | GET/POST | 干預 |
| `/api/v1/interventions/{id}:approve` | POST | 核准干預 |
| `/api/v1/interventions/{id}:execute` | POST | 執行或標記執行 |
| `/api/v1/interventions/{id}/outcomes` | GET/POST | Outcome |
| `/api/v1/price-actions` | GET/POST | 價格方案 |
| `/api/v1/ad-campaigns` | GET/POST | 廣告活動 |
| `/api/v1/ad-campaigns/{id}/lift` | GET | 廣告增量結果 |

### 9.5 Asset / Network / Learning

| API | Method | 用途 |
|---|---|---|
| `/api/v1/valuations:run` | POST | 建立估值 job |
| `/api/v1/valuations/{id}` | GET | 估值結果 |
| `/api/v1/data-rooms` | GET/POST | 資料室 |
| `/api/v1/network-plans:solve` | POST | 建立 NetPlan solver job |
| `/api/v1/network-plans/{id}` | GET | 店網方案 |
| `/api/v1/models` | GET | 模型清單 |
| `/api/v1/models/{id}:promote` | POST | 模型升版 |
| `/api/v1/models/{id}:rollback` | POST | 模型回滾 |
| `/api/v1/feature-contracts` | GET | Feature Contract |
| `/api/v1/label-registry` | GET/POST | Label Registry |

## 10. Response Metadata

所有模型、決策與報告類 API 必須包含：

```json
{
  "metadata": {
    "model_version": "sitescore-v1.2.0",
    "policy_version": "site-decision-policy-v3",
    "feature_snapshot_time": "2026-06-25T23:59:59+08:00",
    "prediction_origin_time": "2026-06-26T00:00:00+08:00",
    "confidence": "medium",
    "data_freshness": {"transactions": "2026-06-25", "poi": "2026-06-01"},
    "correlation_id": "01HY..."
  }
}
```

## 11. API 安全檢查

1. mutation API 必須檢查 CSRF 或等效防護（依前端部署方式）。
2. 下載報告與匯出資料必須透過短效 signed URL 或 API stream，並寫 Audit。
3. 估值、財務、個資與高風險模型 API 必須檢查資料 scope，不得只檢查登入。
4. 所有 API 必須有 rate limiting strategy。
5. Internal API 不能暴露到 public ingress。

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD06-001` | OpenAPI 可產生 TypeScript client 且前端可使用 | CI Check |
| `ODP-AC-SD06-002` | 長任務 API 回傳 job_id 且 job 狀態可查詢 | Integration Test |
| `ODP-AC-SD06-003` | mutation API 支援 idempotency | Contract Test |
| `ODP-AC-SD06-004` | 權限與 scope 測試覆蓋至少核心角色與加盟主限制 | Security Test |
| `ODP-AC-SD06-005` | 錯誤格式、correlation_id、audit event 一致 | API Contract Test |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
