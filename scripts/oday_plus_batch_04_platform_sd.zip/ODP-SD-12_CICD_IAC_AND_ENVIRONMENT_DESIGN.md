---
doc_id: ODP-SD-12
title: "CI/CD、IaC 與環境設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "DevOps Owner / SRE Owner"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus CI/CD、IaC 與環境設計

## 1. 文件目的

本文件定義 ODay Plus 的 CI/CD、Infrastructure as Code、環境分層、測試 Gate、Container Build、DB Migration、dbt Deployment、Model Release、Feature Flag、Canary、Rollback 與 Release Governance。此文件是工程交付、DevSecOps 與上線查核的基線。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 交付原則

1. 所有雲端資源必須由 Terraform 或核准 IaC 管理。
2. 所有 Docker image 必須可重建、可掃描、可追溯 git SHA。
3. DB migration、dbt transformation、API schema、event schema、model release 必須納入 CI/CD gate。
4. Production 部署必須有 approval、release note、rollback plan。
5. Feature flag 控制高風險功能與高階模型啟用。
6. 禁止手動修改 Production 資源後不回寫 IaC。

## 3. 環境

| Environment | 用途 | 資料 | 部署策略 |
|---|---|---|---|
| local | 開發 | synthetic/fixture | docker compose |
| dev | 開發整合 | synthetic 或去識別小樣本 | 自動部署 feature/dev branch 可選 |
| staging | UAT、整合、release candidate | 去識別或授權 staging copy | merge to main 後自動或半自動 |
| production | 正式 | production | approval + canary/rollout |
| sandbox | 分析探索 | 非 production 或嚴格控管 | 不得成為 production dependency |

## 4. Branch 與 Release

| Branch | 用途 |
|---|---|
| `main` | 永遠可部署到 staging |
| `release/*` | Production candidate |
| `feature/*` | 功能開發 |
| `hotfix/*` | 緊急修復 |
| `docs/*` | 文件變更 |

### 4.1 版本標籤

| 產物 | 版本 |
|---|---|
| API/Web/Worker image | `app_version + git_sha` |
| DB schema | Alembic revision |
| dbt model | git_sha + dbt manifest hash |
| Event schema | semver |
| OpenAPI | semver/hash |
| Model | `model_name:version` + dataset_snapshot_id + git_sha |
| Terraform | module version + plan artifact |

## 5. CI Pipeline

```mermaid
flowchart LR
  PR[Pull Request] --> LINT[Lint / Format]
  LINT --> UNIT[Unit Tests]
  UNIT --> CONTRACT[API/Event Contract Tests]
  CONTRACT --> SEC[SAST / Dependency / Secret Scan]
  SEC --> BUILD[Build Images]
  BUILD --> SCAN[Image Scan / SBOM]
  SCAN --> MIG[Migration Dry Run]
  MIG --> DBT[dbt Build/Test]
  DBT --> PREVIEW[Preview Deploy optional]
```

### 5.1 CI Gates

| Gate | 必須 |
|---|---|
| Lint/Format | Python/TS/SQL/Terraform |
| Unit Test | Domain policy、service、workers |
| API Contract | OpenAPI compatibility |
| Event Contract | schema compatibility |
| Data Contract | dbt tests、freshness checks where applicable |
| Security | secret scan、dependency scan、SAST |
| Container | build、scan、SBOM |
| Migration | dry-run or shadow migration |
| Documentation | docs front matter、links、doc id uniqueness |

## 6. CD Pipeline

```mermaid
flowchart LR
  MAIN[main merge] --> STG_BUILD[Build immutable artifacts]
  STG_BUILD --> STG_DEPLOY[Deploy staging]
  STG_DEPLOY --> STG_TEST[Smoke / Integration / E2E]
  STG_TEST --> APPROVAL[Production Approval]
  APPROVAL --> PROD_PLAN[Terraform Plan / Migration Plan]
  PROD_PLAN --> PROD_DEPLOY[Canary / Rolling Deploy]
  PROD_DEPLOY --> MONITOR[Observe SLO]
  MONITOR --> DONE[Release Complete]
  MONITOR --> ROLLBACK[Rollback]
```

## 7. Terraform 結構

```text
infra/terraform/
├── modules/
│   ├── project/
│   ├── vpc/
│   ├── cloud-run-service/
│   ├── cloud-run-job/
│   ├── cloud-sql-postgres/
│   ├── bigquery-dataset/
│   ├── gcs-bucket/
│   ├── pubsub-topic/
│   ├── memorystore-redis/
│   ├── secret-manager/
│   ├── iam-binding/
│   ├── monitoring-dashboard/
│   └── alert-policy/
├── envs/
│   ├── dev/
│   ├── staging/
│   └── production/
└── policies/
```

### 7.1 Terraform 規範

1. Production apply 需人工核准。
2. Plan artifact 必須保存。
3. Remote state 使用 GCS bucket + state lock strategy。
4. IAM 變更需 security review。
5. Deleting critical resource 需 break-glass 或二級核准。
6. drift detection 至少每週。

## 8. Database Migration

| 資料層 | 工具 | Gate |
|---|---|---|
| Cloud SQL | Alembic | migration review、staging dry-run、rollback plan |
| BigQuery/dbt | dbt Core | dbt build、tests、docs、lineage |
| Event schema | schema registry files | backward compatibility test |
| Search index | migration script | reindex plan |
| Feature store/views | dbt + feature contract | model owner approval |

Migration 規則：

1. 不得在同一 release 中同時做無回退 DB breaking change 與大功能上線。
2. 大表變更需 expand/contract pattern。
3. 欄位刪除需先 deprecate，再清理。
4. 所有 migration 必須能在 staging 以 production-like snapshot 測試。

## 9. Model Release Pipeline

```mermaid
flowchart LR
  DATA[Dataset Snapshot] --> TRAIN[Training]
  TRAIN --> VALIDATE[Validation / Backtest]
  VALIDATE --> CARD[Model Card]
  CARD --> REG[Register]
  REG --> SHADOW[Shadow]
  SHADOW --> CANARY[Canary]
  CANARY --> PROD[Promote Alias]
  PROD --> MONITOR[Monitor]
  MONITOR --> ROLLBACK[Rollback if needed]
```

### 9.1 Model Gate

| Gate | 必須 |
|---|---|
| Dataset snapshot | 可重現、point-in-time correctness |
| Baseline comparison | 優於或不劣於 baseline |
| Segment metrics | 新店/成熟店、區域、品牌、店型 |
| Calibration | P10/P50/P90 或 coverage 檢查 |
| Drift | 無重大未解釋漂移 |
| Model Card | 限制、使用條件、回滾條件 |
| Approval | Model Owner + Release Owner |
| Rollback | previous production alias available |

## 10. Feature Flag

| Flag 類型 | 用途 |
|---|---|
| Release flag | 控制新功能入口 |
| Model flag | 控制模型版本或 challenger |
| Risk flag | 控制 PriceOps、Bandit、NetPlan advanced solver |
| UI flag | 控制前端顯示 |
| Tenant/Role flag | 控制特定品牌、區域、角色啟用 |
| Kill switch | 快速關閉高風險功能 |

所有高階模型，如 Bandit、MMM、Robust NetPlan、Deep Forecast，必須以 Feature Flag 與 Readiness Gate 控制啟用。

## 11. Rollback

| 產物 | Rollback 方法 |
|---|---|
| Web | Cloud Run previous revision / CDN rollback |
| API | previous Cloud Run revision |
| Worker | pause subscription + deploy previous image |
| DB migration | rollback script 或 expand/contract 避免 hard rollback |
| dbt | deploy previous manifest / restore view definition |
| Model | model alias rollback |
| Event schema | keep old consumer; stop new producer |
| Feature | disable flag |
| Price/Decision | business rollback workflow，不等於 code rollback |

## 12. Release Checklist

Production release 必須附：

1. Release note。
2. Impacted modules。
3. OpenAPI diff。
4. Event schema diff。
5. DB migration plan。
6. dbt lineage impact。
7. Feature flags。
8. Security scan result。
9. Test report。
10. Rollback plan。
11. Monitoring watch window。
12. Approvers。

## 13. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD12-001` | Terraform 管理主要 GCP 資源，且有 dev/staging/prod 區隔 | IaC Review |
| `ODP-AC-SD12-002` | CI 至少包含 lint、unit、contract、security、image scan | CI Review |
| `ODP-AC-SD12-003` | CD 支援 staging、production approval、rollback | Release Dry Run |
| `ODP-AC-SD12-004` | DB/dbt/model release 都有 gate 與可追蹤版本 | DevOps Review |
| `ODP-AC-SD12-005` | 高風險功能與高階模型受 feature flag 控制 | Feature Flag Test |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
