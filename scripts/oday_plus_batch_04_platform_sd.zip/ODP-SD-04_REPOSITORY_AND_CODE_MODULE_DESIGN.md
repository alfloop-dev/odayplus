---
doc_id: ODP-SD-04
title: "Repository 與程式模組設計"
version: 0.1.0
status: draft-for-review
document_class: system-design
batch: 4
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Tech Lead / Backend Lead / Frontend Lead"
approvers: "Architecture Owner / Product Lead / Security Owner / SRE Owner"
content_format: markdown
---


# ODay Plus Repository 與程式模組設計

## 1. 文件目的

本文件定義 ODay Plus 的 Repository、Package、Module、Coding Boundary、命名、測試與產物生成方式。目標是讓一人或小團隊可以用單一工程骨架完整實作全平台，同時保留未來依模組拆分成獨立服務的能力。


## 0. 文件基線與引用規則

本文件屬於第 4 批「平台 SD 主文件」，必須與第 1 至第 3 批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、交換契約、Canonical Model、Model-ready Views、資料品質與時間語意 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. Repository 決策

### 2.1 建議採 Monorepo

ODay Plus 第一階段建議採 Monorepo，原因：

1. 多數模組共享 Domain、Auth、Audit、Job、Workflow、OpenAPI、Data Contract。
2. 前後端與資料契約需要同步演進。
3. 開發人力集中，跨 repo 的版本管理成本不必要。
4. 可用 workspace 與 package boundary 控制依賴，而不是用 repo 數量控制架構。

### 2.2 拆成多 repo 的條件

符合下列情況再拆：

| 條件 | 說明 |
|---|---|
| 獨立團隊 | 有獨立維運、排程與 release owner |
| 不同安全域 | 例如 Data Room 或 PII pipeline 需獨立權限 |
| 不同部署節奏 | 模型訓練框架與前端 UI 完全不同週期 |
| 外部交付 | 需交由委外或開源部分元件 |
| 法規隔離 | 個資、財務、估值或補助查核資料有隔離需求 |

## 3. Monorepo 結構

```text
oday-plus/
├── apps/
│   ├── web/                         # OpsBoard Web, React/Next.js
│   ├── api/                         # FastAPI core-api / BFF
│   ├── worker/                      # Event consumers and async workers
│   ├── scheduler/                   # Scheduled triggers / orchestration entrypoints
│   └── cli/                         # Admin and migration utilities
├── modules/
│   ├── integration/
│   ├── external_data/
│   ├── heatzone/
│   ├── listing/
│   ├── sitescore/
│   ├── forecastops/
│   ├── intervention/
│   ├── priceops/
│   ├── adlift/
│   ├── avm/
│   ├── netplan/
│   ├── learninghub/
│   └── opsboard/
├── shared/
│   ├── domain/                      # shared value objects, enums, errors
│   ├── application/                 # command/query/job abstractions
│   ├── infrastructure/              # db, pubsub, storage, auth clients
│   ├── auth/
│   ├── audit/
│   ├── jobs/
│   ├── workflow/
│   ├── notification/
│   └── observability/
├── packages/
│   ├── openapi-client/              # generated TS client
│   ├── ui/                          # design system components
│   ├── schemas/                     # JSON schema / AsyncAPI / shared DTOs
│   └── testkit/                     # test utilities and fixtures
├── pipelines/
│   ├── dbt/
│   ├── airflow_or_dagster/          # if used
│   └── data_quality/
├── models/
│   ├── sitescore/
│   ├── forecastops/
│   ├── priceops/
│   ├── adlift/
│   ├── avm/
│   └── shared_ml/
├── solver/
│   ├── pricing/
│   └── netplan/
├── infra/
│   ├── terraform/
│   ├── docker/
│   ├── k8s_optional/
│   └── cloudbuild/
├── docs/
│   ├── architecture/
│   ├── api/
│   ├── events/
│   └── adr/
└── tests/
    ├── contract/
    ├── integration/
    ├── e2e/
    ├── performance/
    └── security/
```

## 4. Module 內部結構

每個 domain module 應使用一致結構：

```text
modules/sitescore/
├── domain/
│   ├── entities.py
│   ├── value_objects.py
│   ├── policies.py
│   └── events.py
├── application/
│   ├── commands.py
│   ├── queries.py
│   ├── services.py
│   └── workflows.py
├── infrastructure/
│   ├── repositories.py
│   ├── model_client.py
│   ├── pubsub_handlers.py
│   └── report_adapter.py
├── api/
│   ├── router.py
│   ├── schemas.py
│   └── dependencies.py
├── workers/
│   ├── score_worker.py
│   ├── realization_worker.py
│   └── report_worker.py
├── tests/
│   ├── unit/
│   ├── integration/
│   └── contract/
└── README.md
```

### 4.1 分層規則

| 層 | 可依賴 | 不得依賴 |
|---|---|---|
| `domain` | Python stdlib、shared domain primitives | DB、Pub/Sub、HTTP、GCP、ML client、framework |
| `application` | domain、repository interface、shared abstractions | 具體 Cloud/GCP SDK、前端 schema |
| `infrastructure` | application interfaces、GCP clients、DB clients | 其他 module 的 infrastructure |
| `api` | application services、DTO、auth deps | 直接寫 SQL 或 Pub/Sub |
| `workers` | application services、infrastructure adapters | 前端與 UI package |

## 5. 技術 Stack

| 層 | 技術 | 備註 |
|---|---|---|
| Frontend | TypeScript、React/Next.js、TanStack Query/Table、MapLibre/deck.gl、ECharts | UX 文件將細化 |
| Backend API | Python、FastAPI、Pydantic、SQLAlchemy/SQLModel、Alembic | OpenAPI 自動產生 |
| Workers | Python、FastAPI CLI/worker entrypoints、Pub/Sub client | 依 job type 啟動 |
| Data | dbt Core、SQL、BigQuery、PostgreSQL/PostGIS | dbt docs 產生資料文件 |
| Geo | H3、GeoPandas、Shapely、OSMnx、PostGIS | GDAL 相關 image 可獨立 |
| ML | scikit-learn、CatBoost、LightGBM、StatsForecast、MLForecast、MLflow、Evidently | Deep learning 受 Gate 控制 |
| Causal | DoWhy、EconML、CausalML | 第 6 批細化 |
| Solver | OR-Tools、Pyomo、CVXPY | NetPlan、PriceOps |
| Infra | Terraform、Docker、Cloud Build/GitHub Actions | 第 4 批 SD-12 細化 |
| Observability | OpenTelemetry、Cloud Logging/Monitoring、Prometheus-compatible metrics | SD-11 細化 |

## 6. 命名規範

| 類型 | 規範 | 例子 |
|---|---|---|
| Python package | snake_case | `forecastops`, `external_data` |
| API route | kebab-case plural | `/site-scores/{site_score_id}` |
| DB table | snake_case singular/plural 一致，建議 plural | `site_score_runs` |
| Event type | dot notation | `sitescore.completed.v1` |
| Job type | snake_case | `sitescore_score`, `forecast_daily_score` |
| Command | imperative | `CreateSiteScoreRun` |
| Query | noun phrase | `GetSiteScoreReport` |
| React component | PascalCase | `SiteScoreSummaryCard` |
| Feature flag | snake_case | `enable_bandit_policy` |
| Terraform module | kebab-case | `cloud-run-service` |

## 7. API 與 Schema 生成

| 產物 | 來源 | 生成結果 |
|---|---|---|
| OpenAPI | FastAPI route + Pydantic schema | `docs/api/openapi.json`、TS client |
| AsyncAPI | `packages/schemas/events` | Event catalog 文件與 contract tests |
| DB schema | Alembic migrations | ERD、migration history |
| dbt docs | `pipelines/dbt` | lineage、model docs、column docs |
| Model Card | ML training pipeline | `docs/model-cards/*.md` 或 GCS artifact |
| UI route map | `apps/web` route config | UX 與 auth guard trace |

## 8. Dependency Rule

### 8.1 Domain 間互動

Domain 之間不得直接 import 彼此 implementation。允許：

1. 透過 API client。
2. 透過 domain event。
3. 透過 shared canonical DTO。
4. 透過 read-only model-ready view。
5. 透過 workflow orchestration。

### 8.2 禁止依賴範例

```python
# 禁止：PriceOps 直接修改 InterventionOps repository
from modules.intervention.infrastructure.repositories import InterventionRepo

# 應改用：發送 command 或呼叫 application interface
from modules.intervention.application.commands import AttachActionToIntervention
```

## 9. 測試結構

| 測試 | 位置 | 覆蓋 |
|---|---|---|
| Unit | `modules/*/tests/unit` | domain policy、value object、business rule |
| API Contract | `tests/contract/api` | OpenAPI request/response、error code、auth |
| Event Contract | `tests/contract/events` | schema、version、required fields |
| Data Contract | `pipelines/dbt/tests` | not null、unique、accepted values、freshness |
| Integration | `tests/integration` | DB/PubSub/GCS/Redis local emulator 或 staging |
| E2E | `tests/e2e` | 展店、預警、干預、估值、模型發布流程 |
| Model | `models/*/tests` | backtest、calibration、segment metrics |
| Solver | `solver/*/tests` | hard constraint、infeasible、alternative plan |
| Security | `tests/security` | RBAC、ABAC、PII masking、export permission |

## 10. Local Development

```text
docker compose up postgres redis pubsub-emulator minio mlflow
make api-dev
make web-dev
make worker-dev
make db-migrate
make dbt-build
make test
```

### 10.1 Local 模擬

| GCP 服務 | Local 替代 |
|---|---|
| Cloud SQL | PostgreSQL + PostGIS container |
| Pub/Sub | Pub/Sub emulator 或 NATS local |
| Cloud Storage | MinIO |
| BigQuery | DuckDB/BigQuery sandbox 或 small test dataset |
| Secret Manager | `.env.local` + sealed dev values，不可含 prod secret |
| Vertex AI | local model stub / MLflow local |

## 11. Package 發布與版本

| Package | Version 規則 |
|---|---|
| `packages/openapi-client` | 跟 OpenAPI spec hash 或 semver |
| `packages/schemas` | event/schema semver；breaking change 需新 event version |
| `shared/domain` | app semver；需跑全部 domain tests |
| `ui` | design system semver |
| `models/*` | model_version + dataset_snapshot_id + git_sha |
| `infra/terraform` | module version + environment plan |

## 12. 驗收條件

| AC ID | 驗收條件 | 驗證方式 |
|---|---|---|
| `ODP-AC-SD04-001` | Repository 結構能容納所有 domain module 與共用平台元件 | Repo Review |
| `ODP-AC-SD04-002` | 每個 module 均符合 domain/application/infrastructure/api/workers 分層 | Code Review |
| `ODP-AC-SD04-003` | OpenAPI、AsyncAPI、dbt docs、Model Card 至少有生成流程設計 | CI Review |
| `ODP-AC-SD04-004` | 依賴方向可由 lint/import rule 或 code review 控制 | Static Check |
| `ODP-AC-SD04-005` | Local development 可啟動 API、Web、worker、DB、event emulator | Developer Smoke Test |


## 追蹤與驗收

| Trace 類型 | 對應 |
|---|---|
| HLR | `ODP-HLR-GOV-*`、`ODP-HLR-INT-*`、`ODP-HLR-HZ-*`、`ODP-HLR-SITE-*`、`ODP-HLR-FCT-*`、`ODP-HLR-INTV-*`、`ODP-HLR-PRICE-*`、`ODP-HLR-AD-*`、`ODP-HLR-AVM-*`、`ODP-HLR-NET-*`、`ODP-HLR-LH-*`、`ODP-HLR-OPS-*` |
| FR | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中列出的全平台 FR |
| NFR | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 中的效能、可用性、資安、資料品質、模型治理與可觀測性要求 |
| Data | `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| QA | 第 8 批 QA 文件需將本文件的架構決策轉為 Contract Test、Integration Test、E2E、Security Test、Performance Test 與 Audit Evidence |

本文件中列為 `MUST` 的架構與設計項目，後續必須在程式碼、IaC、OpenAPI、AsyncAPI、dbt、Migration、Test Case 或 Runbook 中至少有一項可查證交付物。
