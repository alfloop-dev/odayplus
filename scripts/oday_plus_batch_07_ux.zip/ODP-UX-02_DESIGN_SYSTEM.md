---
id: ODP-UX-02
title: Design System 設計規範
batch: 7
category: UX
doc_type: user-experience
version: 1.0.0
status: draft
formal_deliverable: true
owner: Product Design / Frontend
updated_at: 2026-06-26
depends_on:
  - ODP-UX-01_INFORMATION_ARCHITECTURE_AND_NAVIGATION
  - ODP-SA-04_USERS_ROLES_AND_ACCESS_REQUIREMENTS
  - ODP-SD-09_IDENTITY_SECURITY_AND_PRIVACY_DESIGN
---

# ODP-UX-02 Design System 設計規範

## 1. 文件目的

本文件定義 ODay Plus OpsBoard 的 Design System。此 Design System 必須同時支援：

- 地圖型決策。
- 表格式營運管理。
- 預測區間與模型證據。
- 人工核准與稽核留痕。
- 多角色權限。
- 高風險決策的可理解呈現。
- 加盟主可讀的簡化語言。
- AI／資料團隊可讀的技術語言。

Design System 的核心原則是：**一致、可解釋、可追溯、可操作。**

---

## 2. 設計原則

### 2.1 Clarity over density

ODay Plus 含大量資料與模型結果。畫面設計應優先讓使用者快速回答：

```text
現在狀態是什麼？
為什麼系統這樣判斷？
我可以做什麼？
做了之後會留下什麼紀錄？
```

不可為了塞入更多欄位而犧牲判讀。

### 2.2 Decision-first

每個工作頁都應以決策任務為中心，而不是以資料瀏覽為中心。

範例：

- SiteScore Report 的主視覺不是全部特徵，而是 GO / WAIT / REJECT、P10/P50/P90、回本期與主要證據。
- ForecastOps 的主視覺不是每日營收表，而是未來軌跡、四燈、SiteScore Gap 與根因證據。
- NetPlan 的主視覺不是 Solver 參數，而是方案差異、限制、風險與可執行時序。

### 2.3 Prediction is not decision

UI 必須清楚分離：

```text
模型預測
系統建議
人工核准
實際執行
結果回收
```

模型輸出不得直接呈現為「已決定」。

### 2.4 Uncertainty is visible

所有預測與估值都必須顯示不確定性：

- P10 / P50 / P90。
- Confidence。
- Coverage。
- Sample Size。
- Data freshness。
- Model version。
- Feature snapshot time。

### 2.5 Audit by design

所有高風險操作的元件都必須內建 Audit 表達：

- Actor。
- Timestamp。
- Reason。
- Approval。
- Override。
- Model version。
- Policy version。
- Before / After。

---

## 3. Design Tokens

### 3.1 Semantic Color Tokens

實作層應使用 semantic token，不在 component 中硬編色碼。

```text
color.bg.canvas
color.bg.surface
color.bg.muted
color.bg.warning-soft
color.bg.danger-soft
color.bg.success-soft

color.text.primary
color.text.secondary
color.text.muted
color.text.inverse
color.text.danger
color.text.warning
color.text.success

color.border.default
color.border.strong
color.border.focus
color.border.danger
color.border.warning

color.status.green
color.status.yellow
color.status.orange
color.status.red
color.status.gray
color.status.blue
color.status.purple

color.model.production
color.model.candidate
color.model.shadow
color.model.canary
color.model.rollback

color.map.heat.low
color.map.heat.medium
color.map.heat.high
color.map.risk.low
color.map.risk.medium
color.map.risk.high
```

### 3.2 Status Color Rules

| 狀態 | 語意 | 使用場景 |
|---|---|---|
| Green | 正常、達標、低風險 | 四燈綠、資料新鮮、Job 成功 |
| Yellow | 輕微偏離、需注意 | 四燈黃、資料快過期 |
| Orange | 高風險、需處置 | 四燈橙、干預建議 |
| Red | 危急、阻擋、重大失敗 | 四燈紅、資料 QA fail、硬限制違反 |
| Gray | 未啟用、無資料、草稿 | 無樣本、未發布 |
| Blue | 資訊、進行中 | Job Running、Canary |
| Purple | 模型／AI 相關 | Model Version、Feature Registry |

### 3.3 Typography Tokens

```text
font.family.sans
font.family.mono

font.size.xs
font.size.sm
font.size.md
font.size.lg
font.size.xl
font.size.2xl
font.size.3xl

font.weight.regular
font.weight.medium
font.weight.semibold
font.weight.bold

line-height.compact
line-height.normal
line-height.relaxed
```

文字層級：

| Token | 用途 |
|---|---|
| Display | Executive summary / major KPI |
| H1 | Page title |
| H2 | Section title |
| H3 | Card title |
| Body | 一般說明 |
| Caption | Metadata, timestamp |
| Mono | IDs, model version, code, event name |

### 3.4 Spacing Tokens

```text
space.0
space.1
space.2
space.3
space.4
space.6
space.8
space.12
space.16
```

### 3.5 Radius Tokens

```text
radius.none
radius.sm
radius.md
radius.lg
radius.xl
radius.full
```

### 3.6 Shadow / Elevation

```text
elevation.none
elevation.card
elevation.dropdown
elevation.modal
elevation.toast
```

### 3.7 Z-index

```text
z.base
z.sticky
z.dropdown
z.drawer
z.modal
z.toast
z.command-palette
```

---

## 4. Layout System

### 4.1 App Shell

固定架構：

```text
Global Header
├── Sidebar
│   └── Workspace Navigation
├── Main Content
│   ├── Page Header
│   ├── Filter Bar
│   ├── Content Area
│   └── Right Drawer / Detail Panel
└── Toast / Modal / Command Palette
```

### 4.2 Page Header

Page Header 應包含：

```text
Title
Subtitle / Summary
Status Badge
Primary Action
Secondary Actions
Breadcrumb
Last Updated
```

### 4.3 Page Density

支援三種密度：

| Density | 使用場景 |
|---|---|
| Comfortable | 預設，適合一般使用者 |
| Compact | 表格密集操作，例如 Listing Inbox |
| Presentation | 管理層檢視與會議投影 |

### 4.4 Responsive Breakpoints

```text
breakpoint.sm = mobile
breakpoint.md = tablet
breakpoint.lg = desktop
breakpoint.xl = large desktop
breakpoint.2xl = command center / wall screen
```

最低支援：

- Desktop first。
- Tablet 可檢視關鍵摘要與任務。
- Mobile 僅支援任務確認、通知、簡易回報與加盟主查看，不承擔完整模型審查。

---

## 5. Core Components

## 5.1 Button

### Variants

```text
primary
secondary
tertiary
danger
warning
success
ghost
link
```

### Rules

- 高風險動作用 `danger`，需二次確認。
- 核准類按鈕需明確文字，例如 `核准此調價方案`，不可只寫 `OK`。
- Disabled button 必須提供 tooltip 說明原因。
- Loading button 需避免重複提交。

## 5.2 Badge

### Badge Types

```text
status
priority
role
model-version
data-quality
confidence
sla
permission
```

### 範例

```text
RED
P1
PRODUCTION
LOW_CONFIDENCE
STALE
REQUIRES_APPROVAL
READ_ONLY
```

## 5.3 Card

Card 是 ODay Plus 的主要資訊承載元件。

### Card Types

```text
Summary Card
Decision Card
Evidence Card
KPI Card
Risk Card
Model Card
Data Quality Card
Task Card
Store Card
Candidate Site Card
Valuation Card
Scenario Card
```

### Decision Card 必備區塊

```text
Decision Title
System Recommendation
Human Decision Status
Evidence Summary
Risk / Confidence
Required Approval
Primary Action
Audit Metadata
```

## 5.4 Table

### 表格能力

- Sorting。
- Filtering。
- Column visibility。
- Column pinning。
- Row selection。
- Batch action。
- Inline status。
- Export。
- Saved view。
- Server-side pagination。
- Row detail drawer。

### 表格必備欄位模式

列表類頁面須保留：

```text
entity_name
status
priority / score
owner
updated_at
primary_action
```

### 敏感欄位

高敏感資料預設遮罩：

- 交易金額明細。
- 加盟主個資。
- 會員資料。
- 精細成本。
- 估值底價。

## 5.5 Form

### Form Patterns

```text
Simple Form
Wizard Form
Review Form
Approval Form
Bulk Import Form
Filter Form
Policy Form
```

### Form Rules

- 所有提交需明確顯示即將影響的實體。
- 高風險表單需 preview before submit。
- 所有人工 override 需 reason。
- 表單驗證需顯示欄位級錯誤與整體錯誤摘要。
- 失敗時保留輸入內容。

## 5.6 Modal

Modal 只用於：

- 確認。
- 短表單。
- 危險操作。
- 操作不可中斷的提示。

禁止在 Modal 中放大型模型報告或複雜表格。大型內容應使用 Page 或 Drawer。

## 5.7 Drawer

Drawer 用於列表中的快速查看與次要操作：

```text
Listing preview
Task detail
Alert preview
Model version detail
Data quality event detail
```

Drawer 支援：

- Esc 關閉。
- Deep link。
- 切換上一筆／下一筆。
- 保留列表狀態。

## 5.8 Tabs

Tabs 用於同一實體的不同資訊面向：

```text
Summary
Evidence
History
Decision
Execution
Outcome
Audit
```

Tabs 不應用來切換不同工作流程。

## 5.9 Timeline

Timeline 用於呈現：

- 開店流程。
- 警示處理流程。
- 干預觀察窗。
- 價格發布與 rollback。
- AVM 交易流程。
- NetPlan 季度計畫。
- Model Release。

Timeline 每個節點需包含：

```text
timestamp
actor
event_type
status
description
related_artifact
```

## 5.10 Empty State

Empty State 統一元件：

```text
title
description
next_actions
optional_doc_link
```

## 5.11 Toast

Toast 用於輕量回饋：

- 儲存成功。
- Job 建立。
- 匯出開始。
- 指派完成。

重大錯誤不只用 Toast，必須有 inline error 或 error page。

## 5.12 Command Palette

快捷鍵：`Cmd/Ctrl + K`

支援：

- 搜尋頁面。
- 搜尋實體。
- 建立任務。
- 跳轉最近瀏覽。
- 執行有權限的快速動作。

---

## 6. Domain Components

## 6.1 HeatZone Score Card

必備欄位：

```text
HeatZone ID
行政區 / 商圈
H3 resolution
HeatZone Score
Priority Rank
Unmet Demand Score
ODay G2 Fit Score
Cannibalization Risk
Rent Feasibility
Listing Availability
Confidence
Last Scored At
```

## 6.2 Candidate Site Card

必備欄位：

```text
Candidate Site ID
Address
Geocode Confidence
Rent
Area
Frontage
Floor
Parking / Temporary Stop
Feasibility Flags
HeatZone
Listing Source
Status
```

## 6.3 SiteScore Report Card

必備欄位：

```text
Recommendation: GO / WAIT / REJECT / INVESTIGATE
M1 P10 / P50 / P90
M3 P10 / P50 / P90
M6 P10 / P50 / P90
M12 P10 / P50 / P90
Payback Period
Rent Reasonableness
Cannibalization Risk
Comparable Stores
Key Positive Factors
Key Negative Factors
Model Version
Feature Snapshot Time
```

## 6.4 Forecast Band Component

呈現：

- Actual。
- Forecast P50。
- P10 / P90 band。
- Intervention markers。
- SiteScore original path。
- Confidence。
- Horizon selector：4w / 8w / 12w / 24w。

## 6.5 Four-Light Badge

四燈：

```text
GREEN
YELLOW
ORANGE
RED
```

規則：

- Badge 需有文字，不可只靠顏色。
- 滑鼠 hover 顯示觸發條件。
- 點擊進入 Alert Evidence。
- 色盲模式使用 icon / pattern 區分。

## 6.6 Root Cause Evidence Card

欄位：

```text
Cause Candidate
Evidence Strength
Supporting Signals
Contradicting Signals
Data Confidence
Recommended Next Check
```

## 6.7 Intervention Card

欄位：

```text
Intervention Type
Eligibility Status
Conflict Status
Action Set
Approval Status
Execution Status
Observation Window
Outcome Status
Evidence Level
```

## 6.8 Price Plan Comparison

欄位：

```text
Current Price
Candidate Price
Expected Demand Change
Expected Gross Margin Change
Risk
Hard Constraint Violations
Rollback Plan
Approval Required
```

## 6.9 AdLift Report Card

欄位：

```text
Campaign
Treatment Stores
Control Stores
Pre-trend Status
Incremental Revenue
Incremental Gross Margin
iROMI
Evidence Level
Continue / Stop Recommendation
```

## 6.10 AVM Valuation Card

欄位：

```text
Fair Value P10 / P50 / P90
Reserve Price
Asking Price
Income Approach
Asset Approach
Market Comparable
Liquidity Score
Data Room Completeness
Finance Approval Status
```

## 6.11 NetPlan Scenario Card

欄位：

```text
Scenario Name
Objective Value
OPEN / KEEP / IMPROVE / MOVE / EXIT count
Budget Usage
Expected GM
Risk
Binding Constraints
Solver Status
Alternative Plan Available
Approval Status
```

## 6.12 Model Release Card

欄位：

```text
Model ID
Version
Champion / Challenger
Metric Summary
Segment Regression
Data Quality Status
Drift Status
Release Stage
Rollback Target
Approval Status
```

---

## 7. State Components

## 7.1 Job Progress

Job Progress 應顯示：

```text
job_id
job_type
status
submitted_at
started_at
elapsed_time
estimated_stage
progress_message
retry_count
correlation_id
```

大型 Job 如 NetPlan Solver 不應顯示假進度百分比；若無真實進度，顯示階段狀態即可。

## 7.2 Data Freshness Indicator

狀態：

```text
FRESH
STALE
MISSING
PARTIAL
FAILED_QA
```

顯示：

```text
source
last_observed_at
last_ingested_at
expected_frequency
freshness_sla
```

## 7.3 Confidence Indicator

Confidence 不以單一顏色代表，需顯示原因：

```text
High confidence: sample size sufficient, recent data, calibrated interval.
Low confidence: sparse comparable stores, stale rent data, geocode uncertain.
```

---

## 8. Iconography

### 8.1 Icon 類型

```text
Map / Location
Store
Machine
Revenue
Forecast
Alert
Intervention
Price
Campaign
Valuation
Network
Model
Data
Audit
User
Lock
Warning
Rollback
```

### 8.2 Icon 原則

- Icon 不能單獨傳達高風險狀態，必須搭配文字。
- 同一模組 icon 不可跨語意使用。
- 加盟主介面避免使用過度技術化 icon。

---

## 9. Motion and Feedback

### 9.1 Motion 原則

- Motion 用於引導注意，不用於裝飾。
- 地圖 layer 切換可淡入淡出。
- Drawer 開合需快速。
- Critical alert 不使用閃爍動畫，避免干擾。
- Loading 使用 skeleton 或 stage indicator。

### 9.2 Interaction Feedback

每次操作需回饋：

```text
操作已送出
Job 已建立
等待核准
已核准
已拒絕
已排程執行
已進入觀察窗
結果成熟
```

---

## 10. Accessibility

### 10.1 基本要求

- 支援鍵盤操作。
- 所有互動元件有可讀 label。
- 色彩不可作為唯一訊息。
- 圖表需有資料表替代。
- Map layer 需有列表替代。
- Modal / Drawer 焦點管理。
- Form error 關聯欄位。
- Toast 可被 screen reader 讀取。

### 10.2 色盲友善

四燈與風險狀態需搭配：

- Icon。
- Pattern。
- Text。
- Tooltip。

### 10.3 高密度表格

表格需支援：

- Sticky header。
- Column resize。
- Keyboard navigation。
- Row focus。
- Screen reader summary。

---

## 11. Language and Copy

### 11.1 語言層級

前端文案分為三層：

| 層級 | 使用者 | 風格 |
|---|---|---|
| Business | 管理層、營運、加盟主 | 直接、可執行 |
| Analytical | 展店審查、行銷、財務 | 指標、區間、比較 |
| Technical | AI／資料、稽核 | 版本、特徵、資料品質 |

### 11.2 禁用文案

避免：

```text
AI 決定
模型保證
一定會成長
絕對準確
立即改善
```

建議：

```text
系統建議
預測區間
信心水準
需人工核准
觀察窗成熟後驗證
```

### 11.3 Error Copy

錯誤訊息需包含：

```text
發生什麼事
可能原因
可採取下一步
錯誤代碼
correlation_id
```

範例：

```text
無法產生 SiteScore 報告，因候選物件缺少可用經緯度。
請重新執行地址解析或改用人工輸入座標。
錯誤代碼：GEOCODE_REQUIRED
Correlation ID：...
```

---

## 12. Localization

系統預設語言：繁體中文。

需保留：

- 英文技術名詞原文。
- 狀態代碼英文。
- 模型名稱英文。
- API / Event / Job ID 英文。

範例：

```text
四燈狀態：ORANGE
模型版本：forecastops-growth-v1.2.3
資料狀態：STALE
```

---

## 13. Theming

### 13.1 Theme

支援：

```text
light
dark
high-contrast
presentation
```

### 13.2 Map Theme

地圖需獨立 theme：

- Light basemap。
- Dark basemap。
- Minimal basemap for dense layers。
- Print-safe map style。

---

## 14. Design System Governance

### 14.1 Component Lifecycle

```text
PROPOSED
EXPERIMENTAL
APPROVED
DEPRECATED
REMOVED
```

### 14.2 Component Documentation

每個 component 需有：

```text
Purpose
Props
States
Variants
Accessibility
Examples
Do / Don't
Related API
Related domain entities
```

### 14.3 Breaking Change

任何元件 breaking change 需建立 ADR，並列出受影響頁面。

---

## 15. 驗收條件

Design System 完成後，需滿足：

- 所有狀態顏色與文字語意統一。
- 所有高風險決策元件內建 Audit 與 Approval 表達。
- 預測與估值元件可呈現不確定性。
- 地圖、表格、卡片、時間軸、模型版本等核心元件有一致規範。
- 加盟主與總部畫面可共用設計語言但支援不同資訊密度。
- 不依賴顏色作為唯一風險表達。
- 可由前端程式建立 token、component、storybook 與視覺回歸測試。
