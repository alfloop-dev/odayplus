---
id: ODP-UX-01
title: 資訊架構與導覽設計
batch: 7
category: UX
doc_type: user-experience
version: 1.0.0
status: draft
formal_deliverable: true
owner: Product Design / Frontend
updated_at: 2026-06-26
depends_on:
  - ODP-00-01_SCOPE_AND_BOUNDARIES
  - ODP-SA-03_CAPABILITY_MAP_AND_MODULE_BOUNDARIES
  - ODP-SA-04_USERS_ROLES_AND_ACCESS_REQUIREMENTS
  - ODP-SD-01_SYSTEM_OVERALL_ARCHITECTURE
  - ODP-MOD-11_OPSBOARD
---

# ODP-UX-01 資訊架構與導覽設計

## 1. 文件目的

本文件定義 ODay Plus 前端產品的資訊架構、導覽層級、工作區切分、角色入口、全域搜尋、任務中心、通知中心與跨模組跳轉規則。

ODay Plus 前端不是單一 Dashboard，而是一個多角色、多模組、多決策流的 OpsBoard 工作台。前端必須讓不同角色在同一個系統中完成下列閉環：

```text
展店發現
→ 物件蒐集
→ 店址評估
→ 開店審查
→ 開店後營運監控
→ 異常預警
→ 營運干預
→ 價格／廣告／維修／促銷處置
→ 干預效果驗證
→ 門市估值
→ 留守／改善／遷點／退出／新開店規劃
→ 模型回訓與治理
→ 稽核留痕
```

前端資訊架構的核心原則是：**以工作任務與決策責任切分，而不是以模型名稱或資料表切分。**

---

## 2. 使用者入口原則

### 2.1 角色入口

ODay Plus 需支援下列主要角色：

| 角色 | 主要入口 | 核心任務 |
|---|---|---|
| 管理層 | Executive Workspace | 展店優先順序、店網規劃、資本配置、重大退出決策 |
| 展店業務 | Expansion Workspace | 查看熱區、追蹤物件、安排現勘 |
| 展店審查 | Site Review Workspace | 審查 SiteScore、回本期、租金合理性、GO/WAIT/REJECT |
| 營運主管 | Operations Workspace | 監控門市四燈、成長軌跡、異常分布 |
| 區域督導 | Field Ops Workspace | 處理警示、執行處置、回報觀察結果 |
| 行銷團隊 | Marketing Workspace | 廣告投放建議、活動效果、iROMI |
| 定價團隊 | Pricing Workspace | 價格方案、彈性估計、安全限制、調價核准 |
| 財務／法務 | Asset Workspace | 估值、租約、保留價、資料室、交易程序 |
| AI／資料團隊 | Learning Workspace | 模型版本、特徵、標籤、漂移、回訓、發布 |
| 加盟主 | Franchisee Workspace | 自店營運狀態、建議、處置任務、估值／遷點方案 |
| 稽核／治理 | Governance Workspace | 決策留痕、模型版本、人工覆核、資料品質 |

### 2.2 角色切換

同一使用者可能有多重角色，例如營運主管同時可檢視 ForecastOps 與 InterventionOps。前端應提供：

- 全域角色切換器。
- 預設角色由登入後的最高頻工作區決定。
- 角色切換不應改變資料權限，只改變導覽優先順序。
- 使用者無權限的模組不得顯示操作按鈕；如需顯示資料摘要，應以唯讀模式呈現。

---

## 3. 全站資訊架構

### 3.1 第一層：產品殼層

```text
OpsBoard Shell
├── Home
├── Task Center
├── Notifications
├── Global Search
├── Workspaces
├── Reports
├── Learning Hub
├── Governance
├── Admin
└── Help / Runbook
```

### 3.2 第二層：工作區

```text
Workspaces
├── Executive
├── Expansion
├── Site Review
├── Operations
├── Intervention
├── Pricing
├── Marketing / AdLift
├── Asset / DealRoom
├── Network Planning
├── Learning
├── Franchisee Portal
└── Audit
```

### 3.3 第三層：模組頁面

```text
Expansion
├── HeatZone Map
├── HeatZone Ranking
├── Listing Inbox
├── Listing Review
├── Candidate Site Detail
├── SiteScore Report
└── Opening Decision Board

Operations
├── Store Overview
├── Forecast Timeline
├── Four-Light Alert Center
├── Root Cause Evidence
├── Store Detail
└── SiteScore Realization

Intervention
├── Intervention Inbox
├── Intervention Detail
├── Eligibility Check
├── Action Builder
├── Approval
├── Execution Tracking
├── Observation Window
└── Outcome Review

Pricing
├── Pricing Candidates
├── Elasticity Evidence
├── Pricing Simulation
├── Pricing Optimizer Result
├── Price Approval
└── Price Rollback

Marketing / AdLift
├── Ad Need Score
├── Campaign Candidate
├── Control Matching
├── DiD / Lift Report
├── iROMI
└── Continue / Stop Decision

Asset / DealRoom
├── AVM Queue
├── Valuation Card
├── Data Room
├── Comparable Stores
├── Reserve / Asking Price
└── Transaction Workflow

Network Planning
├── Scenario Builder
├── OPEN / KEEP / IMPROVE / MOVE / EXIT Plan
├── Solver Result
├── Infeasibility Diagnosis
├── Alternative Plans
└── Quarterly Timeline

Learning
├── Feature Registry
├── Label Registry
├── Dataset Snapshots
├── Model Registry
├── Model Cards
├── Backtests
├── Drift Monitor
├── Release Controller
└── Rollback Console

Audit
├── Decision Log
├── Intervention Log
├── Model Release Log
├── Data Quality Events
├── User Activity
└── Evidence Export
```

---

## 4. 導覽結構

### 4.1 Global Header

Global Header 固定顯示：

| 元件 | 說明 |
|---|---|
| Product Logo | ODay Plus |
| Workspace Switcher | 依使用者角色列出可進入工作區 |
| Global Search | 搜尋門市、物件、熱區、任務、模型、決策 |
| Task Center Icon | 顯示待辦數 |
| Notification Icon | 顯示新警示、核准、失敗 Job |
| Environment Badge | Dev / Staging / Production |
| User Menu | 個人設定、角色、登出、說明 |

### 4.2 Sidebar

Sidebar 隨工作區改變。規則：

- 第一層顯示工作區主要任務。
- 第二層顯示模組頁面。
- 當頁所在項目高亮。
- 無權限項目不顯示。
- 可讀不可寫項目顯示唯讀標記。

### 4.3 Breadcrumb

所有 Detail 頁必須有 Breadcrumb：

```text
Expansion > Listing Inbox > Candidate Site > SiteScore Report
Operations > Four-Light Alert Center > Store Detail > Intervention
Learning > Model Registry > Model Version > Release Decision
```

Breadcrumb 支援回上一層，不取代瀏覽器 Back 行為。

### 4.4 Deep Link

所有可審查、可稽核、可分享的頁面必須支援 Deep Link：

| 物件 | URL Pattern |
|---|---|
| Store | `/stores/{store_id}` |
| Candidate Site | `/candidates/{candidate_site_id}` |
| SiteScore Report | `/sitescore/reports/{report_id}` |
| Alert | `/alerts/{alert_id}` |
| Intervention | `/interventions/{intervention_id}` |
| Pricing Plan | `/pricing/plans/{plan_id}` |
| AdLift Report | `/adlift/reports/{report_id}` |
| AVM Report | `/avm/reports/{valuation_id}` |
| NetPlan Scenario | `/netplan/scenarios/{scenario_id}` |
| Model Version | `/learning/models/{model_id}/versions/{version}` |
| Decision Log | `/audit/decisions/{decision_id}` |

---

## 5. Home 設計

### 5.1 Home 的目的

Home 不應成為大雜燴報表，而應回答：

```text
我今天需要處理什麼？
哪些風險需要我注意？
哪些決策卡住？
哪些模型／資料狀態不健康？
```

### 5.2 Home 區塊

```text
Home
├── My Tasks
├── Critical Alerts
├── Pending Approvals
├── Recent Decisions
├── Data / Model Health
├── Store Network Snapshot
└── Quick Actions
```

### 5.3 Role-based Home

| 角色 | Home 優先區塊 |
|---|---|
| 管理層 | Top risks, NetPlan, capital decisions, high-value approvals |
| 展店業務 | Assigned HeatZones, new listings, site visit tasks |
| 展店審查 | SiteScore reports awaiting review |
| 營運主管 | Red / orange stores, unresolved interventions |
| 區域督導 | Field tasks, observation windows, maintenance confirmations |
| 行銷 | Campaign candidates, AdLift results |
| 定價 | Pricing plans awaiting review |
| 財務／法務 | Valuation requests, data room readiness |
| AI／資料 | data quality failures, model releases, drift alerts |
| 加盟主 | own store status, recommended actions, pending acknowledgements |

---

## 6. Task Center

### 6.1 Task 類型

| Task Type | 來源 | 執行者 |
|---|---|---|
| `LISTING_REVIEW` | Listing Pipeline | 展店業務 |
| `SITE_VISIT` | Listing / SiteScore | 展店業務 |
| `SITE_DECISION_APPROVAL` | SiteScore | 展店審查 / 管理層 |
| `ALERT_TRIAGE` | ForecastOps | 營運主管 / 區域督導 |
| `INTERVENTION_APPROVAL` | InterventionOps | 營運主管 |
| `INTERVENTION_EXECUTION` | InterventionOps | 區域督導 |
| `PRICE_APPROVAL` | PriceOps | 定價團隊 / 管理層 |
| `AD_CAMPAIGN_REVIEW` | AdLift | 行銷團隊 |
| `VALUATION_REVIEW` | DealRoomAVM | 財務 / 法務 |
| `NETPLAN_APPROVAL` | NetPlan | 管理層 |
| `MODEL_RELEASE_REVIEW` | Learning Hub | AI / 資料 / 治理 |
| `DATA_QUALITY_REVIEW` | Data Quality | Data Owner |
| `AUDIT_REVIEW` | Audit | 稽核人員 |

### 6.2 Task 欄位

每一個 Task 必須至少包含：

```yaml
task_id:
task_type:
title:
description:
priority:
status:
owner_user_id:
owner_role:
source_module:
source_entity_type:
source_entity_id:
created_at:
due_at:
sla_status:
decision_required:
related_store_id:
related_region_id:
model_version:
data_snapshot_time:
```

### 6.3 Task Status

```text
CREATED
ASSIGNED
IN_PROGRESS
WAITING_FOR_INPUT
WAITING_FOR_APPROVAL
APPROVED
REJECTED
EXECUTED
OBSERVING
DONE
CANCELLED
EXPIRED
```

### 6.4 Task List UX

Task List 預設排序：

1. P0 / P1 優先。
2. 即將 SLA breach 優先。
3. 需本人核准者優先。
4. 新增未讀者優先。
5. 建立時間倒序。

Task List 支援：

- 篩選：角色、模組、區域、門市、優先級、期限、狀態。
- 批次操作：指派、關閉、匯出、加註。
- Saved Views：每個角色可保存常用篩選。
- Inline Preview：點擊右側 drawer 預覽，不離開列表。

---

## 7. Notifications

### 7.1 通知類型

| Notification | 說明 |
|---|---|
| Critical Alert | 紅燈、重大資料品質失敗、服務中斷 |
| Approval Request | 需核准的 SiteScore、PriceOps、NetPlan |
| Job Finished | 批次評分、模型訓練、報告完成 |
| Job Failed | Worker / Batch / Solver 失敗 |
| Data Stale | 來源資料超過新鮮度門檻 |
| Model Drift | 模型漂移或監控失敗 |
| Observation Matured | 干預觀察窗成熟，可檢視結果 |
| Audit Required | 稽核抽查或不一致事件 |

### 7.2 通知行為

- 通知可點擊跳到來源 Detail 頁。
- 通知應可標記已讀。
- P0 / P1 通知需留存不可刪除。
- 通知本身不等於 Audit Log；Audit Log 由後端另行持久化。
- 系統通知和 Email / LINE / Slack 等外部通道分離設計。

---

## 8. Global Search

### 8.1 搜尋範圍

Global Search 至少支援：

- 門市名稱、地址、店號。
- 候選物件地址、物件編號。
- 熱區名稱、H3 cell、行政區。
- 任務編號。
- Decision ID。
- Model ID / version。
- AVM 報告。
- NetPlan Scenario。
- 干預活動。
- 使用者與角色。

### 8.2 搜尋結果分組

```text
Stores
Candidate Sites
HeatZones
Tasks
Decisions
Reports
Models
Users
```

### 8.3 搜尋權限

搜尋結果必須先套用權限再呈現。不可讓使用者透過搜尋知道無權限實體存在。

### 8.4 搜尋結果項目

每筆搜尋結果需顯示：

```text
Name / Title
Entity Type
Key Metadata
Status Badge
Last Updated
Primary Action
```

---

## 9. Reports

Reports 是報表入口，不是主要操作入口。

### 9.1 報表分類

```text
Reports
├── Expansion Reports
├── Operations Reports
├── Intervention Reports
├── Pricing Reports
├── AdLift Reports
├── Valuation Reports
├── NetPlan Reports
├── Data Quality Reports
├── Model Performance Reports
└── Audit Reports
```

### 9.2 報表行為

- 報表可匯出 CSV、XLSX、PDF。
- 匯出動作需記錄 Audit。
- 高風險報表包含資料快照時間與模型版本。
- 報表不應提供未經核准的操作捷徑。

---

## 10. Workspace 詳細導覽

## 10.1 Executive Workspace

目的：讓管理層看見整體店網狀態、資本配置、重大決策與執行結果。

頁面：

```text
Executive Overview
Network Health
Expansion Priority
Risk Portfolio
Capital Allocation
NetPlan Decisions
Major Approvals
Outcome Review
```

核心卡片：

- Top 10 expansion regions。
- Top 10 red-risk stores。
- NetPlan scenario summary。
- Pending high-value approvals。
- New store realization dashboard。
- Intervention ROI summary。
- Asset valuation portfolio。

## 10.2 Expansion Workspace

目的：將「先找物件」轉成「先找區、再找物件、再做 SiteScore」。

頁面：

```text
HeatZone Map
HeatZone Ranking
Assigned Areas
Listing Inbox
Listing Review
Candidate Site Detail
SiteScore Report
Opening Decision Board
```

主要導覽路徑：

```text
HeatZone Map
→ HeatZone Detail
→ Listing Inbox filtered by HeatZone
→ Candidate Site Detail
→ SiteScore Report
→ Decision Approval
→ Opening Tracking
```

## 10.3 Operations Workspace

目的：讓營運主管與區域督導掌握每家店的未來軌跡、四燈與根因證據。

頁面：

```text
Operations Overview
Store Health Map
Four-Light Alert Center
Forecast Timeline
Store Detail
Root Cause Evidence
SiteScore Realization
```

主要導覽路徑：

```text
Four-Light Alert Center
→ Store Detail
→ Forecast Evidence
→ Recommended Intervention
→ Create Intervention Task
```

## 10.4 Intervention Workspace

目的：統一管理所有營運處置的 Eligibility、Action Set、Approval、Execution、Observation、Outcome。

頁面：

```text
Intervention Inbox
Eligibility Review
Action Builder
Conflict Check
Approval
Execution Tracking
Observation Window
Outcome Review
```

主要導覽路徑：

```text
Alert
→ Intervention Proposal
→ Conflict Check
→ Approval
→ Execution
→ Observation
→ Outcome
→ Label Registry
```

## 10.5 Pricing Workspace

目的：支援安全調價，不讓模型直接改價。

頁面：

```text
Pricing Candidates
Elasticity Evidence
Demand Simulation
Optimization Result
Price Approval
Rollout Monitor
Rollback
```

## 10.6 Marketing / AdLift Workspace

目的：支援廣告投放必要性、對照組、增量毛利與繼續／停止決策。

頁面：

```text
Ad Need Score
Campaign Candidates
Matched Controls
Campaign Detail
Lift Report
iROMI
Continue / Stop Decision
```

## 10.7 Asset / DealRoom Workspace

目的：支援估值、資料室、保留價與交易程序。

頁面：

```text
AVM Queue
Valuation Card
Comparable Stores
Data Room
Reserve Price Review
Transaction Checklist
```

## 10.8 Network Planning Workspace

目的：支援 OPEN / KEEP / IMPROVE / MOVE / EXIT 的整體最佳化方案。

頁面：

```text
Scenario Builder
Constraint Editor
Solver Run
Solver Result
Alternative Plans
Infeasibility Diagnosis
Quarterly Timeline
Executive Approval
Outcome Tracking
```

## 10.9 Learning Workspace

目的：讓 AI／資料團隊治理 Feature、Label、Dataset、Model、Backtest、Drift、Release、Rollback。

頁面：

```text
Data Quality Center
Feature Registry
Label Registry
Dataset Snapshots
Model Registry
Model Card
Backtest Result
Drift Monitor
Release Controller
Rollback Console
```

## 10.10 Franchisee Workspace

目的：讓加盟主看懂與自己門市相關的狀態、建議與決策，不暴露全平台敏感資料。

頁面：

```text
My Store Overview
My Alerts
Recommended Actions
Execution Checklist
Observation Results
Valuation / Network Option
Documents
Support
```

限制：

- 不顯示其他加盟主資料。
- 不顯示模型內部參數。
- 不顯示全品牌競爭策略。
- 可顯示「為何建議」與「下一步需做什麼」。

---

## 11. 資訊層級

所有 Detail 頁面建議使用同一資訊層級：

```text
1. Summary
2. Status
3. Evidence
4. Recommendation
5. Decision
6. Execution / Result
7. Version / Audit
```

### 11.1 Summary

一句話說明此頁重點。例如：

```text
此候選點 SiteScore P50 M12 為 320,000，回本期 P50 為 23 個月，目前建議 WAIT。
```

### 11.2 Status

狀態包含：

- 業務狀態。
- 模型狀態。
- 資料新鮮度。
- 核准狀態。
- Job 狀態。

### 11.3 Evidence

Evidence 需可被人理解：

- 主要正向因子。
- 主要負向因子。
- Comparable。
- Trend。
- Confidence。
- 資料限制。

### 11.4 Recommendation

Recommendation 必須標示：

```text
Generated by system
Policy version
Model version
Generated at
Requires human approval: true / false
```

### 11.5 Decision

Decision 必須區分：

```text
System Prediction
System Recommendation
Human Decision
Execution
Outcome
```

### 11.6 Version / Audit

任何決策頁都需顯示：

- Feature snapshot time。
- Model version。
- Policy version。
- Actor。
- Decision time。
- Reason。
- Override reason。
- Outcome time。

---

## 12. 全域狀態語言

前端應統一顯示以下狀態，不得各模組自創名稱。

### 12.1 Job Status

```text
QUEUED
RUNNING
SUCCEEDED
FAILED
CANCELLED
PARTIAL
RETRYING
EXPIRED
```

### 12.2 Decision Status

```text
DRAFT
SYSTEM_RECOMMENDED
PENDING_REVIEW
APPROVED
REJECTED
OVERRIDDEN
EXECUTED
OBSERVING
OUTCOME_READY
CLOSED
```

### 12.3 Data Status

```text
FRESH
STALE
PARTIAL
MISSING
LOW_CONFIDENCE
FAILED_QA
BLOCKED
```

### 12.4 Model Status

```text
EXPERIMENTAL
CANDIDATE
CHALLENGER
CHAMPION
SHADOW
CANARY
PRODUCTION
DEPRECATED
ROLLED_BACK
BLOCKED
```

---

## 13. 快捷動作

### 13.1 Global Quick Actions

```text
新增候選物件
匯入 Listing
建立 SiteScore 評估
建立營運干預
建立價格方案
建立廣告活動
建立 AVM 估值
建立 NetPlan 情境
建立資料品質事件
建立模型發布請求
```

快捷動作必須受權限控制。

### 13.2 Contextual Actions

每個 Detail 頁應提供 context-aware actions，例如：

| 頁面 | Contextual Actions |
|---|---|
| HeatZone Detail | 指派展店業務、建立 Listing Filter、標記熱區狀態 |
| Candidate Site | 建立 SiteScore、安排現勘、拒絕物件 |
| SiteScore Report | 送審、核准、退回、要求補件 |
| Alert Detail | 建立干預、標記已知事件、要求現場回報 |
| Intervention Detail | 核准、執行、延長觀察窗、關閉 |
| Price Plan | 模擬、送審、核准、Rollback |
| AVM Report | 建立 Data Room、送財務審查、產出估值卡 |
| NetPlan Scenario | 執行 Solver、比較方案、送管理層核准 |
| Model Version | Shadow、Canary、Promote、Rollback |

---

## 14. Empty / Loading / Error IA 原則

### 14.1 Empty State

Empty State 不只顯示「沒有資料」，而要提供下一步。

範例：

```text
目前沒有待審 SiteScore。
你可以：
1. 從 Listing 建立候選點評估。
2. 匯入新的候選物件。
3. 查看已完成審查紀錄。
```

### 14.2 Loading State

Loading State 需分級：

- API 查詢：Skeleton。
- 大型報告：Job progress。
- Solver：顯示 queue / running / elapsed。
- 地圖：顯示 layer loading。
- 模型報告：顯示資料快照與預估完成狀態。

### 14.3 Error State

Error State 必須顯示：

```text
錯誤摘要
錯誤代碼
是否可重試
建議下一步
correlation_id
發生時間
```

禁止只顯示 `Something went wrong`。

---

## 15. LLM 讀取友善規範

本文件與後續 UX 文件供 LLM 與開發者共同使用，因此所有頁面、元件、工作流必須有穩定 ID。

### 15.1 Screen ID

格式：

```text
UX-SCR-{DOMAIN}-{NUMBER}
```

範例：

```text
UX-SCR-EXP-001 HeatZone Map
UX-SCR-OPS-003 Four-Light Alert Center
UX-SCR-ML-006 Model Release Controller
```

### 15.2 Component ID

格式：

```text
UX-CMP-{TYPE}-{NUMBER}
```

範例：

```text
UX-CMP-CARD-001 Decision Summary Card
UX-CMP-TABLE-004 Listing Table
UX-CMP-MAP-002 H3 HeatLayer
```

### 15.3 Flow ID

格式：

```text
UX-FLOW-{DOMAIN}-{NUMBER}
```

範例：

```text
UX-FLOW-SITE-001 Candidate to SiteScore Approval
UX-FLOW-INT-002 Intervention Observation
UX-FLOW-NET-001 NetPlan Scenario Approval
```

---

## 16. 驗收條件

第七批 UX 資訊架構文件完成後，需滿足：

- 所有 ODay Plus 模組都有對應工作區或入口。
- 所有角色都能找到主要任務。
- 任務、通知、搜尋、導覽、Deep Link 規則一致。
- 前端不直接暴露模型內部細節，但可呈現可解釋證據。
- 系統預測、系統建議、人工決策、實際執行、實際結果在資訊架構上分離。
- 所有高風險動作都有核准與稽核入口。
- 所有 Detail 頁有版本與 Audit 區塊。
- 加盟主入口與總部入口具備明確資料隔離。
