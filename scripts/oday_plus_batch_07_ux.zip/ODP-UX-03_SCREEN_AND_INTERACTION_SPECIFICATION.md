---
id: ODP-UX-03
title: 畫面與互動規格
batch: 7
category: UX
doc_type: user-experience
version: 1.0.0
status: draft
formal_deliverable: true
owner: Product Design / Frontend
updated_at: 2026-06-26
depends_on:
  - ODP-UX-01_INFORMATION_ARCHITECTURE_AND_NAVIGATION
  - ODP-UX-02_DESIGN_SYSTEM
  - ODP-SD-06_API_DESIGN_SPECIFICATION
  - ODP-SD-08_WORKFLOW_JOB_AND_STATE_MACHINE_DESIGN
  - ODP-MOD-00_INTEGRATION_LAYER_AND_EXTERNAL_DATA_PLATFORM
  - ODP-MOD-11_OPSBOARD
---

# ODP-UX-03 畫面與互動規格

## 1. 文件目的

本文件定義 ODay Plus 前端主要畫面、互動流程、欄位、按鈕、驗證、狀態、API 對應與事件追蹤。此文件作為 UI 實作、E2E 測試、UAT 與 LLM 生成前端任務的基準。

---

## 2. 畫面命名規則

### 2.1 Screen ID

```text
UX-SCR-{DOMAIN}-{NNN}
```

Domain：

| Domain | 說明 |
|---|---|
| SHELL | 全域殼層 |
| HOME | 首頁 |
| EXP | 展店與選址 |
| OPS | 營運預測 |
| INT | 干預 |
| PRICE | 定價 |
| AD | 廣告 |
| AVM | 估值 |
| NET | 店網規劃 |
| LEARN | 學習治理 |
| AUDIT | 稽核 |
| ADMIN | 管理 |
| FRAN | 加盟主入口 |

### 2.2 Interaction ID

```text
UX-ACT-{DOMAIN}-{NNN}
```

### 2.3 Tracking Event

```text
ui.{domain}.{screen}.{action}
```

範例：

```text
ui.sitescore.report.submit_review
ui.intervention.detail.approve
ui.netplan.scenario.run_solver
```

---

## 3. 全域畫面

## 3.1 UX-SCR-SHELL-001 OpsBoard App Shell

### 目的

提供全平台導覽、角色切換、搜尋、任務與通知入口。

### 主要元件

```text
Global Header
Workspace Switcher
Sidebar
Breadcrumb
Main Content
Right Drawer
Toast
Command Palette
```

### 互動

| Action ID | 操作 | 結果 |
|---|---|---|
| UX-ACT-SHELL-001 | 切換 Workspace | Sidebar 與 Home context 更新 |
| UX-ACT-SHELL-002 | 開啟 Global Search | 顯示搜尋輸入與最近瀏覽 |
| UX-ACT-SHELL-003 | 開啟 Task Center | 顯示本人任務 |
| UX-ACT-SHELL-004 | 開啟 Notifications | 顯示通知清單 |
| UX-ACT-SHELL-005 | 點擊 Environment Badge | 顯示環境與版本資訊 |

### 權限

- 無登入不得進入。
- Workspace 顯示依角色權限。
- Production 環境高風險操作需二次確認。

---

## 3.2 UX-SCR-HOME-001 Role-based Home

### 目的

依使用者角色呈現待辦、風險、核准與系統健康摘要。

### 區塊

```text
My Tasks
Critical Alerts
Pending Approvals
Recent Decisions
Data / Model Health
Quick Actions
```

### 欄位

| 區塊 | 欄位 |
|---|---|
| My Tasks | task_id, type, priority, due_at, status |
| Critical Alerts | store, alert_type, four_light, age, owner |
| Pending Approvals | decision_type, entity, requested_by, risk |
| Data / Model Health | data_status, model_status, last_updated |

### Empty State

```text
目前沒有待辦任務。
可從左側工作區進入 HeatZone、Operations 或 Learning Hub 查看整體狀態。
```

---

## 4. 展店與選址畫面

## 4.1 UX-SCR-EXP-001 HeatZone Map

### 目的

讓展店團隊從全台熱區開始決策，找出優先找店區域。

### Layout

```text
Filter Bar
Map Canvas
Layer Control
Ranking Side Panel
HeatZone Detail Drawer
```

### Filters

```text
行政區
H3 resolution
HeatZone status
Priority rank range
Unmet demand range
ODay G2 fit range
Cannibalization risk
Rent feasibility
Listing availability
Confidence
```

### Map Layers

```text
HeatZone Score
Unmet Demand
ODay G2 Fit
Cannibalization Risk
Rent Feasibility
Existing Stores
Competitor Stores
Candidate Listings
```

### Detail Drawer 欄位

```text
heat_zone_id
admin_area
h3_cell
score
priority_rank
unmet_demand_score
format_fit_score
cannibalization_risk
rent_feasibility
listing_count
status
confidence
last_scored_at
```

### Actions

| Action ID | 操作 | 條件 |
|---|---|---|
| UX-ACT-EXP-001 | 指派展店業務 | 有 Expansion Manager 權限 |
| UX-ACT-EXP-002 | 查看區域 Listing | 熱區有 listing_count > 0 |
| UX-ACT-EXP-003 | 建立物件搜尋任務 | 熱區狀態不是 SATURATED |
| UX-ACT-EXP-004 | 標記熱區狀態 | 需主管權限 |

### API

```text
GET /heatzones/map
GET /heatzones/{heat_zone_id}
POST /heatzones/{heat_zone_id}/assign
PATCH /heatzones/{heat_zone_id}/status
```

### Tracking

```text
ui.exp.heatzone_map.layer_toggle
ui.exp.heatzone_map.open_detail
ui.exp.heatzone_map.assign_area
```

---

## 4.2 UX-SCR-EXP-002 HeatZone Ranking

### 目的

以列表形式比較熱區與排序。

### Columns

```text
rank
heat_zone_name
admin_area
score
unmet_demand_score
format_fit_score
cannibalization_risk
rent_feasibility
listing_count
status
confidence
updated_at
primary_action
```

### Batch Actions

```text
Assign owner
Export CSV
Create listing search tasks
Mark as reviewed
```

### 驗證

- 批次指派需檢查被指派者是否有區域權限。
- 匯出需記錄 Audit。

---

## 4.3 UX-SCR-EXP-003 Listing Inbox

### 目的

管理外部物件來源、人工匯入與合作 feed。

### Filters

```text
source
ingestion_batch
address_parse_status
geocode_status
dedup_status
hard_rule_status
heat_zone_match
review_status
```

### Columns

```text
listing_id
source
address_raw
address_normalized
rent
area
floor
geocode_status
duplicate_group
hard_rule_status
heat_zone
review_status
created_at
```

### Actions

| 操作 | 說明 |
|---|---|
| 匯入 CSV / Excel | 建立 listing ingest job |
| 建立單筆物件 | 人工新增 |
| 執行地址解析 | 觸發 parser job |
| 執行 Geocode | 觸發 geocoder job |
| 合併重複物件 | 選擇 canonical listing |
| 轉為候選點 | 建立 candidate_site |

### API

```text
GET /listings
POST /listings/import
POST /listings
POST /listings/{listing_id}/parse
POST /listings/{listing_id}/geocode
POST /listings/merge
POST /candidate-sites/from-listing
```

---

## 4.4 UX-SCR-EXP-004 Candidate Site Detail

### 目的

呈現候選店址完整資料、可行性、來源與評估狀態。

### Tabs

```text
Summary
Property
Location
Feasibility
Listing History
SiteScore
Audit
```

### Summary 欄位

```text
candidate_site_id
address
geocode_confidence
rent
area
frontage
floor
parking
utilities
heat_zone
source
status
owner
```

### Actions

```text
Edit candidate
Request site visit
Run feasibility check
Run SiteScore
Reject candidate
Add comment
```

### Validation

- 沒有經緯度不可執行 SiteScore。
- 缺少租金不可計算回本期，但可執行部分評估。
- 硬性條件不符合時，SiteScore 可產出但不能建議 GO。

---

## 4.5 UX-SCR-EXP-005 SiteScore Report

### 目的

呈現候選點 ODay G2 開店後營收路徑、風險、證據與決策建議。

### Page Header

```text
Candidate Address
Recommendation Badge: GO / WAIT / REJECT / INVESTIGATE
Report Status
Generated At
Model Version
Feature Snapshot Time
```

### Sections

```text
Decision Summary
Revenue Path
Payback Period
Rent Reasonableness
Cannibalization Risk
Comparable Stores
Key Positive / Negative Factors
Feasibility Rules
Confidence and Data Quality
Human Review
Audit
```

### Revenue Path

顯示：

```text
M1 P10 / P50 / P90
M3 P10 / P50 / P90
M6 P10 / P50 / P90
M12 P10 / P50 / P90
Mature P10 / P50 / P90
```

### Actions

```text
Submit for review
Approve GO
Approve WAIT
Reject
Request site visit
Request data correction
Override recommendation
Export report
```

### Override Form

必填：

```text
override_decision
reason
risk_acknowledgement
approver
attachments_optional
```

### API

```text
GET /sitescore/reports/{report_id}
POST /sitescore/reports/{report_id}/submit-review
POST /sitescore/reports/{report_id}/decisions
POST /sitescore/reports/{report_id}/export
```

### Error States

| 情境 | 訊息 |
|---|---|
| 資料過期 | 此報告使用的 feature snapshot 已過期，請重新評分 |
| 模型停用 | 此模型版本已 deprecated，需重新產生 |
| 硬限制失敗 | 此物件不符合硬性開店條件，不可核准 GO |

---

## 5. 營運預測畫面

## 5.1 UX-SCR-OPS-001 Operations Overview

### 目的

總覽全店網營運健康、四燈分布與未處理風險。

### Components

```text
Store Health Map
Four-Light Distribution
Top Risk Stores
Forecast Accuracy Snapshot
Intervention Outcome Snapshot
Data Freshness
```

### Actions

```text
Open Alert Center
Filter by region
Export operations summary
```

---

## 5.2 UX-SCR-OPS-002 Four-Light Alert Center

### 目的

集中處理綠／黃／橙／紅燈警示。

### Filters

```text
light_status
region
store_age
alert_type
root_cause_candidate
owner
sla_status
intervention_status
```

### Columns

```text
store_id
store_name
region
light_status
alert_started_at
duration
primary_evidence
site_score_gap
recommended_intervention_type
owner
sla_status
primary_action
```

### Actions

```text
Assign owner
Create intervention
Mark as known event
Dismiss with reason
Escalate
```

Dismiss 必填 reason，並保留 Audit。

---

## 5.3 UX-SCR-OPS-003 Store Detail

### Tabs

```text
Overview
Forecast
Four-Light
Root Cause
Transactions
Machines
Interventions
SiteScore Realization
Audit
```

### Overview

顯示：

```text
store_name
brand
region
store_age
format
current_light_status
revenue_rolling_28d
gross_margin_rolling_28d
machine_availability
last_intervention
```

### Forecast Tab

元件：

- Actual vs Forecast。
- P10/P50/P90 band。
- 4w / 8w / 12w / 24w horizon。
- Intervention markers。
- SiteScore baseline。
- Forecast error summary。

### Actions

```text
Create intervention
Open price analysis
Open ad analysis
Open AVM
Add note
```

---

## 5.4 UX-SCR-OPS-004 Root Cause Evidence

### 目的

呈現營收偏離可能原因排序。

### Evidence Types

```text
Revenue residual
Cost unit risk
Equipment availability
Customer experience
Price mismatch
Ad insufficiency
Promotion overlap
External shock
Competitor change
Weather / seasonality
```

### UI

每個 Root Cause Card 顯示：

```text
cause
evidence_strength
supporting_signals
contradicting_signals
data_confidence
recommended_next_check
```

### Action

```text
Create intervention from cause
Request field check
Attach evidence
```

---

## 6. Intervention 畫面

## 6.1 UX-SCR-INT-001 Intervention Inbox

### Columns

```text
intervention_id
store
trigger_source
intervention_type
eligibility_status
conflict_status
approval_status
execution_status
observation_window
owner
```

### Actions

```text
Create intervention
Review eligibility
Approve
Assign
Export
```

---

## 6.2 UX-SCR-INT-002 Intervention Detail

### Sections

```text
Trigger
Eligibility
Action Set
Conflict Check
Approval
Execution
Observation Window
Outcome
Evidence Level
Audit
```

### Actions

```text
Approve intervention
Reject intervention
Edit action set
Start execution
Update execution result
Extend observation window
Close intervention
```

### State Machine

```text
DRAFT
ELIGIBILITY_CHECKED
CONFLICT_CHECKED
PENDING_APPROVAL
APPROVED
EXECUTING
OBSERVING
OUTCOME_READY
EVALUATED
CLOSED
CANCELLED
```

---

## 7. PriceOps 畫面

## 7.1 UX-SCR-PRICE-001 Pricing Candidates

### Purpose

列出適合調價的門市、設備、時段與候選方案。

### Columns

```text
store
machine_type
time_window
current_price
candidate_price
expected_demand_change
expected_gm_change
risk
hard_constraint_status
approval_status
```

### Actions

```text
Open simulation
Create price plan
Batch compare
```

---

## 7.2 UX-SCR-PRICE-002 Pricing Simulation

### Sections

```text
Current price
Candidate price
Demand simulation
Gross margin simulation
Capacity risk
Customer impact
Hard constraints
Rollback plan
```

### Actions

```text
Submit price plan
Approve
Reject
Request revision
```

---

## 8. AdLift 畫面

## 8.1 UX-SCR-AD-001 Campaign Candidate

### Columns

```text
store
ad_need_score
recommended_channel
budget_range
control_match_availability
expected_incremental_gm
risk
```

### Actions

```text
Create campaign
Find controls
Reject candidate
```

## 8.2 UX-SCR-AD-002 Lift Report

### Sections

```text
Campaign Summary
Treatment Stores
Control Stores
Pre-trend Test
Incremental Revenue
Incremental GM
iROMI
Evidence Level
Continue / Stop Recommendation
```

---

## 9. AVM / DealRoom 畫面

## 9.1 UX-SCR-AVM-001 AVM Queue

### Columns

```text
store
trigger_source
valuation_status
data_room_status
gm_ttm
gm_fwd
liquidity_score
finance_owner
```

### Actions

```text
Create valuation
Open valuation card
Request finance review
```

## 9.2 UX-SCR-AVM-002 Valuation Card

### Sections

```text
Valuation Summary
Income Approach
Asset Approach
Market Comparable
P10 / P50 / P90
Fair / Reserve / Asking
Liquidity
Data Room
Finance Approval
Audit
```

### Actions

```text
Approve reserve price
Request adjustment
Generate data room
Export valuation card
```

---

## 10. NetPlan 畫面

## 10.1 UX-SCR-NET-001 Scenario Builder

### Sections

```text
Planning Horizon
Candidate Actions
Budget Constraints
Lease Constraints
Construction Constraints
Equipment Constraints
Cannibalization Constraints
Objective Function
```

### Actions

```text
Save scenario
Run solver
Duplicate scenario
Compare scenarios
```

### Validation

- 必須有 planning horizon。
- Budget hard constraint 不可缺。
- 若選擇 MOVE，需有 candidate destination 或 search constraint。
- 若無可行解，顯示 infeasibility diagnosis。

## 10.2 UX-SCR-NET-002 Solver Result

### Sections

```text
Solver Status
Objective Value
Recommended Actions
Alternative Plans
Binding Constraints
Risk
Quarterly Timeline
Expected Outcomes
Approval
```

### Actions

```text
Approve plan
Reject plan
Request alternative
Export executive report
```

---

## 11. Learning Hub 畫面

## 11.1 UX-SCR-LEARN-001 Data Quality Center

### Columns

```text
source
dataset
status
freshness
completeness
validity
owner
last_check
blocking_models
```

### Actions

```text
Open issue
Acknowledge
Block model run
Trigger recheck
```

## 11.2 UX-SCR-LEARN-002 Model Registry

### Columns

```text
model_id
module
version
stage
champion_status
last_trained
metric_summary
drift_status
release_status
```

### Actions

```text
Open model card
Promote
Shadow
Canary
Rollback
Deprecate
```

## 11.3 UX-SCR-LEARN-003 Model Release Controller

### Sections

```text
Model version
Validation summary
Backtest
Segment performance
Data quality gate
Drift gate
Risk assessment
Approval
Rollback target
```

### Actions

```text
Submit release
Approve shadow
Approve canary
Promote production
Rollback
Reject release
```

---

## 12. Audit 畫面

## 12.1 UX-SCR-AUDIT-001 Decision Log

### Filters

```text
decision_type
actor
module
entity_type
entity_id
decision_status
model_version
date_range
override_only
```

### Columns

```text
decision_id
module
entity
system_recommendation
human_decision
actor
decision_time
model_version
reason
outcome_status
```

### Actions

```text
Open detail
Export evidence
```

## 12.2 UX-SCR-AUDIT-002 Audit Evidence Detail

### Sections

```text
Decision
Source Data Snapshot
Model Version
Policy Version
Actor
Approval Chain
Execution
Outcome
Related Events
Export
```

---

## 13. Admin 畫面

## 13.1 UX-SCR-ADMIN-001 User and Role Management

### 功能

- 使用者列表。
- 角色指派。
- 區域／品牌／門市 scope。
- 權限預覽。
- 停用使用者。
- Audit trail。

## 13.2 UX-SCR-ADMIN-002 Feature Flag Management

### 功能

- 模組開關。
- 高階模型開關。
- 角色分組開關。
- Canary audience。
- Rollback。

---

## 14. 加盟主入口

## 14.1 UX-SCR-FRAN-001 My Store Overview

### 目的

讓加盟主以非技術語言理解自己的門市狀態。

### Sections

```text
目前狀態
營收趨勢
系統提醒
建議處置
執行進度
觀察結果
文件與支援
```

### 禁止顯示

- 其他加盟主資料。
- 全店網策略。
- 模型內部參數。
- 未核准的估值底價。
- 敏感競爭資訊。

## 14.2 UX-SCR-FRAN-002 Recommended Action

### Fields

```text
action_title
why_recommended
what_to_do
expected_observation_period
who_will_help
status
feedback
```

---

## 15. 共用互動規則

### 15.1 Approval Interaction

所有核准類互動需包含：

```text
Decision summary
System recommendation
Evidence
Risks
Required checkbox
Reason field
Confirm button
```

### 15.2 Override Interaction

Override 必須：

- 顯示原系統建議。
- 要求 override reason。
- 要求風險確認。
- 記錄 actor。
- 進入 Audit Log。
- 可被後續 outcome 檢視。

### 15.3 Export Interaction

匯出需：

- 顯示資料範圍。
- 顯示是否含敏感資料。
- 權限檢查。
- 建立 export job。
- 寫入 Audit。

### 15.4 Comment Interaction

Comment 應支援：

- Mention user。
- Attach file。
- Link entity。
- Mark as decision note。
- Audit retention。

---

## 16. 前端事件追蹤

### 16.1 Event 欄位

```yaml
event_name:
user_id:
role:
workspace:
screen_id:
entity_type:
entity_id:
action:
timestamp:
environment:
correlation_id:
```

### 16.2 需要追蹤的事件

```text
screen_view
filter_apply
sort_change
export_request
decision_submit
approval_submit
override_submit
job_create
report_open
model_release_action
map_layer_toggle
```

---

## 17. 驗收條件

- 每個主要模組至少有列表頁與 Detail 頁規格。
- 每個高風險流程有 Approval / Override / Audit 規格。
- 每個畫面可對應 API、Event、權限與 E2E 測試。
- 加盟主入口已與總部入口隔離。
- Job、資料品質、模型版本、決策留痕在畫面上可見。
- 所有錯誤與空狀態均提供下一步。
