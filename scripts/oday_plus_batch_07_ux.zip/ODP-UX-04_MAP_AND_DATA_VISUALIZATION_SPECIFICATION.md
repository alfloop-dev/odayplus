---
id: ODP-UX-04
title: 地圖與資料視覺化規格
batch: 7
category: UX
doc_type: user-experience
version: 1.0.0
status: draft
formal_deliverable: true
owner: Product Design / Data Visualization / Frontend
updated_at: 2026-06-26
depends_on:
  - ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION
  - ODP-MOD-01_HEATZONE_RADAR
  - ODP-MOD-03_SITESCORE
  - ODP-MOD-04_FORECASTOPS
  - ODP-MOD-09_NETPLAN
  - ODP-UX-02_DESIGN_SYSTEM
---

# ODP-UX-04 地圖與資料視覺化規格

## 1. 文件目的

本文件定義 ODay Plus 的地圖、圖表、表格視覺化、預測區間、不確定性、模型證據、店網規劃與稽核資料的呈現規格。

ODay Plus 的視覺化不是一般 BI 圖表，而是要支援業務決策：

```text
哪裡值得開？
哪個點可以開？
哪家店正在偏離？
該做什麼處置？
這個處置是否有效？
這家店值多少？
店網應該如何調整？
這個模型／決策能否被追溯？
```

---

## 2. 視覺化原則

### 2.1 顯示決策，不只顯示資料

每個視覺化都需回答：

```text
使用者要根據此圖做什麼？
此圖是否顯示足夠證據？
是否有明確下一步？
```

### 2.2 顯示不確定性

預測、估值、效果估計都不得只顯示單點值。必須顯示：

- P10 / P50 / P90。
- Confidence。
- Coverage。
- Sample size。
- Data freshness。
- Model version。

### 2.3 地圖不是唯一入口

所有地圖資訊必須有列表替代。原因：

- 可及性。
- 大量資料時更容易比較。
- 使用者可能不熟悉地圖操作。
- 匯出與稽核需要表格式資料。

### 2.4 顏色不是唯一訊息

風險狀態需同時以：

- 顏色。
- 文字。
- Icon。
- Pattern。
- Tooltip。

呈現。

---

## 3. 地圖系統

### 3.1 地圖技術

建議前端：

```text
MapLibre GL JS
deck.gl
H3-js
Turf.js
Supercluster
```

後端資料：

```text
PostGIS
BigQuery GIS
H3 index
GeoJSON / Vector Tiles
```

### 3.2 Basemap

支援：

```text
light
dark
minimal
satellite_optional
print_safe
```

預設使用 minimal，避免干擾 HeatZone 與 Listing layer。

### 3.3 地圖層級

```text
Taiwan Overview
Region / City
District
HeatZone / H3
Service Area
Candidate Site
Store / Machine
```

### 3.4 H3 Resolution

H3 resolution 不直接固定於全台所有區域，需依場景調整。

| 場景 | 建議 |
|---|---|
| 全台熱區 | 較粗 resolution，避免過細造成噪音 |
| 都會區比較 | 中 resolution |
| 候選點周邊 | 細 resolution 或等時圈 |
| 樣本不足 | 可向父層 H3 fallback |
| 地圖效能 | 依 zoom level 動態切換 |

### 3.5 地圖效能要求

- 初次載入 Taiwan overview ≤ 3 秒。
- 單層 H3 cell 建議不超過前端一次渲染上限。
- 超大量 layer 使用 tile / server-side aggregation。
- Listing marker 使用 cluster。
- Store marker 依 zoom level 聚合。
- Tooltip 採 lazy fetch 詳細資料。

---

## 4. HeatZone Map

### 4.1 UX-VIZ-MAP-001 HeatZone Score Layer

### 用途

呈現全台每個 H3 cell 或區域格網的展店優先度。

### Data

```text
heat_zone_id
h3_index
score
priority_rank
unmet_demand_score
format_fit_score
cannibalization_risk
rent_feasibility
listing_availability
confidence
status
last_scored_at
```

### Visual Encoding

| 欄位 | 呈現 |
|---|---|
| score | sequential heat scale |
| priority_rank | label / side ranking |
| confidence | opacity / border pattern |
| status | badge / hatch pattern |
| stale data | warning overlay |
| selected cell | strong border |

### Tooltip

```text
熱區：{name}
排名：#{priority_rank}
HeatZone Score：{score}
未滿足需求：{unmet_demand_score}
ODay G2 適配：{format_fit_score}
自家稀釋風險：{cannibalization_risk}
租金可行性：{rent_feasibility}
信心水準：{confidence}
資料時間：{last_scored_at}
```

### Click Behavior

點擊 cell 開啟 HeatZone Detail Drawer。

### Legend

Legend 必須顯示：

- 分數區間。
- Confidence 解釋。
- 狀態圖案。
- 最後更新時間。

---

## 5. Listing Map

### 5.1 UX-VIZ-MAP-002 Candidate Listing Layer

### 用途

呈現熱區內潛在出租物件。

### Marker 狀態

```text
RAW
PARSED
GEOCODED
DUPLICATE
FAILED_HARD_RULE
CANDIDATE
SCORED
REJECTED
```

### Marker Tooltip

```text
地址
租金
坪數
來源
Geocode confidence
Hard rule status
HeatZone match
```

### Cluster Behavior

- Zoom out：cluster。
- Zoom in：individual marker。
- Cluster click：zoom to bounds。
- Marker click：Candidate Site preview drawer。

### Filtering

```text
source
rent_range
area_range
hard_rule_status
geocode_confidence
heat_zone_score
review_status
```

---

## 6. SiteScore Visualization

### 6.1 UX-VIZ-CHART-001 Revenue Path Fan Chart

### 用途

顯示候選店址 M1/M3/M6/M12/成熟期營收路徑與不確定性。

### Data

```text
horizon
p10
p50
p90
mature_expected
confidence
```

### Visual

- X-axis：M1 / M3 / M6 / M12 / Mature。
- Y-axis：Monthly revenue。
- P50 line。
- P10-P90 band。
- Optional comparable store actual lines。

### Tooltip

```text
月份：M6
P10：...
P50：...
P90：...
主要不確定來源：...
```

### Rules

- 不可只顯示 P50。
- 若 confidence 低，圖表上方需顯示 warning。
- 若資料過期，圖表需標示 stale。

### 6.2 UX-VIZ-CHART-002 Payback Distribution

### 用途

顯示回本期區間，不只單一月數。

### Visual

- Histogram 或 interval bar。
- P50 marker。
- 可接受門檻線。
- 租金敏感度 toggle。

### 6.3 UX-VIZ-COMP-001 Comparable Stores

### 用途

比較候選點與相似店。

### 呈現

```text
Map markers
Comparable table
Similarity score
Same-age comparison
Mature comparison
Revenue path overlay
```

### Comparable 必備欄位

```text
store_id
distance
location_type
format_similarity
machine_mix_similarity
store_age
revenue_m3
revenue_m6
revenue_m12
similarity_score
```

---

## 7. ForecastOps Visualization

### 7.1 UX-VIZ-CHART-003 Store Forecast Band

### 用途

呈現單店歷史實績與未來 4/8/12/24 週預測。

### Data

```text
date
actual_revenue
forecast_p10
forecast_p50
forecast_p90
intervention_marker
site_score_baseline
```

### Visual

- Actual line。
- Forecast P50 line。
- P10-P90 band。
- SiteScore baseline line。
- Intervention markers。
- Anomaly markers。

### Controls

```text
horizon: 4w / 8w / 12w / 24w
metric: revenue / gross_margin / transactions / utilization
granularity: daily / weekly
show_site_score_baseline
show_interventions
show_weather
```

### 7.2 UX-VIZ-CHART-004 SiteScore Realization

### 用途

比較開店前 SiteScore 預測與實際營運。

### Visual

- Baseline predicted path。
- Actual path。
- Realization ratio line。
- M1/M3/M6/M12 checkpoints。
- Flag if under-realized。

### 7.3 UX-VIZ-CHART-005 Four-Light Trend

### 用途

顯示單店四燈歷史變化。

### Visual

- Timeline strip。
- Green / Yellow / Orange / Red states。
- Hover 顯示當時觸發條件。
- Click 可進入該次 alert。

### 7.4 UX-VIZ-COMP-002 Root Cause Evidence Vector

### 用途

將多來源證據整合成根因候選排序。

### Visual

```text
Cause cards
Evidence strength bars
Supporting / contradicting signal chips
Confidence indicator
```

### Cause Categories

```text
Revenue Residual
Store-age Ramp
Seasonality
Equipment Availability
Cost Unit
Customer Experience
Price
Ad
Promotion
Competitor
External Shock
```

---

## 8. Intervention Visualization

### 8.1 UX-VIZ-CHART-006 Intervention Timeline

### 用途

呈現干預從建立到觀察結果成熟的全流程。

### Timeline Nodes

```text
Triggered
Eligibility checked
Action built
Conflict checked
Approved
Executed
Observation started
Outcome collected
Effect evaluated
Closed
```

### 8.2 UX-VIZ-CHART-007 Before / After with Control

### 用途

呈現干預前後與對照組差異。

### Visual

- Treatment actual。
- Control actual。
- Intervention start。
- Observation window。
- Difference indicator。
- Evidence Level。

### Rules

- 若無對照組，不得宣稱因果。
- 若 Pre-trend failed，需顯示警示。
- 若重疊干預存在，需標示 contamination。

---

## 9. PriceOps Visualization

### 9.1 UX-VIZ-CHART-008 Demand Curve

### 用途

呈現價格與需求／毛利關係。

### Visual

- Price on X-axis。
- Expected demand on left Y-axis。
- Expected gross margin on right Y-axis。
- Candidate price markers。
- Hard constraint boundaries。
- Safe action zone shading。

### Rules

- Hard constraint violation 必須明顯顯示。
- 現行價格與候選價格需同時呈現。
- 不支援自動執行，只支援人工核准。

### 9.2 UX-VIZ-TABLE-001 Pricing Plan Comparison

Columns：

```text
Plan
Price Change
Expected Demand
Expected Revenue
Expected Gross Margin
Risk
Constraint Status
Rollback Plan
Approval Status
```

---

## 10. AdLift Visualization

### 10.1 UX-VIZ-CHART-009 Treatment vs Control Trend

### 用途

呈現廣告投放店與對照店在投放前後的趨勢。

### Visual

- Treatment group line。
- Control group line。
- Campaign start/end markers。
- Pre-period and post-period shading。
- Pre-trend status badge。

### 10.2 UX-VIZ-CHART-010 Incrementality Waterfall

### 用途

拆解廣告效益。

```text
Observed Revenue Change
- Baseline Trend
- Seasonality
- Control Change
= Incremental Revenue
- Incremental Cost
= Incremental Gross Margin
```

### 10.3 UX-VIZ-CARD-001 iROMI Card

欄位：

```text
incremental_gross_margin
ad_spend
iromi
confidence
evidence_level
recommendation
```

---

## 11. DealRoomAVM Visualization

### 11.1 UX-VIZ-CHART-011 Valuation Range

### 用途

呈現 Fair / Reserve / Asking 的關係。

### Visual

- Horizontal range bar。
- P10 / P50 / P90 markers。
- Reserve price marker。
- Asking price marker。
- Comparable transaction markers if available。

### 11.2 UX-VIZ-CHART-012 Valuation Lens Comparison

### 用途

比較 Income / Asset / Market 三鏡頭。

### Visual

```text
Income Approach range
Asset Approach range
Market Comparable range
Final blended range
```

### 11.3 UX-VIZ-COMP-003 Data Room Completeness

### 用途

呈現估值資料室完整度。

Categories：

```text
Financial
Asset
Lease
Maintenance
Photos
Legal
Operations
Model Reports
```

狀態：

```text
complete
partial
missing
blocked
```

---

## 12. NetPlan Visualization

### 12.1 UX-VIZ-CHART-013 Network Scenario Map

### 用途

在地圖上呈現 OPEN / KEEP / IMPROVE / MOVE / EXIT 方案。

### Encoding

| Action | Marker / Pattern |
|---|---|
| OPEN | new store marker |
| KEEP | stable marker |
| IMPROVE | wrench / improvement marker |
| MOVE | arrow from old to new |
| EXIT | exit marker |
| HOLD | gray marker |

### Layers

```text
Existing stores
Candidate stores
Recommended actions
Cannibalization zones
Budget regions
Lease risk
```

### 12.2 UX-VIZ-CHART-014 Quarterly Timeline

### 用途

呈現 8-12 季的店網行動時序。

### Visual

- Gantt chart。
- Store rows。
- Quarter columns。
- Action bars。
- Dependency markers。
- Lease deadline vertical lines。
- Budget usage summary。

### 12.3 UX-VIZ-CHART-015 Constraint Utilization

### 用途

呈現資本、人力、施工、租約等限制使用程度。

### Visual

```text
Budget usage
Construction capacity
Equipment availability
Field team capacity
Lease deadlines
Cannibalization constraints
```

### 12.4 UX-VIZ-COMP-004 Infeasibility Diagnosis

當 Solver 無可行解，顯示：

```text
violated_constraint
affected_stores
required_relaxation
business_impact
suggested_action
```

UI 不應自動放寬限制。

---

## 13. Learning Hub Visualization

### 13.1 UX-VIZ-CHART-016 Model Performance Trend

Metrics：

```text
MAPE
MAE
RMSE
Coverage
Calibration
Segment error
Drift score
```

### Visual

- Metric line over model versions。
- Champion / Challenger markers。
- Release events。
- Rollback events。

### 13.2 UX-VIZ-CHART-017 Calibration Plot

用於：

- SiteScore P80/P90 coverage。
- Forecast P10/P90 interval。
- AVM valuation range coverage。

### 13.3 UX-VIZ-CHART-018 Drift Monitor

顯示：

```text
feature_name
drift_score
threshold
affected_model
severity
last_checked
```

### 13.4 UX-VIZ-COMP-005 Dataset Snapshot Lineage

呈現：

```text
Raw Sources
Canonical Tables
Model-ready Views
Dataset Snapshot
Training Run
Model Version
Prediction
Decision
Outcome
```

---

## 14. Audit Visualization

### 14.1 UX-VIZ-TIMELINE-001 Decision Audit Timeline

每個 Decision Detail 顯示：

```text
Prediction generated
Recommendation generated
Human review requested
Human decision submitted
Execution started
Outcome observed
Feedback written to label registry
```

### 14.2 UX-VIZ-TABLE-002 Evidence Export Table

欄位：

```text
decision_id
entity
model_version
feature_snapshot_time
actor
decision_time
execution_status
outcome_status
audit_status
```

---

## 15. Chart Interaction Rules

### 15.1 Tooltip

Tooltip 應包含：

- 數值。
- 單位。
- 時間。
- 資料來源。
- 模型版本，如相關。
- 不確定性，如相關。

### 15.2 Brush and Zoom

時序圖應支援：

- Brush。
- Zoom reset。
- Date range quick select。
- Export current view。

### 15.3 Drill-down

圖表 drill-down 必須可追溯：

```text
KPI → Store List → Store Detail → Evidence → Decision Log
```

### 15.4 Export

視覺化匯出需支援：

```text
PNG
CSV underlying data
PDF report section
```

匯出需記錄 Audit。

---

## 16. 資料品質顯示規則

每個視覺化右上角顯示 Data Badge：

```text
FRESH
STALE
PARTIAL
LOW_CONFIDENCE
FAILED_QA
```

點擊 Data Badge 顯示：

```text
source
snapshot_time
ingested_at
quality_checks
known_limitations
```

---

## 17. 隱私與敏感資料

### 17.1 加盟主視圖

不可顯示：

- 其他加盟主營收。
- 全店網競爭策略。
- 詳細模型內部權重。
- 競品敏感資料。
- 未核准的底價或交易資訊。

### 17.2 內部視圖

敏感資料顯示需依權限遮罩：

```text
Full
Masked
Aggregated
Hidden
```

### 17.3 匯出限制

高敏感資料匯出需：

- 二次確認。
- 理由。
- Audit。
- Watermark。
- Expiration link if applicable。

---

## 18. 驗收條件

- HeatZone、Listing、SiteScore、ForecastOps、InterventionOps、PriceOps、AdLift、AVM、NetPlan、Learning Hub 都有視覺化規格。
- 所有預測與估值都顯示不確定性。
- 地圖視覺化有列表替代。
- 四燈與風險不只靠顏色表達。
- 所有圖表可顯示資料時間與模型版本。
- Solver 無可行解時有診斷視覺化。
- 干預與廣告效果圖表不在 Evidence 不足時宣稱因果。
- 視覺化匯出與敏感資料處理符合稽核要求。
