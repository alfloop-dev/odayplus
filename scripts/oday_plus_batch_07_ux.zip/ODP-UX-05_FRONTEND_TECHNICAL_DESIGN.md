---
id: ODP-UX-05
title: 前端技術設計
batch: 7
category: UX
doc_type: user-experience
version: 1.0.0
status: draft
formal_deliverable: true
owner: Frontend Engineering
updated_at: 2026-06-26
depends_on:
  - ODP-SD-04_REPOSITORY_AND_CODE_MODULE_DESIGN
  - ODP-SD-06_API_DESIGN_SPECIFICATION
  - ODP-SD-07_EVENT_AND_MESSAGE_CONTRACTS
  - ODP-SD-09_IDENTITY_SECURITY_AND_PRIVACY_DESIGN
  - ODP-UX-01_INFORMATION_ARCHITECTURE_AND_NAVIGATION
  - ODP-UX-02_DESIGN_SYSTEM
  - ODP-UX-03_SCREEN_AND_INTERACTION_SPECIFICATION
  - ODP-UX-04_MAP_AND_DATA_VISUALIZATION_SPECIFICATION
---

# ODP-UX-05 前端技術設計

## 1. 文件目的

本文件定義 ODay Plus 前端技術架構、專案結構、路由、狀態管理、API client、RBAC、Feature Flag、地圖與圖表整合、測試、效能、可觀測性與發布策略。

前端技術目標：

- 支援完整 OpsBoard。
- 支援多角色、多模組、多工作流。
- 支援地圖、表格、圖表、報告、核准、稽核。
- 與 OpenAPI / AsyncAPI / Event / Job 狀態一致。
- 不將模型或決策邏輯寫死在前端。
- 支援 LLM 後續產生頁面與元件任務。

---

## 2. 技術選型

### 2.1 Core Stack

```text
React
Next.js
TypeScript
Vite optional for isolated packages
TanStack Query
TanStack Table
Zustand or Jotai for local UI state
React Hook Form
Zod
MapLibre GL JS
deck.gl
ECharts or Apache ECharts
OpenAPI generated client
Playwright
Vitest
Storybook
```

### 2.2 Styling

建議：

```text
CSS Variables for design tokens
Tailwind CSS optional
CSS Modules optional
Radix UI / Ariakit for accessible primitives
```

若使用 Tailwind，顏色不可直接使用任意色碼，需映射 Design Tokens。

### 2.3 Map

```text
MapLibre GL JS
deck.gl
h3-js
supercluster
turf
```

### 2.4 Charts

```text
ECharts
Custom SVG for specialized visualizations
Canvas for dense timeline if needed
```

### 2.5 Codegen

```text
OpenAPI → TypeScript API Client
AsyncAPI → Event type definitions
Zod Schema → Runtime validation
```

---

## 3. Repository Structure

建議在 monorepo 下管理前端：

```text
oday-plus/
├── apps/
│   └── web/
│       ├── app/
│       ├── components/
│       ├── features/
│       ├── layouts/
│       ├── routes/
│       ├── styles/
│       ├── middleware.ts
│       └── next.config.ts
├── packages/
│   ├── ui/
│   ├── design-tokens/
│   ├── api-client/
│   ├── domain-types/
│   ├── auth/
│   ├── maps/
│   ├── charts/
│   ├── forms/
│   ├── audit-client/
│   └── testing/
└── docs/
```

### 3.1 Feature Structure

```text
features/
├── shell/
├── home/
├── tasks/
├── notifications/
├── search/
├── expansion/
├── listing/
├── sitescore/
├── operations/
├── intervention/
├── priceops/
├── adlift/
├── avm/
├── netplan/
├── learninghub/
├── audit/
├── admin/
└── franchisee/
```

### 3.2 每個 feature 內部

```text
feature/
├── api/
├── components/
├── hooks/
├── pages/
├── routes.ts
├── schemas.ts
├── types.ts
├── permissions.ts
├── tracking.ts
└── __tests__/
```

---

## 4. Routing Design

### 4.1 Route Groups

```text
/
├── /home
├── /tasks
├── /notifications
├── /search
├── /expansion
├── /operations
├── /interventions
├── /pricing
├── /adlift
├── /avm
├── /netplan
├── /learning
├── /audit
├── /admin
└── /franchisee
```

### 4.2 Detail Routes

```text
/stores/[storeId]
/heatzones/[heatZoneId]
/listings/[listingId]
/candidates/[candidateSiteId]
/sitescore/reports/[reportId]
/alerts/[alertId]
/interventions/[interventionId]
/pricing/plans/[planId]
/adlift/reports/[reportId]
/avm/reports/[valuationId]
/netplan/scenarios/[scenarioId]
/learning/models/[modelId]/versions/[version]
/audit/decisions/[decisionId]
```

### 4.3 Route Metadata

每個 route 定義：

```ts
type RouteMeta = {
  routeId: string;
  title: string;
  workspace: WorkspaceId;
  requiredPermissions: Permission[];
  requiredFeatureFlags?: FeatureFlag[];
  breadcrumb: BreadcrumbSpec;
  auditPageView?: boolean;
};
```

---

## 5. Authentication and Authorization

### 5.1 Auth Flow

支援：

```text
OIDC / OAuth2
JWT access token
refresh token
server-side session optional
```

### 5.2 RBAC / ABAC

前端權限只用於顯示與操作限制；最終權限由後端判斷。

前端需支援：

```text
role
permission
tenant_scope
brand_scope
region_scope
store_scope
module_scope
```

### 5.3 Permission Guard

```ts
<PermissionGuard
  permission="sitescore.decision.approve"
  scope={{ storeId, regionId }}
  fallback={<ReadOnlyNotice />}
/>
```

### 5.4 Data Masking

前端根據 API 回傳的 field permission 顯示：

```text
visible
masked
hidden
aggregated
```

禁止前端自行假設敏感欄位可見。

---

## 6. API Client

### 6.1 OpenAPI Client

API client 由 OpenAPI 產生。

```text
packages/api-client
├── generated/
├── interceptors/
├── errors/
├── queryKeys/
└── clients/
```

### 6.2 Interceptors

每個 request 加入：

```text
Authorization
X-Correlation-ID
X-Request-ID
X-Client-Version
X-Workspace
```

### 6.3 Error Handling

API Error 需標準化：

```ts
type ApiError = {
  code: string;
  message: string;
  details?: unknown;
  correlation_id: string;
  retryable: boolean;
  field_errors?: FieldError[];
};
```

### 6.4 Query Keys

TanStack Query key 必須穩定：

```ts
['sitescoreReport', reportId]
['storeForecast', storeId, horizon, metric]
['heatzoneMap', filters]
['tasks', filters]
['modelVersion', modelId, version]
```

### 6.5 Mutation Pattern

Mutation 後：

- 顯示 optimistic feedback only if safe。
- 高風險操作不得 optimistic update。
- 成功後 invalidate relevant queries。
- 建立 Audit 的操作需顯示 decision_id 或 job_id。

---

## 7. State Management

### 7.1 Server State

使用 TanStack Query：

- API data。
- List filters with URL sync。
- Job status polling。
- Report data。
- Model registry data。

### 7.2 Local UI State

使用 Zustand / Jotai：

- Sidebar collapsed。
- Drawer open。
- Map layer visibility。
- Table column visibility。
- Command palette。
- User preferences。

### 7.3 URL State

以下狀態需與 URL 同步：

```text
filters
sort
page
selected tab
map viewport if shareable
selected entity
date range
```

### 7.4 Form State

使用 React Hook Form + Zod：

- Approval forms。
- Override forms。
- Scenario builder。
- Listing import mapping。
- Price plan forms。

---

## 8. Feature Flag

### 8.1 Flag Types

```text
module flag
screen flag
action flag
model flag
advanced feature flag
role rollout flag
canary flag
```

### 8.2 Example Flags

```text
feature.heatzone.enabled
feature.sitescore.enabled
feature.forecastops.enabled
feature.priceops.enabled
feature.adlift.enabled
feature.avm.enabled
feature.netplan.enabled
feature.learninghub.model_release.enabled
feature.advanced.bandit.enabled
feature.advanced.robust_netplan.enabled
```

### 8.3 Rules

- Flag 關閉時 route 不顯示。
- Deep link 進入關閉功能時顯示 FeatureUnavailable。
- Production 中高階模型功能預設需 Gate 才可啟用。
- Flag 狀態需記錄到 page telemetry。

---

## 9. Component Architecture

### 9.1 UI Package

```text
packages/ui/
├── Button
├── Badge
├── Card
├── Table
├── Form
├── Modal
├── Drawer
├── Tabs
├── Timeline
├── Toast
├── Tooltip
├── CommandPalette
├── DataStatusBadge
├── ModelVersionBadge
├── ApprovalPanel
├── AuditMetadata
└── EmptyState
```

### 9.2 Domain Components

```text
packages/ui-domain/
├── HeatZoneScoreCard
├── CandidateSiteCard
├── SiteScoreReportSummary
├── ForecastBandChart
├── FourLightBadge
├── RootCauseEvidenceCard
├── InterventionTimeline
├── PricingPlanComparison
├── AdLiftReportCard
├── ValuationRangeChart
├── NetPlanScenarioCard
├── ModelReleaseCard
└── DecisionAuditTimeline
```

### 9.3 Component Contract

每個 component 文件需包含：

```text
Purpose
Props
State
Events
Permissions
Accessibility
Testing
Examples
```

---

## 10. Map Architecture

### 10.1 Map Package

```text
packages/maps/
├── MapShell
├── LayerRegistry
├── HeatZoneLayer
├── ListingLayer
├── StoreLayer
├── CompetitorLayer
├── ServiceAreaLayer
├── NetPlanActionLayer
├── MapTooltip
├── MapLegend
├── useMapFilters
└── useMapViewport
```

### 10.2 Layer Registry

```ts
type MapLayerSpec = {
  id: string;
  name: string;
  module: string;
  defaultVisible: boolean;
  minZoom?: number;
  maxZoom?: number;
  requiredPermissions?: Permission[];
  dataSource: 'api' | 'tile' | 'client';
};
```

### 10.3 Performance

- Use vector tiles for dense H3 layers。
- Use clustering for listings。
- Lazy load layer data。
- Memoize deck.gl layers。
- Avoid re-rendering map on sidebar state change。
- Use worker for heavy geometry processing if needed。

---

## 11. Chart Architecture

### 11.1 Chart Package

```text
packages/charts/
├── ForecastBandChart
├── RevenuePathFanChart
├── PaybackDistribution
├── FourLightTimeline
├── DemandCurve
├── TreatmentControlTrend
├── IncrementalityWaterfall
├── ValuationRangeChart
├── QuarterlyTimeline
├── ConstraintUtilization
├── CalibrationPlot
└── DriftMonitorChart
```

### 11.2 Chart Props Pattern

```ts
type ChartProps<TData> = {
  data: TData[];
  loading?: boolean;
  error?: ApiError;
  emptyState?: EmptyStateConfig;
  height?: number;
  onPointClick?: (point: TData) => void;
  showLegend?: boolean;
  exportable?: boolean;
};
```

### 11.3 Chart Data Quality

每個 chart 接收：

```ts
dataQuality?: {
  status: DataStatus;
  snapshotTime: string;
  sources: string[];
  warnings: string[];
};
```

---

## 12. Job and Workflow Handling

### 12.1 Job Polling

Job 類型：

```text
sitescore_score
heatzone_batch_score
listing_import
forecast_batch_score
pricing_optimization
adlift_estimation
avm_report
netplan_solver
model_training
model_backtest
export_report
```

### 12.2 Job Hook

```ts
useJobStatus(jobId, {
  pollInterval,
  stopWhen: ['SUCCEEDED', 'FAILED', 'CANCELLED', 'PARTIAL'],
});
```

### 12.3 Long-running UX

- 建立 Job 後回傳 job_id。
- 顯示 Job status panel。
- 可離開頁面。
- 完成後通知。
- 失敗時可查看 error detail 與 correlation_id。
- Retry 需權限。

---

## 13. Forms and Validation

### 13.1 Approval Form Schema

```ts
const approvalSchema = z.object({
  decision: z.enum(['APPROVE', 'REJECT', 'REQUEST_REVISION']),
  reason: z.string().min(10),
  riskAcknowledged: z.boolean(),
  attachments: z.array(fileSchema).optional(),
});
```

### 13.2 Override Form Schema

```ts
const overrideSchema = z.object({
  overrideDecision: z.string(),
  originalRecommendation: z.string(),
  reason: z.string().min(20),
  riskAcknowledged: z.literal(true),
});
```

### 13.3 Import Mapping Form

支援：

- 欄位 mapping。
- 型別檢查。
- 預覽前 50 筆。
- 錯誤列下載。
- Dry-run。
- Commit。

---

## 14. Audit and Telemetry

### 14.1 Page View Event

```ts
track('ui.screen.view', {
  screen_id,
  workspace,
  route,
  role,
  entity_type,
  entity_id,
});
```

### 14.2 Action Event

```ts
track('ui.action.submit', {
  action_id,
  screen_id,
  entity_type,
  entity_id,
  decision_type,
  correlation_id,
});
```

### 14.3 Error Event

```ts
track('ui.error', {
  screen_id,
  error_code,
  correlation_id,
  retryable,
});
```

### 14.4 Audit vs Telemetry

Telemetry 用於產品分析，不可取代 Audit Log。以下操作必須呼叫後端建立正式 Audit：

```text
approval
override
export
permission change
model release
rollback
data quality override
price approval
netplan approval
valuation approval
```

---

## 15. Error Boundary

### 15.1 Levels

```text
App-level Error Boundary
Workspace-level Error Boundary
Page-level Error Boundary
Component-level Error Boundary
```

### 15.2 Error UI

顯示：

```text
錯誤摘要
可重試按鈕
返回安全頁
correlation_id
copy diagnostics
```

### 15.3 Degraded Mode

若部分服務不可用：

- 地圖失敗但列表可用。
- 圖表失敗但表格可用。
- 模型報告失敗但歷史報告可讀。
- Notification 失敗不阻擋主要流程。

---

## 16. Performance

### 16.1 Targets

| 項目 | 目標 |
|---|---|
| App shell first usable | ≤ 3 秒 |
| Route transition | ≤ 1 秒 |
| Table first page | ≤ 2 秒 |
| Map initial layer | ≤ 3 秒 |
| Detail page critical content | ≤ 2 秒 |
| Large report job creation | ≤ 1 秒回傳 job_id |

### 16.2 Techniques

- Route-level code splitting。
- Lazy load map / chart packages。
- Virtualized tables。
- Server-side pagination。
- Prefetch likely detail pages。
- Cache static dictionaries。
- Avoid large JSON in initial page。
- Use compressed responses。
- Use CDN for static assets。

---

## 17. Testing Strategy

### 17.1 Unit Tests

- Utility functions。
- Formatters。
- Permission helpers。
- Zod schemas。
- Query key factories。

### 17.2 Component Tests

- Button / Badge / Card。
- Approval panel。
- Data status badge。
- FourLightBadge。
- ModelVersionBadge。
- Table filters。
- Form validation。

### 17.3 Integration Tests

- Listing import dry-run。
- SiteScore submit review。
- Alert to Intervention。
- Price approval。
- NetPlan run solver。
- Model release rollback。

### 17.4 E2E Tests

使用 Playwright。

關鍵 flows：

```text
HeatZone → Listing → Candidate → SiteScore → Approval
Store Alert → Intervention → Execution → Observation → Outcome
Pricing Candidate → Simulation → Approval → Rollback
Ad Campaign → Controls → Lift Report → Continue / Stop
AVM → Data Room → Valuation Approval
NetPlan Scenario → Solver → Alternative Plan → Approval
Model Version → Shadow → Canary → Production → Rollback
```

### 17.5 Visual Regression

Storybook + screenshot testing：

- Core components。
- Domain cards。
- Charts。
- Maps static fixtures。
- Light / dark / high-contrast themes。

---

## 18. Accessibility Testing

Required:

- axe automated scan。
- Keyboard navigation test。
- Screen reader spot check。
- Color contrast test。
- Chart data table fallback。
- Map list fallback。

---

## 19. Security Frontend Concerns

### 19.1 Token Handling

- 不將 token 存入 localStorage，除非安全架構明確允許。
- 優先使用 httpOnly cookie 或安全 session。
- Refresh token 由 auth layer 管理。

### 19.2 XSS

- 不使用 unsafe HTML。
- Markdown rendering 需 sanitize。
- User comments sanitize。
- External links rel noopener。

### 19.3 CSRF

若使用 cookie auth，需 CSRF token 或 SameSite strategy。

### 19.4 Sensitive Data

- 不在 client log 印出敏感資料。
- 不在 telemetry 傳送個資或完整地址，除非已授權。
- 匯出需後端授權，前端不可自行組完整敏感報表。

---

## 20. Build and Release

### 20.1 CI

```text
lint
typecheck
unit test
component test
build
storybook build
visual regression
e2e smoke
dependency scan
bundle analysis
```

### 20.2 Environment

```text
development
staging
production
```

### 20.3 Environment Config

```text
API_BASE_URL
AUTH_ISSUER
FEATURE_FLAG_URL
MAP_TILE_URL
SENTRY_DSN or observability endpoint
APP_ENV
APP_VERSION
```

### 20.4 Release

- Production release 需 tag。
- App version 顯示於 User Menu。
- Feature flags 可控制功能開關。
- Rollback 至前一版靜態 asset / Cloud Run revision。
- API breaking change 不可直接上 production。

---

## 21. LLM-friendly Development Tasks

前端任務應以穩定格式描述：

```yaml
task_id:
screen_id:
component_id:
feature:
route:
api_dependencies:
permissions:
states:
acceptance_criteria:
test_cases:
```

範例：

```yaml
task_id: FE-EXP-001
screen_id: UX-SCR-EXP-001
feature: expansion
route: /expansion/heatzones
api_dependencies:
  - GET /heatzones/map
  - GET /heatzones/{heat_zone_id}
permissions:
  - heatzone.read
states:
  - loading
  - empty
  - loaded
  - error
acceptance_criteria:
  - 使用者可以切換 HeatZone Score 與 Cannibalization Risk 圖層
  - 點擊 H3 cell 開啟 Detail Drawer
  - 無權限使用者不得看到指派按鈕
test_cases:
  - map layer toggle
  - drawer open
  - permission hidden action
```

---

## 22. 驗收條件

- 前端專案結構可支援所有 ODay Plus 模組。
- OpenAPI client、RBAC、Feature Flag、Job polling、Audit interaction 有一致實作模式。
- 地圖與圖表可延遲載入並滿足效能要求。
- 高風險操作不可 optimistic update。
- 所有錯誤有 correlation_id 呈現。
- 所有主要 workflow 有 E2E 測試規劃。
- 前端不直接實作模型決策邏輯。
- 任何敏感資料顯示與匯出皆依後端授權。
