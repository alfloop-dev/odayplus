---
doc_id: ODP-DATA-01
title: "資料來源盤點與資料責任表"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus 資料來源盤點與資料責任表

## 1. 文件目的

本文件定義 ODay Plus 全平台所需資料來源、責任人、取得方式、更新頻率、歷史長度、資料品質、授權限制、SLA、風險與最低可用條件。它是後續 `ODP-DATA-02` 到 `ODP-DATA-07` 的總入口。

ODay Plus 的設計原則是：上游 IoT 與內部資料底座只提供事實資料與事件；本平台透過 Integration Layer、Canonical Data Model、Model-ready Views 將其轉成可供 HeatZone、Listing、SiteScore、ForecastOps、InterventionOps、PriceOps、AdLift、DealRoomAVM、NetPlan、Learning Hub 與 OpsBoard 使用的資料產品。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. 資料來源分類

| 分類 | 說明 | 主要用途 | 責任邊界 |
|---|---|---|---|
| `INTERNAL_MASTER` | 門市、品牌、設備、會員、價格、租約、資產等主檔 | 全平台共同鍵、權限、決策與報表 | 上游提供來源事實；ODay Plus 建立 Canonical 與映射 |
| `INTERNAL_EVENT` | 交易、設備狀態、Cycle、故障、客服、工單、促銷、廣告、成本等事件 | ForecastOps、Intervention、AVM、Learning Hub | 上游提供事件；ODay Plus 定義時間語意與事件契約 |
| `EXTERNAL_GEO` | 行政區、H3、路網、等時圈、交通、停車、POI、競店、商圈 | HeatZone、SiteScore、NetPlan、AdLift 對照組 | ODay Plus 負責 Connector、快照、授權、版本與品質 |
| `EXTERNAL_MARKET` | 租金、出租物件、商用不動產、成交參考、區域人口與所得 | Listing、SiteScore、DealRoomAVM、NetPlan | ODay Plus 負責整合與來源可用性控管 |
| `EXTERNAL_TIME_CONTEXT` | 天氣、假日、學期、活動、重大建設、政策與區域事件 | ForecastOps、SiteScore、AdLift、NetPlan | ODay Plus 負責來源版本與決策時間可見性 |
| `USER_DECISION` | 使用者核准、拒絕、Override、註記、處置、稽核紀錄 | OpsBoard、Learning Hub、模型污染防止 | ODay Plus 原生資料，必須全量留痕 |
| `MODEL_OUTPUT` | 預測、建議、區間、解釋、模型版本、特徵版本 | 全模組決策與治理 | ODay Plus 原生資料，需可重現 |

## 3. Ownership 原則

### 3.1 角色定義

| 角色 | 定義 | 主要責任 |
|---|---|---|
| Business Data Owner | 業務資料意義的最終擁有者 | 定義欄位語意、可接受品質、缺值處理與可用範圍 |
| Source System Owner | 來源系統技術擁有者 | 提供資料、維持來源可用性、處理重拉與來源修正 |
| Integration Owner | ODay Plus 接入與轉換負責人 | Connector、Mapping、Canonical、Quarantine、Backfill |
| Data Product Owner | Canonical / Model-ready View 負責人 | View 口徑、版本、品質、文件與變更審核 |
| Model Owner | 使用資料的模型負責人 | 指定模型輸入需求、資料污染風險與驗證標準 |
| Security Owner | 資安與個資控管負責人 | IAM、遮罩、保留期限、稽核與外部資料授權 |

### 3.2 責任原則

1. 模型不得直接讀取未經定義的 Raw Source。
2. 上游欄位異動不得直接影響模型與前端；必須先經 Source-to-Canonical Mapping。
3. 所有資料產品必須有 Owner、更新頻率、品質門檻、血緣與版本。
4. 外部資料必須保留授權條件、來源、取得時間、有效期間、覆蓋範圍與 Confidence。
5. 上游 IoT 團隊不需要理解 ODay Plus 模型，只需符合交換契約；資料語意轉換由 ODay Plus Integration Layer 負責。

## 4. 資料來源總表

### 4.1 內部與 IoT 資料

| Source ID | 來源名稱 | 來源分類 | 來源系統／提供者 | 主要欄位 | 粒度 | 最低歷史 | 更新頻率 | 主要消費者 | Owner | Criticality |
|---|---|---|---|---|---|---|---|---|---|---|
| `SRC-INT-STORE-MASTER` | 門市主檔 | `INTERNAL_MASTER` | IoT／內部資料底座 | store code、品牌、地址、座標、開幕日、狀態、店型 | 門市 | 全量 | 每日或異動即時 | 全模組 | Store Data Owner | P0 |
| `SRC-INT-MACHINE-MASTER` | 設備主檔 | `INTERNAL_MASTER` | IoT／內部資料底座 | machine sn、類型、公斤數、設備品牌、安裝日、狀態 | 機台 | 全量 | 每日或異動即時 | ForecastOps、PriceOps、AVM | Equipment Data Owner | P0 |
| `SRC-INT-TRANSACTION` | 交易與營收 | `INTERNAL_EVENT` | IoT／支付／POS | transaction id、store、machine、amount、payment、refund、event time | 交易 | 36 個月以上，目標 60 個月 | 每日，重大可近即時 | ForecastOps、AVM、AdLift、Learning Hub | Finance / Data Owner | P0 |
| `SRC-INT-MACHINE-CYCLE` | 設備使用 Cycle | `INTERNAL_EVENT` | IoT | start/end、cycle type、duration、success/failure | 機台 Cycle | 24 個月以上 | 每日或近即時 | ForecastOps、Capacity、Root Cause | Equipment Data Owner | P0 |
| `SRC-INT-MACHINE-STATUS` | 設備狀態與停機 | `INTERNAL_EVENT` | IoT | heartbeat、online/offline、error code、availability | 機台事件 | 12 個月以上 | 近即時或每小時 | ForecastOps、Intervention、OpsBoard | IoT Owner | P0 |
| `SRC-INT-MEMBER` | 會員主檔與歸戶 | `INTERNAL_MASTER` | 會員／CRM | member id、channel id、join date、consent、status | 會員 | 全量 | 每日或異動即時 | CRM、AdLift、Promotion | CRM Data Owner | P1 |
| `SRC-INT-PRICE` | 價格表 | `INTERNAL_MASTER` | 價格／POS | equipment type、time band、price、effective period | 門市×設備×時段 | 全量 | 異動即時 | PriceOps、ForecastOps | Pricing Owner | P0 |
| `SRC-INT-PROMOTION` | 促銷與優惠券 | `INTERNAL_EVENT` | CRM／行銷 | campaign id、coupon、target、budget、period、redemption | 活動／核銷 | 36 個月 | 每日 | Intervention、AdLift、ForecastOps | Marketing Owner | P1 |
| `SRC-INT-AD` | 廣告投放 | `INTERNAL_EVENT` | Ads／行銷平台 | channel、budget、impression、click、store scope、period | 活動×日 | 24 個月 | 每日 | AdLift、ForecastOps | Marketing Owner | P1 |
| `SRC-INT-MAINTENANCE` | 維修與清潔工單 | `INTERNAL_EVENT` | 工務／客服 | ticket id、store、machine、issue、opened/closed、status | 工單 | 24 個月 | 每日或異動即時 | ForecastOps、Intervention | Operations Owner | P0 |
| `SRC-INT-CUSTOMER-SERVICE` | 客服與客訴 | `INTERNAL_EVENT` | 客服系統／LINE | case id、topic、sentiment、TTR、store、machine | 客服案件 | 24 個月 | 每日 | ForecastOps、Root Cause、OpsBoard | CS Owner | P1 |
| `SRC-INT-COST` | 水電瓦斯耗材與成本 | `INTERNAL_EVENT` | 財務／能源帳單 | cost type、period、amount、unit consumption | 門市×期間 | 24 個月 | 月／週 | ForecastOps、AVM、NetPlan | Finance Owner | P1 |
| `SRC-INT-LEASE` | 租約資料 | `INTERNAL_MASTER` | 法務／財務 | lease start/end、rent、deposit、terms、renewal option | 門市／物件 | 全量 | 月或異動即時 | SiteScore、AVM、NetPlan | Legal / Finance | P0 |
| `SRC-INT-ASSET` | 資產與設備帳 | `INTERNAL_MASTER` | 財務／設備 | asset id、book value、depreciation、purchase date | 資產 | 全量 | 月 | AVM、NetPlan | Finance Owner | P1 |

### 4.2 外部資料

| Source ID | 來源名稱 | 來源分類 | 取得方式 | 主要欄位 | 空間粒度 | 時間粒度 | 更新頻率 | 主要消費者 | 授權風險 | Criticality |
|---|---|---|---|---|---|---|---|---|---|---|
| `SRC-EXT-ADMIN` | 行政區與地理邊界 | `EXTERNAL_GEO` | 公開資料／檔案 | 縣市、區、里、polygon | Polygon | 版本 | 半年／年 | HeatZone、SiteScore | 低 | P0 |
| `SRC-EXT-H3` | H3 格網 | `EXTERNAL_GEO` | 系統產生 | h3 index、resolution、parent、centroid | H3 | 版本 | 固定 | HeatZone、NetPlan | 低 | P0 |
| `SRC-EXT-ROAD` | 路網與可達性 | `EXTERNAL_GEO` | OSM／公開資料／商用 | road graph、travel time、barrier | 路段／等時圈 | 版本 | 月／季 | SiteScore、HeatZone | 中 | P0 |
| `SRC-EXT-POI` | POI 與生活機能 | `EXTERNAL_GEO` | API／檔案／商用 | type、brand、location、status | 點位 | Snapshot | 月 | HeatZone、SiteScore | 中 | P0 |
| `SRC-EXT-COMPETITOR` | 競店 | `EXTERNAL_GEO` | 地圖、商業名錄、人工校正 | brand、capacity proxy、location、status | 店點 | Snapshot | 月 | HeatZone、SiteScore、NetPlan | 中 | P0 |
| `SRC-EXT-POPULATION` | 人口、戶數、租屋與所得 | `EXTERNAL_MARKET` | 公開資料／商用 | resident、household、student、income | 行政區／格網 | 年／季 | 季／年 | HeatZone、SiteScore | 低 | P0 |
| `SRC-EXT-RENT` | 租金行情 | `EXTERNAL_MARKET` | 公開、商用、Listing 推估 | rent per ping、quantile、source | 區域／物件 | 月／季 | 月 | SiteScore、Listing、NetPlan | 中 | P0 |
| `SRC-EXT-LISTING` | 出租物件 | `EXTERNAL_MARKET` | CSV、合作 Feed、API、人工 | address、rent、ping、floor、available date | 物件 | Snapshot | 日／週 | Listing、SiteScore | 高 | P0 |
| `SRC-EXT-WEATHER` | 天氣 | `EXTERNAL_TIME_CONTEXT` | API | temp、rain、humidity、typhoon | 區域／站點 | 小時／日 | 日／小時 | ForecastOps、AdLift | 低 | P1 |
| `SRC-EXT-CALENDAR` | 假日、學期、活動 | `EXTERNAL_TIME_CONTEXT` | 公開資料、人工維護 | holiday、school term、event | 全台／區域 | 日 | 年／月 | ForecastOps、SiteScore | 低 | P1 |
| `SRC-EXT-CONSTRUCTION` | 重大建設與商圈變化 | `EXTERNAL_TIME_CONTEXT` | 公開資料、人工維護 | project、location、phase、expected impact | 區域 | 版本 | 月／季 | NetPlan、HeatZone | 中 | P2 |
| `SRC-EXT-VALUATION-COMP` | 交易／轉讓 Comparable | `EXTERNAL_MARKET` | 人工、商用、內部 DealRoom | asking、closing price、asset mix | 交易案 | 事件 | 異動 | AVM | 高 | P1 |

## 5. Criticality 與最低可用定義

| 等級 | 定義 | 例子 | 缺失時處理 |
|---|---|---|---|
| P0 | 沒有此資料，核心模組不得正式產生決策 | 門市主檔、設備主檔、交易、價格、Listing、Geocode | Block scoring / Block approval / Trigger Incident |
| P1 | 沒有此資料可產生降級結果，但必須標示信心下降 | 會員、廣告、天氣、客服、成本 | Degraded mode / Confidence penalty |
| P2 | 進階解釋或策略所需，缺失不阻擋基礎功能 | 重大建設、部分商圈動態、外部估值 comparable | Warning / Manual review |

## 6. 資料來源評分模型

每一來源必須每次 Snapshot 後計算 `source_readiness_score`，範圍 0–100。

| 指標 | 權重 | 說明 |
|---|---:|---|
| Completeness | 20 | 必填欄位完整度 |
| Freshness | 15 | 距離預期更新時間的延遲 |
| Validity | 15 | 型別、值域、座標、時間、金額有效性 |
| Uniqueness | 10 | 主鍵、自然鍵或去重後唯一性 |
| Coverage | 15 | 空間、品牌、門市、時間涵蓋範圍 |
| Stability | 10 | Schema 與統計分布是否穩定 |
| Legal / License | 10 | 授權可用性與使用限制 |
| Operational SLA | 5 | 重送、Backfill、來源支援能力 |

低於 80 不得進入 Production Model-ready View；60–79 可進入 Staging 或人工審核；低於 60 必須進 Quarantine。

## 7. 資料責任矩陣

| 資料產品 | Source Owner | Integration Owner | Data Product Owner | Model Owner | Security Owner | 核准會議 |
|---|---|---|---|---|---|---|
| Store / Machine Canonical | IoT／內部資料底座 | ODay Plus Integration | Data Architect | All Model Owners | Security Owner | Data Contract Review |
| Transaction Canonical | Finance / IoT | ODay Plus Integration | Data Product Owner | Forecast / AVM / AdLift | Security Owner | Data Contract Review |
| Listing Canonical | External Data Owner | ODay Plus Integration | Listing PO | SiteScore Owner | Security Owner | External Data Review |
| Geo Feature Mart | External Data Owner | Geo Data Engineer | Geo Data Product Owner | HeatZone / SiteScore | Security Owner | Data Contract Review |
| Intervention / Decision Log | ODay Plus Platform | Platform Backend | Product Owner | Learning Hub Owner | Security Owner | Governance Review |
| Model-ready Views | Data Product Owner | Data Engineering | Data Product Owner | Model Owner | Security Owner | Model Review |

## 8. 來源上線門檻

每一資料來源上線前必須完成：

1. 來源 Owner 與緊急聯絡人。
2. 欄位清單與範例資料。
3. 主鍵與去重策略。
4. 時間欄位語意：事件時間、觀察時間、更新時間。
5. 更新頻率與延遲 SLA。
6. Backfill 與重送方法。
7. 刪除、退款、作廢、補登、修正語意。
8. DQ 測試與 Quarantine 規則。
9. 資安與個資分類。
10. 授權條件與可用於模型訓練之聲明。
11. 對應 Canonical Entity。
12. Data Contract Review 紀錄與版本號。

## 9. 主要風險與因應

| 風險 | 影響 | 偵測 | 因應 |
|---|---|---|---|
| 上游主鍵不穩定 | 門市、機台、交易歸戶錯誤 | Identity collision、missing reference | 建立 Identity Mapping 與人工校正流程 |
| 交易補登或退款覆蓋原始紀錄 | Forecast / AVM 污染 | Source version mismatch | 以事件更正，不允許無紀錄覆蓋 |
| 外部 Listing 授權不足 | 無法合法使用或留存 | License registry | 優先使用合作 Feed、人工輸入、可授權來源 |
| Geocode 錯誤 | HeatZone / SiteScore 錯判 | 抽樣、距離異常、行政區不符 | 多服務驗證、人工校正、Confidence penalty |
| POI 過期或重複 | 商圈特徵偏誤 | Duplicate / age check | 去重、快照、人工抽樣 |
| 干預資料未記錄 | 無法做因果或排除污染 | Intervention overlap check | 所有價格、廣告、促銷、維修必須進 Intervention Log |
| 時間洩漏 | 回測過度樂觀 | PIT audit | 所有 View 依 Decision Time 取可見資料 |

## 10. 與後續文件關係

| 後續文件 | 使用本文件內容 |
|---|---|
| `ODP-DATA-02` | 擷取內部／IoT 來源成為正式交換契約 |
| `ODP-DATA-03` | 擷取外部來源成為 Connector 設計 |
| `ODP-DATA-04` | 以所有來源建立 Canonical Data Model |
| `ODP-DATA-05` | 定義每一來源欄位到 Canonical 的轉換 |
| `ODP-DATA-06` | 將 Canonical 轉成 Model-ready Views |
| `ODP-DATA-07` | 建立資料品質、血緣與時間語意治理 |

## 11. 驗收條件

| 驗收項目 | 驗收方式 | 必要性 |
|---|---|---|
| 所有 P0 來源有 Owner 與 SLA | 資料來源清冊與簽核 | MUST |
| 所有 P0 來源有主鍵、時間欄位、Backfill 定義 | Contract Review | MUST |
| 所有外部來源有授權與 Snapshot 設計 | External Data Review | MUST |
| 每一來源能對應至少一個 Canonical Entity 或明確標記不接入 | Mapping Review | MUST |
| 每一來源有 DQ 規則與 Quarantine 流程 | DQ Test Report | MUST |
| Critical Source Fail 可阻擋 Production View | Pipeline Run / Test | MUST |
