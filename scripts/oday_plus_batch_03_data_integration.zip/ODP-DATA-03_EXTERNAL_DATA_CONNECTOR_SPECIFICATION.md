---
doc_id: ODP-DATA-03
title: "外部資料 Connector 規格"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus 外部資料 Connector 規格

## 1. 文件目的

本文件定義 ODay Plus 外部資料 Connector 的統一規格，包括來源登錄、授權紀錄、快照、排程、API／檔案／人工輸入、地址解析、Geocode、H3、去重、品質檢查、重試、Quarantine、版本與資料產品發布。

外部資料是 HeatZone、Listing、SiteScore、AdLift、DealRoomAVM 與 NetPlan 的核心基礎；所有外部資料必須先進入 External Data Platform，再轉成 Canonical 或 Feature Mart，模型不得直接呼叫外部 API 作為正式推論依據。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. Connector 設計原則

1. 來源可追溯：每筆資料必須保留來源、取得時間、授權、快照版本。
2. 可重現：模型訓練與決策所用外部特徵必須能依 Decision Time 重建。
3. 合法使用：不得接入授權不明或禁止模型訓練／商用使用的來源。
4. 先 Snapshot 再轉換：外部 API 回應不得直接餵給模型，必須先落地 raw snapshot。
5. 空間可解釋：地址、座標、H3、行政區與等時圈都必須有 confidence。
6. 允許人工校正：POI、競店、Listing 與 Geocode 必須支援人工覆核與版本化。
7. 多來源融合要保留 provenance：融合後資料不得失去來源與權重。

## 3. Connector 架構

```mermaid
flowchart LR
    A[External Source] --> B[Connector Adapter]
    B --> C[Raw Snapshot Store]
    C --> D[Parser / Normalizer]
    D --> E[Validation & License Check]
    E --> F{DQ Pass?}
    F -- No --> Q[Quarantine]
    F -- Yes --> G[Canonical Staging]
    G --> H[Geo Enrichment]
    H --> I[Dedup / Entity Resolution]
    I --> J[Feature Mart / Model-ready View]
    J --> K[Consumer Modules]
    Q --> R[Manual Review]
    R --> G
```

## 4. 通用 Connector Metadata

每一 Connector 必須在 `external_source_registry` 登錄：

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_id` | string | Y | 例如 `SRC-EXT-POI-GOOGLE-LIKE`、`SRC-EXT-LISTING-PARTNER-A` |
| `source_name` | string | Y | 來源名稱 |
| `source_category` | string | Y | `poi`、`competitor`、`listing`、`weather` 等 |
| `provider` | string | Y | 供應者或內部維護者 |
| `acquisition_method` | string | Y | api/file/manual/feed/public_dataset |
| `license_type` | string | Y | public/open/commercial/partner/manual/internal |
| `allowed_usage` | array | Y | display、feature、training、prediction、report、audit |
| `prohibited_usage` | array | N | 禁止事項 |
| `retention_policy` | string | Y | 原始資料保留期限 |
| `refresh_frequency` | string | Y | daily/weekly/monthly/quarterly/ad_hoc |
| `owner` | string | Y | Source Owner |
| `integration_owner` | string | Y | Connector Owner |
| `dq_profile` | string | Y | 套用的 DQ 規則組 |
| `pii_classification` | string | Y | none/low/medium/high |
| `cost_model` | string | N | free/per_request/subscription/manual |
| `status` | string | Y | candidate/staging/production/deprecated/blocked |

## 5. Connector 類型規格

### 5.1 API Connector

| 項目 | 規格 |
|---|---|
| 認證 | API Key、OAuth、Service Account 或 Partner Token |
| Rate Limit | 必須記錄限制與重試策略 |
| Pagination | 必須支援 checkpoint |
| Raw 保存 | 保存 request metadata、response metadata、payload hash |
| 重試 | 指數退避，避免超過供應商限制 |
| 錯誤 | 4xx 進設定錯誤或授權錯誤；5xx 可重試；429 特別處理 |
| 去重 | 以 provider id、座標、名稱、地址、時間建立自然鍵 |

### 5.2 File / Feed Connector

| 項目 | 規格 |
|---|---|
| 格式 | CSV、Excel、JSON、Parquet、GeoJSON、Shapefile |
| 檔案命名 | `{source_id}/{snapshot_date}/{file_name}` |
| Schema | 必須有欄位定義與型別 |
| Encoding | UTF-8 優先；若非 UTF-8 必須轉換 |
| Header | 必須支援欄位對應與版本 |
| 重複檔案 | 以 checksum 判定 |
| 失敗 | 原檔保留，轉入 Quarantine |

### 5.3 Manual / Curated Connector

| 項目 | 規格 |
|---|---|
| 用途 | 競店人工校正、Listing 實勘修正、商圈事件、重大建設 |
| UI | 需有建立者、審核者、時間、理由 |
| 版本 | 所有人工校正必須 SCD2 或 event sourced |
| 稽核 | 不得無留痕覆蓋外部來源 |
| Confidence | 人工覆核可提高 confidence，但必須標示 reviewer |

### 5.4 Web / Scraping Connector

僅在來源合法、robots、授權與法務審核通過後可用。第一版優先使用人工、CSV/Excel、合作仲介 Feed 與正式 API。若使用 Scraping，必須有 ADR、Legal Review、Rate Limit、來源保存與退出方案。

## 6. 外部來源 Connector Catalog

| Connector ID | 類別 | 來源內容 | 方法 | 更新 | 主要輸出 | Consumer | 必要性 |
|---|---|---|---|---|---|---|---|
| `CONN-GEO-ADMIN` | 地理 | 行政區、縣市區里界線 | public file | quarterly/yearly | `geo_admin_boundary` | HeatZone/SiteScore | MUST |
| `CONN-GEO-H3` | 地理 | H3 全台格網 | generated | on demand | `geo_h3_cell` | HeatZone | MUST |
| `CONN-GEO-ROAD` | 路網 | 道路、路口、等時圈 | OSM/public/commercial | monthly | `road_network_snapshot` | SiteScore/HeatZone | MUST |
| `CONN-GEO-POI` | POI | 學校、宿舍、超商、餐飲、社區、商場、醫院、辦公 | API/file | monthly | `poi_snapshot` | HeatZone/SiteScore | MUST |
| `CONN-GEO-COMPETITOR` | 競店 | 競店、自家店外部比對、容量 proxy | API/manual | monthly | `competitor_store_snapshot` | HeatZone/SiteScore/NetPlan | MUST |
| `CONN-MKT-POP` | 人口 | 人口、戶數、租屋、學生、所得 | public/commercial | quarterly/yearly | `population_snapshot` | HeatZone | MUST |
| `CONN-MKT-RENT` | 租金 | 租金行情、區域分位、物件租金 | feed/file/api | monthly | `rent_market_snapshot` | Listing/SiteScore | MUST |
| `CONN-LISTING-PARTNER` | 物件 | 出租物件 | partner feed/API | daily/weekly | `listing_raw_snapshot` | Listing | MUST |
| `CONN-WEATHER` | 天氣 | 溫度、雨量、颱風、濕度 | API | daily/hourly | `weather_daily_snapshot` | ForecastOps/AdLift | SHOULD |
| `CONN-CALENDAR` | 時間 | 假日、學期、事件 | public/manual | yearly/monthly | `calendar_context` | ForecastOps/SiteScore | SHOULD |
| `CONN-CONSTRUCTION` | 區域事件 | 重大建設、道路改變、商圈衝擊 | public/manual | monthly | `local_change_event` | NetPlan/HeatZone | SHOULD |
| `CONN-VALUATION-COMP` | 估值 | 轉讓、成交、詢價 comparable | internal/manual/commercial | ad hoc | `valuation_comparable_snapshot` | DealRoomAVM | SHOULD |

## 7. 地址、Geocode 與 H3 規格

### 7.1 地址正規化

| 處理 | 說明 |
|---|---|
| 全形半形與空白 | 統一處理 |
| 行政區補全 | 依來源或地理結果補全 |
| 路街巷弄號解析 | 分離可查詢欄位 |
| 樓層與備註 | 保留但不參與主要 Geocode |
| 地址版本 | `address_normalized_version` |

### 7.2 Geocode 結果欄位

| 欄位 | 說明 |
|---|---|
| `latitude` / `longitude` | 座標 |
| `geocode_provider` | 供應者 |
| `geocode_precision` | rooftop、street、district、manual |
| `geocode_confidence` | 0–1 |
| `admin_match_flag` | 是否與行政區一致 |
| `manual_override_flag` | 是否人工校正 |
| `h3_res_8` / `h3_res_9` / `h3_res_10` | 多解析度 H3 |
| `service_area_id` | 等時圈或生活圈 |

### 7.3 座標品質規則

1. 座標必須落在台灣合理範圍或指定市場範圍。
2. Listing 座標不得只落在縣市中心；若精度不足，需標示低 confidence。
3. POI 或競店若多來源位置相差超過門檻，需進人工覆核。
4. Geocode 版本改變時，需觸發下游 Feature 重算。

## 8. Listing Connector 特別規則

| 規則 | 說明 |
|---|---|
| 合規優先 | 自動爬取必須延後至來源合規確認 |
| 物件去重 | 名稱、地址、座標、租金、坪數、聯絡資訊、照片 hash 綜合判斷 |
| 可用狀態 | active/inactive/leased/unknown/manual_review |
| 時效 | listing 若超過 freshness threshold 必須標示 stale |
| Hard Rules | 坪數、租金、樓層、排水、電力、瓦斯、通風等以欄位或人工狀態表示 |
| 稽核 | 每次物件評分需保存當時 listing snapshot |

## 9. POI 與競店融合規則

### 9.1 POI 分類

| 大類 | 子類範例 | 主要模型用途 |
|---|---|---|
| Residence | 社區大樓、住宅區 | 外部需求 |
| Education | 大學、學校、宿舍 | 學生與租屋需求 |
| Daily Life | 超商、市場、餐飲 | 生活機能 |
| Work | 辦公、科技園區、工業區 | 白天人口與通勤 |
| Transit | 捷運、公車、停車場 | 可達性 |
| Competition | 自助洗衣、洗衣店、同業 | 競爭與稀釋 |

### 9.2 競店欄位

| 欄位 | 說明 |
|---|---|
| `competitor_id` | 融合後競店 ID |
| `source_competitor_id` | 來源 ID |
| `brand_name` | 品牌 |
| `store_name` | 店名 |
| `latitude` / `longitude` | 座標 |
| `estimated_capacity` | 容量 proxy，可由照片、評論、人工填入 |
| `status` | active/closed/unknown |
| `confidence` | 融合信心 |
| `last_verified_at` | 最近確認時間 |

## 10. Raw Snapshot 儲存規則

| 層 | 命名 | 說明 |
|---|---|---|
| Raw | `raw_external/{source_id}/{snapshot_date}/...` | 原始不可變資料 |
| Parsed | `parsed_external.{source_id}_{entity}` | 初步解析後 |
| Canonical Staging | `stg_external_{entity}` | 欄位標準化後 |
| Curated | `curated_{entity}` | 去重、校正、融合後 |
| Feature | `feature_{domain}_{view}` | 模型特徵 |

Raw Snapshot 不得更新，只能新增新版。若來源要求刪除，需依 retention policy 做合規處理並保留刪除稽核紀錄。

## 11. Connector 錯誤與重試

| 情境 | 重試 | Quarantine | 告警 |
|---|---|---|---|
| API 429 | 指數退避 | N | Warning |
| API 5xx | 3–5 次 | N | Warning / Error |
| API 401/403 | N | Y | Error |
| Schema mismatch | N | Y | Error |
| License expired | N | Y | Critical |
| Geocode low confidence | N | Y or manual review | Warning |
| File checksum duplicate | N | N | Info |
| File corrupt | N | Y | Error |

## 12. 資料發布 Gate

外部資料進入 Production 前必須通過：

1. Source Registry 狀態為 `production`。
2. License Review 通過。
3. Raw Snapshot 可重現。
4. DQ score >= 80。
5. Coverage 滿足模組最低需求。
6. Geocode / H3 欄位完整。
7. Data Product Owner 核准。
8. 若影響模型，需 Model Owner 核准。

## 13. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| 每個 Connector 有 source registry | Registry Review | MUST |
| 每個 Connector 產生 raw snapshot | Storage Inspection | MUST |
| Listing Connector 支援去重與 stale 標記 | Golden Dataset | MUST |
| Geocode 有 confidence 與人工覆核流程 | UI/API Test | MUST |
| 外部資料有授權與 retention | Security/Legal Review | MUST |
| Connector fail 不污染 Production View | Pipeline Test | MUST |
| 可依 snapshot_date 重建外部特徵 | Reproducibility Test | MUST |
