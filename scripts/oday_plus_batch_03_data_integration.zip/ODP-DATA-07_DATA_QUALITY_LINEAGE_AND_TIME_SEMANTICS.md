---
doc_id: ODP-DATA-07
title: "資料品質、血緣與時間語意"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus 資料品質、血緣與時間語意

## 1. 文件目的

本文件定義 ODay Plus 的資料品質、資料血緣、時間語意、Point-in-time Correctness、資料污染防止、Data Quality Gate、Lineage、Retention 與 Incident 規則。它是模型可信度、決策可追溯與補助查核證據鏈的共同基礎。

ODay Plus 的核心不是只產生模型分數，而是讓每一次預測、建議、核准、執行與結果都可追溯到當時可見資料、特徵版本、模型版本、政策版本與人工決策紀錄。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. 時間語意標準

| 時間欄位 | 定義 | 例子 | 必要性 |
|---|---|---|---|
| `event_time` | 事件真實發生時間 | 交易付款時間、機台故障時間 | P0 |
| `observation_time` | 來源系統觀察或收到事件時間 | IoT 收到機台狀態時間 | P0 |
| `ingested_at` | ODay Plus 接收資料時間 | Integration pipeline 寫入時間 | P0 |
| `source_updated_at` | 來源最後更新時間 | 交易被補登或修正時間 | P0 |
| `feature_snapshot_time` | 特徵快照時間 | Forecast 特徵截至昨晚 23:59 | P0 |
| `prediction_origin_time` | 模型做預測的起點 | Forecast 今日 00:00 | P0 |
| `decision_time` | 系統或人工做決策時間 | SiteScore 核准會議時間 | P0 |
| `execution_time` | 動作真正執行時間 | 調價生效、廣告上線 | P0 |
| `outcome_time` | Outcome 被觀察的時間 | 觀察窗結束日 | P0 |
| `label_maturity_time` | Outcome 成熟、可訓練時間 | 退款與補登完成後 | P0 |

## 3. Point-in-time Correctness

### 3.1 基本規則

任一模型訓練、回測或推論只能使用在該 `decision_time` 或 `prediction_origin_time` 以前已知且成熟的資料。

不得使用：

1. 決策後才發生的新競店、新道路、新活動。
2. 決策後才修正的租金、物件狀態或交易結果。
3. 開店後實績來訓練同一候選點的開店前 SiteScore。
4. 干預後 outcome 當成干預前 feature。
5. 未達 `label_maturity_time` 的結果當成訓練標籤。

### 3.2 PIT Join 條件

每一 Feature Join 必須滿足：

```sql
feature.event_time <= prediction_origin_time
AND feature.observation_time <= feature_snapshot_time
AND feature.available_from <= feature_snapshot_time
AND (feature.available_to IS NULL OR feature.available_to > feature_snapshot_time)
```

若使用修正資料，必須依 `source_updated_at` 和 `observation_time` 重建當時可見版本。

## 4. 資料品質維度

| 維度 | 定義 | 範例規則 |
|---|---|---|
| Completeness | 必填欄位完整 | 交易必須有 store、event_time、amount |
| Validity | 值域與型別正確 | 金額非負，退款例外；座標在合理範圍 |
| Uniqueness | 主鍵或自然鍵唯一 | transaction_id 不重複 |
| Consistency | 跨表一致 | machine 所屬 store 存在且有效 |
| Freshness | 符合更新 SLA | 交易 T+1 08:00 前到位 |
| Accuracy | 與抽樣或人工比對一致 | Geocode 抽樣正確率 |
| Coverage | 空間、時間、品牌覆蓋足夠 | POI 覆蓋全台目標區域 |
| Stability | 分布與 Schema 穩定 | 營收突然歸零需告警 |
| Lineage | 可追溯來源與轉換 | View 可追到 raw snapshot |
| Legality | 授權與個資合法 | 外部資料可用於訓練 |

## 5. Data Quality Rule Catalog

### 5.1 P0 規則

| Rule ID | 資料 | 規則 | Fail Action |
|---|---|---|---|
| `DQ-P0-STORE-001` | store | open store 必須有有效地址 | Block downstream scoring |
| `DQ-P0-STORE-002` | store | store_id 唯一且 SCD period 不重疊 | Block canonical publish |
| `DQ-P0-MACHINE-001` | machine | active machine 必須屬於有效 store | Quarantine row |
| `DQ-P0-TXN-001` | transaction | source_transaction_id 在 source 內唯一 | Quarantine duplicates |
| `DQ-P0-TXN-002` | transaction | succeeded transaction 必須 amount >= 0 | Quarantine row |
| `DQ-P0-TXN-003` | transaction | transaction event_time 不得為未來時間 | Quarantine row |
| `DQ-P0-PRICE-001` | price | 同 store/machine/time band 生效期間不得重疊 | Block PriceOps |
| `DQ-P0-LISTING-001` | listing | active listing 必須有地址與租金 | Quarantine / manual review |
| `DQ-P0-GEO-001` | geocode | production site geocode_confidence >= threshold | Manual review |
| `DQ-P0-DECISION-001` | decision | approved decision 必須有 actor、time、basis | Block execution |
| `DQ-P0-MODEL-001` | prediction | production prediction 必須有 model_version | Block display as official |

### 5.2 P1/P2 規則

| Rule ID | 資料 | 規則 | Fail Action |
|---|---|---|---|
| `DQ-P1-CS-001` | customer service | topic_code 不可為未知超過門檻 | Confidence penalty |
| `DQ-P1-WEATHER-001` | weather | 天氣缺值可用鄰近站點 | Impute + flag |
| `DQ-P1-COST-001` | cost | 月成本不可超出同群 p99 無註記 | Warning / review |
| `DQ-P2-POI-001` | POI | POI 超過 freshness threshold | Confidence penalty |
| `DQ-P2-CONST-001` | construction | 重大建設需人工確認 | Manual review |

## 6. 品質分數與 Gate

### 6.1 分數公式

`data_quality_score = completeness*0.2 + validity*0.2 + consistency*0.15 + freshness*0.15 + uniqueness*0.1 + coverage*0.1 + lineage*0.1`

若 Legality fail 或 PII violation，總分直接為 0 並阻擋發布。

### 6.2 Gate 等級

| Gate | 門檻 | 允許動作 |
|---|---|---|
| `RAW_ACCEPTED` | Schema 可解析 | 進 Raw Store |
| `CANONICAL_READY` | P0 DQ pass, score >= 80 | 發布 Canonical |
| `FEATURE_READY` | View DQ pass, PIT pass | 發布 Model-ready View |
| `TRAINING_READY` | label mature, no leakage | 可進訓練 |
| `SCORING_READY` | feature current, source valid | 可推論 |
| `DECISION_READY` | prediction + policy + audit basis | 可產生正式決策建議 |

## 7. Data Lineage 模型

### 7.1 Lineage 層級

```mermaid
flowchart LR
    A[External / Internal Source] --> B[Raw Snapshot]
    B --> C[Parsed Staging]
    C --> D[Canonical Entity]
    D --> E[Feature Mart]
    E --> F[Model-ready View]
    F --> G[Training Dataset Snapshot]
    F --> H[Prediction Run]
    G --> I[Model Version]
    I --> H
    H --> J[Decision]
    J --> K[Approval]
    K --> L[Execution]
    L --> M[Outcome]
    M --> N[Label Registry]
    N --> G
```

### 7.2 必要 Lineage 欄位

| 層 | 必要欄位 |
|---|---|
| Raw Snapshot | `snapshot_id`、`source_id`、`snapshot_time`、`schema_version`、`storage_uri`、`checksum` |
| Pipeline Run | `pipeline_run_id`、`code_version`、`mapping_version`、`started_at`、`ended_at`、`status` |
| Canonical | `source_snapshot_id`、`mapping_version`、`created_by_run_id` |
| Feature View | `view_name`、`view_version`、`feature_snapshot_time`、`source_snapshot_ids` |
| Dataset Snapshot | `dataset_snapshot_id`、`view_versions`、`entity_count`、`time_range` |
| Model Version | `model_version_id`、`training_dataset_snapshot_id`、`model_artifact_uri` |
| Prediction | `prediction_run_id`、`model_version_id`、`input_snapshot_id` |
| Decision | `decision_id`、`prediction_run_id`、`policy_version_id`、`actor_id` |
| Outcome | `outcome_id`、`decision_id`、`execution_id`、`label_maturity_time` |

## 8. Label Maturity 與資料污染防止

### 8.1 Label Registry 規則

| Label Type | 成熟條件 | 可用模型 |
|---|---|---|
| SiteScore M3/M6/M12 realization | 新店開幕後達指定月份，退款補登完成 | SiteScore、Brand Transfer、Ramp |
| Forecast outcome | 預測 horizon 結束且交易修正完成 | ForecastOps |
| Intervention effect | observation window 結束、重疊干預標記完成 | PriceOps、AdLift、InterventionOps |
| Valuation outcome | 成交或 90/180/365 日結果成熟 | AVM、NetPlan |
| NetPlan action outcome | 行動執行後指定天數完成 | NetPlan |

### 8.2 污染防止策略

| 污染類型 | 例子 | 防止方式 |
|---|---|---|
| Future leakage | 用未來競店訓練過去 SiteScore | PIT Join |
| Treatment leakage | 廣告活動後營收當自然需求 | Intervention labels |
| Selection bias | 只用核准開店樣本訓練 | Rejected candidate logging |
| Survivorship bias | 只用存活門市 | Closed store retention |
| Target leakage | 使用實際 M6 當 M1 feature | Feature blacklist |
| Manual decision pollution | 人工 override 後結果無標記 | Decision / Approval Log |

## 9. Drift Monitoring

| Drift 類型 | 指標 | 頻率 | 行動 |
|---|---|---|---|
| Schema Drift | 欄位新增、刪除、型別改變 | 每批 | Block if breaking |
| Data Drift | PSI、KS、分布差異 | 每日／每週 | Warning / retrain review |
| Label Drift | Outcome 分布變化 | 每月 | Model Review |
| Prediction Drift | 預測分布與信心變化 | 每日／每週 | Shadow / rollback review |
| Concept Drift | 模型誤差惡化 | 每月／季 | Challenger / retrain |
| Geo Coverage Drift | POI、Listing、競店覆蓋變化 | 每月 | Connector review |

## 10. Data Incident 分級

| 等級 | 定義 | 例子 | 處理 |
|---|---|---|---|
| D-P1 | 影響正式決策或大量門市 | 交易缺失、門市主檔錯誤、PII 外洩 | Incident Commander、阻擋決策、Postmortem |
| D-P2 | 影響單一模組或部分區域 | Listing 來源中斷、POI 過期 | 告警、降級、修復 |
| D-P3 | 非關鍵延遲或小範圍缺失 | 天氣缺值、少量客服 topic unknown | 記錄、下次修復 |

## 11. Retention 與 Archive

| 資料類型 | 保存期限 | 備註 |
|---|---:|---|
| Raw P0 Source | 至少 5 年或依契約 | 支援查核與重現 |
| Canonical Operational | 至少 5 年 | 決策與稽核相關不得提前刪除 |
| Model-ready Views | 至少 3 年 | 可由 Canonical 重建者可縮短 |
| Model Artifact | 至少 5 年 | Production 模型與查核模型保留 |
| Decision / Approval / Audit | 至少 7 年或依契約 | 高風險決策保留更久 |
| PII | 依個資法與同意範圍 | 需支援刪除或匿名化 |
| External Raw | 依授權 | 不可違反來源契約 |

## 12. 補助查核證據鏈

每一查核點或驗收報告必須能提供：

1. 資料來源 snapshot 與時間。
2. Data Quality Report。
3. Mapping 版本。
4. Model-ready View 版本。
5. 模型版本與 Model Card。
6. Prediction Run。
7. Decision / Approval / Execution / Outcome。
8. 前端畫面截圖或報表。
9. Audit Log。
10. 若有異常，需附 Incident / Postmortem。

## 13. 工具建議

| 能力 | 建議工具 |
|---|---|
| Data Transformation | dbt Core |
| Data Quality | Great Expectations / dbt tests |
| Lineage | dbt docs + OpenLineage compatible metadata |
| Model Tracking | MLflow / Vertex AI Metadata |
| Monitoring | Evidently、Prometheus、Grafana、Cloud Monitoring |
| Logging | OpenTelemetry、Cloud Logging |
| Audit | Operational DB + immutable log store |

## 14. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| 所有 P0 pipeline 有 DQ Gate | Pipeline Test | MUST |
| 任一 prediction 可追到 raw snapshot | Lineage Drill | MUST |
| 任一 decision 可追到 model_version 與 feature_snapshot | Audit Drill | MUST |
| PIT backtest 能阻擋未來資料 | Leakage Test | MUST |
| Intervention outcome 不污染 Forecast / SiteScore | Label Registry Test | MUST |
| PII 欄位有分類、遮罩與刪除流程 | Security Test | MUST |
| Data Incident 有分級與 Runbook | Incident Simulation | MUST |
| 補助查核可輸出證據鏈 | Acceptance Evidence Review | MUST |
