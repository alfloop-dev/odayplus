---
doc_id: ODP-DATA-04
title: "Canonical Data Model"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus Canonical Data Model

## 1. 文件目的

本文件定義 ODay Plus 平台內部統一資料模型，即 Canonical Data Model。它是 Integration Layer 與所有產品模組之間的共用語意契約。所有上游內部資料、IoT 事件、外部資料與平台原生資料，必須先被轉成 Canonical Entity 或 Canonical Event，才能進一步建立 Model-ready Views、API、報表、模型訓練資料與稽核資料。

Canonical Data Model 不等於單一實體資料庫設計；它是平台語意模型。實際儲存可依 Cloud SQL/PostGIS、BigQuery、Object Storage、Search Index、Feature Mart 拆分，但欄位語意不得分裂。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. 命名與型別規範

| 項目 | 規範 |
|---|---|
| Entity ID | `{entity}_id`，使用 ODay Plus 產生的穩定 UUID 或 Snowflake-like ID |
| Source ID | `source_*_id`，保留來源系統 ID |
| 時間 | timestamp 欄位一律含 timezone，語意需明確 |
| 日期 | date 欄位只用於日粒度事實，例如開幕日、租約日 |
| 金額 | numeric，必須搭配 `currency` |
| 狀態 | 使用小寫蛇形或文件定義 enum |
| JSON | 僅用於來源原文、可變規則或低頻 metadata，不得取代核心欄位 |
| SCD2 | 主檔變更需有 `effective_from`、`effective_to`、`is_current` |
| Audit | 重要資料表需有 `created_at`、`updated_at`、`created_by`、`updated_by` 或 pipeline run id |

## 3. 領域模型總覽

```mermaid
erDiagram
    BRAND ||--o{ STORE : owns
    STORE ||--o{ MACHINE : contains
    STORE ||--o{ TRANSACTION : receives
    MACHINE ||--o{ MACHINE_CYCLE : runs
    MACHINE ||--o{ MACHINE_STATUS_EVENT : emits
    STORE ||--o{ PRICE_SCHEDULE : uses
    STORE ||--o{ WORK_ORDER : has
    STORE ||--o{ CUSTOMER_SERVICE_CASE : receives
    STORE ||--o{ STORE_DAILY_FACT : aggregates
    GEO_CELL ||--o{ GEO_FEATURE : describes
    LISTING ||--o{ CANDIDATE_SITE : becomes
    CANDIDATE_SITE ||--o{ SITESCORE_RUN : evaluated_by
    STORE ||--o{ FORECAST_RUN : forecasted_by
    STORE ||--o{ INTERVENTION : treated_by
    INTERVENTION ||--o{ INTERVENTION_OUTCOME : measured_by
    STORE ||--o{ VALUATION_RUN : valued_by
    NETWORK_PLAN ||--o{ NETWORK_PLAN_ACTION : contains
    MODEL_VERSION ||--o{ PREDICTION : produces
    DECISION ||--o{ APPROVAL : requires
    DECISION ||--o{ AUDIT_EVENT : logs
```

## 4. Core Master Entities

### 4.1 `tenant`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `tenant_id` | string | 平台租戶或品牌集團 |
| `tenant_name` | string | 名稱 |
| `status` | string | active/inactive |
| `created_at` | timestamp | 建立時間 |

### 4.2 `brand`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `brand_id` | string | 品牌 ID |
| `tenant_id` | string | 所屬租戶 |
| `brand_code` | string | 品牌代碼，例如 ODay、洗多屋 |
| `brand_name` | string | 品牌名稱 |
| `brand_type` | string | owned/franchise/competitor/external |
| `brand_capture_group` | string | Brand Transfer 分群 |
| `status` | string | active/inactive |

### 4.3 `store`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `store_id` | string | 平台門市 ID |
| `tenant_id` | string | 租戶 |
| `brand_id` | string | 品牌 |
| `source_store_id` | string | 主要來源 ID |
| `store_name` | string | 門市名稱 |
| `store_status` | string | planned/open/suspended/closed/transferred |
| `ownership_type` | string | owned/franchise/investor_operated/partner |
| `store_format_code` | string | ODay G2、G1、傳統等 |
| `opened_on` | date | 開幕日 |
| `closed_on` | date | 關閉日 |
| `address_id` | string | 地址與地理資訊 |
| `region_code` | string | 區域／督導範圍 |
| `service_start_time` | time | 營業起始 |
| `service_end_time` | time | 營業結束 |
| `effective_from` | timestamp | 生效時間 |
| `effective_to` | timestamp | 失效時間 |
| `is_current` | boolean | 是否目前版本 |

### 4.4 `address_location`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `address_id` | string | 地址 ID |
| `raw_address` | string | 原始地址 |
| `normalized_address` | string | 正規化地址 |
| `city` | string | 縣市 |
| `district` | string | 區 |
| `village` | string | 里 |
| `road` | string | 路街 |
| `latitude` | numeric | 緯度 |
| `longitude` | numeric | 經度 |
| `geocode_precision` | string | rooftop/street/district/manual |
| `geocode_confidence` | numeric | 0–1 |
| `h3_res_8` | string | H3 |
| `h3_res_9` | string | H3 |
| `h3_res_10` | string | H3 |
| `manual_override_flag` | boolean | 人工覆核 |

### 4.5 `machine`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `machine_id` | string | 平台機台 ID |
| `store_id` | string | 所屬門市 |
| `source_machine_id` | string | 來源機台 ID |
| `machine_serial_no` | string | 設備序號 |
| `equipment_brand_id` | string | 設備品牌 |
| `machine_family` | string | washer/dryer/combo/payment_terminal/other |
| `machine_type` | string | 具體型號類型 |
| `capacity_kg` | numeric | 公斤數 |
| `capacity_band` | string | small/medium/large/xlarge |
| `installed_on` | date | 安裝日 |
| `removed_on` | date | 移除日 |
| `machine_status` | string | active/inactive/maintenance/retired |
| `effective_from` | timestamp | 生效時間 |
| `effective_to` | timestamp | 失效時間 |

## 5. Operational Event Entities

### 5.1 `transaction`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `transaction_id` | string | 平台交易 ID |
| `source_transaction_id` | string | 來源交易 ID |
| `store_id` | string | 門市 |
| `machine_id` | string | 機台，可空 |
| `member_id` | string | 會員，可空 |
| `event_time` | timestamp | 實際交易時間 |
| `observation_time` | timestamp | 系統觀察時間 |
| `payment_time` | timestamp | 支付完成時間 |
| `gross_amount` | numeric | 原始金額 |
| `discount_amount` | numeric | 折扣 |
| `net_amount` | numeric | 淨額 |
| `currency` | string | 幣別 |
| `payment_method` | string | 支付方式 |
| `transaction_status` | string | succeeded/failed/refunded/voided/partial |
| `refund_of_transaction_id` | string | 原交易 |
| `price_schedule_id` | string | 當時價表 |
| `promotion_id` | string | 活動 |
| `source_system` | string | 來源 |

### 5.2 `machine_cycle`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `cycle_id` | string | Cycle ID |
| `store_id` | string | 門市 |
| `machine_id` | string | 機台 |
| `transaction_id` | string | 關聯交易 |
| `cycle_start_time` | timestamp | 開始 |
| `cycle_end_time` | timestamp | 結束 |
| `cycle_type` | string | wash/dry/combo/cleaning/test |
| `duration_sec` | integer | 秒數 |
| `cycle_status` | string | started/completed/failed/cancelled |
| `error_code` | string | 錯誤碼 |

### 5.3 `machine_status_event`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `status_event_id` | string | 狀態事件 ID |
| `store_id` | string | 門市 |
| `machine_id` | string | 機台 |
| `event_time` | timestamp | 狀態時間 |
| `status_type` | string | online/offline/error/available/occupied/maintenance |
| `severity` | string | info/warn/error/critical |
| `error_code` | string | 錯誤碼 |
| `resolved_time` | timestamp | 解決時間 |

### 5.4 `work_order`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `work_order_id` | string | 工單 ID |
| `store_id` | string | 門市 |
| `machine_id` | string | 機台，可空 |
| `issue_type` | string | failure/cleaning/inspection/complaint |
| `issue_subtype` | string | 子類別 |
| `opened_at` | timestamp | 開單 |
| `closed_at` | timestamp | 結案 |
| `status` | string | open/in_progress/resolved/cancelled |
| `severity` | string | low/medium/high/critical |
| `cost_amount` | numeric | 成本 |
| `root_cause` | string | 根因 |

### 5.5 `customer_service_case`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `case_id` | string | 客服案件 ID |
| `store_id` | string | 門市 |
| `machine_id` | string | 機台 |
| `member_id` | string | 會員 |
| `opened_at` | timestamp | 開案 |
| `closed_at` | timestamp | 結案 |
| `channel` | string | LINE/web/phone/system |
| `topic_code` | string | 主題 |
| `sentiment_score` | numeric | 情緒 |
| `resolution_status` | string | resolved/unresolved/escalated |
| `ttr_minutes` | numeric | 解決時間 |

## 6. Geo and Market Entities

### 6.1 `geo_cell`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `geo_cell_id` | string | 平台地理單元 ID |
| `h3_index` | string | H3 |
| `h3_resolution` | integer | 解析度 |
| `parent_h3_index` | string | 上層 H3 |
| `centroid_latitude` | numeric | 中心點 |
| `centroid_longitude` | numeric | 中心點 |
| `admin_city` | string | 縣市 |
| `admin_district` | string | 區 |
| `service_area_id` | string | 生活圈／等時圈 |

### 6.2 `poi`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `poi_id` | string | POI ID |
| `source_poi_id` | string | 來源 ID |
| `poi_name` | string | 名稱 |
| `poi_category` | string | 大類 |
| `poi_subcategory` | string | 子類 |
| `address_id` | string | 地址 |
| `geo_cell_id` | string | 地理格 |
| `status` | string | active/closed/unknown |
| `confidence` | numeric | 信心 |
| `snapshot_id` | string | 來源快照 |

### 6.3 `competitor_store`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `competitor_store_id` | string | 競店 ID |
| `brand_name` | string | 品牌 |
| `store_name` | string | 店名 |
| `address_id` | string | 地址 |
| `geo_cell_id` | string | 地理格 |
| `estimated_capacity` | numeric | 容量 proxy |
| `distance_to_nearest_oday_m` | numeric | 到最近自家店距離 |
| `status` | string | active/closed/unknown |
| `confidence` | numeric | 信心 |
| `last_verified_at` | timestamp | 最近確認 |

### 6.4 `listing`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `listing_id` | string | 融合後物件 ID |
| `source_listing_id` | string | 來源 ID |
| `source_id` | string | 來源 |
| `listing_status` | string | active/inactive/leased/manual_review/stale |
| `address_id` | string | 地址 |
| `rent_amount` | numeric | 租金 |
| `currency` | string | 幣別 |
| `area_ping` | numeric | 坪數 |
| `floor` | string | 樓層 |
| `frontage_m` | numeric | 面寬 |
| `depth_m` | numeric | 深度 |
| `corner_flag` | boolean | 角間 |
| `parking_flag` | boolean | 停車 |
| `utility_electricity_flag` | boolean | 電力 |
| `utility_drainage_flag` | boolean | 排水 |
| `utility_gas_flag` | boolean | 瓦斯 |
| `available_from` | date | 可租日 |
| `snapshot_id` | string | 來源快照 |
| `confidence` | numeric | 信心 |

### 6.5 `candidate_site`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `candidate_site_id` | string | 候選點 ID |
| `listing_id` | string | 來源物件，可空 |
| `address_id` | string | 地址 |
| `target_format_code` | string | ODay G2 等 |
| `site_status` | string | new/screened/scored/visited/rejected/approved/opened |
| `created_by` | string | 建立者 |
| `created_at` | timestamp | 建立時間 |

## 7. Decision and Model Entities

### 7.1 `model_version`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `model_version_id` | string | 模型版本 |
| `model_name` | string | 模型名稱 |
| `model_family` | string | heatzone/sitescore/forecast/price/adlift/avm/netplan |
| `registry_uri` | string | MLflow/Vertex/Artifact |
| `training_dataset_snapshot_id` | string | 訓練資料 |
| `feature_view_version` | string | 特徵版本 |
| `status` | string | development/staging/shadow/canary/production/retired |
| `released_at` | timestamp | 發布時間 |

### 7.2 `prediction_run`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `prediction_run_id` | string | 預測 run |
| `model_version_id` | string | 模型版本 |
| `feature_snapshot_time` | timestamp | 特徵快照時間 |
| `prediction_origin_time` | timestamp | 預測起點 |
| `prediction_horizon` | string | horizon |
| `input_snapshot_id` | string | 輸入快照 |
| `output_uri` | string | 大型輸出路徑 |
| `run_status` | string | queued/running/succeeded/failed/partial |

### 7.3 `prediction`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `prediction_id` | string | 預測 ID |
| `prediction_run_id` | string | run |
| `entity_type` | string | geo_cell/candidate_site/store/intervention/valuation |
| `entity_id` | string | 實體 ID |
| `target_name` | string | target |
| `p10_value` | numeric | P10 |
| `p50_value` | numeric | P50 |
| `p90_value` | numeric | P90 |
| `unit` | string | 單位 |
| `explanation_json` | json | 解釋 |
| `confidence` | numeric | 信心 |

### 7.4 `decision`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `decision_id` | string | 決策 ID |
| `decision_type` | string | site_go_wait_reject/alert_action/price/ad/valuation/netplan/model_release |
| `entity_type` | string | 對象類型 |
| `entity_id` | string | 對象 ID |
| `recommendation` | string | 系統建議 |
| `decision_status` | string | proposed/approved/rejected/overridden/executed/cancelled/expired |
| `policy_version_id` | string | 政策版本 |
| `prediction_run_id` | string | 依據預測 |
| `created_by` | string | 建立者或系統 |
| `created_at` | timestamp | 建立時間 |

### 7.5 `approval`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `approval_id` | string | 核准 ID |
| `decision_id` | string | 決策 |
| `approver_id` | string | 核准人 |
| `approval_status` | string | pending/approved/rejected/returned/escalated |
| `approved_at` | timestamp | 核准時間 |
| `comment` | string | 意見 |

## 8. Module-specific Entities

### 8.1 `heatzone_score`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `heatzone_score_id` | string | ID |
| `geo_cell_id` | string | 地理格 |
| `score_run_id` | string | 批次 |
| `heat_score` | numeric | 熱區分數 |
| `priority_rank` | integer | 排名 |
| `unmet_demand_score` | numeric | 未滿足需求 |
| `format_fit_score` | numeric | ODay G2 適配 |
| `cannibalization_risk_score` | numeric | 稀釋風險 |
| `rent_feasibility_score` | numeric | 租金可行 |
| `heatzone_state` | string | untouched/partially_absorbed/saturated/under_realized/still_expandable |
| `confidence` | numeric | 信心 |

### 8.2 `sitescore_run`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `sitescore_run_id` | string | SiteScore run |
| `candidate_site_id` | string | 候選點 |
| `target_format_code` | string | 店型 |
| `prediction_run_id` | string | 預測 run |
| `m1_p10/m1_p50/m1_p90` | numeric | 第 1 月 |
| `m3_p10/m3_p50/m3_p90` | numeric | 第 3 月 |
| `m6_p10/m6_p50/m6_p90` | numeric | 第 6 月 |
| `m12_p10/m12_p50/m12_p90` | numeric | 第 12 月 |
| `payback_p50_months` | numeric | 回本期 |
| `decision_recommendation` | string | go/wait/reject/investigate |
| `report_uri` | string | 報告 |

### 8.3 `forecast_output`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `forecast_output_id` | string | Forecast ID |
| `store_id` | string | 門市 |
| `prediction_run_id` | string | run |
| `horizon_days` | integer | 28/56/84/168 |
| `target_metric` | string | revenue/gm/utilization |
| `p10/p50/p90` | numeric | 區間 |
| `trajectory_class` | string | ramping/growing/plateau/declining |
| `turning_point_probability` | numeric | 轉折機率 |
| `sitescore_gap_ratio` | numeric | 實績對原預測 |

### 8.4 `alert`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `alert_id` | string | 警示 ID |
| `store_id` | string | 門市 |
| `alert_level` | string | green/yellow/orange/red |
| `alert_reason_code` | string | revenue_gap/equipment/cost/customer/ad/price/external |
| `evidence_json` | json | 證據 |
| `opened_at` | timestamp | 產生時間 |
| `closed_at` | timestamp | 關閉時間 |
| `status` | string | open/acknowledged/in_progress/resolved/dismissed |

### 8.5 `intervention`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `intervention_id` | string | 干預 ID |
| `store_id` | string | 門市 |
| `intervention_type` | string | price/ad/promotion/crm/maintenance/cleaning/other |
| `trigger_alert_id` | string | 警示 |
| `eligibility_status` | string | eligible/ineligible/manual_review |
| `action_set_json` | json | 候選動作 |
| `approved_action_json` | json | 核准動作 |
| `start_time` | timestamp | 開始 |
| `end_time` | timestamp | 結束 |
| `observation_start_time` | timestamp | 觀察開始 |
| `observation_end_time` | timestamp | 觀察結束 |
| `status` | string | proposed/approved/executing/observing/evaluated/stopped/rolled_back |

### 8.6 `intervention_outcome`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `outcome_id` | string | Outcome ID |
| `intervention_id` | string | 干預 |
| `outcome_time` | timestamp | Outcome 觀察時間 |
| `incremental_revenue` | numeric | 增量營收 |
| `incremental_gross_margin` | numeric | 增量毛利 |
| `method` | string | before_after/did/synthetic/uplift/manual |
| `evidence_level` | string | low/medium/high/causal_candidate |
| `side_effect_json` | json | 副作用 |
| `label_maturity_time` | timestamp | 標籤成熟時間 |

### 8.7 `valuation_run`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `valuation_run_id` | string | 估值 run |
| `store_id` | string | 門市 |
| `valuation_date` | date | 估值日 |
| `normalized_gm_ttm` | numeric | 正常化 TTM GM |
| `gm_fwd_p50` | numeric | 預估 GM |
| `income_value_p10/p50/p90` | numeric | Income Approach |
| `asset_value_p50` | numeric | Asset Approach |
| `market_value_p50` | numeric | Market Approach |
| `fair_price_p50` | numeric | 公允價 |
| `reserve_price` | numeric | 保留價 |
| `asking_price` | numeric | 詢價 |
| `report_uri` | string | 估值報告 |

### 8.8 `network_plan`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `network_plan_id` | string | 店網方案 ID |
| `planning_period_start` | date | 期間開始 |
| `planning_period_end` | date | 期間結束 |
| `scenario_name` | string | base/downside/upside/custom |
| `objective_value` | numeric | 目標值 |
| `solver_status` | string | optimal/feasible/infeasible/timeout/error |
| `constraint_summary_json` | json | 限制摘要 |
| `created_at` | timestamp | 建立時間 |

### 8.9 `network_plan_action`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `network_plan_action_id` | string | 行動 ID |
| `network_plan_id` | string | 方案 |
| `store_id` | string | 既有門市，可空 |
| `candidate_site_id` | string | 新址，可空 |
| `action_type` | string | open/keep/improve/move/exit |
| `quarter` | string | 執行季度 |
| `expected_gm_delta` | numeric | 毛利影響 |
| `capital_required` | numeric | 資本需求 |
| `risk_level` | string | low/medium/high |

## 9. Audit and Governance Entities

### 9.1 `audit_event`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `audit_event_id` | string | 稽核事件 ID |
| `actor_id` | string | 人或服務 |
| `actor_type` | string | user/service/system |
| `action` | string | create/update/delete/approve/reject/export/run_model |
| `entity_type` | string | 實體 |
| `entity_id` | string | ID |
| `occurred_at` | timestamp | 時間 |
| `before_hash` | string | 變更前 |
| `after_hash` | string | 變更後 |
| `ip_address` | string | IP |
| `correlation_id` | string | 追蹤 |

### 9.2 `data_snapshot`

| 欄位 | 型別 | 說明 |
|---|---|---|
| `snapshot_id` | string | Snapshot ID |
| `snapshot_type` | string | raw/canonical/model_ready/training |
| `source_id` | string | 來源 |
| `snapshot_time` | timestamp | 快照時間 |
| `storage_uri` | string | 儲存路徑 |
| `schema_version` | string | Schema |
| `row_count` | integer | 筆數 |
| `quality_score` | numeric | 品質分數 |
| `created_by_run_id` | string | Pipeline run |

## 10. 狀態代碼總表

| Entity | 欄位 | 值 |
|---|---|---|
| Store | `store_status` | planned/open/suspended/closed/transferred |
| Listing | `listing_status` | active/inactive/leased/manual_review/stale |
| Candidate Site | `site_status` | new/screened/scored/visited/rejected/approved/opened |
| HeatZone | `heatzone_state` | untouched/partially_absorbed/saturated/under_realized/still_expandable |
| Decision | `decision_status` | proposed/approved/rejected/overridden/executed/cancelled/expired |
| Alert | `alert_level` | green/yellow/orange/red |
| Intervention | `status` | proposed/approved/executing/observing/evaluated/stopped/rolled_back |
| Model Version | `status` | development/staging/shadow/canary/production/retired |
| Job | `run_status` | queued/running/succeeded/failed/cancelled/partial |
| Solver | `solver_status` | optimal/feasible/infeasible/timeout/error |

## 11. 實作儲存建議

| 資料型態 | 建議儲存 | 說明 |
|---|---|---|
| Operational Canonical | Cloud SQL PostgreSQL / PostGIS | 工作流、核准、任務、門市主檔、Listing 狀態 |
| Analytical Canonical | BigQuery | 模型、報表、批次與長期歷史 |
| Raw Snapshot | Cloud Storage | 外部來源與上游原始檔 |
| Geo | PostGIS + BigQuery GIS | 地理查詢與批次特徵 |
| Search | OpenSearch / Postgres full-text | Listing、報告、稽核查詢 |
| Model Artifact | GCS / MLflow / Vertex AI | 模型與輸出報告 |

## 12. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| P0 來源可映射到 Canonical Entity | Mapping Review | MUST |
| Canonical ID 與 Source ID 分離 | Schema Review | MUST |
| 決策、核准、執行、Outcome 分成不同 Entity | ERD Review | MUST |
| 交易退款與作廢可用事件表示 | Golden Dataset Test | MUST |
| 主檔支援有效期間與歷史重建 | SCD Test | MUST |
| 所有 Model Output 可追到 model_version 與 data snapshot | Lineage Test | MUST |
| 所有高風險操作有 Audit Event | Security Test | MUST |
