---
doc_id: ODP-DATA-06
title: "Model-ready Views 規格"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus Model-ready Views 規格

## 1. 文件目的

本文件定義 ODay Plus 各模型、決策服務與報表使用的 Model-ready Views。Model-ready View 是 Raw／Canonical 資料與模型之間的正式契約，用來避免不同模型直接讀同一張原始表而產生語意混亂、資料洩漏或訓練／推論不一致。

每個 View 必須定義 Grain、Entity、Feature Snapshot Time、Prediction Origin Time、Target、可用模型、刷新頻率、品質門檻、時間語意與資料污染處理規則。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. View 設計原則

1. 每個 View 只服務明確問題，不做萬用寬表。
2. 每個 View 必須有粒度：H3、候選點、門市日、機台小時、干預店日等。
3. 每個 View 必須保存 `feature_snapshot_time` 與來源 snapshot。
4. 訓練資料必須符合 point-in-time correctness。
5. 干預資料必須標示 Treatment，不得默默當成一般特徵。
6. 模型輸入與 Target 必須分開；Prediction Output 不得回灌成訓練特徵，除非明確設計。
7. View 的 schema 改變必須產生新版本。
8. Production model 只能使用 production View。

## 3. Model-ready View Catalog

| View | Grain | 主要用途 | 主要消費者 | Refresh | Criticality |
|---|---|---|---|---|---|
| `geo_grid_view` | H3 cell × snapshot | 熱區需求與機會缺口 | HeatZone | weekly/monthly | P0 |
| `candidate_site_view` | candidate site × decision time | 具體物件評分 | SiteScore | on demand/daily | P0 |
| `brand_transfer_view` | source brand × target brand × segment × age | 跨品牌轉換 | SiteScore | monthly/quarterly | P1 |
| `ramp_curve_view` | store cohort × store age × calendar | 新店爬坡 | SiteScore/ForecastOps | monthly | P1 |
| `store_machine_timeseries_view` | store/machine × date/hour | 店級與設備級時序 | ForecastOps | daily/hourly | P0 |
| `forecast_training_view` | store × date | Forecast 訓練 | ForecastOps | daily | P0 |
| `intervention_panel_view` | store × date × intervention | 干預效果 | Intervention/PriceOps | daily | P0 |
| `matched_control_view` | treated store × control candidate × date | 廣告／促銷對照 | AdLift | campaign / weekly | P1 |
| `valuation_view` | store × valuation date | 估值 | DealRoomAVM | monthly/on demand | P1 |
| `network_plan_view` | store/candidate × planning period | 店網最佳化 | NetPlan | monthly/quarterly | P1 |

## 4. 共用欄位

每個 View 至少包含：

| 欄位 | 說明 |
|---|---|
| `view_name` | View 名稱 |
| `view_version` | View 版本 |
| `entity_id` | 主要實體 ID |
| `feature_snapshot_time` | 特徵快照時間 |
| `prediction_origin_time` | 預測起點或決策時間 |
| `source_snapshot_ids` | 來源 snapshot 清單 |
| `data_quality_score` | View 品質分數 |
| `confidence` | 特徵信心 |
| `is_training_eligible` | 是否可進訓練 |
| `is_scoring_eligible` | 是否可推論 |
| `exclusion_reason` | 排除原因 |

## 5. `geo_grid_view`

### 5.1 目的

供 HeatZone Radar 估計全台各空間單元的外部洗衣需求、未滿足需求、競爭缺口、ODay G2 適配度、自家稀釋與租金可行性。

### 5.2 Grain

`h3_index` × `h3_resolution` × `feature_snapshot_time`

### 5.3 主要欄位

| 欄位 | 說明 |
|---|---|
| `h3_index` | H3 cell |
| `h3_resolution` | 解析度 |
| `admin_city` / `admin_district` | 行政區 |
| `population_total` | 常住人口 |
| `household_count` | 戶數 |
| `rental_population_proxy` | 租屋人口 proxy |
| `student_population_proxy` | 學生人口 proxy |
| `daytime_population_proxy` | 白天人口 proxy |
| `poi_school_count` | 學校 POI |
| `poi_residential_count` | 住宅 POI |
| `poi_market_count` | 市場／生活機能 |
| `competitor_count_500m` | 競店數 |
| `competitor_capacity_proxy_500m` | 競店容量 proxy |
| `oday_store_count_500m` | 自家店數 |
| `oday_overlap_ratio` | 自家服務重疊 |
| `rent_p50_per_ping` | 租金中位 |
| `listing_count_active` | 目前物件數 |
| `road_access_score` | 可達性分數 |
| `parking_score` | 停車／臨停 proxy |
| `external_demand_baseline` | 透明加權 baseline |
| `feature_confidence` | 來源信心 |

### 5.4 Target / Output

| 用途 | Target / Output |
|---|---|
| 訓練 | 外部需求 proxy、歷史門市營收回推、區位型態 |
| 推論 | heat_score、priority_rank、unmet_demand_score、format_fit_score、cannibalization_risk |

### 5.5 DQ Gate

- H3 覆蓋率 >= 99%。
- P0 外部來源新鮮度達標。
- 競店資料若超過 freshness threshold，必須 confidence penalty。
- 人口或租金缺值可用上層 H3 或行政區回退，但必須標示。

## 6. `candidate_site_view`

### 6.1 目的

供 SiteScore 評估具體候選物件是否適合開 ODay G2，並輸出 M1/M3/M6/M12、成熟期營收、回本期、稀釋與風險。

### 6.2 Grain

`candidate_site_id` × `prediction_origin_time`

### 6.3 主要欄位

| 欄位 | 說明 |
|---|---|
| `candidate_site_id` | 候選點 |
| `listing_id` | 來源物件 |
| `target_format_code` | ODay G2 |
| `rent_amount` | 租金 |
| `area_ping` | 坪數 |
| `frontage_m` | 面寬 |
| `floor` | 樓層 |
| `utility_electricity_flag` | 電力 |
| `utility_drainage_flag` | 排水 |
| `utility_gas_flag` | 瓦斯 |
| `ventilation_flag` | 通風 |
| `geocode_confidence` | Geocode 信心 |
| `h3_index` | H3 |
| `external_demand_score` | 外部需求 |
| `format_fit_score` | 店型適配 |
| `brand_capture_prior` | 品牌捕獲先驗 |
| `competitor_distance_min_m` | 最近競店 |
| `competitor_count_500m` | 競店數 |
| `oday_cannibalization_risk` | 自家稀釋 |
| `rent_to_demand_ratio` | 租金需求比 |
| `comparable_store_ids` | 相似店 |
| `hard_rule_fail_reasons` | 硬限制失敗原因 |

### 6.4 Feature Exclusion

不得使用：該候選點決策時間之後才出現的新競店、新道路、未來租金、未來開店實績、未成熟 outcome。

### 6.5 Output

- M1/M3/M6/M12 P10/P50/P90。
- Mature state P10/P50/P90。
- Payback months P10/P50/P90。
- GO/WAIT/REJECT/INVESTIGATE 建議。
- Explainability：主要正向與負向因子。

## 7. `brand_transfer_view`

### 7.1 Grain

`source_brand_id` × `target_brand_id` × `location_type` × `store_format_code` × `store_age_bucket` × `feature_snapshot_time`

### 7.2 主要欄位

| 欄位 | 說明 |
|---|---|
| `source_brand_id` | 來源品牌 |
| `target_brand_id` | 目標品牌，ODay |
| `location_type` | 區位類型 |
| `source_format_code` | 來源店型 |
| `target_format_code` | ODay G2 |
| `store_age_bucket` | 店齡區間 |
| `conversion_p10/p50/p90` | 轉換係數 |
| `sample_size` | 樣本數 |
| `shrinkage_level` | 階層式收縮程度 |
| `confidence` | 信心 |
| `valid_from` / `valid_to` | 適用期間 |

### 7.3 樣本不足規則

若 segment 樣本不足，必須回退至較高層級：目標品牌全體、區位全品牌、相近品牌、相近店型。不得用極少樣本產生未收縮倍率。

## 8. `ramp_curve_view`

### 8.1 Grain

`cohort_key` × `store_age_month` × `calendar_month` × `feature_snapshot_time`

### 8.2 欄位

| 欄位 | 說明 |
|---|---|
| `cohort_key` | 區位、品牌、店型 cohort |
| `store_age_month` | 店齡月 |
| `ramp_index_p10/p50/p90` | 爬坡指數 |
| `seasonality_index` | 季節指數 |
| `sample_store_count` | 樣本店數 |
| `mature_baseline_month` | 預估達成熟月份 |
| `confidence` | 信心 |

## 9. `store_machine_timeseries_view`

### 9.1 目的

供 ForecastOps、設備異常、有效產能、根因與日常監控使用。

### 9.2 Grain

第一版：`store_id` × `date`；進階：`store_id` × `machine_id` × `hour`

### 9.3 欄位

| 欄位 | 說明 |
|---|---|
| `store_id` | 門市 |
| `machine_id` | 機台，可空 |
| `date` / `hour` | 時間 |
| `gross_revenue` | 營收 |
| `net_revenue` | 淨營收 |
| `gross_margin_proxy` | 毛利 proxy |
| `transaction_count` | 交易數 |
| `cycle_count` | cycle 數 |
| `available_minutes` | 可用分鐘 |
| `occupied_minutes` | 使用分鐘 |
| `downtime_minutes` | 停機分鐘 |
| `availability_rate` | 可用率 |
| `utilization_rate` | 稼動率 |
| `avg_cycle_duration_sec` | 平均 cycle |
| `refund_count` | 退款數 |
| `cs_case_count` | 客服案件數 |
| `work_order_count` | 工單數 |
| `price_index` | 價格指數 |
| `promotion_flag` | 促銷 |
| `ad_flag` | 廣告 |
| `weather_features` | 天氣 |

## 10. `forecast_training_view`

### 10.1 Grain

`store_id` × `date` × `feature_snapshot_time`

### 10.2 特徵群

| 群組 | 欄位範例 |
|---|---|
| Lag | revenue_lag_1/7/14/28 |
| Rolling | rolling_mean_7/28、volatility_28 |
| Calendar | day_of_week、holiday、month、school_term |
| Store Static | location_type、format、machine_count、capacity |
| Store Age | store_age_days、ramp_bucket |
| Dynamic Exogenous | price_index、ad_flag、promotion_flag、weather、downtime |
| Peer | peer_revenue_index、same_age_cohort_index |
| SiteScore | original_m1/m3/m6/m12 path、realization ratio |

### 10.3 Target

| Target | Horizon |
|---|---|
| `daily_net_revenue` | 1–28 days |
| `weekly_net_revenue` | 4/8/12/24 weeks |
| `gross_margin_proxy` | optional |
| `utilization_rate` | optional |

### 10.4 資料污染規則

廣告、促銷、調價、維修、清潔等干預必須標示；Forecast 模型可使用為 exogenous features，但 SiteScore 訓練需依規則排除或正常化。

## 11. `intervention_panel_view`

### 11.1 Grain

`store_id` × `date` × `intervention_id`

### 11.2 欄位

| 欄位 | 說明 |
|---|---|
| `intervention_id` | 干預 |
| `store_id` | 門市 |
| `date` | 日期 |
| `intervention_type` | price/ad/promotion/crm/maintenance/cleaning |
| `treatment_flag` | 是否 treatment |
| `treatment_intensity` | 強度，如預算、折扣、調價幅度 |
| `eligibility_score` | eligibility |
| `propensity_score` | 後續因果使用 |
| `overlap_interventions` | 重疊干預 |
| `pre_period_flag` | 前期 |
| `treatment_period_flag` | 執行期 |
| `observation_period_flag` | 觀察期 |
| `outcome_revenue` | outcome |
| `outcome_gm` | outcome |
| `evidence_level` | 證據等級 |

## 12. `matched_control_view`

### 12.1 用途

供 AdLift、促銷與部分干預效果估計選擇對照店。

### 12.2 Grain

`treated_store_id` × `control_store_id` × `date`

### 12.3 欄位

| 欄位 | 說明 |
|---|---|
| `treated_store_id` | Treatment 店 |
| `control_store_id` | 候選對照店 |
| `match_score` | 匹配分數 |
| `location_similarity` | 區位相似 |
| `store_age_similarity` | 店齡相似 |
| `format_similarity` | 店型相似 |
| `pretrend_pvalue` | Pre-trend 檢定 |
| `pre_period_revenue_series` | 前期序列摘要 |
| `excluded_reason` | 排除原因 |
| `valid_control_flag` | 是否可用 |

## 13. `valuation_view`

### 13.1 Grain

`store_id` × `valuation_date`

### 13.2 欄位

| 欄位 | 說明 |
|---|---|
| `store_id` | 門市 |
| `valuation_date` | 估值日 |
| `gm_ttm` | 近 12 月毛利 |
| `normalized_gm_ttm` | 正常化毛利 |
| `gm_fwd_p10/p50/p90` | 未來毛利 |
| `asset_book_value` | 資產帳面值 |
| `remaining_asset_life` | 剩餘壽命 |
| `lease_remaining_months` | 租約剩餘 |
| `rent_amount` | 租金 |
| `intervention_adjustment` | 干預正常化調整 |
| `forecast_confidence` | Forecast 信心 |
| `comparable_count` | 可比案件 |
| `liquidity_features` | 流動性特徵 |

## 14. `network_plan_view`

### 14.1 Grain

`planning_entity_id` × `planning_period`，其中 entity 可為既有 store 或 candidate site。

### 14.2 欄位

| 欄位 | 說明 |
|---|---|
| `entity_type` | existing_store/candidate_site |
| `entity_id` | 實體 |
| `planning_quarter` | 季度 |
| `action_candidates` | open/keep/improve/move/exit |
| `expected_gm_p10/p50/p90` | 預期毛利 |
| `capital_required` | 資本需求 |
| `lease_constraint` | 租約限制 |
| `construction_lead_time` | 裝修時間 |
| `staffing_constraint` | 人力限制 |
| `cannibalization_matrix_row` | 稀釋矩陣 |
| `valuation_p50` | 估值 |
| `risk_score` | 風險 |
| `hard_constraint_flags` | 硬限制 |

## 15. View 版本化

| 變更 | 處理 |
|---|---|
| 新增 nullable feature | Minor version |
| 改變 feature 公式 | Major version |
| 移除欄位 | Breaking，需雙版本並行 |
| 改變 target 定義 | New view version + Model Review |
| 改變 point-in-time 規則 | ADR + full backtest |

## 16. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| 10 個 Model-ready Views 皆有 Grain、欄位與消費者 | Document Review | MUST |
| 每個 View 有 feature_snapshot_time | Schema Test | MUST |
| 訓練 View 可執行 point-in-time join | Backtest Audit | MUST |
| 干預欄位可區分 treatment / natural variation | Data Test | MUST |
| View DQ fail 可阻擋 Production Model | Pipeline Gate | MUST |
| View version 可追到模型版本 | Lineage Test | MUST |
| 任一決策可重建當時 View snapshot | Reproducibility Test | MUST |
