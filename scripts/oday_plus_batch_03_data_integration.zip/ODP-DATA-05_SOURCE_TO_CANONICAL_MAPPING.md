---
doc_id: ODP-DATA-05
title: "Source-to-Canonical Mapping"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus Source-to-Canonical Mapping

## 1. 文件目的

本文件定義 ODay Plus 如何將上游 IoT／內部資料、外部資料與人工資料轉換成 Canonical Data Model。它是 Integration Layer 的實作契約，也是資料品質測試、Backfill、Quarantine 與模型輸入可重現性的基礎。

本文件不假設上游欄位固定不變；所有欄位異動都必須先更新 Mapping 版本，才可進入 Production Pipeline。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. Mapping 基本規則

| 規則 | 說明 |
|---|---|
| Source Preserve | 原始資料不可直接丟棄，至少保存 raw snapshot 或 raw payload hash |
| Canonical Required | 模型與 API 只讀 Canonical 或 Model-ready View |
| Deterministic Transform | 轉換必須可重跑、可重現、可比對 |
| Type Strict | 型別錯誤不得默默轉成 null |
| Time Explicit | 所有事件必須有 event_time 與 observation_time |
| Key Mapping | source id 必須透過 identity mapping 產生 canonical id |
| Versioned | 每個 mapping 有 mapping_version |
| Auditable | 轉換 run 必須產生 row count、error count、dq score |

## 3. Mapping Metadata

每一條 mapping 必須能在 `mapping_registry` 中登錄：

| 欄位 | 說明 |
|---|---|
| `mapping_id` | 例如 `MAP-INT-TRANSACTION-v1` |
| `source_id` | 來源 ID |
| `source_dataset` | 來源資料集 |
| `target_entity` | Canonical Entity |
| `mapping_version` | 版本 |
| `owner` | Integration Owner |
| `effective_from` | 生效時間 |
| `effective_to` | 失效時間 |
| `status` | draft/staging/production/deprecated |
| `dq_profile` | 套用 DQ 規則 |
| `breaking_change_flag` | 是否破壞性變更 |

## 4. 通用欄位 Mapping

| Source Pattern | Canonical Field | Transform Rule | DQ Rule |
|---|---|---|---|
| `source_system` | `source_system` | trim lower snake case | not null |
| any primary key | `source_record_id` | cast string | not null, unique within source |
| source created/occurred time | `event_time` | parse timezone, default source timezone Asia/Taipei if documented | not null, valid timestamp |
| source received/uploaded time | `observation_time` | parse timestamp | not null, >= event_time unless exception |
| source update time | `source_updated_at` | parse timestamp | not null |
| source deleted flag | `is_deleted` | boolean normalize | default false |
| payload | `raw_payload` | JSON serialize with PII policy | optional |
| natural key | `idempotency_key` | deterministic concat/hash | not null |

## 5. 內部來源 Mapping

### 5.1 Store Master → `store` / `address_location`

| Source Field | Canonical Field | Transform | Required | Error Handling |
|---|---|---|---|---|
| `shop_no` / `store_code` | `store.source_store_id` | cast string, trim | Y | reject row |
| `brand_code` | `brand.brand_code` | normalize brand code | Y | quarantine if unknown |
| `shop_name` | `store.store_name` | trim | Y | quarantine if empty |
| `status` | `store.store_status` | map to enum | Y | quarantine if unmapped |
| `open_date` | `store.opened_on` | parse date | N | warning |
| `close_date` | `store.closed_on` | parse date | N | warning |
| `address` | `address_location.raw_address` | preserve raw | Y | quarantine if open store has no address |
| `lat` | `address_location.latitude` | numeric | N | geocode if null |
| `lng` | `address_location.longitude` | numeric | N | geocode if null |
| `format` | `store.store_format_code` | map to ODay G2/G1/traditional | N | default unknown |
| `region` | `store.region_code` | map region | N | warning |
| `updated_at` | SCD fields | compare hash and create new version | Y | reject if invalid |

Status mapping:

| Source | Canonical |
|---|---|
| `open`、`營業中`、`active` | `open` |
| `planned`、`preopen`、`籌備` | `planned` |
| `closed`、`結束` | `closed` |
| `suspended`、`暫停` | `suspended` |
| `transferred`、`轉讓` | `transferred` |

### 5.2 Machine Master → `machine`

| Source Field | Canonical Field | Transform | Required | Error Handling |
|---|---|---|---|---|
| `device_sn` / `machine_no` | `machine.source_machine_id` | cast string | Y | reject |
| `shop_no` | `machine.store_id` | identity lookup | Y | quarantine if missing store |
| `serial_no` | `machine.machine_serial_no` | trim | Y | warning if duplicate |
| `equipment_brand` | `machine.equipment_brand_id` | brand lookup | N | unknown brand |
| `type` | `machine.machine_family` | washer/dryer/combo/payment_terminal | Y | quarantine if unmapped |
| `kg` | `machine.capacity_kg` | numeric | N | warning |
| `kg` | `machine.capacity_band` | banding rule | N | null if kg missing |
| `installed_at` | `machine.installed_on` | date | N | warning |
| `removed_at` | `machine.removed_on` | date | N | warning |
| `status` | `machine.machine_status` | enum | Y | quarantine if unmapped |

Capacity band rule:

| 條件 | `capacity_band` |
|---|---|
| null | null |
| <= 10 kg | `small` |
| > 10 and <= 18 kg | `medium` |
| > 18 and <= 28 kg | `large` |
| > 28 kg | `xlarge` |

### 5.3 Transaction → `transaction`

| Source Field | Canonical Field | Transform | Required | Error Handling |
|---|---|---|---|---|
| `txn_id` | `transaction.source_transaction_id` | cast string | Y | reject |
| `shop_no` | `transaction.store_id` | identity lookup | Y | quarantine |
| `device_sn` | `transaction.machine_id` | identity lookup | N | null with warning if not found |
| `member_no` / `line_uid` | `transaction.member_id` | tokenized identity lookup | N | null |
| `txn_time` | `transaction.event_time` | timestamp parse | Y | reject |
| `paid_at` | `transaction.payment_time` | timestamp parse | N | warning |
| `created_at` | `transaction.observation_time` | timestamp parse | Y | reject |
| `amount` | `transaction.gross_amount` | decimal | Y | reject if invalid |
| `discount` | `transaction.discount_amount` | decimal default 0 | N | default 0 |
| `net_amount` | `transaction.net_amount` | if null amount-discount | Y | reject if inconsistent beyond tolerance |
| `payment_type` | `transaction.payment_method` | enum mapping | N | unknown |
| `status` | `transaction.transaction_status` | enum mapping | Y | quarantine if unmapped |
| `refund_txn_id` | `transaction.refund_of_transaction_id` | lookup original | N | warning if missing |
| `price_ver` | `transaction.price_schedule_id` | lookup | N | null with DQ warning |
| `campaign_id` | `transaction.promotion_id` | lookup | N | null |

Transaction status mapping:

| Source | Canonical | 計算營收 |
|---|---|---|
| `paid`、`success` | `succeeded` | Y |
| `failed`、`timeout` | `failed` | N |
| `refund`、`refunded` | `refunded` | negative or linked adjustment |
| `void`、`cancelled` | `voided` | N |
| `partial_refund` | `partial` | net adjusted |

### 5.4 Machine Cycle → `machine_cycle`

| Source Field | Canonical Field | Transform |
|---|---|---|
| `cycle_id` | `cycle.source_cycle_id` | cast string |
| `shop_no` | `cycle.store_id` | store lookup |
| `device_sn` | `cycle.machine_id` | machine lookup |
| `start_time` | `cycle.cycle_start_time` | timestamp |
| `end_time` | `cycle.cycle_end_time` | timestamp |
| `mode` | `cycle.cycle_type` | wash/dry/combo/cleaning/test |
| `duration` | `cycle.duration_sec` | seconds normalize |
| `status` | `cycle.cycle_status` | enum |
| `error` | `cycle.error_code` | trim |
| `txn_id` | `cycle.transaction_id` | transaction lookup |

### 5.5 Machine Status → `machine_status_event`

| Source Field | Canonical Field | Transform |
|---|---|---|
| `event_id` | `status_event.source_status_event_id` | cast string |
| `device_sn` | `status_event.machine_id` | lookup |
| `status_time` | `status_event.event_time` | timestamp |
| `status` | `status_event.status_type` | enum |
| `severity` | `status_event.severity` | info/warn/error/critical |
| `error_code` | `status_event.error_code` | normalize |
| `resolved_at` | `status_event.resolved_time` | timestamp |

### 5.6 Price Schedule → `price_schedule`

| Source Field | Canonical Field | Transform |
|---|---|---|
| `price_id` | `price_schedule.source_price_id` | cast string |
| `shop_no` | `price_schedule.store_id` | lookup |
| `machine_type` | `price_schedule.machine_family` | enum |
| `kg_band` | `price_schedule.capacity_band` | enum |
| `time_band` | `price_schedule.time_band` | enum |
| `price` | `price_schedule.price_amount` | decimal |
| `start_at` | `price_schedule.effective_from` | timestamp |
| `end_at` | `price_schedule.effective_to` | timestamp |
| `approved_by` | `price_schedule.approved_by` | user mapping |

### 5.7 Work Order / CS Case / Cost / Lease / Asset

| Source Dataset | Canonical Entity | Key Transform | Critical Rule |
|---|---|---|---|
| `maintenance_ticket` | `work_order` | ticket id + store/machine lookup | open/closed times required |
| `customer_case` | `customer_service_case` | case id + topic taxonomy | PII masking required |
| `monthly_cost` | `store_cost_fact` | store + month + cost type | cost period required |
| `lease_contract` | `lease` | store/listing + lease period | lease end required for NetPlan |
| `asset_register` | `asset` | asset id + machine/store lookup | book value and depreciation required for AVM |

## 6. 外部來源 Mapping

### 6.1 POI → `poi`

| Source Field | Canonical Field | Transform |
|---|---|---|
| provider POI id | `poi.source_poi_id` | cast string |
| name | `poi.poi_name` | normalize whitespace |
| category | `poi.poi_category` | taxonomy mapping |
| subcategory | `poi.poi_subcategory` | taxonomy mapping |
| address | `address_location.raw_address` | preserve |
| lat/lng | `address_location.latitude/longitude` | numeric validity |
| status | `poi.status` | active/closed/unknown |
| snapshot | `poi.snapshot_id` | snapshot lookup |
| confidence | `poi.confidence` | provider confidence + geocode confidence |

### 6.2 Competitor → `competitor_store`

| Source Field | Canonical Field | Transform |
|---|---|---|
| external id | `competitor_store.source_competitor_id` | cast string |
| name | `competitor_store.store_name` | normalize |
| brand | `competitor_store.brand_name` | brand dictionary |
| address/lat/lng | `address_location` | geocode / validate |
| rating/photos/review | `estimated_capacity` | optional proxy, not authoritative |
| status | `competitor_store.status` | active/closed/unknown |
| last seen | `last_verified_at` | timestamp |

### 6.3 Listing → `listing`

| Source Field | Canonical Field | Transform | Rule |
|---|---|---|---|
| listing id | `listing.source_listing_id` | cast string | if missing, hash natural key |
| address | `address_location.raw_address` | normalize | required |
| rent | `listing.rent_amount` | parse amount | must be > 0 if listed |
| ping | `listing.area_ping` | parse numeric | warn if missing |
| floor | `listing.floor` | normalize | basement/1F/2F etc. |
| description | utility flags | NLP/manual extraction | confidence tagged |
| available date | `listing.available_from` | date | optional |
| status | `listing.listing_status` | active/stale/leased/manual_review | required |
| source snapshot | `listing.snapshot_id` | lookup | required |

### 6.4 Population / Rent / Weather / Calendar

| Source | Canonical / Feature | Transform |
|---|---|---|
| population | `geo_demographic_snapshot` | join to admin boundary and H3 by area-weighted allocation |
| rent market | `rent_market_snapshot` | normalize per ping/month, assign geo cell and quantile |
| weather | `weather_daily` | station/area to store or H3 nearest match |
| calendar | `calendar_context` | holiday, school term, weekday, long weekend flags |

## 7. Identity Mapping 流程

```mermaid
flowchart TB
    A[Source Record] --> B[Normalize Natural Key]
    B --> C{Existing Source Mapping?}
    C -- Yes --> D[Use Canonical ID]
    C -- No --> E{Potential Duplicate?}
    E -- No --> F[Create Canonical ID]
    E -- Yes --> G[Manual / Rule-based Resolution]
    G --> H[Mapping Decision]
    H --> D
    F --> I[Insert Mapping]
    D --> J[Canonical Entity]
```

Identity Mapping 表必須包含：`source_system`、`source_entity_type`、`source_id`、`canonical_entity_type`、`canonical_id`、`confidence`、`effective_from`、`effective_to`、`review_status`。

## 8. Quarantine 規則

| 觸發條件 | Quarantine Reason | 可自動修復 | 人工處理 |
|---|---|---|---|
| 必填欄位缺失 | `missing_required_field` | N | Source Owner |
| 主鍵重複且 payload 不同 | `duplicate_key_conflict` | N | Integration Owner |
| 門市或機台找不到 | `missing_reference` | 部分可 | Data Steward |
| 時間不可解析 | `invalid_time` | N | Source Owner |
| 金額不合理 | `invalid_amount` | N | Finance Owner |
| Geocode 信心低 | `low_geocode_confidence` | 部分可 | Geo Steward |
| 未授權來源 | `license_blocked` | N | Security / Legal |

## 9. Mapping 測試

| 測試 | 說明 |
|---|---|
| Row Count Reconciliation | 來源筆數與 canonical 筆數差異需可解釋 |
| Duplicate Test | canonical key 唯一 |
| Null Test | 必填欄位不可為 null |
| Referential Test | store、machine、transaction 等關聯存在 |
| Enum Test | 狀態與類別必須落在定義值 |
| Time Test | event_time、observation_time、effective period 合理 |
| Amount Test | 金額、折扣、淨額一致 |
| Snapshot Reproducibility | 同一來源 snapshot 重跑結果一致 |

## 10. Mapping 變更流程

1. 建立 mapping change request。
2. 標示 minor / major / breaking。
3. 產生 Staging mapping version。
4. 用 golden dataset 回歸測試。
5. 檢查下游 Model-ready Views 影響。
6. Data Contract Review 核准。
7. Production 雙版本並行一段時間，必要時可回滾。
8. 更新文件與 RTM。

## 11. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| 所有 P0 source 有 mapping registry | Registry Review | MUST |
| 每個 mapping 有 golden dataset | Test Data Review | MUST |
| 每個 mapping 可重跑產生一致結果 | Pipeline Test | MUST |
| 主鍵映射支援重命名、換機、搬遷 | Identity Test | MUST |
| Quarantine reason 可追蹤 | Quarantine Report | MUST |
| Breaking change 不得直接覆蓋 production | Change Review | MUST |
| Mapping 版本可追到 Model-ready View 版本 | Lineage Test | MUST |
