---
doc_id: ODP-DATA-02
title: "IoT／內部資料交換契約"
version: 0.1.0
status: draft-for-review
document_class: data-integration
batch: 3
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Data Architect / Integration Owner"
approvers: "Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---

# ODay Plus IoT／內部資料交換契約

## 1. 文件目的

本文件定義 ODay Plus 與上游 IoT／內部資料底座之間的資料交換契約。上游團隊只需依本契約提供可重現、可追蹤、可解釋的事實資料；ODay Plus 不要求上游理解 HeatZone、SiteScore、ForecastOps 或其他模型邏輯。

本契約不是資料庫實體設計，而是跨系統整合邊界。ODay Plus 會在 Integration Layer 中把上游資料轉成 Canonical Data Model，再提供給 Model-ready Views 與各產品模組。


## 0. 文件基線與引用規則

本文件屬於第 3 批「資料與整合」正式文件，必須與前兩批文件共同使用：

| 文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游責任邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Data Owner、Integration Owner、Model Owner 與治理責任 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR 與後續設計、測試、驗收追蹤 |
| `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求基線，特別是 Integration、Model-ready View、Audit 與治理需求 |
| `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 上游、外部資料、API、Batch、Event 與 SLA 整合要求 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。

## 2. 整合模式

| 模式 | 用途 | 頻率 | 介面 | 備註 |
|---|---|---|---|---|
| Batch Snapshot | 主檔、成本、租約、資產 | 每日／每週／每月 | BigQuery table、Cloud Storage parquet/csv、SFTP | 必須有 snapshot_date |
| Incremental Batch | 交易、工單、客服、價格異動 | 每小時／每日 | BigQuery partition、Storage object | 必須有 watermark |
| Event Stream | 設備故障、重大交易、異常狀態 | 近即時 | Pub/Sub、Webhook | 事件須可重送與冪等 |
| On-demand Backfill | 重算、修正、災難復原 | 依請求 | Batch export | 必須支援指定期間 |
| API Lookup | 少量即時查詢 | 同步 | REST / gRPC | 不作為模型訓練主要資料來源 |

第一版可只採 Batch + Backfill；重大設備故障與狀態異常可後續升級為 Event Stream。

## 3. 通用資料交換 Envelope

所有 Batch 或 Event 必須能轉成以下通用欄位：

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_system` | string | Y | 來源系統代碼，例如 `iot_core`、`payment`、`crm` |
| `source_dataset` | string | Y | 來源資料集／表／topic |
| `source_record_id` | string | Y | 來源唯一紀錄 ID；若來源無 ID，需由自然鍵產生 |
| `source_event_type` | string | Y | `snapshot`、`create`、`update`、`delete`、`void`、`refund`、`correction` |
| `event_time` | timestamp | Y | 事件真正發生時間 |
| `observation_time` | timestamp | Y | 上游系統觀察或收到時間 |
| `source_updated_at` | timestamp | Y | 來源最後更新時間 |
| `ingested_at` | timestamp | N | ODay Plus 接收時間，由 Integration Layer 填入 |
| `source_version` | string | N | 來源 Schema 或資料版本 |
| `idempotency_key` | string | Y | 重送去重鍵 |
| `correlation_id` | string | N | 跨事件追蹤 ID |
| `payload_hash` | string | N | 內容雜湊，用於變更偵測 |
| `is_deleted` | boolean | N | 邏輯刪除 |
| `raw_payload` | json | N | 原始資料保留，視資安政策遮罩 |

## 4. 主鍵與識別規則

### 4.1 上游鍵與 ODay Plus 鍵

ODay Plus 不直接把上游主鍵當作平台主鍵。所有來源鍵必須進入 Identity Mapping。

| 概念 | 上游提供 | ODay Plus Canonical Key | 規則 |
|---|---|---|---|
| 品牌 | `brand_code`、`brand_name` | `brand_id` | 同品牌不同寫法須映射 |
| 門市 | `shop_no`、`store_code` | `store_id` | 門市搬遷須建立新址或有效期間，不得覆蓋歷史 |
| 機台 | `device_sn`、`machine_no` | `machine_id` | 換機、移機、重編號須保留歷史有效期 |
| 交易 | `txn_id`、`payment_id` | `transaction_id` | 交易補登、退款、作廢以事件表示 |
| 會員 | `line_uid`、`member_no` | `member_id` | 個資與外部 ID 需遮罩或 token 化 |
| 工單 | `ticket_no` | `work_order_id` | 工單合併、重開須有關聯 |

### 4.2 禁止事項

1. 不得無版本覆蓋歷史門市地址。
2. 不得將退款直接改寫原交易金額而無 refund event。
3. 不得重複使用已停用的 machine id 表示新設備。
4. 不得只提供本月累計值而不提供原始事件或可重建明細。
5. 不得只提供「目前狀態」而無狀態生效時間。

## 5. 必要資料集規格

### 5.1 `store_master_snapshot`

| 欄位 | 型別 | 必填 | 說明 | Canonical |
|---|---|---|---|---|
| `source_store_id` | string | Y | 上游門市 ID | `store_identity.source_id` |
| `brand_code` | string | Y | 品牌代碼 | `brand.code` |
| `store_name` | string | Y | 門市名稱 | `store.name` |
| `store_status` | string | Y | `planned/open/suspended/closed/transferred` | `store.status` |
| `open_date` | date | N | 開幕日 | `store.opened_on` |
| `close_date` | date | N | 關閉日 | `store.closed_on` |
| `address_raw` | string | Y | 原始地址 | `location.raw_address` |
| `latitude` | numeric | N | 來源座標 | `location.latitude` |
| `longitude` | numeric | N | 來源座標 | `location.longitude` |
| `store_format` | string | N | ODay G2、傳統、其他 | `store.format_code` |
| `owned_flag` | boolean | N | 自有或加盟 | `store.ownership_type` |
| `region_code` | string | N | 區域或督導範圍 | `store.region_code` |
| `effective_from` | timestamp | Y | 生效時間 | SCD2 |
| `effective_to` | timestamp | N | 失效時間 | SCD2 |

最低品質：`source_store_id` 唯一；開店門市必須有地址；若無座標，ODay Plus 將 Geocode，但地址須可解析。

### 5.2 `machine_master_snapshot`

| 欄位 | 型別 | 必填 | 說明 | Canonical |
|---|---|---|---|---|
| `source_machine_id` | string | Y | 上游機台 ID | `machine_identity.source_id` |
| `source_store_id` | string | Y | 所屬門市 | `machine.store_id` |
| `machine_serial_no` | string | Y | 序號 | `machine.serial_no` |
| `equipment_brand` | string | N | 設備品牌 | `machine.equipment_brand_id` |
| `machine_family` | string | Y | washer/dryer/combo/other | `machine.machine_family` |
| `capacity_kg` | numeric | N | 公斤數 | `machine.capacity_kg` |
| `capacity_band` | string | N | small/medium/large/xlarge | `machine.capacity_band` |
| `installed_at` | date | N | 安裝日期 | `machine.installed_on` |
| `removed_at` | date | N | 移除日期 | `machine.removed_on` |
| `status` | string | Y | active/inactive/maintenance/retired | `machine.status` |

### 5.3 `transaction_event`

| 欄位 | 型別 | 必填 | 說明 | Canonical |
|---|---|---|---|---|
| `source_transaction_id` | string | Y | 來源交易 ID | `transaction.source_id` |
| `source_store_id` | string | Y | 門市 | `transaction.store_id` |
| `source_machine_id` | string | N | 機台 | `transaction.machine_id` |
| `member_source_id` | string | N | 會員來源 ID | `transaction.member_id` |
| `event_time` | timestamp | Y | 實際交易時間 | `transaction.event_time` |
| `payment_time` | timestamp | N | 支付完成時間 | `transaction.payment_time` |
| `gross_amount` | numeric | Y | 原始交易金額 | `transaction.gross_amount` |
| `discount_amount` | numeric | N | 折扣金額 | `transaction.discount_amount` |
| `net_amount` | numeric | Y | 淨額 | `transaction.net_amount` |
| `currency` | string | Y | 幣別 | `transaction.currency` |
| `payment_method` | string | N | 現金、LINE Pay、信用卡等 | `transaction.payment_method` |
| `transaction_status` | string | Y | succeeded/failed/refunded/voided/partial | `transaction.status` |
| `refund_reference_id` | string | N | 退款關聯原交易 | `transaction.refund_of_transaction_id` |
| `price_version` | string | N | 當時價表版本 | `transaction.price_version_id` |
| `promotion_id` | string | N | 優惠或活動 | `transaction.promotion_id` |

交易資料必須支援：退款、作廢、補登、部分退款、失敗交易、重送去重。

### 5.4 `machine_cycle_event`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_cycle_id` | string | Y | 來源 cycle ID |
| `source_store_id` | string | Y | 門市 |
| `source_machine_id` | string | Y | 機台 |
| `cycle_start_time` | timestamp | Y | 啟動時間 |
| `cycle_end_time` | timestamp | N | 結束時間 |
| `cycle_type` | string | N | wash/dry/combo/cleaning/test |
| `duration_sec` | integer | N | 執行秒數 |
| `cycle_status` | string | Y | started/completed/failed/cancelled |
| `error_code` | string | N | 錯誤碼 |
| `transaction_reference_id` | string | N | 關聯交易 |

### 5.5 `machine_status_event`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_status_event_id` | string | Y | 來源事件 ID |
| `source_machine_id` | string | Y | 機台 |
| `status_event_time` | timestamp | Y | 狀態發生時間 |
| `status_type` | string | Y | online/offline/error/available/occupied/maintenance |
| `error_code` | string | N | 錯誤碼 |
| `severity` | string | N | info/warn/error/critical |
| `resolved_time` | timestamp | N | 解除時間 |
| `source_payload` | json | N | 原始狀態 |

### 5.6 `price_schedule_snapshot`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_price_id` | string | Y | 來源價表 ID |
| `source_store_id` | string | Y | 門市 |
| `machine_family` | string | Y | 設備類型 |
| `capacity_band` | string | N | 容量級距 |
| `time_band` | string | N | 時段，例如 off_peak/peak/weekend |
| `price_amount` | numeric | Y | 價格 |
| `currency` | string | Y | 幣別 |
| `effective_from` | timestamp | Y | 生效時間 |
| `effective_to` | timestamp | N | 失效時間 |
| `approved_by` | string | N | 核准人 |

### 5.7 `promotion_campaign_snapshot`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_campaign_id` | string | Y | 活動 ID |
| `campaign_type` | string | Y | coupon/discount/points/recall/ad |
| `store_scope` | array | N | 適用門市 |
| `member_segment` | string | N | 會員區隔 |
| `start_time` | timestamp | Y | 開始 |
| `end_time` | timestamp | Y | 結束 |
| `budget_amount` | numeric | N | 預算 |
| `discount_rule` | json | N | 優惠規則 |
| `approval_status` | string | N | draft/approved/executed/cancelled |

### 5.8 `maintenance_work_order_event`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_work_order_id` | string | Y | 工單 ID |
| `source_store_id` | string | Y | 門市 |
| `source_machine_id` | string | N | 機台 |
| `issue_type` | string | Y | failure/cleaning/inspection/complaint |
| `issue_subtype` | string | N | 子類別 |
| `opened_at` | timestamp | Y | 開單時間 |
| `closed_at` | timestamp | N | 結案時間 |
| `status` | string | Y | open/in_progress/resolved/cancelled |
| `severity` | string | N | low/medium/high/critical |
| `cost_amount` | numeric | N | 維修成本 |
| `root_cause` | string | N | 原因 |

### 5.9 `customer_service_case_event`

| 欄位 | 型別 | 必填 | 說明 |
|---|---|---|---|
| `source_case_id` | string | Y | 客服案件 ID |
| `source_store_id` | string | N | 關聯門市 |
| `source_machine_id` | string | N | 關聯機台 |
| `member_source_id` | string | N | 會員 |
| `case_opened_at` | timestamp | Y | 開案時間 |
| `case_closed_at` | timestamp | N | 結案時間 |
| `channel` | string | N | LINE/web/phone/system |
| `topic_code` | string | Y | 客訴或問題主題 |
| `sentiment_score` | numeric | N | 情緒分數 |
| `resolution_status` | string | N | resolved/unresolved/escalated |

### 5.10 `lease_asset_snapshot`

| 資料集 | 必要欄位 | 用途 |
|---|---|---|
| `lease_snapshot` | store、rent、deposit、lease_start、lease_end、renewal、termination_terms | SiteScore、AVM、NetPlan |
| `asset_register_snapshot` | asset id、store、machine、book value、depreciation、purchase date、remaining life | DealRoomAVM、NetPlan |
| `cost_statement_snapshot` | store、period、water、electricity、gas、detergent、maintenance、other cost | ForecastOps、AVM |

## 6. Event Topic 規格

| Topic | Producer | Consumer | 必須支援 |
|---|---|---|---|
| `iot.machine.status.v1` | IoT | Integration Consumer / Alert Engine | idempotency、retry、DLQ |
| `payment.transaction.v1` | Payment/POS | Integration Consumer | refund correlation、ordering by transaction |
| `ops.work_order.v1` | 工務系統 | Integration Consumer / ForecastOps | status transition |
| `crm.member_event.v1` | CRM | Integration Consumer / Promotion | consent update |
| `pricing.schedule_change.v1` | 價格系統 | Integration Consumer / PriceOps | effective time |

### 6.1 Event JSON 範例

```json
{
  "event_id": "evt_20260626_000001",
  "event_type": "machine.status.changed",
  "event_version": "1.0",
  "source_system": "iot_core",
  "idempotency_key": "iot_core:machine:ABC123:2026-06-26T08:15:00+08:00:error:E07",
  "correlation_id": "corr_9d8f",
  "event_time": "2026-06-26T08:15:00+08:00",
  "observation_time": "2026-06-26T08:15:02+08:00",
  "payload": {
    "source_store_id": "S001",
    "source_machine_id": "M-ABC123",
    "status_type": "error",
    "error_code": "E07",
    "severity": "critical"
  }
}
```

## 7. Backfill 與重算要求

| 要求 | 說明 |
|---|---|
| 指定期間重拉 | 必須能指定日期或時間區間重拉 P0 資料 |
| 全量快照 | 主檔需支援全量 Snapshot |
| 水位線 | Incremental Batch 必須提供 reliable watermark |
| 重送冪等 | 相同 `idempotency_key` 重送不得產生重複紀錄 |
| 來源修正 | 修正資料須以 correction event 或新版 snapshot 表示 |
| 追溯重建 | 必須能重建任一決策時間點可見資料 |

## 8. SLA 與資料新鮮度

| 資料集 | Freshness SLA | 延遲等級 | 超時處理 |
|---|---:|---|---|
| 交易 | T+1 日 08:00 前 | P0 | Block daily Forecast scoring |
| 門市／設備主檔 | T+1 日 08:00 前 | P0 | Block scoring if missing reference |
| 價格 | 異動後 2 小時內或 T+1 | P0 | Block PriceOps / Flag Forecast |
| 機台狀態 | 近即時或每小時 | P0/P1 | Critical alert degraded if unavailable |
| 維修工單 | T+1 日 | P0 | Root cause confidence penalty |
| 客服 | T+1 日 | P1 | Root cause confidence penalty |
| 成本 | 月結後 5 工作日 | P1 | AVM confidence penalty |
| 租約 | 異動後 1 工作日 | P0 | Block NetPlan decision |

## 9. 錯誤處理

| 錯誤類型 | 判定 | 處理 |
|---|---|---|
| Schema mismatch | 欄位缺失、型別錯誤 | Reject batch / Quarantine |
| Missing reference | 交易找不到門市或機台 | Quarantine record / Alert Source Owner |
| Duplicate key | 同 key 不同 payload | Compare hash / create conflict ticket |
| Late arrival | 超過預期延遲 | Load with late flag / trigger backfill tests |
| Invalid time | event_time 晚於 observation_time 太多或不合理 | Quarantine |
| Negative amount | 非退款卻負值 | Quarantine |
| PII violation | 未遮罩個資進入非授權區 | Block / Security Incident |

## 10. 資安與個資

1. 所有資料交換必須使用加密傳輸。
2. 會員、支付識別、聯絡資訊必須依資料分類遮罩或 token 化。
3. ODay Plus 模型預設不得使用可識別個人資料；如需使用，必須經 Security Review 與 Model Review。
4. 所有資料接入、Backfill、查詢與匯出必須保留 Audit Log。
5. 上游若刪除或匿名化個資，必須提供對應事件，ODay Plus 需同步更新可識別資料區。

## 11. 契約版本與變更

| 變更類型 | 例子 | 處理方式 |
|---|---|---|
| Minor | 新增 nullable 欄位 | 通知 Integration Owner，更新 mapping |
| Major | 欄位型別改變、語意改變 | Data Contract Review、版本升級 |
| Breaking | 移除必填欄位、主鍵規則改變 | 不得直接上線，需 ADR 與雙版本並行 |
| Emergency | 上游事故臨時修正 | 事件紀錄、Incident、後續 Postmortem |

## 12. 驗收條件

| 項目 | 驗收方式 | 必要性 |
|---|---|---|
| P0 資料集皆有 Schema 與樣本 | Schema Review | MUST |
| P0 資料集皆能完成每日同步 | Pipeline Run | MUST |
| P0 資料集支援指定日期 Backfill | Backfill Test | MUST |
| refund／void／correction 可被正確表示 | Golden Dataset Test | MUST |
| identity mapping 可處理換機、移店、門市改名 | Integration Test | MUST |
| DQ fail 可阻擋 Production View | DQ Gate Test | MUST |
| 所有 Event 支援 idempotency | Replay Test | MUST |
| PII 欄位被分類與遮罩 | Security Test | MUST |
