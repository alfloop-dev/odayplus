---
id: ODP-OPS-05
title: Incident、備份與復原手冊
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: SRE / Security Owner / Project Manager
updated_at: 2026-06-26
depends_on:
  - ODP-SD-10_EXCEPTION_HANDLING_AND_RELIABILITY_DESIGN
  - ODP-SD-11_OBSERVABILITY_AND_AUDIT_DESIGN
  - ODP-QA-05_PERFORMANCE_SECURITY_AND_DR_TEST
  - ODP-OPS-04_RUNBOOK
---

# ODP-OPS-05 Incident、備份與復原手冊

## 1. 文件目的

本文件定義 ODay Plus 的事件管理、備份策略、復原程序、RPO/RTO、服務中斷補償證據、災難復原演練與 Postmortem 流程。

---

## 2. Incident Management

## 2.1 Incident 定義

任何造成以下影響者皆為 Incident：

- 使用者無法使用核心功能。
- 資料延遲或錯誤影響模型與決策。
- 模型服務異常。
- 高風險決策流程失效。
- Audit log 不完整。
- 權限或個資風險。
- SLA breach。
- Cloud service outage。
- 外部資料源長時間中斷。
- Solver、Batch、Workflow 無法完成。

---

## 3. Incident Severity

| Severity | 影響 | 範例 | 通知 |
|---|---|---|---|
| P0 | 資安、資料完整性或全平台重大中斷 | 權限繞過、audit loss、production DB corruption | 立即通知全體 owner |
| P1 | 核心業務流程無法運作 | SiteScore/ForecastOps 全面失效 | 通知 domain owner |
| P2 | 重要功能局部失效 | Listing import fail、AVM report delay | 通知相關 owner |
| P3 | 非核心功能或可延後 | 報表格式錯誤 | issue tracking |
| P4 | 改善項 | usability | backlog |

---

## 4. Incident Roles

| Role | 責任 |
|---|---|
| Incident Commander | 統一指揮、決策、對外更新 |
| Tech Lead | 技術診斷與恢復 |
| Data Lead | 資料影響與修復 |
| ML Lead | 模型影響與 rollback |
| Security Lead | 資安與個資影響 |
| Communications Lead | 內外部溝通 |
| Scribe | 紀錄 timeline |
| Business Owner | 業務影響判斷 |
| Support Lead | 使用者支援 |

P0/P1 必須指定 Incident Commander。

---

## 5. Incident Lifecycle

```text
Detected
→ Triage
→ Declare
→ Mitigate
→ Recover
→ Validate
→ Communicate
→ Close
→ Postmortem
→ Preventive actions
```

### 5.1 Declare Incident Template

```yaml
incident_id:
severity:
title:
detected_at:
declared_at:
declared_by:
incident_commander:
affected_services:
affected_users:
affected_data:
initial_hypothesis:
communication_channel:
```

---

## 6. Incident Response SLA

| 事件等級 | 初始回應 | 狀態更新 | 目標恢復 |
|---|---|---|---|
| P0 | 15 分鐘 | 每 30 分鐘 | 依 DR / RTO |
| P1 | 30 分鐘 | 每 60 分鐘 | 當日恢復或 workaround |
| P2 | 4 小時 | 每日 | 排程修復 |
| P3 | 1 工作日 | 依 issue | backlog |
| P4 | 依排程 | 依 issue | backlog |

營運服務 SLA 可設定：

- 緊急問題 4 小時內回應。
- 普通問題 12 小時內回應。
- RTO 4 小時。
- RPO 1 小時。

---

## 7. Communication

### 7.1 Internal Update

```text
[Incident Update]
ID:
Severity:
Status:
Impact:
Current hypothesis:
Actions taken:
Next action:
Next update:
```

### 7.2 External / Business Update

```text
目前 ODay Plus 的 {module} 功能受到影響。
影響範圍：{impact}
已採取措施：{mitigation}
資料與決策紀錄狀態：{data_status}
下一次更新時間：{time}
```

### 7.3 Close Message

```text
事件已恢復。
恢復時間：
影響期間：
已確認功能：
後續改善：
```

---

## 8. 備份策略

## 8.1 備份範圍

| 資源 | 備份方式 | 頻率 |
|---|---|---|
| Cloud SQL / PostGIS | automated backup + PITR | daily + PITR |
| BigQuery canonical | table snapshots / exports | daily |
| BigQuery model_ready | reproducible via dbt + snapshots | daily / on release |
| Cloud Storage raw | versioning | continuous |
| Cloud Storage reports | versioning + lifecycle | continuous |
| Model artifacts | immutable storage | on model release |
| MLflow metadata | DB backup | daily |
| Audit logs | append-only + export | continuous / daily |
| Terraform state | remote backend with versioning | continuous |
| Secret Manager | versioning | on change |
| Git repository | remote + tags | every commit |

## 8.2 Backup Naming

```text
backup-{resource}-{env}-{yyyymmddhhmm}-{version}
```

## 8.3 Backup Metadata

```yaml
backup_id:
resource:
environment:
created_at:
created_by:
source_version:
retention_until:
encryption:
location:
validation_status:
restore_tested_at:
```

---

## 9. RPO / RTO

| 系統 | RPO | RTO |
|---|---|---|
| Core API / OpsBoard | 1 小時 | 4 小時 |
| Cloud SQL | 1 小時 | 4 小時 |
| BigQuery canonical | 24 小時或依資料源 | 8 小時 |
| Audit logs | 接近 0，需 append-only | 4 小時 |
| Model artifacts | 0，immutable | 2 小時 |
| Reports | 24 小時 | 8 小時 |
| External data | 依來源頻率 | 依來源 |
| Feature marts | 可重建 | 8 小時 |

---

## 10. Restore Procedures

## 10.1 Cloud SQL Restore

### 步驟

1. 宣告 maintenance / incident。
2. Freeze writes。
3. 確認 restore target time。
4. 建立 restored instance。
5. 執行 integrity check。
6. 切換 connection string。
7. 執行 smoke test。
8. 恢復 service。
9. 記錄 restore report。

### Validation

```text
row counts
critical tables exist
foreign key consistency
audit table continuity
latest decision visible
API smoke pass
```

---

## 10.2 BigQuery Restore

### 步驟

1. 確認受影響 dataset / table。
2. 找到 snapshot / export。
3. Restore 到 temporary table。
4. 比對 row count / hash。
5. 切換 view 指向。
6. 重跑 dbt tests。
7. 重跑受影響 model-ready views。
8. 記錄 restore evidence。

---

## 10.3 Cloud Storage Restore

### 適用

- Reports。
- Model artifacts。
- Raw files。
- Evidence packages。

### 步驟

1. 找版本。
2. Restore object version。
3. 驗證 hash。
4. 驗證權限。
5. 更新 metadata。
6. 通知 owner。

---

## 10.4 Model Artifact Restore

### 步驟

1. 從 Model Registry 找 previous production model。
2. 確認 artifact URI。
3. 確認 model card。
4. 切換 serving alias。
5. 執行 prediction smoke。
6. 確認 Decision Log 顯示舊 model_version。
7. 通知 AI owner。

詳細模型 rollback 見 ODP-OPS-06。

---

## 11. Disaster Recovery Scenarios

## 11.1 Scenario A：Cloud SQL 不可用

### 動作

1. 宣告 P0/P1。
2. 停止寫入高風險操作。
3. 檢查 Cloud SQL status。
4. 若短暫中斷，等待恢復並監控。
5. 若長時間中斷，restore to standby。
6. 切換 API DB connection。
7. Smoke test。
8. 恢復服務。

## 11.2 Scenario B：BigQuery 資料污染

### 動作

1. 停止相關 scoring jobs。
2. 標記 data quality failed。
3. 找到污染開始時間。
4. Restore / rebuild affected tables。
5. 重跑 dbt tests。
6. 重算受影響 outputs。
7. 不覆蓋已決策歷史，建立 diff。

## 11.3 Scenario C：Audit Log 寫入失敗

### 動作

1. 立即暫停所有高風險決策。
2. 保留 API request logs。
3. 修復 audit store。
4. 重放 audit events。
5. 標示 recovered audit。
6. 執行 completeness check。
7. 恢復高風險操作。

## 11.4 Scenario D：Model Serving 故障

### 動作

1. 切換 previous champion。
2. 或切換 baseline mode。
3. 暫停高風險自動建議。
4. 重跑 smoke prediction。
5. 通知 AI owner。
6. Postmortem。

## 11.5 Scenario E：Pub/Sub 堆積

### 動作

1. 查 queue depth。
2. 查 consumer errors。
3. 暫停 poison message。
4. 增加 worker scale。
5. DLQ 分析。
6. 確認 idempotency。
7. Resume processing。

---

## 12. Backup Verification

每日自動檢查：

- Backup job success。
- Backup object existence。
- Backup encryption。
- Backup size anomaly。
- Audit export success。
- Model artifact integrity。

每季演練：

- Cloud SQL restore。
- BigQuery snapshot restore。
- Cloud Storage object restore。
- Model artifact restore。
- Audit evidence restore。

---

## 13. 服務中斷補償證據

若 SLA 包含補償，需保存：

```text
incident_id
start_time
end_time
unavailable_minutes
affected_services
system_logs
monitoring_evidence
calculation
compensation_level
approved_by
```

範例規則：

```text
中斷累計 >1 小時且 <4 小時：延長使用期 1 日
中斷累計 >=4 小時且 <12 小時：延長使用期 1 日 + 補償月費 10%
中斷累計 >=12 小時：補償月費 25% + 額外延長 1 個月
```

---

## 14. Postmortem

### 14.1 適用

P0/P1 必須 postmortem。P2 視情況。

### 14.2 Template

```yaml
incident_id:
title:
severity:
date:
duration:
impact:
timeline:
root_cause:
contributing_factors:
what_went_well:
what_went_wrong:
detection_gap:
response_gap:
data_impact:
model_impact:
decision_impact:
customer_impact:
corrective_actions:
preventive_actions:
owners:
due_dates:
```

### 14.3 原則

- 不以個人究責為目的。
- 聚焦系統性改善。
- 每個 action item 需有 owner 和 due date。
- Action item 需追蹤至完成。
- 若涉及補助查核，需保存 postmortem evidence。

---

## 15. DR Drill Plan

### 15.1 頻率

- 半年一次完整 DR drill。
- 每季一次 restore drill。
- 每次重大架構變更後執行 targeted drill。

### 15.2 Drill Checklist

- [ ] 設定演練目標。
- [ ] 選定 scenario。
- [ ] 通知參與者。
- [ ] 建立測試資料。
- [ ] 執行 failover / restore。
- [ ] 測量 RPO。
- [ ] 測量 RTO。
- [ ] 執行 smoke test。
- [ ] 產出 DR report。
- [ ] 建立改善項。

---

## 16. 驗收條件

本文件完成後需滿足：

- Incident 分級、角色、流程明確。
- 備份範圍與 restore 程序明確。
- RPO / RTO 可驗證。
- Audit failure、資料污染、模型故障有 DR 流程。
- Postmortem 與服務中斷補償證據可產出。
