---
id: ODP-OPS-06
title: 模型發布與回滾手冊
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: MLOps Lead / ML Lead / Governance Owner
updated_at: 2026-06-26
depends_on:
  - ODP-ML-01_AI_ML_OVERALL_DESIGN
  - ODP-ML-02_FEATURE_AND_LABEL_REGISTRY
  - ODP-ML-04_MODEL_VALIDATION_AND_MODEL_CARD
  - ODP-QA-04_MODEL_AND_DECISION_ACCEPTANCE_SPECIFICATION
  - ODP-SD-11_OBSERVABILITY_AND_AUDIT_DESIGN
---

# ODP-OPS-06 模型發布與回滾手冊

## 1. 文件目的

本文件定義 ODay Plus 模型從訓練、驗證、登錄、Shadow、Canary、Production、監控到 Rollback 的正式操作流程。

ODay Plus 模型包含：

- HeatZone Demand。
- SiteScore Revenue Path。
- Brand Transfer。
- Ramp / Seasonality。
- ForecastOps。
- Trajectory Classifier。
- Change-point。
- Price Elasticity。
- Ad Incrementality。
- AVM。
- Liquidity。
- NetPlan Solver parameters / scenario model。

---

## 2. 模型生命週期

```text
EXPERIMENTAL
→ CANDIDATE
→ VALIDATED
→ SHADOW
→ CANARY
→ PRODUCTION
→ DEPRECATED
→ ROLLED_BACK
→ ARCHIVED
```

### 2.1 狀態定義

| Status | 說明 |
|---|---|
| EXPERIMENTAL | Notebook / lab |
| CANDIDATE | 完成訓練，待驗證 |
| VALIDATED | 通過離線驗證 |
| SHADOW | 影子推論，不影響決策 |
| CANARY | 小比例使用或低風險使用 |
| PRODUCTION | 正式模型 |
| DEPRECATED | 不再新用 |
| ROLLED_BACK | 曾上線但已回滾 |
| ARCHIVED | 長期保存 |

---

## 3. 模型發布前置條件

### 3.1 必備資料

```text
training_dataset_snapshot
validation_dataset_snapshot
feature_schema
label_definition
model_artifact
model_metrics
segment_metrics
calibration_report
model_card
risk_assessment
rollback_target
monitoring_config
```

### 3.2 必備檢查

- Data quality gate pass。
- Point-in-time correctness pass。
- No critical leakage。
- Baseline comparison pass。
- Segment no severe regression。
- Calibration pass if interval model。
- Model card complete。
- Security / dependency scan pass。
- Owner approval complete。

---

## 4. Model Registry

### 4.1 Registry 欄位

```yaml
model_id:
model_family:
version:
status:
artifact_uri:
training_dataset_snapshot:
validation_dataset_snapshot:
feature_schema_version:
label_version:
metrics:
segment_metrics:
calibration:
created_by:
created_at:
approved_by:
approved_at:
rollback_target:
monitoring_config:
```

### 4.2 Model Alias

```text
champion
challenger
shadow
canary
production
previous_production
```

每個 model family 只能有一個 production alias。

---

## 5. Model Card

每個 production model 必須包含：

```text
Model purpose
Business use
Out of scope
Training data
Feature list
Target / label
Validation method
Metrics
Segment performance
Calibration
Known limitations
Bias / risk
Decision policy dependency
Human approval requirement
Rollback condition
Owner
Approval
```

---

## 6. Release Workflow

```text
Train
→ Register
→ Validate
→ Model Review
→ Shadow
→ Shadow Review
→ Canary
→ Canary Review
→ Promote Production
→ Monitor
```

### 6.1 Release Request

```yaml
release_request_id:
model_id:
version:
target_stage:
reason:
expected_impact:
affected_modules:
affected_decisions:
risk_level:
rollback_target:
requested_by:
```

### 6.2 Approval

| Risk | Approval |
|---|---|
| Low | ML owner |
| Medium | ML owner + product owner |
| High | ML owner + business owner + governance owner |
| Critical | Model Review Board |

High-risk models：

- SiteScore GO decision。
- ForecastOps red alert。
- PriceOps optimizer。
- AdLift causal effect。
- AVM reserve price support。
- NetPlan MOVE / EXIT。

---

## 7. Shadow Deployment

### 7.1 目的

Shadow 模型只產生預測，不影響使用者看到的正式建議。

### 7.2 Shadow 必測

- Prediction success rate。
- Latency。
- Output schema。
- Distribution vs production。
- Segment drift。
- Alert volume simulation。
- Decision impact simulation。

### 7.3 Shadow 通過條件

- 服務穩定。
- 無 schema mismatch。
- 重大 segment regression 為 0 或有核准例外。
- Output 可解釋。
- Audit metadata 正確。

---

## 8. Canary Deployment

### 8.1 Canary 策略

可依下列範圍：

- 低風險門市。
- 指定區域。
- 指定角色。
- 指定 candidate site。
- 指定 report only。
- 指定 percentage traffic。

### 8.2 Canary Gate

| 指標 | 條件 |
|---|---|
| Error rate | 不高於 production |
| Latency | 達 SLA |
| Data quality | pass |
| Alert volume | 不超過營運負荷 |
| Business sanity | pass |
| Human override rate | 不異常 |
| Safety constraints | 0 violation |

### 8.3 Canary 停止條件

- Hard constraint violation。
- P0/P1 incident。
- 高風險 false recommendation。
- Latency severe breach。
- Data leakage suspected。
- Business owner request。

---

## 9. Production Promotion

### 9.1 Promotion Checklist

- [ ] Model card approved。
- [ ] Validation report approved。
- [ ] Shadow report approved。
- [ ] Canary report approved。
- [ ] Rollback target exists。
- [ ] Monitoring enabled。
- [ ] Feature flags configured。
- [ ] Downstream API compatible。
- [ ] Frontend compatible。
- [ ] Decision policy compatible。
- [ ] Release note ready。

### 9.2 Promotion Steps

1. Freeze model registry change。
2. Update production alias。
3. Deploy model serving endpoint / container。
4. Run smoke predictions。
5. Verify model_version in predictions。
6. Verify Decision Log metadata。
7. Notify stakeholders。
8. Monitor first 24 hours。

---

## 10. Rollback

## 10.1 Rollback Types

| Type | 說明 |
|---|---|
| Serving rollback | 切回 previous model artifact |
| Alias rollback | production alias 回前版 |
| Policy rollback | 決策規則回前版 |
| Feature rollback | feature view 回前版 |
| Data rollback | dataset / feature 修復 |
| Business decision rollback | 取消或修正已執行的業務動作 |

注意：**模型 rollback 與業務 decision rollback 是兩件事。**

## 10.2 Rollback Triggers

- Model endpoint down。
- Prediction error spike。
- Calibration failure online。
- Drift severe。
- Alert explosion。
- High-risk false GO。
- Price constraint risk。
- AVM valuation abnormal。
- NetPlan infeasible due to model issue。
- Data leakage discovered。
- Security issue。

## 10.3 Rollback Steps

1. 宣告 rollback incident / change。
2. 找 previous_production。
3. 確認 artifact 存在。
4. 切換 alias 或 traffic。
5. 執行 smoke prediction。
6. 停止新模型相關 jobs。
7. 標記新模型 `ROLLED_BACK`。
8. 建立 rollback audit。
9. 通知下游。
10. 啟動 postmortem。

### 10.4 Rollback Smoke Test

```text
prediction endpoint returns
model_version = previous
schema valid
latency normal
decision policy sees previous model
audit log records rollback
```

---

## 11. Model Monitoring

### 11.1 技術指標

- Prediction latency。
- Prediction error rate。
- Endpoint availability。
- Request volume。
- Feature missing rate。
- Schema mismatch。
- Drift score。
- Output distribution。

### 11.2 業務指標

| Model | Monitoring |
|---|---|
| SiteScore | realization ratio、M3/M6 error、GO outcome |
| ForecastOps | forecast error、alert precision、alert volume |
| PriceOps | GM impact、constraint violation、rollback rate |
| AdLift | evidence level、iROMI、pre-trend pass |
| AVM | valuation coverage、finance override |
| NetPlan | plan adoption、constraint satisfaction |

### 11.3 Alert

```text
model_endpoint_down
prediction_error_rate_high
latency_breach
feature_missing_spike
drift_threshold_breach
calibration_breach
segment_regression
decision_volume_anomaly
```

---

## 12. Dataset and Feature Compatibility

### 12.1 Feature Schema Change

若 feature schema breaking change：

1. 建立 feature schema version。
2. 更新 model spec。
3. 重訓 candidate。
4. 不直接讓 production model 讀新 schema。
5. 維持 compatibility layer。
6. 通過 data contract review。

### 12.2 Label Change

Label 定義變更需：

- 新 label_version。
- 重新 backtest。
- 更新 model card。
- 不與舊版 metrics 直接比較，除非有 bridging analysis。

---

## 13. Decision Policy Compatibility

模型輸出若影響決策政策，需檢查：

- GO/WAIT/REJECT rule。
- Four-light policy。
- Eligibility rule。
- Pricing hard constraint。
- AVM approval threshold。
- NetPlan hard constraint。

模型不可自行決定業務執行，需經 Decision Layer。

---

## 14. Emergency Model Disable

若需要立即停用：

1. 關閉 model feature flag。
2. 切換 baseline / previous champion。
3. 暫停高風險 action。
4. 通知 stakeholders。
5. 建立 incident。
6. 產生 impact report。

---

## 15. Audit

每次 release / rollback 必須記錄：

```text
release_request_id
model_id
version
from_stage
to_stage
actor
approver
reason
metrics
rollback_target
timestamp
affected_modules
feature_schema_version
dataset_snapshot
```

---

## 16. 驗收條件

本文件完成後需滿足：

- 模型生命週期與狀態清楚。
- Shadow、Canary、Production、Rollback 有明確流程。
- 高風險模型有核准要求。
- 模型 rollback 與業務 decision rollback 明確分離。
- Production model 有 Model Card、monitoring、rollback target。
