---
id: ODP-OPS-02
title: 資料 Migration／Backfill／重算設計
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: Data Engineering Lead / MLOps Lead / SRE
updated_at: 2026-06-26
depends_on:
  - ODP-DATA-04_CANONICAL_DATA_MODEL
  - ODP-DATA-05_SOURCE_TO_CANONICAL_MAPPING
  - ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION
  - ODP-DATA-07_DATA_QUALITY_LINEAGE_AND_TIME_SEMANTICS
  - ODP-SD-05_DATABASE_AND_STORAGE_DESIGN
  - ODP-QA-02_TEST_DATA_AND_ENVIRONMENT_STRATEGY
---

# ODP-OPS-02 資料 Migration／Backfill／重算設計

## 1. 文件目的

本文件定義 ODay Plus 的資料 migration、歷史資料 backfill、特徵重建、模型輸出重算、決策結果保護與資料版本治理方式。

ODay Plus 的資料會同時支援：

- 營運查詢。
- 模型訓練。
- 批次推論。
- 決策建議。
- 人工核准。
- 查核留痕。
- 補助證據。

因此資料重算不得破壞已發生的決策紀錄，也不得讓歷史模型訓練取得當時不存在的未來資訊。

---

## 2. 資料層級

ODay Plus 資料分為：

```text
Raw Landing
→ Source Normalized
→ Canonical
→ Feature / Analytical Mart
→ Model-ready Views
→ Dataset Snapshot
→ Prediction Output
→ Decision / Execution / Outcome
→ Audit Evidence
```

### 2.1 可重算層

| 層級 | 可否重算 | 說明 |
|---|---|---|
| Raw Landing | 不覆蓋，只追加 | 原始來源保存 |
| Source Normalized | 可重建 | 依 raw 重建 |
| Canonical | 可重建，但需版本 | 主語意層 |
| Feature Mart | 可重建 | dbt / pipeline |
| Model-ready Views | 可重建 | point-in-time |
| Dataset Snapshot | 不覆蓋 | immutable |
| Prediction Output | 可產生新版，不覆蓋舊版 | 需 model_version |
| Decision | 不可重算覆蓋 | 人工與系統決策留痕 |
| Outcome | 可追加修正，不覆蓋 | 退款、補登、成熟標籤 |
| Audit | 不可修改 | append-only |

---

## 3. Migration 類型

### 3.1 Schema Migration

包含：

- 新增資料表。
- 新增欄位。
- 修改欄位型別。
- 建立 index。
- 建立 partition。
- 建立 view。
- 建立 materialized view。
- 修改 enum。
- 新增 status。
- 資料表拆分或合併。

### 3.2 Data Migration

包含：

- 欄位值轉換。
- 舊 ID 對新 ID。
- 補填缺漏欄位。
- 建立對照表。
- 重建 foreign key。
- 修正時間欄位。
- 重算 feature。
- 轉移 object storage 路徑。

### 3.3 Model-related Migration

包含：

- feature schema migration。
- label definition migration。
- model input migration。
- model output migration。
- prediction table migration。
- model registry metadata migration。

### 3.4 Workflow Migration

包含：

- status enum 更新。
- decision workflow 更新。
- task state migration。
- approval chain migration。
- observation window migration。
- legacy intervention state migration。

---

## 4. Migration 原則

### 4.1 向後相容優先

除非有安全或資料污染風險，migration 應採：

```text
expand
→ dual write / dual read
→ backfill
→ switch read
→ deprecate
→ remove
```

### 4.2 不覆蓋決策歷史

任何 migration 不得改寫：

- Decision Log。
- Approval。
- Execution record。
- Audit trail。
- Model release log。
- Evidence export。
- Historical prediction used for decision。

若需修正，採用 correction record：

```text
original_record_id
correction_id
correction_reason
corrected_by
corrected_at
```

### 4.3 所有 migration 需可回滾

至少需定義：

```yaml
migration_id:
forward_steps:
rollback_steps:
data_backup:
validation_queries:
owner:
approval:
```

### 4.4 大型 migration 必須 dry-run

Dry-run 應輸出：

- 影響資料筆數。
- 欄位分布差異。
- 失敗筆數。
- 預估執行時間。
- 預估成本。
- 下游影響。
- rollback feasibility。

---

## 5. Migration 流程

```text
Create migration proposal
→ Impact analysis
→ Dry-run in staging
→ Validation
→ Approval
→ Production backup
→ Production execution
→ Post-migration validation
→ Release note
→ Monitoring
```

### 5.1 Migration Proposal

```yaml
migration_id:
title:
owner:
reason:
affected_tables:
affected_views:
affected_apis:
affected_models:
affected_workflows:
risk_level:
expected_downtime:
requires_backfill:
requires_model_retrain:
requires_recompute:
rollback_plan:
```

### 5.2 Impact Analysis

必須檢查：

- API response 是否改變。
- OpenAPI 是否需更新。
- dbt model 是否受影響。
- Feature registry 是否需更新。
- Model input schema 是否改變。
- Existing reports 是否受影響。
- UAT / evidence 是否受影響。
- External data connector 是否受影響。

---

## 6. Backfill 設計

## 6.1 Backfill 類型

| 類型 | 說明 |
|---|---|
| Historical source backfill | 從來源重拉歷史 |
| Canonical backfill | 依 raw 重建 canonical |
| Feature backfill | 重建 feature mart |
| Model-ready backfill | 重建 model-ready views |
| Prediction backfill | 對歷史時間點重跑模型 |
| Outcome backfill | 回補成熟 outcome |
| Audit backfill | 僅限補齊技術 metadata，不可偽造操作 |
| External data backfill | 外部資料快照回補 |

## 6.2 Backfill 原則

- 必須指定時間範圍。
- 必須指定 source snapshot。
- 必須指定 schema version。
- 必須可分批。
- 必須 idempotent。
- 必須可中斷後續跑。
- 必須寫入 backfill_run table。
- 必須產生 validation report。

## 6.3 Backfill Run Metadata

```yaml
backfill_run_id:
backfill_type:
target_table:
date_from:
date_to:
source_snapshot:
schema_version:
started_at:
finished_at:
status:
records_read:
records_written:
records_skipped:
records_failed:
owner:
reason:
correlation_id:
```

## 6.4 Backfill Status

```text
PLANNED
DRY_RUN
APPROVED
RUNNING
PAUSED
SUCCEEDED
FAILED
PARTIAL
CANCELLED
VALIDATED
ROLLED_BACK
```

---

## 7. 重算設計

## 7.1 重算類型

```text
feature_recompute
heatzone_rescore
listing_reparse
listing_regeocode
sitescore_rescore
forecast_rescore
intervention_effect_reevaluate
price_simulation_recompute
adlift_reestimate
avm_revalue
netplan_resolve
model_backtest_recompute
audit_evidence_regenerate
```

## 7.2 重算原則

### 7.2.1 產生新版本，不覆蓋舊版本

例如 SiteScore 重新評分：

```text
report_id: SSR-001
version: 1
model_version: sitescore-v1.0
decision_status: APPROVED
```

重算後：

```text
report_id: SSR-001
version: 2
model_version: sitescore-v1.1
decision_status: GENERATED
```

不可覆蓋 version 1，且 version 1 仍保留原核准依據。

### 7.2.2 已人工決策的結果不可自動替換

若重算結果與舊結果不同：

- 顯示 diff。
- 建立 review task。
- 由 owner 決定是否更新業務決策。
- 保留舊決策與新建議。

### 7.2.3 模型重算必須保留 origin time

ForecastOps 歷史重算需指定：

```text
prediction_origin_time
feature_snapshot_time
model_version
prediction_horizon
```

不得使用未來資料。

---

## 8. Point-in-time Correctness

### 8.1 必備時間欄位

所有 model-ready view 必須支援：

```text
entity_id
event_time
observation_time
feature_snapshot_time
decision_time
label_available_after
```

### 8.2 PIT Join

歷史訓練資料只能 join：

```text
feature.observation_time <= decision_time
```

禁止 join：

```text
feature.event_time <= decision_time
```

但 `observation_time > decision_time` 的資料。

### 8.3 PIT Validation

每次 dataset snapshot 需檢查：

```sql
select count(*)
from training_dataset
where feature_observation_time > decision_time;
```

結果必須為 0。

---

## 9. Recompute Dependency Graph

### 9.1 依賴順序

```text
Raw source
→ Canonical
→ Feature marts
→ Model-ready views
→ Dataset snapshots
→ Model training / scoring
→ Decision policy
→ Reports
→ Audit evidence
```

### 9.2 模組依賴

| 變更 | 需重算 |
|---|---|
| POI data | HeatZone、SiteScore、NetPlan |
| Rent data | HeatZone、SiteScore、AVM |
| Competitor data | HeatZone、SiteScore、NetPlan |
| Store transaction data | ForecastOps、AVM、AdLift |
| Machine availability | ForecastOps、InterventionOps、AVM |
| Price history | PriceOps、ForecastOps、AdLift |
| Campaign history | AdLift、ForecastOps |
| Geocode correction | Listing、SiteScore、HeatZone |
| Brand transfer logic | SiteScore |
| Ramp curve logic | SiteScore、ForecastOps |
| GM normalization | AVM、NetPlan |

---

## 10. Backfill / Recompute API

### 10.1 建立重算工作

```http
POST /ops/recompute-jobs
```

Request：

```json
{
  "job_type": "sitescore_rescore",
  "entity_type": "candidate_site",
  "entity_ids": ["CS-001"],
  "date_from": null,
  "date_to": null,
  "reason": "geocode correction",
  "dry_run": true
}
```

Response：

```json
{
  "job_id": "JOB-001",
  "status": "QUEUED",
  "requires_approval": true
}
```

### 10.2 查詢重算影響

```http
GET /ops/recompute-jobs/{job_id}/impact
```

### 10.3 核准重算

```http
POST /ops/recompute-jobs/{job_id}/approve
```

---

## 11. Validation

### 11.1 Migration Validation

檢查：

- Row count。
- Null count。
- Duplicate keys。
- Referential integrity。
- Enum validity。
- Distribution shift。
- API smoke。
- Dashboard smoke。
- Model input schema。

### 11.2 Backfill Validation

檢查：

- Source row count = target row count within tolerance。
- Failed records reason。
- Date coverage。
- Partition completeness。
- Data quality tests。
- Sample manual check。
- Downstream dbt test。

### 11.3 Recompute Validation

檢查：

- Output version created。
- Old output retained。
- Decision log unaffected。
- Diff report created。
- Model version correct。
- Feature snapshot correct。
- Audit event written。

---

## 12. Rollback

### 12.1 Schema Rollback

- 使用 migration rollback script。
- 若 destructive change 已執行，使用 backup restore。
- 回滾前需 freeze writes。

### 12.2 Data Rollback

- 恢復備份 partition。
- 或使用 correction records 抵銷。
- 不刪除 audit。

### 12.3 Backfill Rollback

每次 backfill 必須標記：

```text
backfill_run_id
```

Target table 需支援依 run_id 移除或隔離：

```sql
delete from target_table
where backfill_run_id = '...'
```

若不允許 delete，則建立 `is_active` / `superseded_by`。

---

## 13. 權限

| 操作 | 權限 |
|---|---|
| 查看 migration | ops.read |
| 建立 migration | ops.migration.create |
| 執行 dry-run | ops.migration.dry_run |
| 核准 production migration | ops.migration.approve |
| 執行 production migration | ops.migration.execute |
| 建立 backfill | data.backfill.create |
| 核准 backfill | data.backfill.approve |
| 建立 model recompute | ml.recompute.create |
| 核准高風險 recompute | governance.approve |

---

## 14. Audit

所有 migration / backfill / recompute 必須寫入：

```text
operation_id
operation_type
actor
reason
target
date_range
before_version
after_version
dry_run_result
approval
started_at
finished_at
status
validation_result
correlation_id
```

---

## 15. 事故預防

### 15.1 禁止事項

- 不得在 production 手動直接改表。
- 不得覆蓋已核准決策。
- 不得刪除 audit。
- 不得無 snapshot 重算模型。
- 不得未 dry-run 即執行高風險 backfill。
- 不得在 business hours 執行大型 destructive migration。
- 不得使用未成熟 outcome 作 label。

### 15.2 安全措施

- Feature flag。
- Read-only window。
- Backup before migration。
- Canary backfill。
- Partition-level validation。
- Alert on anomaly。
- Manual approval。
- Post-run report。

---

## 16. 常見情境 Runbook

### 16.1 Geocode 修正

```text
1. 更新 candidate_site geocode。
2. 建立 affected entities impact report。
3. 重算 listing heatzone match。
4. 重算 SiteScore。
5. 建立 report diff。
6. 若舊 report 已決策，通知 reviewer。
```

### 16.2 外部租金資料更新

```text
1. Ingest rent snapshot。
2. Run data quality。
3. Rebuild rent features。
4. Recompute HeatZone rent feasibility。
5. Recompute affected SiteScore rent reasonableness。
6. Update confidence。
```

### 16.3 交易資料補登

```text
1. Ingest correction records。
2. Update canonical transaction with correction chain。
3. Rebuild store time series。
4. Recompute ForecastOps if within active window。
5. Recompute AVM if GM_TTM affected。
6. Do not rewrite past decisions。
```

### 16.4 模型輸出欄位變更

```text
1. Expand prediction table schema。
2. Update API to support old/new fields。
3. Backfill new field for new outputs only if possible。
4. Update frontend with fallback。
5. Deprecate old field after compatibility period。
```

---

## 17. 驗收條件

本文件完成後需滿足：

- Migration、Backfill、Recompute 三者分工清楚。
- 已決策資料不可被覆蓋。
- Point-in-time correctness 有明確驗證。
- 所有重算皆版本化。
- 每個 operation 有 dry-run、approval、audit、rollback。
- 常見資料修正情境有 runbook。
