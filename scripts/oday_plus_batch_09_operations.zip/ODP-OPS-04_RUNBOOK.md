---
id: ODP-OPS-04
title: Runbook
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: SRE / Engineering Lead / Support Lead
updated_at: 2026-06-26
depends_on:
  - ODP-SD-10_EXCEPTION_HANDLING_AND_RELIABILITY_DESIGN
  - ODP-SD-11_OBSERVABILITY_AND_AUDIT_DESIGN
  - ODP-QA-05_PERFORMANCE_SECURITY_AND_DR_TEST
  - ODP-OPS-03_DEPLOYMENT_AND_ENVIRONMENT_SETUP_MANUAL
---

# ODP-OPS-04 Runbook

## 1. 文件目的

本文件提供 ODay Plus 日常維運、警示處理、常見故障排除、資料問題、模型問題、Job 問題、外部資料中斷、前端異常、API 異常、Solver 失敗與 Audit 異常的操作流程。

Runbook 的目標是讓值班人員在事件發生時能快速回答：

```text
發生什麼？
影響範圍是什麼？
是否要升級？
如何暫時止血？
如何恢復？
如何保留證據？
如何避免再發？
```

---

## 2. 事件分級

| Severity | 說明 | 範例 | 目標 |
|---|---|---|---|
| P0 | 全平台或高風險決策安全受影響 | 權限繞過、Audit 失效、Production DB unavailable | 立即處理 |
| P1 | 核心流程不可用 | SiteScore 無法評分、ForecastOps 無法產生四燈 | 緊急處理 |
| P2 | 重要功能受影響但有 workaround | Listing import 失敗、報表匯出失敗 | 當日處理 |
| P3 | 局部功能或非核心問題 | UI 顯示錯誤、低風險 job 延遲 | 排程修復 |
| P4 | 建議或改善 | 文案、易用性 | backlog |

---

## 3. 通用 Incident Triage

### 3.1 第一時間檢查

```text
1. 確認 alert 來源。
2. 確認 environment。
3. 確認 service / job / module。
4. 查 correlation_id。
5. 查最近 deploy / migration / model release。
6. 查 error rate / latency / queue depth。
7. 確認是否影響 high-risk decision。
8. 建立 incident record。
```

### 3.2 通用指令

```bash
gcloud run services list --region=${REGION}
gcloud run services describe core-api --region=${REGION}
gcloud run jobs executions list --region=${REGION}
gcloud logging read 'severity>=ERROR' --limit=50
gcloud pubsub subscriptions describe ${SUBSCRIPTION}
```

### 3.3 升級條件

以下必須升級 P0/P1：

- Audit write 失敗。
- 權限錯誤。
- 高風險核准流程錯誤。
- Production data corruption。
- Model prediction 使用錯誤版本。
- PriceOps hard constraint 被繞過。
- NetPlan 方案違反 hard constraints。
- 個資外洩疑慮。
- RPO / RTO 風險。

---

## 4. API 異常 Runbook

## 4.1 症狀

- 5xx error rate 上升。
- P95 latency 超標。
- Health check fail。
- 특정 endpoint timeout。
- 使用者無法開啟頁面。

## 4.2 檢查

```text
1. Cloud Run revision health。
2. Recent deployment。
3. Error logs。
4. Cloud SQL connection。
5. Redis connection。
6. Pub/Sub publish errors。
7. Auth provider status。
8. Downstream model endpoint。
```

## 4.3 止血

| 情境 | 動作 |
|---|---|
| 新版 revision 出錯 | rollback Cloud Run revision |
| 下游模型不可用 | 啟用 degraded mode / previous model |
| DB connection exhausted | scale DB / reduce concurrency / restart service |
| 特定 endpoint 出錯 | disable feature flag |
| 大量請求 | rate limit / Cloud Armor rule |

## 4.4 恢復確認

- 5xx 回到正常。
- P95 回到 SLA。
- Smoke test 通過。
- Error logs 下降。
- User flow 可完成。
- Audit write 正常。

---

## 5. Frontend 異常 Runbook

## 5.1 症狀

- 白畫面。
- Route 404。
- 登入後跳轉錯誤。
- 地圖無法載入。
- 圖表無資料。
- 按鈕無反應。
- Permission guard 錯誤。

## 5.2 檢查

```text
1. Browser console error。
2. Network tab API error。
3. App version。
4. Feature flag。
5. Route config。
6. OpenAPI client compatibility。
7. CDN / static asset status。
```

## 5.3 止血

- Rollback frontend revision。
- 關閉 feature flag。
- 回切 API compatibility mode。
- 若地圖 layer 失敗，切換列表模式。
- 若圖表失敗，顯示 table fallback。

---

## 6. Job 失敗 Runbook

## 6.1 適用 Job

```text
external-data-ingest
geo-feature-worker
listing-import
listing-geocode
heatzone-batch-score
sitescore-score
forecast-batch-score
pricing-optimizer
adlift-estimation
avm-report
netplan-solver
model-training
data-quality
audit-export
```

## 6.2 檢查

```text
1. job_id。
2. job_type。
3. status。
4. input parameters。
5. error code。
6. retry count。
7. worker logs。
8. resource usage。
9. upstream data status。
10. idempotency key。
```

## 6.3 通用處理

| 狀態 | 處理 |
|---|---|
| QUEUED 過久 | 查 queue depth / worker capacity |
| RUNNING 過久 | 查 timeout / resource / deadlock |
| FAILED retryable | retry |
| FAILED non-retryable | 修正資料或設定 |
| PARTIAL | 下載 failed records |
| DLQ | inspect poison message |
| CANCELLED | 查 actor 與 reason |

## 6.4 重跑規則

重跑前確認：

- Job idempotent。
- 不會覆蓋已決策結果。
- 有 retry reason。
- 高風險 job 有 approval。
- DLQ 訊息已分析。

---

## 7. Data Freshness Runbook

## 7.1 症狀

- Data status = STALE。
- Data quality alert。
- Model scoring blocked。
- Dashboard 顯示資料過期。
- 外部 connector 失敗。

## 7.2 檢查

```text
1. Source system status。
2. Last observed_at。
3. Last ingested_at。
4. Expected frequency。
5. Connector logs。
6. API quota / rate limit。
7. Schema change。
8. Data quality report。
```

## 7.3 處理

| 原因 | 動作 |
|---|---|
| 上游未提供 | 通知 data owner |
| Connector fail | retry / fix credential |
| API rate limit | adjust schedule / quota |
| Schema changed | contract review / mapper update |
| Data quality fail | quarantine / block downstream |
| External source unavailable | use fallback / lower confidence |

## 7.4 恢復

- 重跑 ingestion。
- 重跑 data quality。
- 重建 model-ready view。
- 解除 model block。
- 發送資料恢復通知。

---

## 8. Geocode 失敗 Runbook

### 8.1 症狀

- Listing geocode_status = FAILED。
- Candidate Site 無法 SiteScore。
- HeatZone match missing。

### 8.2 檢查

- address_raw 是否完整。
- address_normalized 是否合理。
- geocode provider quota。
- provider response。
- duplicate address。
- manual coordinate 是否存在。

### 8.3 處理

1. 重新 address normalization。
2. 使用 alternative provider。
3. 若仍失敗，進入 manual geocode queue。
4. 標示 geocode_confidence。
5. 低 confidence 不允許 GO，需人工現勘或補件。

---

## 9. SiteScore 異常 Runbook

### 9.1 症狀

- SiteScore job failed。
- Report 無法生成。
- Recommendation 缺失。
- P10/P50/P90 不合理。
- Report model_version 錯誤。

### 9.2 檢查

```text
candidate_site_id
feature_snapshot_time
geocode_status
rent
hard_rule_status
model_version
feature schema
model endpoint
report generator logs
```

### 9.3 處理

| 原因 | 動作 |
|---|---|
| 缺 geocode | 執行 geocode |
| 缺租金 | 允許 partial report 或補件 |
| hard rule fail | report 可生成但不得 GO |
| model endpoint fail | 使用 previous champion 或重試 |
| feature schema mismatch | block scoring / fix feature view |
| report generation fail | retry report worker |

### 9.4 恢復確認

- Report 可開啟。
- model_version 正確。
- feature_snapshot_time 正確。
- Audit event 存在。
- 舊 report 未被覆蓋。

---

## 10. ForecastOps / 四燈 Runbook

### 10.1 症狀

- 每日 forecast 未產生。
- 四燈異常大量紅燈。
- Store forecast 圖表空白。
- Alert 未建立。
- Root cause evidence 缺失。

### 10.2 檢查

- store_machine_timeseries_view。
- forecast_batch_score job。
- model_version。
- data freshness。
- price / ad / maintenance markers。
- seasonal calendar。
- alert policy version。

### 10.3 處理

| 原因 | 動作 |
|---|---|
| 上游交易資料延遲 | 降級使用前一日資料並標示 stale |
| 模型失敗 | fallback baseline |
| alert policy 錯誤 | rollback policy version |
| 大量 false alert | 暫停自動 task creation，保留 alert |
| root cause view 缺資料 | 顯示 insufficient evidence |

---

## 11. InterventionOps Runbook

### 11.1 症狀

- 干預無法建立。
- Eligibility 無法計算。
- Conflict check 錯誤。
- Approval 卡住。
- Observation window 未建立。
- Outcome 未成熟。

### 11.2 處理

| 問題 | 動作 |
|---|---|
| 無 trigger entity | 確認 alert_id / manual reason |
| eligibility fail | 查看規則與資料 |
| conflict check fail | 手動 review，不可跳過 |
| approval stuck | 重新指派 approver |
| execution failed | 通知 owner / 建立 incident |
| outcome missing | 檢查資料來源與 maturity time |

---

## 12. PriceOps Runbook

### 12.1 Critical

以下立即 P1：

- Hard constraint violation。
- 未核准價格被執行。
- Rollback 失敗。
- 價格資料同步錯誤。

### 12.2 處理

1. 關閉 PriceOps execution feature flag。
2. 停止 pending price execution。
3. 檢查 price plan approval。
4. 回滾至 previous price。
5. 建立 audit incident。
6. 通知定價 owner。
7. 啟動 postmortem。

---

## 13. AdLift Runbook

### 13.1 常見問題

- Control matching failed。
- Pre-trend failed。
- Campaign outcome missing。
- Overlapping interventions。
- iROMI 顯示異常。

### 13.2 處理

- Pre-trend failed 時降 evidence level。
- 無 control 時不得宣稱因果。
- 重疊干預標示 contamination。
- Outcome missing 時延長或重建 observation window。
- 不自動 stop campaign，需人工 decision。

---

## 14. AVM Runbook

### 14.1 症狀

- AVM report failed。
- Data room incomplete。
- GM normalization abnormal。
- Valuation range too wide。
- Finance approval missing。

### 14.2 處理

- 檢查 GM_TTM / GM_FWD。
- 檢查 asset ledger。
- 檢查 lease data。
- 若 confidence 低，report 顯示 low confidence。
- Reserve price 不可自動設定，需 finance approval。

---

## 15. NetPlan Runbook

### 15.1 症狀

- Solver timeout。
- Infeasible。
- Scenario 無結果。
- Hard constraint violation。
- Alternative plan missing。

### 15.2 處理

| 問題 | 動作 |
|---|---|
| Solver timeout | 增加資源 / 縮小 scenario / 分區求解 |
| Infeasible | 啟動 infeasibility diagnosis |
| Constraint violation | 阻擋方案，不可核准 |
| Alternative missing | 重新執行 alternative generation |
| Result suspicious | 要求 OR owner review |

---

## 16. Learning Hub / Model Release Runbook

### 16.1 Critical

- Production model alias 指錯。
- Model rollback fail。
- Model card missing。
- Drift monitor fail。
- Data quality fail 仍發布模型。

### 16.2 處理

使用 OPS-06 模型發布與回滾手冊。

---

## 17. Audit Write Failure Runbook

### 17.1 症狀

- Audit log write failed。
- Decision 操作無 audit_id。
- Export evidence failed。

### 17.2 等級

Audit write failure 影響高風險決策，一律 P0/P1。

### 17.3 處理

1. 立即暫停高風險操作 feature flag。
2. 檢查 audit store。
3. 檢查 API log 中未寫入 audit 的操作。
4. 重放 audit events。
5. 補齊 audit 需標示 `recovered_audit=true`。
6. 恢復後執行 audit completeness check。

---

## 18. External Source Unavailable Runbook

### 18.1 處理策略

| Source | Strategy |
|---|---|
| POI | 使用上次 snapshot，降低 confidence |
| Rent | 使用上次 snapshot，標示 stale |
| Weather | 可 fallback，不阻擋大部分流程 |
| Listing | 暫停新 listing ingest |
| Geocode | 切換 alternative provider 或 manual |
| Competitor | 使用上次 snapshot，阻擋高 confidence GO |

---

## 19. 通知與溝通

### 19.1 Incident Update Template

```text
事件：
等級：
開始時間：
影響範圍：
目前狀態：
已採取措施：
下一步：
預計下次更新：
負責人：
```

### 19.2 User-facing Message

```text
目前系統部分功能暫時無法使用。
已受影響功能：{module}
您的既有資料與決策紀錄不受影響。
我們會於系統恢復後更新狀態。
```

---

## 20. Post-incident

每個 P0/P1 需完成：

- Timeline。
- Root cause。
- Detection gap。
- Customer impact。
- Data impact。
- Decision impact。
- Recovery action。
- Preventive action。
- Owner。
- Due date。

---

## 21. 驗收條件

本 Runbook 完成後需滿足：

- 覆蓋 API、前端、Job、資料、模型、Solver、Audit。
- 高風險操作有明確止血策略。
- 每個主要模組有故障排除流程。
- Audit failure 與 PriceOps hard constraint failure 被視為高嚴重度。
- 能支援一線維運人員實際操作。
