---
id: ODP-OPS-03
title: 部署與環境建置手冊
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: DevOps / SRE / Engineering Lead
updated_at: 2026-06-26
depends_on:
  - ODP-SD-02_GCP_PHYSICAL_DEPLOYMENT_ARCHITECTURE
  - ODP-SD-03_SERVICE_AND_COMPONENT_BOUNDARIES
  - ODP-SD-12_CICD_IAC_AND_ENVIRONMENT_DESIGN
  - ODP-QA-05_PERFORMANCE_SECURITY_AND_DR_TEST
---

# ODP-OPS-03 部署與環境建置手冊

## 1. 文件目的

本文件定義 ODay Plus 在 GCP 上的環境建置、部署流程、服務設定、密鑰管理、CI/CD、資料庫 migration、dbt deployment、Cloud Run service/job、監控與 rollback 操作手冊。

---

## 2. 環境清單

```text
local
development
integration
staging
production
sandbox
```

### 2.1 環境用途

| Environment | 用途 |
|---|---|
| local | 開發者本機 |
| development | 功能開發整合 |
| integration | 跨模組與資料契約測試 |
| staging | UAT、E2E、release validation |
| production | 正式營運 |
| sandbox | Demo、教育訓練、加盟主測試 |

---

## 3. GCP Project 建議

```text
odp-dev
odp-int
odp-stg
odp-prod
odp-sandbox
```

每個 project 應獨立：

- IAM。
- Secret Manager。
- Cloud SQL。
- BigQuery dataset。
- Cloud Storage bucket。
- Pub/Sub topics。
- Cloud Run services。
- Monitoring dashboards。

---

## 4. 基礎資源

## 4.1 Networking

需建立：

```text
VPC
subnet
serverless VPC connector
private service access
egress control
Cloud NAT if needed
firewall rules
```

## 4.2 Compute

| Workload | GCP 服務 |
|---|---|
| Frontend | Cloud Run / Cloud CDN static |
| API | Cloud Run Services |
| Worker | Cloud Run Services / Jobs |
| Scheduled batch | Cloud Run Jobs + Scheduler |
| Model training | Vertex AI / Cloud Run Jobs |
| Model serving | Vertex AI Endpoint / Cloud Run |
| Solver | Cloud Run Jobs / GKE optional |
| Workflow | Temporal / Cloud Run services |

## 4.3 Data

| Data | GCP 服務 |
|---|---|
| Operational DB | Cloud SQL PostgreSQL + PostGIS |
| Analytical | BigQuery |
| Object storage | Cloud Storage |
| Cache / Lock | Memorystore Redis |
| Search | OpenSearch optional |
| Artifact | Artifact Registry |
| Secret | Secret Manager |

## 4.4 Observability

```text
Cloud Logging
Cloud Monitoring
Cloud Trace
OpenTelemetry Collector
Error Reporting
Alerting policies
```

---

## 5. Terraform Structure

```text
infra/
├── modules/
│   ├── network/
│   ├── cloud-run-service/
│   ├── cloud-run-job/
│   ├── cloud-sql/
│   ├── bigquery/
│   ├── pubsub/
│   ├── storage/
│   ├── secret-manager/
│   ├── iam/
│   ├── monitoring/
│   └── artifact-registry/
├── envs/
│   ├── dev/
│   ├── integration/
│   ├── staging/
│   ├── production/
│   └── sandbox/
└── README.md
```

### 5.1 Terraform 命令

```bash
terraform init
terraform plan -var-file=env.tfvars
terraform apply -var-file=env.tfvars
```

Production apply 需：

- PR review。
- plan artifact。
- SRE approval。
- Change window。
- Rollback plan。

---

## 6. Repository Build

### 6.1 Backend Build

```bash
docker build -f apps/api/Dockerfile -t api:${GIT_SHA} .
docker build -f apps/worker/Dockerfile -t worker:${GIT_SHA} .
```

### 6.2 Frontend Build

```bash
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm build
```

### 6.3 Python Build

```bash
python -m pip install -r requirements.txt
pytest
ruff check .
mypy .
```

### 6.4 Image Push

```bash
docker tag api:${GIT_SHA} ${REGION}-docker.pkg.dev/${PROJECT}/oday/api:${GIT_SHA}
docker push ${REGION}-docker.pkg.dev/${PROJECT}/oday/api:${GIT_SHA}
```

---

## 7. Cloud Run Services

### 7.1 Services

```text
opsboard-web
core-api
expansion-api
operations-api
intervention-api
asset-network-api
learninghub-api
workflow-service
notification-service
```

### 7.2 Common Environment Variables

```text
APP_ENV
APP_VERSION
SERVICE_NAME
DATABASE_URL
BIGQUERY_PROJECT
GCS_BUCKET
PUBSUB_PROJECT
REDIS_HOST
OTEL_EXPORTER_OTLP_ENDPOINT
AUTH_ISSUER
AUTH_AUDIENCE
FEATURE_FLAG_PROVIDER
```

### 7.3 Cloud Run Deploy

```bash
gcloud run deploy core-api \
  --image=${IMAGE} \
  --region=${REGION} \
  --platform=managed \
  --service-account=${SA} \
  --set-env-vars=APP_ENV=staging,APP_VERSION=${GIT_SHA} \
  --vpc-connector=${VPC_CONNECTOR} \
  --allow-unauthenticated=false
```

### 7.4 Health Checks

每個 service 必須提供：

```text
GET /healthz
GET /readyz
GET /version
```

`/healthz` 驗證 process。  
`/readyz` 驗證 DB、Pub/Sub、feature flag、必要 dependency。

---

## 8. Cloud Run Jobs

### 8.1 Jobs

```text
external-data-ingest
geo-feature-worker
listing-import-job
listing-geocode-job
heatzone-batch-score
sitescore-score-job
forecast-batch-score
pricing-optimizer-job
adlift-estimation-job
avm-report-job
netplan-solver-job
model-training-job
model-backtest-job
data-quality-job
dbt-build-job
audit-export-job
```

### 8.2 Job Deploy

```bash
gcloud run jobs deploy heatzone-batch-score \
  --image=${IMAGE} \
  --region=${REGION} \
  --service-account=${SA} \
  --tasks=4 \
  --max-retries=2 \
  --set-env-vars=APP_ENV=staging,JOB_TYPE=heatzone_batch_score
```

### 8.3 Job Execute

```bash
gcloud run jobs execute heatzone-batch-score \
  --region=${REGION} \
  --wait
```

---

## 9. Scheduler

使用 Cloud Scheduler 觸發：

| Schedule | Job |
|---|---|
| 每日 02:00 | external-data-ingest |
| 每日 03:00 | data-quality-job |
| 每日 04:00 | forecast-batch-score |
| 每週 | adlift-estimation-job |
| 每月 | heatzone-batch-score |
| 每月 / 季 | model-backtest-job |
| 每季 | netplan-solver-job |

---

## 10. Pub/Sub

### 10.1 Topic Naming

```text
odp.{env}.{domain}.{event}
```

範例：

```text
odp.prod.sitescore.report_generated
odp.prod.forecast.alert_created
odp.prod.intervention.approved
odp.prod.model.release_requested
```

### 10.2 Subscription

```text
{subscriber-service}.{topic}.sub
```

### 10.3 DLQ

所有 critical subscription 必須有 DLQ：

```text
odp.prod.dlq
```

---

## 11. Cloud SQL / PostGIS

### 11.1 初始化

```bash
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
```

### 11.2 Migration

使用 Alembic / Flyway：

```bash
alembic upgrade head
alembic current
```

Production migration 流程：

1. Backup。
2. Migration dry-run。
3. Apply in staging。
4. Smoke test。
5. Production change window。
6. Apply。
7. Post-migration validation。
8. Rollback readiness。

---

## 12. BigQuery / dbt

### 12.1 Dataset

```text
raw
source_normalized
canonical
feature_marts
model_ready
snapshots
audit_exports
qa_reports
```

### 12.2 dbt Commands

```bash
dbt deps
dbt seed --target staging
dbt run --target staging
dbt test --target staging
dbt docs generate
```

### 12.3 dbt Deployment

- Dev 可由開發者觸發。
- Staging 由 CI/CD 觸發。
- Production 需 data owner approval。
- Model-ready view breaking change 需 contract review。

---

## 13. Secret Manager

### 13.1 Secret Naming

```text
odp-{env}-{service}-{secret-name}
```

範例：

```text
odp-prod-core-api-db-url
odp-prod-external-connector-api-key
```

### 13.2 Secret Rules

- 不在 env file commit secret。
- 不在 log 印 secret。
- Secret rotation 需 runbook。
- Production secret access 最小權限。
- Break-glass access 必須 audit。

---

## 14. IAM

### 14.1 Service Accounts

```text
sa-core-api
sa-worker
sa-dbt
sa-ml-training
sa-model-serving
sa-solver
sa-audit-export
sa-ci-cd
```

### 14.2 原則

- 一服務一 service account。
- 不使用 default compute service account。
- Production 不允許 owner/editor broad permission。
- CI/CD service account 僅有部署所需權限。
- 所有 elevated access 有 expiry。

---

## 15. Monitoring

### 15.1 Dashboards

```text
API Dashboard
Job Dashboard
Data Freshness Dashboard
Model Serving Dashboard
ForecastOps Dashboard
Event / PubSub Dashboard
Database Dashboard
Security Dashboard
SLA Dashboard
```

### 15.2 Alerts

```text
API error rate high
API latency high
Cloud Run revision unhealthy
Job failed
Queue depth high
Data freshness breach
Data quality failed
Model endpoint unavailable
Solver timeout
Cloud SQL CPU / connection high
Backup failed
Audit write failed
```

---

## 16. Deployment Pipeline

```text
Pull Request
→ lint / typecheck
→ unit tests
→ build image
→ security scan
→ deploy dev
→ integration tests
→ deploy staging
→ E2E / UAT
→ approval
→ deploy production canary
→ smoke test
→ traffic increase
→ post-release monitoring
```

### 16.1 Production Deploy Checklist

- [ ] Release note completed。
- [ ] Migration reviewed。
- [ ] Data contract compatible。
- [ ] Model version approved。
- [ ] Feature flag plan ready。
- [ ] Rollback plan ready。
- [ ] On-call aware。
- [ ] Monitoring dashboard open。
- [ ] Smoke test script ready。

---

## 17. Rollback

### 17.1 Cloud Run Rollback

```bash
gcloud run services update-traffic core-api \
  --to-revisions=${PREVIOUS_REVISION}=100 \
  --region=${REGION}
```

### 17.2 Database Rollback

- 若 non-destructive：apply rollback migration。
- 若 destructive：restore backup / PITR。
- 若 data migration：依 migration_id revert。
- 若無法即時 rollback：啟用 degraded mode。

### 17.3 Frontend Rollback

- 回切 previous Cloud Run revision。
- 或回切 CDN / static asset version。
- Feature flag 關閉新功能。

### 17.4 Model Rollback

使用 OPS-06 流程。

---

## 18. Smoke Test

Production deploy 後執行：

```text
login
GET /healthz
GET /version
open OpsBoard
search store
open HeatZone map
open SiteScore report
open Store forecast
create test job in safe mode
check audit write
check logs and traces
```

---

## 19. Deployment Failure Handling

| Failure | 處理 |
|---|---|
| Image deploy fail | rollback image / inspect build |
| Health check fail | route traffic back |
| Migration fail | stop deploy / rollback migration |
| API 5xx | rollback revision |
| Data quality fail | block model jobs |
| Frontend route broken | rollback frontend |
| Feature defect | disable flag |
| Model error | rollback model alias |
| Pub/Sub consumer error | pause subscription / DLQ |

---

## 20. 驗收條件

本文件完成後需滿足：

- GCP 環境與服務建置步驟明確。
- Cloud Run service/job 部署方式明確。
- Terraform、DB migration、dbt、Secret、IAM、Pub/Sub、Monitoring 有規範。
- Production deploy 有 checklist 與 rollback。
- Smoke test 與 failure handling 可執行。
