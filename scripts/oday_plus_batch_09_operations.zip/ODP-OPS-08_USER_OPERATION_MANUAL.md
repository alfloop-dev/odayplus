---
id: ODP-OPS-08
title: 使用者操作手冊
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: Product Owner / Training Lead / Support Lead
updated_at: 2026-06-26
depends_on:
  - ODP-SA-05_USE_CASES_AND_USER_JOURNEYS
  - ODP-UX-01_INFORMATION_ARCHITECTURE_AND_NAVIGATION
  - ODP-UX-03_SCREEN_AND_INTERACTION_SPECIFICATION
  - ODP-QA-06_UAT_AND_FORMAL_ACCEPTANCE_CHECKLIST
---

# ODP-OPS-08 使用者操作手冊

## 1. 文件目的

本文件提供 ODay Plus 一般使用者、業務角色、營運角色、財務／法務、AI／資料團隊、加盟主與稽核人員的操作指引。

本手冊重點是：**如何完成工作任務與決策流程**，不是說明模型內部技術。

---

## 2. 登入與首頁

### 2.1 登入

1. 開啟 ODay Plus。
2. 使用公司帳號登入。
3. 若啟用 MFA，完成二次驗證。
4. 系統依角色進入對應 Home。

### 2.2 Home

Home 顯示：

- 我的任務。
- 重大警示。
- 待核准事項。
- 最近決策。
- 資料與模型健康狀態。
- 快捷動作。

### 2.3 Workspace 切換

若您有多重角色，可從左上方 Workspace Switcher 切換：

```text
Executive
Expansion
Site Review
Operations
Intervention
Pricing
Marketing
Asset
Network Planning
Learning
Franchisee
Audit
```

---

## 3. 任務中心

### 3.1 查看任務

1. 點擊右上角 Task Center。
2. 使用篩選條件查看：
   - 我的任務。
   - 待核准。
   - 即將逾期。
   - 指定模組。
   - 指定門市。
3. 點擊任務進入 Detail。

### 3.2 任務狀態

```text
CREATED
ASSIGNED
IN_PROGRESS
WAITING_FOR_INPUT
WAITING_FOR_APPROVAL
APPROVED
REJECTED
EXECUTED
OBSERVING
DONE
CANCELLED
EXPIRED
```

### 3.3 完成任務

任務完成前可能需要：

- 填寫原因。
- 上傳照片或附件。
- 核准或拒絕。
- 指派下一位處理人。
- 等待觀察窗成熟。

---

## 4. 展店業務操作

## 4.1 查看 HeatZone

1. 進入 `Expansion > HeatZone Map`。
2. 選擇圖層：
   - HeatZone Score。
   - 未滿足需求。
   - ODay G2 適配。
   - 自家稀釋風險。
   - 租金可行性。
3. 點擊熱區查看細節。
4. 可指派展店業務或查看該區 Listing。

### 4.2 熱區狀態

```text
UNTOUCHED
PARTIALLY_ABSORBED
SATURATED
UNDER_REALIZED
STILL_EXPANDABLE
```

### 4.3 匯入 Listing

1. 進入 `Expansion > Listing Inbox`。
2. 點擊「匯入」。
3. 上傳 CSV / Excel。
4. 檢查欄位 mapping。
5. 送出 import。
6. 系統會自動：
   - 地址正規化。
   - Geocode。
   - 去重。
   - Hard rule 檢查。
   - HeatZone match。

### 4.4 建立 Candidate Site

1. 在 Listing Inbox 選擇合格物件。
2. 點擊「轉為候選點」。
3. 檢查地址、租金、坪數、樓層、停車、電力、排水。
4. 儲存 Candidate Site。

---

## 5. 展店審查操作

## 5.1 執行 SiteScore

1. 開啟 Candidate Site。
2. 確認 geocode、租金、物件條件。
3. 點擊「執行 SiteScore」。
4. 系統建立評分 Job。
5. Job 完成後進入 SiteScore Report。

### 5.2 閱讀 SiteScore Report

重點區塊：

- GO / WAIT / REJECT / INVESTIGATE。
- M1/M3/M6/M12 營收路徑。
- P10/P50/P90。
- 回本期。
- 租金合理性。
- 自家稀釋。
- Comparable Stores。
- 主要正向與負向因子。
- 模型版本。
- 資料快照時間。

### 5.3 核准或退回

1. 點擊「送審」或進入待審任務。
2. 檢查系統建議。
3. 選擇：
   - 核准 GO。
   - 核准 WAIT。
   - Reject。
   - Request revision。
   - Override。
4. 填寫原因。
5. 送出。

注意：系統預測不是最終決策，最終決策需人工核准。

---

## 6. 營運主管操作

## 6.1 查看 Operations Overview

進入 `Operations > Overview`，查看：

- 四燈分布。
- 紅燈門市。
- 橙燈門市。
- 預測準確度。
- 近期干預結果。
- 資料新鮮度。

## 6.2 處理四燈警示

1. 進入 `Operations > Four-Light Alert Center`。
2. 篩選紅燈或橙燈。
3. 點擊門市。
4. 查看 Forecast 與 Root Cause Evidence。
5. 指派 owner。
6. 建立 Intervention。

### 6.3 Root Cause Evidence

可能原因：

- 自然淡季。
- 店齡爬坡。
- 設備故障。
- 成本異常。
- 客訴／清潔。
- 價格。
- 廣告不足。
- 促銷重疊。
- 競店。
- 商圈變化。

---

## 7. 區域督導操作

## 7.1 查看處置任務

1. 進入 Task Center。
2. 篩選 `INTERVENTION_EXECUTION`。
3. 點擊任務。
4. 查看處置內容與期限。

## 7.2 執行處置

依任務類型執行：

- 調整清潔。
- 檢查設備。
- 促銷布置。
- 會員召回。
- 現場拍照。
- 客訴回覆。
- 維修確認。

## 7.3 回報結果

1. 開啟 Intervention Detail。
2. 點擊「更新執行狀態」。
3. 填寫執行情況。
4. 上傳附件。
5. 送出。
6. 系統進入觀察窗。

---

## 8. InterventionOps 操作

## 8.1 建立干預

來源：

- ForecastOps alert。
- 人工建立。
- PriceOps。
- AdLift。
- 維修／清潔。

步驟：

1. 選擇門市。
2. 選擇干預類型。
3. 系統執行 Eligibility。
4. 系統檢查 Conflict。
5. 建立 Action Set。
6. 送出核准。

## 8.2 觀察窗

觀察窗代表干預後等待結果成熟的期間。結果未成熟前，不應判斷干預是否有效。

---

## 9. PriceOps 操作

## 9.1 查看調價候選

進入 `Pricing > Pricing Candidates`。

檢查：

- 現行價格。
- 候選價格。
- 預期需求變化。
- 預期毛利變化。
- Hard constraints。
- Rollback plan。

## 9.2 建立調價方案

1. 選擇候選。
2. 開啟 Simulation。
3. 檢查需求與毛利。
4. 檢查限制是否違反。
5. 建立 Price Plan。
6. 送審。

## 9.3 核准調價

核准前確認：

- 無 hard constraint violation。
- 有 rollback plan。
- 風險可接受。
- 非重疊促銷。
- 觀察窗設定。

---

## 10. AdLift 操作

## 10.1 建立廣告活動

1. 進入 `Marketing > Campaign Candidates`。
2. 查看 Ad Need Score。
3. 選擇門市與渠道。
4. 系統建立 treatment stores。
5. 系統建立 control stores。
6. 檢查 pre-trend。
7. 送審活動。

## 10.2 查看 Lift Report

活動結束後查看：

- Treatment。
- Control。
- Pre-trend。
- Incremental Revenue。
- Incremental GM。
- iROMI。
- Evidence Level。
- Continue / Stop 建議。

注意：若 evidence insufficient，不能宣稱廣告造成營收提升。

---

## 11. 財務／法務操作

## 11.1 建立 AVM 估值

1. 進入 `Asset > AVM Queue`。
2. 選擇門市。
3. 建立估值請求。
4. 系統產生估值卡。

## 11.2 閱讀估值卡

重點：

- Fair Value P10/P50/P90。
- Reserve Price。
- Asking Price。
- Income Approach。
- Asset Approach。
- Market Comparable。
- Liquidity。
- Data Room completeness。

## 11.3 財務核准

1. 檢查估值資料。
2. 檢查正常化毛利。
3. 設定或核准 reserve price。
4. 填寫 reason。
5. 送出核准。

---

## 12. 管理層 NetPlan 操作

## 12.1 建立 Scenario

1. 進入 `Network Planning > Scenario Builder`。
2. 設定 planning horizon。
3. 選擇候選門市與候選動作。
4. 設定限制：
   - 預算。
   - 租約。
   - 施工。
   - 設備。
   - 人力。
   - 自家稀釋。
5. 執行 Solver。

## 12.2 查看 Solver Result

檢查：

- OPEN / KEEP / IMPROVE / MOVE / EXIT。
- 預期毛利。
- 預算使用。
- 風險。
- Binding constraints。
- Alternative plans。
- Quarterly timeline。

## 12.3 核准方案

方案核准前確認：

- Hard constraints 全部滿足。
- 有 alternative plan。
- 有執行時序。
- 管理層同意風險。
- Outcome tracking 已建立。

---

## 13. AI／資料團隊操作

## 13.1 Data Quality Center

查看：

- 資料來源。
- Freshness。
- Completeness。
- Validity。
- Blocked models。
- Owner。
- Failure reason。

### 處理資料品質失敗

1. 開啟 failure detail。
2. 確認來源。
3. 通知 data owner。
4. 修正後重跑 quality check。
5. 確認模型解除阻擋。

## 13.2 Model Registry

查看：

- Model ID。
- Version。
- Stage。
- Metrics。
- Drift。
- Model Card。
- Release status。

## 13.3 模型發布

1. 查看 candidate model。
2. 檢查 Model Card。
3. 檢查 Backtest。
4. 建立 Release Request。
5. Shadow。
6. Canary。
7. Promote Production。
8. 監控。

## 13.4 Rollback

如發現異常：

1. 開啟 Model Release Controller。
2. 選擇 rollback target。
3. 填寫 reason。
4. 送出核准。
5. 系統切回 previous production。

---

## 14. 稽核人員操作

## 14.1 查詢 Decision Log

1. 進入 `Audit > Decision Log`。
2. 篩選：
   - 模組。
   - 使用者。
   - 時間。
   - Entity。
   - Override only。
   - Model version。
3. 開啟決策明細。

## 14.2 決策明細應包含

- 系統預測。
- 系統建議。
- 人工核准。
- 實際執行。
- 實際結果。
- Actor。
- Model version。
- Policy version。
- Feature snapshot time。
- Reason。
- Audit timeline。

## 14.3 匯出證據

1. 點擊 Export Evidence。
2. 選擇範圍。
3. 填寫匯出理由。
4. 系統建立 export job。
5. 下載證據包。

---

## 15. 加盟主操作

## 15.1 查看自店狀態

1. 登入 Franchisee Portal。
2. 查看 My Store Overview。
3. 查看：
   - 營收趨勢。
   - 系統提醒。
   - 建議處置。
   - 任務。
   - 觀察結果。

加盟主只能看到自己門市，不會看到其他加盟主資料。

## 15.2 回報處置

1. 開啟 Recommended Action。
2. 閱讀為何建議。
3. 按照指示執行。
4. 填寫回報。
5. 上傳照片。
6. 等待區域督導確認。

---

## 16. 通用操作注意事項

### 16.1 不要把模型建議當最終決策

所有高風險動作都需要人工核准。

### 16.2 必填原因

以下操作必填原因：

- Reject。
- Override。
- High-risk approve。
- Rollback。
- Sensitive export。
- Dismiss alert。
- Data quality override。

### 16.3 查看資料時間

任何模型報告都要查看：

- 資料快照時間。
- 模型版本。
- 信心水準。
- 資料品質狀態。

### 16.4 匯出資料

匯出前確認：

- 是否有權限。
- 是否含敏感資料。
- 是否符合用途。
- 是否需要主管核准。

---

## 17. 常見問題

### Q1：為什麼我看不到某個門市？

可能原因：

- 您沒有該區域或門市權限。
- 門市資料尚未同步。
- 門市被停用或封存。

### Q2：為什麼 SiteScore 無法執行？

可能原因：

- 候選點沒有經緯度。
- 租金或必要物件資料缺失。
- Data quality failed。
- 模型服務暫時不可用。

### Q3：為什麼紅燈沒有自動建立處置？

可能原因：

- 系統需要人工 triage。
- 已有重疊干預。
- Eligibility 不通過。
- 資料信心不足。

### Q4：為什麼廣告報告說 evidence insufficient？

可能原因：

- 無對照組。
- Pre-trend 不通過。
- 同期有調價或促銷重疊。
- 觀察窗未成熟。

### Q5：我可以刪除錯誤決策嗎？

不可以。錯誤決策需以 correction 或 override 補正，不能刪除歷史紀錄。

---

## 18. 支援與問題回報

回報問題時請提供：

```text
頁面
操作步驟
錯誤訊息
發生時間
截圖
correlation_id
門市或報告 ID
```

支援優先級：

- 系統不可用。
- 高風險決策受阻。
- 權限問題。
- 資料錯誤。
- 一般操作問題。

---

## 19. 驗收條件

本使用者操作手冊完成後需滿足：

- 覆蓋所有主要角色。
- 覆蓋所有核心模組。
- 說明高風險核准、override、export、rollback。
- 加盟主入口與內部入口分離。
- 使用者能依手冊完成 UAT 主要任務。
