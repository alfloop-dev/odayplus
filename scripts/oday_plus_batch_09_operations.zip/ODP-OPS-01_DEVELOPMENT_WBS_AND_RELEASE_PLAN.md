---
id: ODP-OPS-01
title: 開發 WBS 與 Release Plan
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: Project Manager / Engineering Lead / Product Owner
updated_at: 2026-06-26
depends_on:
  - ODP-00-01_SCOPE_AND_BOUNDARIES
  - ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX
  - ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION
  - ODP-SD-03_SERVICE_AND_COMPONENT_BOUNDARIES
  - ODP-SD-12_CICD_IAC_AND_ENVIRONMENT_DESIGN
  - ODP-MOD-00_INTEGRATION_LAYER_AND_EXTERNAL_DATA_PLATFORM
  - ODP-QA-01_TEST_MASTER_PLAN
  - ODP-QA-06_UAT_AND_FORMAL_ACCEPTANCE_CHECKLIST
---

# ODP-OPS-01 開發 WBS 與 Release Plan

## 1. 文件目的

本文件定義 ODay Plus 全平台開發工作分解結構（WBS）、Release 節奏、里程碑、交付物、進出條件、驗收 Gate、跨模組依賴與上線策略。

ODay Plus 的實作目標不是 MVP 單點功能，而是完整平台：

```text
Integration Layer
→ External Data Platform
→ HeatZone Radar
→ Listing Pipeline
→ SiteScore
→ ForecastOps
→ InterventionOps
→ PriceOps
→ AdLift
→ DealRoomAVM
→ NetPlan
→ Learning Hub
→ OpsBoard
→ Governance / Audit
```

此 Release Plan 的原則是：**完整納入所有模組，但依資料依賴、風險與整合順序分期交付。**

---

## 2. Release 策略

### 2.1 Release 類型

| Release Type | 說明 |
|---|---|
| Foundation Release | 資料、架構、權限、CI/CD、基礎前後端 |
| Domain Release | 單一業務領域完整可測 |
| Integration Release | 跨模組串接與 E2E flow |
| Governance Release | Audit、MLOps、Model Release、Rollback |
| UAT Release | 對業務角色開放驗收 |
| Production Release | 正式上線與營運支援 |
| Hotfix Release | 緊急修復 |
| Model Release | 模型版本發布，不一定伴隨程式碼發布 |
| Data Contract Release | 資料契約或 Model-ready View 更新 |

### 2.2 Release 原則

- 程式碼、資料契約、模型與決策政策需分開版控。
- 高風險功能必須經 Feature Flag 控制。
- 不允許直接在 production 修改資料或模型狀態。
- 所有 release 必須有 rollback plan。
- 每個 release 必須對應 RTM、測試報告、UAT 或查核證據。
- 每個 release 需產生 release note。

---

## 3. 全案 WBS 結構

```text
WBS-00 Project Governance
WBS-01 Platform Foundation
WBS-02 Data Integration
WBS-03 External Data / GIS
WBS-04 Expansion Domain
WBS-05 Operations Domain
WBS-06 Intervention / Price / Ad Domain
WBS-07 Asset / Network Domain
WBS-08 Learning Hub / MLOps
WBS-09 OpsBoard Frontend
WBS-10 Security / Observability / Audit
WBS-11 QA / UAT / Acceptance
WBS-12 Production Operations
```

---

## 4. WBS-00 Project Governance

### 4.1 工作項目

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-00-01 | 文件基線建立 | SA / SD / QA / OPS 文件庫 |
| WBS-00-02 | 需求追蹤矩陣維護 | RTM |
| WBS-00-03 | ADR 流程建立 | ADR template / decision log |
| WBS-00-04 | Release governance | Release calendar / gate |
| WBS-00-05 | RACI 確認 | Owner table |
| WBS-00-06 | 補助查核證據架構 | Evidence matrix |

### 4.2 完成條件

- 72 份文件完成初版。
- 所有正式文件有 ID、version、owner。
- RTM 可追到模組、API、測試與驗收。
- Release / Change / ADR 流程可用。

---

## 5. WBS-01 Platform Foundation

### 5.1 工作項目

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-01-01 | Repository 初始化 | monorepo / package structure |
| WBS-01-02 | Backend skeleton | FastAPI / service modules |
| WBS-01-03 | Frontend skeleton | Next.js / OpsBoard shell |
| WBS-01-04 | Database baseline | Cloud SQL / PostGIS schema |
| WBS-01-05 | BigQuery datasets | raw / canonical / mart / model_ready |
| WBS-01-06 | Object storage layout | datasets / models / reports |
| WBS-01-07 | Pub/Sub topic baseline | event catalog |
| WBS-01-08 | Auth integration | OIDC / RBAC / ABAC |
| WBS-01-09 | Job framework | job table / worker / status API |
| WBS-01-10 | Audit framework | audit event schema |
| WBS-01-11 | CI/CD baseline | build / test / deploy |
| WBS-01-12 | Observability baseline | logs / metrics / traces |

### 5.2 完成條件

- Dev / Staging 可部署。
- App shell 可登入。
- API health check 可用。
- Job 狀態可查。
- Audit event 可寫入。
- 基礎監控可用。
- IaC 初版完成。

---

## 6. WBS-02 Data Integration

### 6.1 工作項目

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-02-01 | IoT / Internal Data Contract | schema / SLA / sample data |
| WBS-02-02 | Source landing zone | raw ingest bucket / dataset |
| WBS-02-03 | Canonical model schema | canonical tables |
| WBS-02-04 | Source-to-Canonical mapping | mapping rules |
| WBS-02-05 | Data quality rules | dbt / Great Expectations |
| WBS-02-06 | Data lineage | lineage metadata |
| WBS-02-07 | Backfill framework | backfill job / runbook |
| WBS-02-08 | Snapshot framework | dataset_snapshot |
| WBS-02-09 | Point-in-time checks | PIT validation tests |
| WBS-02-10 | Model-ready views | initial dbt models |

### 6.2 完成條件

- 內部資料可進 canonical 層。
- 缺漏、重複、時間錯誤可被偵測。
- Model-ready views 可重建。
- Snapshot 可追溯。
- Backfill 可重跑指定日期範圍。

---

## 7. WBS-03 External Data / GIS

### 7.1 工作項目

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-03-01 | 外部資料來源盤點 | source inventory |
| WBS-03-02 | POI connector | connector job |
| WBS-03-03 | Population / household connector | connector job |
| WBS-03-04 | Rent / listing connector | connector job |
| WBS-03-05 | Competitor / own store GIS | geospatial layer |
| WBS-03-06 | Address normalization | parser |
| WBS-03-07 | Geocode service | geocode worker |
| WBS-03-08 | H3 / administrative mapping | geo feature worker |
| WBS-03-09 | Service area / isochrone | GIS job |
| WBS-03-10 | Geo data quality | QA rules |

### 7.2 完成條件

- 外部資料有 source、snapshot_time、confidence。
- 地址可正規化與 geocode。
- H3 / 行政區 / 商圈對應可重建。
- GIS 特徵可供 HeatZone / SiteScore / NetPlan 使用。

---

## 8. WBS-04 Expansion Domain

### 8.1 HeatZone

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-04-01 | HeatZone score baseline | weighted score |
| WBS-04-02 | Demand model training | baseline model |
| WBS-04-03 | HeatZone batch scoring | scheduled job |
| WBS-04-04 | HeatZone API | map / rank / detail |
| WBS-04-05 | HeatZone map UI | HeatZone Map |
| WBS-04-06 | HeatZone state management | status workflow |

### 8.2 Listing

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-04-07 | Listing import | CSV / Excel import |
| WBS-04-08 | Listing parser | address / rent / area |
| WBS-04-09 | Listing geocode | geocode worker |
| WBS-04-10 | Listing dedup | duplicate groups |
| WBS-04-11 | Hard rule engine | feasibility precheck |
| WBS-04-12 | Listing inbox UI | listing management |

### 8.3 SiteScore

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-04-13 | Candidate site model | candidate_site entity |
| WBS-04-14 | SiteScore v1 model | revenue path baseline |
| WBS-04-15 | SiteScore report generator | report |
| WBS-04-16 | SiteScore decision workflow | GO / WAIT / REJECT |
| WBS-04-17 | SiteScore UI | report page |
| WBS-04-18 | SiteScore realization | outcome feedback |

### 8.4 完成條件

- HeatZone → Listing → Candidate Site → SiteScore → Approval E2E 通過。
- SiteScore 報告含 P10/P50/P90、回本期、租金、稀釋與 model version。
- 開店後 outcome 可回收。

---

## 9. WBS-05 Operations Domain

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-05-01 | Store time series view | store_machine_timeseries_view |
| WBS-05-02 | Forecast baseline | seasonal naive / MLForecast |
| WBS-05-03 | Forecast batch score | daily score job |
| WBS-05-04 | Forecast API | store forecast |
| WBS-05-05 | Trajectory classifier | growth / plateau / decline |
| WBS-05-06 | Change-point detector | ruptures / CUSUM / EWMA |
| WBS-05-07 | Four-light policy | green / yellow / orange / red |
| WBS-05-08 | Root cause evidence | evidence vector |
| WBS-05-09 | Alert engine | alert generation |
| WBS-05-10 | Operations UI | overview / alert center / store detail |
| WBS-05-11 | SiteScore gap | realization monitor |
| WBS-05-12 | Feedback loop | alert feedback |

### 完成條件

- 每店可看到 4/8/12/24 週 forecast。
- 四燈可產生與追蹤。
- Root cause evidence 可解釋。
- Alert 可導向 InterventionOps。

---

## 10. WBS-06 Intervention / Price / Ad Domain

### 10.1 InterventionOps

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-06-01 | Intervention entity | schema |
| WBS-06-02 | Eligibility | worker / rules |
| WBS-06-03 | Action builder | action set |
| WBS-06-04 | Conflict check | overlap detection |
| WBS-06-05 | Approval workflow | approval state |
| WBS-06-06 | Execution tracking | execution status |
| WBS-06-07 | Observation window | outcome maturity |
| WBS-06-08 | Effect evaluation | effect report |

### 10.2 PriceOps

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-06-09 | Pricing candidate | candidate generation |
| WBS-06-10 | Elasticity estimation | model |
| WBS-06-11 | Demand simulation | simulator |
| WBS-06-12 | Pricing optimizer | OR-Tools |
| WBS-06-13 | Price plan workflow | approval / rollback |
| WBS-06-14 | Price UI | simulation / approval |

### 10.3 AdLift

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-06-15 | Ad need score | scoring |
| WBS-06-16 | Campaign workflow | campaign entity |
| WBS-06-17 | Control matching | matched controls |
| WBS-06-18 | Pre-trend test | validation |
| WBS-06-19 | DiD / lift report | incrementality |
| WBS-06-20 | AdLift UI | report / iROMI |

### 完成條件

- Alert → Intervention → Execution → Observation → Outcome 通過。
- PriceOps hard constraints 零違反。
- AdLift evidence level 正確。
- 不足以推論因果時不宣稱因果。

---

## 11. WBS-07 Asset / Network Domain

### 11.1 DealRoomAVM

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-07-01 | Valuation view | valuation_view |
| WBS-07-02 | Normalized GM | worker |
| WBS-07-03 | Income approach | valuation worker |
| WBS-07-04 | Asset approach | asset worker |
| WBS-07-05 | Market comparable | comparable search |
| WBS-07-06 | Valuation interval | P10/P50/P90 |
| WBS-07-07 | Data room | checklist / storage |
| WBS-07-08 | Finance approval | approval workflow |

### 11.2 NetPlan

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-07-09 | Network plan view | network_plan_view |
| WBS-07-10 | Scenario builder | scenario UI/API |
| WBS-07-11 | Constraint editor | budget/lease/etc |
| WBS-07-12 | CP-SAT model | solver |
| WBS-07-13 | Alternative plans | compare |
| WBS-07-14 | Infeasibility diagnosis | diagnosis |
| WBS-07-15 | Quarterly timeline | Gantt |
| WBS-07-16 | Outcome tracking | 90/180/365 |

### 完成條件

- AVM 可產出估值卡。
- Fair / Reserve / Asking 分離。
- NetPlan solver 可產出方案或 infeasibility diagnosis。
- 所有方案需管理層核准。

---

## 12. WBS-08 Learning Hub / MLOps

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-08-01 | Feature registry | registry |
| WBS-08-02 | Label registry | registry |
| WBS-08-03 | Dataset snapshot | snapshot system |
| WBS-08-04 | MLflow integration | tracking |
| WBS-08-05 | Model registry | model metadata |
| WBS-08-06 | Model card generator | model card |
| WBS-08-07 | Backtest service | reports |
| WBS-08-08 | Drift monitor | monitoring |
| WBS-08-09 | Release controller | shadow/canary/prod |
| WBS-08-10 | Rollback controller | rollback |
| WBS-08-11 | Learning UI | screens |
| WBS-08-12 | Governance audit | logs |

### 完成條件

- Production model 皆有 model card。
- Release / rollback 可演練。
- Data quality gate 可阻擋模型。
- Model version 可追溯至 prediction / decision。

---

## 13. WBS-09 OpsBoard Frontend

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-09-01 | App shell | header/sidebar |
| WBS-09-02 | Design system | components |
| WBS-09-03 | Task center | task UI |
| WBS-09-04 | Notification center | notification UI |
| WBS-09-05 | Global search | search |
| WBS-09-06 | Expansion screens | HeatZone/Listing/SiteScore |
| WBS-09-07 | Operations screens | Forecast/Four-light |
| WBS-09-08 | Intervention screens | workflow |
| WBS-09-09 | Pricing / Ad screens | PriceOps/AdLift |
| WBS-09-10 | AVM / NetPlan screens | asset/network |
| WBS-09-11 | Learning screens | model/data governance |
| WBS-09-12 | Audit screens | decision log |
| WBS-09-13 | Franchisee portal | self store |
| WBS-09-14 | Admin screens | users/roles/flags |

### 完成條件

- 角色可找到各自任務。
- 高風險操作具核准與稽核。
- 地圖、表格、圖表可用。
- 前端不可繞過後端權限。

---

## 14. WBS-10 Security / Observability / Audit

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-10-01 | IAM / service account | least privilege |
| WBS-10-02 | RBAC / ABAC | policy |
| WBS-10-03 | Secret management | Secret Manager |
| WBS-10-04 | Cloud Armor / WAF | policy |
| WBS-10-05 | Logging | structured logs |
| WBS-10-06 | Metrics | dashboards |
| WBS-10-07 | Tracing | distributed traces |
| WBS-10-08 | Alerting | alert rules |
| WBS-10-09 | Audit store | immutable logs |
| WBS-10-10 | Export governance | sensitive export policy |
| WBS-10-11 | Backup / DR | runbook |
| WBS-10-12 | Security testing | reports |

---

## 15. WBS-11 QA / UAT / Acceptance

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-11-01 | Test master plan | QA-01 |
| WBS-11-02 | Test data | fixtures / golden dataset |
| WBS-11-03 | Unit / component tests | test suite |
| WBS-11-04 | Contract tests | schema tests |
| WBS-11-05 | Integration tests | service tests |
| WBS-11-06 | E2E tests | Playwright |
| WBS-11-07 | Data tests | dbt / GE |
| WBS-11-08 | Model tests | validation |
| WBS-11-09 | Performance tests | k6 / locust |
| WBS-11-10 | Security tests | scan / pen test |
| WBS-11-11 | UAT | sign-off |
| WBS-11-12 | Subsidy evidence | evidence package |

---

## 16. WBS-12 Production Operations

| WBS ID | 工作項目 | 交付物 |
|---|---|---|
| WBS-12-01 | Deployment runbook | OPS-03 |
| WBS-12-02 | Migration / backfill runbook | OPS-02 |
| WBS-12-03 | Service runbook | OPS-04 |
| WBS-12-04 | Incident process | OPS-05 |
| WBS-12-05 | Backup restore process | OPS-05 |
| WBS-12-06 | Model release process | OPS-06 |
| WBS-12-07 | Admin manual | OPS-07 |
| WBS-12-08 | User manual | OPS-08 |
| WBS-12-09 | On-call setup | rotation |
| WBS-12-10 | Post-release review | report |

---

## 17. Release Roadmap

## 17.1 R0 - Foundation Release

### 範圍

- Repo。
- CI/CD。
- Dev / Staging。
- Auth。
- DB baseline。
- Job framework。
- Audit framework。
- OpsBoard shell。
- Data landing zone。

### Gate

- Smoke test。
- Auth test。
- API health。
- Deployment rollback。
- Audit write test。

---

## 17.2 R1 - Data and GIS Release

### 範圍

- Internal data contract。
- External connectors。
- Canonical tables。
- Model-ready views v1。
- Geocode。
- H3 / GIS features。
- Data quality gate。

### Gate

- Data contract test。
- Source-to-canonical test。
- Data freshness test。
- Backfill test。
- PIT test。

---

## 17.3 R2 - Expansion Release

### 範圍

- HeatZone。
- Listing。
- Candidate Site。
- SiteScore。
- Opening decision。
- SiteScore realization v1。

### Gate

- E2E-EXP-001 / 002。
- SiteScore report validation。
- Permission test。
- Audit export。

---

## 17.4 R3 - Operations Release

### 範圍

- ForecastOps。
- Four-light。
- Root cause。
- Store detail。
- Alert center。
- SiteScore gap。

### Gate

- E2E-OPS-001 / 002。
- Forecast model validation。
- Alert precision/recall baseline。
- Alert load review。

---

## 17.5 R4 - Intervention / Price / Ad Release

### 範圍

- InterventionOps。
- PriceOps。
- AdLift。
- Observation / outcome。
- Effect evaluation。

### Gate

- E2E-INT-001。
- E2E-PRICE-001。
- E2E-AD-001。
- Hard constraints。
- Evidence level review。

---

## 17.6 R5 - Asset / Network Release

### 範圍

- DealRoomAVM。
- Data Room。
- NetPlan。
- Solver。
- Alternative plans。
- Outcome tracking。

### Gate

- E2E-AVM-001。
- E2E-NET-001。
- Solver constraints。
- Finance / management UAT。

---

## 17.7 R6 - Learning / Governance Release

### 範圍

- Feature / Label Registry。
- Dataset Snapshot。
- Model Registry。
- Model Card。
- Backtest。
- Drift。
- Release / Rollback。
- Audit evidence export。

### Gate

- E2E-LEARN-001 / 002。
- Model release drill。
- Rollback drill。
- Data quality blocking。
- Audit completeness。

---

## 17.8 R7 - UAT / Production Readiness Release

### 範圍

- All role UAT。
- Performance test。
- Security test。
- DR drill。
- Subsidy evidence package。
- Training material。
- User manual。
- Runbook。

### Gate

- UAT sign-off。
- No P0/P1 defects。
- Security gate。
- DR gate。
- SLA monitoring。
- Production go/no-go。

---

## 18. Release Gate Checklist

```yaml
release_id:
release_type:
scope:
code_tag:
api_version:
db_migration_version:
dbt_version:
model_versions:
feature_flags:
test_report:
security_report:
data_quality_report:
rollback_plan:
uat_required:
business_owner_approval:
ops_owner_approval:
go_no_go_decision:
```

---

## 19. 缺陷與變更控制

### 19.1 Release Blocker

以下一律阻擋 release：

- 權限繞過。
- 高風險決策無 audit。
- 模型版本不可追溯。
- Data quality gate 失效。
- Hard constraints 可被繞過。
- Rollback 不可用。
- Production migration 無回滾策略。
- P0/P1 缺陷未關閉。

### 19.2 Change Freeze

正式上線前設定 freeze：

- T-5：功能 freeze。
- T-3：schema freeze。
- T-2：model freeze。
- T-1：只允許 P0/P1 hotfix。
- T：go/no-go。

---

## 20. 驗收條件

本文件完成後需滿足：

- WBS 覆蓋所有 12 個工作群。
- Release roadmap 覆蓋完整平台。
- 每個 release 有 scope 與 gate。
- 完整區分 code / data / model / policy release。
- 上線前有 UAT、資安、效能、DR、查核證據 gate。
