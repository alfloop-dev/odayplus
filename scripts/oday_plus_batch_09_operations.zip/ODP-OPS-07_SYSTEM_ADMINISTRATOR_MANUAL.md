---
id: ODP-OPS-07
title: 系統管理員手冊
batch: 9
category: Operations
doc_type: operations
version: 1.0.0
status: draft
formal_deliverable: true
owner: System Administrator / SRE / Security Owner
updated_at: 2026-06-26
depends_on:
  - ODP-SA-04_USERS_ROLES_AND_ACCESS_REQUIREMENTS
  - ODP-SD-09_IDENTITY_SECURITY_AND_PRIVACY_DESIGN
  - ODP-UX-03_SCREEN_AND_INTERACTION_SPECIFICATION
  - ODP-OPS-03_DEPLOYMENT_AND_ENVIRONMENT_SETUP_MANUAL
  - ODP-OPS-04_RUNBOOK
---

# ODP-OPS-07 系統管理員手冊

## 1. 文件目的

本文件提供 ODay Plus 系統管理員執行帳號、角色、權限、Feature Flag、資料來源、Job、模型狀態、系統健康、稽核匯出與日常管理的操作指引。

---

## 2. 管理員角色

| Role | 權限範圍 |
|---|---|
| System Admin | 使用者、角色、系統設定 |
| Security Admin | 權限、敏感資料、資安設定 |
| Data Admin | 資料來源、Data Quality、Backfill |
| MLOps Admin | 模型版本、發布、回滾 |
| Ops Admin | Job、Workflow、Runbook、通知 |
| Audit Admin | Audit 查詢、證據匯出 |
| Support Admin | 使用者支援、任務協助 |
| Super Admin | break-glass，受嚴格 audit |

---

## 3. 登入與管理入口

管理入口：

```text
/admin
/admin/users
/admin/roles
/admin/permissions
/admin/scopes
/admin/feature-flags
/admin/data-sources
/admin/jobs
/admin/system-health
/admin/audit
/admin/support
```

所有 admin 操作必須：

- 驗證身分。
- 檢查權限。
- 寫入 Audit。
- 高風險操作需二次確認。
- Break-glass 操作需事後審查。

---

## 4. 使用者管理

### 4.1 建立使用者

必要欄位：

```yaml
user_id:
name:
email:
department:
role:
status:
region_scope:
store_scope:
brand_scope:
effective_from:
effective_to:
```

### 4.2 使用者狀態

```text
INVITED
ACTIVE
SUSPENDED
DISABLED
LOCKED
DELETED
```

### 4.3 常見操作

| 操作 | 注意 |
|---|---|
| Invite user | 驗證 email domain |
| Disable user | 保留 audit，不刪歷史 actor |
| Reset MFA | 需 identity verification |
| Unlock user | 記錄 reason |
| Change role | 需 approval for privileged role |
| Change scope | 需 owner approval |

---

## 5. 角色與權限管理

### 5.1 標準角色

```text
executive
expansion_user
site_reviewer
ops_manager
field_supervisor
marketing_user
pricing_user
finance_user
legal_user
data_scientist
mlops_user
franchisee_user
audit_user
system_admin
readonly_user
```

### 5.2 權限命名

```text
{module}.{resource}.{action}
```

範例：

```text
sitescore.report.read
sitescore.decision.approve
price.plan.approve
model.release.rollback
audit.evidence.export
admin.user.update
```

### 5.3 Scope

Scope 可包含：

```text
tenant
brand
region
store
module
data_classification
```

### 5.4 高風險權限

以下權限需額外核准：

- price.plan.approve。
- netplan.scenario.approve。
- avm.reserve_price.approve。
- model.release.promote。
- model.release.rollback。
- audit.evidence.export_sensitive。
- admin.role.assign_privileged。
- data.backfill.production_execute。

---

## 6. Feature Flag 管理

### 6.1 Flag 類型

```text
module_flag
screen_flag
action_flag
model_flag
advanced_feature_flag
canary_flag
```

### 6.2 操作

- 建立 flag。
- 啟用 flag。
- 停用 flag。
- 設定 role / region / store rollout。
- 查看 flag history。

### 6.3 高風險 Flag

停用以下 flag 可能影響核心流程：

```text
feature.sitescore.enabled
feature.forecastops.enabled
feature.audit.enabled
feature.auth.enforce_rbac
feature.priceops.execution.enabled
feature.model.release.enabled
```

`feature.audit.enabled` 不應由一般管理員關閉。

---

## 7. 資料來源管理

### 7.1 Data Source Registry

欄位：

```yaml
source_id:
source_name:
source_type:
owner:
frequency:
last_observed_at:
last_ingested_at:
freshness_sla:
quality_status:
confidence:
status:
```

### 7.2 操作

- 查看來源狀態。
- 觸發 ingestion。
- 暫停 ingestion。
- 重新驗證。
- 查看 quality report。
- 建立資料問題 ticket。

### 7.3 禁止

- 不得直接在 UI 修改 production raw data。
- 不得忽略 failed QA 並強制模型運行，除非治理核准。
- 不得刪除資料品質失敗紀錄。

---

## 8. Job 管理

### 8.1 Job Console

欄位：

```text
job_id
job_type
status
submitted_by
submitted_at
started_at
finished_at
retry_count
correlation_id
```

### 8.2 操作

| 操作 | 條件 |
|---|---|
| Retry | retryable failure |
| Cancel | running / queued |
| View logs | allowed |
| Download failed rows | data permission |
| Requeue DLQ | admin approval |
| Trigger manual job | role permission |

### 8.3 高風險 Job

- Production backfill。
- Model training。
- Model release。
- Price execution。
- NetPlan solver。
- Audit export。
- Data deletion / retention。

---

## 9. 模型管理

### 9.1 Model Console

欄位：

```text
model_id
version
stage
owner
created_at
metrics
data_quality_status
drift_status
release_status
rollback_target
```

### 9.2 操作

- 查看 model card。
- 查看 metrics。
- 建立 release request。
- Approve shadow。
- Approve canary。
- Promote production。
- Rollback。
- Deprecate。

### 9.3 注意

- 管理員不得跳過 Model Review。
- Production alias 變更需 audit。
- Rollback 需 reason。
- 模型發布不等於業務決策變更。

---

## 10. 系統健康管理

### 10.1 Health Dashboard

監控：

- API status。
- Frontend status。
- Cloud Run revisions。
- Job queue。
- Pub/Sub backlog。
- Cloud SQL。
- BigQuery jobs。
- Data freshness。
- Model endpoint。
- Audit write。
- Backup status。

### 10.2 每日檢查

- [ ] API error rate 正常。
- [ ] Job failure 無異常。
- [ ] Data freshness 正常。
- [ ] Data quality gate 正常。
- [ ] Audit write 正常。
- [ ] Backup success。
- [ ] Model endpoint 正常。
- [ ] Security alert 無未處理。

---

## 11. Audit 管理

### 11.1 查詢

可依：

- actor。
- module。
- entity。
- decision_type。
- time range。
- model_version。
- override only。
- export only。

### 11.2 匯出

高敏感匯出需：

- 權限。
- reason。
- approval。
- watermark。
- expiration。
- export audit。

### 11.3 不可操作

- 不可刪除 audit。
- 不可修改 actor。
- 不可修改 timestamp。
- 不可覆蓋 old audit。
- 補登 audit 需標示 recovered。

---

## 12. 支援管理

### 12.1 Support Ticket

欄位：

```yaml
ticket_id:
requester:
module:
severity:
description:
related_entity:
screenshot:
correlation_id:
assigned_to:
status:
```

### 12.2 支援操作

- 代查狀態。
- 重新指派 task。
- 協助匯出非敏感報表。
- 建立 incident。
- 連結 runbook。

不得代使用者核准高風險決策。

---

## 13. Break-glass

### 13.1 適用

- Production outage。
- 權限系統故障。
- 資安事件。
- DR restore。
- 補救資料污染。

### 13.2 流程

1. Incident Commander 核准。
2. 啟用 temporary privileged access。
3. 設定 expiration。
4. 執行操作。
5. 完整 audit。
6. 事後 review。
7. 關閉權限。

### 13.3 事後檢查

- 操作清單。
- 資料影響。
- 權限是否回收。
- Audit 是否完整。
- 是否需 postmortem。

---

## 14. Admin 操作稽核

所有管理員操作需寫入：

```text
admin_action_id
actor
role
action
target
before
after
reason
timestamp
ip
correlation_id
approval_id
```

---

## 15. 驗收條件

本手冊完成後需滿足：

- 管理員能依手冊管理使用者、權限、資料來源、Job、模型與 Audit。
- 高風險操作有權限與核准要求。
- Break-glass 有嚴格流程。
- 管理員不得破壞歷史決策與 Audit。
