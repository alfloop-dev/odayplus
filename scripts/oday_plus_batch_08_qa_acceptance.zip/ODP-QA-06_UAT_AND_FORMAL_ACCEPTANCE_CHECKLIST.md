---
id: ODP-QA-06
title: UAT 與正式驗收清單
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-06 UAT 與正式驗收清單

## 1. 文件目的

本文件定義 ODay Plus 使用者驗收測試（UAT）與正式驗收簽核清單。UAT 目的不是重跑所有技術測試，而是確認真實業務角色能完成工作任務、理解系統建議、執行核准、追蹤結果、查到證據。

## 2. UAT 原則

UAT 以角色驗收，不以功能清單驗收；以決策閉環驗收，不以單頁面驗收。每個角色需確認「看得到、看得懂、做得到、追得到、驗得到、回得去」。高風險流程需正式簽核：SiteScore GO、PriceOps 調價、AdLift 大額投放、AVM reserve price、NetPlan EXIT/MOVE、Model production release、資料品質 override、權限變更、敏感資料匯出。

## 3. UAT 準備

前置條件：Staging 部署完成、UAT 測試資料完成、帳號與權限完成、feature flag 開啟、UAT 腳本發佈、known issues 清單完成、回報管道建立、截圖錄影策略確認、補助查核證據保存位置確認。

UAT 測試資料至少包含：3 個 HeatZone、20 筆 Listing、10 筆 Candidate Site、5 份 SiteScore Report、10 家 Store、3 筆 Red Alert、3 筆 Intervention、2 筆 Price Plan、2 筆 Ad Campaign、2 份 AVM Report、2 個 NetPlan Scenario、3 個 Model Version、20 筆 Decision Log。

## 4. 角色 UAT 清單

### 4.1 展店業務

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-EXP-001 | 查看 HeatZone Map | 可理解熱區分數與排名 |
| UAT-EXP-002 | 指派熱區任務 | Task Center 正確產生任務 |
| UAT-EXP-003 | 匯入 Listing | 可解析、顯示錯誤列 |
| UAT-EXP-004 | 轉候選物件 | Candidate Site 正確建立 |
| UAT-EXP-005 | 安排現勘 | 任務與狀態可追蹤 |

### 4.2 展店審查

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-SITE-001 | 閱讀 SiteScore Report | 可理解 P10/P50/P90、回本期、風險 |
| UAT-SITE-002 | 核准 GO | Decision Log 完整 |
| UAT-SITE-003 | 退回補件 | 報告狀態正確 |
| UAT-SITE-004 | Override 系統建議 | 必填原因並留痕 |
| UAT-SITE-005 | 匯出評估報告 | 權限與 Audit 正確 |

### 4.3 營運主管

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-OPS-001 | 查看 Operations Overview | 四燈分布與重點風險清楚 |
| UAT-OPS-002 | 打開紅燈門市 | Forecast 與 Evidence 可理解 |
| UAT-OPS-003 | 指派警示 | owner 與 SLA 正確 |
| UAT-OPS-004 | 建立干預 | intervention proposal 正確 |
| UAT-OPS-005 | 檢視 SiteScore Realization | 預測與實績差距清楚 |

### 4.4 區域督導

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-FIELD-001 | 查看本人任務 | 任務清單符合 scope |
| UAT-FIELD-002 | 執行處置單 | 狀態可更新 |
| UAT-FIELD-003 | 上傳回報 | 附件與備註可保存 |
| UAT-FIELD-004 | 查看觀察窗 | 知道何時結果成熟 |
| UAT-FIELD-005 | 關閉任務 | 必要欄位完成 |

### 4.5 行銷團隊

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-AD-001 | 查看 Ad Need Score | 可判斷投放優先順序 |
| UAT-AD-002 | 建立 campaign | Treatment stores 正確 |
| UAT-AD-003 | 檢視 control matching | 對照組可解釋 |
| UAT-AD-004 | 檢視 lift report | iROMI 與 evidence level 清楚 |
| UAT-AD-005 | Continue / Stop | 決策留痕完整 |

### 4.6 定價團隊

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-PRICE-001 | 查看定價候選 | 候選店與設備清楚 |
| UAT-PRICE-002 | 檢視需求模擬 | demand / GM 變化可理解 |
| UAT-PRICE-003 | 檢查 hard constraints | 違反時不可核准 |
| UAT-PRICE-004 | 核准調價 | 核准留痕完整 |
| UAT-PRICE-005 | Rollback | 回滾流程可執行 |

### 4.7 財務／法務

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-AVM-001 | 建立估值請求 | 資料需求清楚 |
| UAT-AVM-002 | 檢視估值卡 | Fair/Reserve/Asking 分離 |
| UAT-AVM-003 | 補齊 Data Room | 文件狀態可管理 |
| UAT-AVM-004 | 財務核准 | reason 與 approval chain 完整 |
| UAT-AVM-005 | 匯出估值卡 | 匯出受權限與 Audit 控制 |

### 4.8 管理層

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-NET-001 | 查看 Executive Overview | 店網風險與資本配置清楚 |
| UAT-NET-002 | 建立 NetPlan 情境 | 限制與目標可設定 |
| UAT-NET-003 | 檢視 Solver Result | OPEN/KEEP/IMPROVE/MOVE/EXIT 清楚 |
| UAT-NET-004 | 比較 Alternative Plans | 差異可理解 |
| UAT-NET-005 | 核准 NetPlan | 核准與 outcome tracking 建立 |

### 4.9 AI／資料團隊

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-ML-001 | 查看 Data Quality Center | 可判斷資料失敗來源 |
| UAT-ML-002 | 查看 Feature Registry | feature lineage 清楚 |
| UAT-ML-003 | 查看 Model Card | 指標與限制清楚 |
| UAT-ML-004 | Shadow / Canary | 流程可執行 |
| UAT-ML-005 | Rollback | 可切回前一版本 |

### 4.10 加盟主

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-FRAN-001 | 登入自店入口 | 只看到自店資料 |
| UAT-FRAN-002 | 查看營運狀態 | 文案可理解 |
| UAT-FRAN-003 | 查看建議處置 | 下一步清楚 |
| UAT-FRAN-004 | 回報執行結果 | 回報成功且通知督導 |
| UAT-FRAN-005 | 查看觀察結果 | 不暴露敏感模型參數 |

### 4.11 稽核人員

| ID | 任務 | 通過條件 |
|---|---|---|
| UAT-AUDIT-001 | 搜尋 Decision Log | 可依模組、角色、時間查詢 |
| UAT-AUDIT-002 | 開啟決策明細 | 預測、建議、核准、執行、結果分離 |
| UAT-AUDIT-003 | 匯出證據包 | 包含完整 metadata |
| UAT-AUDIT-004 | 查模型版本 | 可追溯 model version |
| UAT-AUDIT-005 | 查權限變更 | 可追溯 actor 與 reason |

## 5. 正式驗收 Checklist

### 5.1 功能驗收

HeatZone、Listing、SiteScore、ForecastOps、InterventionOps、PriceOps、AdLift、DealRoomAVM、NetPlan、Learning Hub、OpsBoard、Audit 均需通過。

### 5.2 資料驗收

IoT/內部資料契約、External connector、Canonical data model、Source-to-canonical mapping、Model-ready views、Data quality gate、Point-in-time correctness、Lineage 均需通過。

### 5.3 模型與決策驗收

Model card、Backtest、Calibration、Baseline comparison、Decision policy、Hard constraints、Human approval、Rollback 均需通過。

### 5.4 非功能驗收

API P95、Batch window、Security test、Privacy test、Permission test、Backup restore、DR drill、Observability、SLA monitoring 均需通過。

### 5.5 查核驗收

計畫功能證據、技術指標證據、驗證指標證據、操作截圖、測試報告、UAT 簽核、Audit evidence export、補助查核矩陣均需完成。

## 6. UAT Defect 判定

決策無法完成、高風險操作無 Audit、權限錯誤、模型版本不可追溯、資料錯誤會阻擋驗收。文案不清、UI 小瑕疵、報表格式微調可附條件驗收，但需列入修正清單。

## 7. Sign-off 格式

```yaml
uat_session_id:
module:
role:
tester_name:
tester_department:
date:
environment:
build_version:
data_snapshot:
test_cases:
  - id:
    result:
    defects:
decision:
  accepted: true / false
  accepted_with_conditions: true / false
conditions:
sign_off_by:
signature_date:
```

## 8. 驗收條件

所有角色 UAT 腳本完成；P0/P1 UAT 缺陷為 0；高風險流程具正式簽核；正式驗收 checklist 完成；UAT sign-off 保存；補助查核證據可從 UAT 結果連回。
