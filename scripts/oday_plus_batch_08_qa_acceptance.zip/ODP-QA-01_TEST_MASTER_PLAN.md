---
id: ODP-QA-01
title: 測試總體計畫
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-01 測試總體計畫

## 1. 文件目的

本文件定義 ODay Plus 全平台的測試策略、測試範圍、測試層級、責任分工、測試環境、測試資料、缺陷管理、進出準則、Release Gate 與正式驗收交付物。ODay Plus 是一套涵蓋展店、營運、干預、估值、店網規劃、模型治理與稽核的決策平台，因此測試不能只驗證畫面按鈕可用，還必須驗證資料語意、模型版本、人工核准、決策留痕、回訓閉環、權限、備援與補助查核證據。

## 2. 測試目標

### 2.1 產品正確性

確認各角色能完成自己的工作任務：展店業務可從 HeatZone 找區並管理 Listing；展店審查可核准 SiteScore；營運主管可處理四燈警示；區域督導可執行處置；行銷與定價團隊可驗證 AdLift 與 PriceOps；財務法務可完成 AVM 與 Data Room；管理層可審查 NetPlan；AI／資料團隊可治理模型；稽核人員可追溯全流程。

### 2.2 資料正確性

確認 IoT／內部資料、外部資料、Canonical Data Model 與 Model-ready Views 的欄位、主鍵、時間語意、來源、版本、血緣與資料品質皆符合契約。任何模型訓練或推論不得使用 decision_time 之後才可得知的資料。

### 2.3 模型與決策可靠性

確認模型輸出、系統建議、人工核准、實際執行與結果回收在資料與畫面上分離。模型準確不代表決策正確，因此必須同時驗證 baseline、holdout、calibration、segment performance、hard constraints、人工核准與 rollback。

### 2.4 查核可舉證

所有計畫承諾必須可由系統證據支持：截圖、操作影片、API response、Job log、模型驗證報告、Data quality report、Audit export、UAT sign-off、Cloud monitoring report、DR report、Security report。

## 3. 測試範圍

| 模組 | QA 覆蓋重點 |
|---|---|
| Integration Layer / External Data Platform | 來源契約、mapping、canonical model、資料品質、backfill、lineage |
| HeatZone Radar | 熱區分數、優先排序、H3 圖層、信心分數、熱區狀態 |
| Listing Pipeline | 匯入、地址解析、geocode、去重、hard rule、人工審查 |
| SiteScore | M1/M3/M6/M12、P10/P50/P90、回本期、GO/WAIT/REJECT、人工核准 |
| ForecastOps | 4/8/12/24 週預測、四燈、轉折、根因證據、SiteScore realization |
| InterventionOps | Eligibility、Action Set、Conflict、Approval、Execution、Observation、Outcome |
| PriceOps | 價格彈性、需求模擬、hard constraints、人工核准、rollback |
| AdLift | Treatment、Control、Pre-trend、Incremental GM、iROMI、Evidence Level |
| DealRoomAVM | Normalized GM、估值區間、Data Room、Reserve Price、財務核准 |
| NetPlan | Scenario、OPEN/KEEP/IMPROVE/MOVE/EXIT、solver、替代方案、無可行解診斷 |
| Learning Hub | Feature/Label/Dataset/Model Registry、Backtest、Drift、Release、Rollback |
| OpsBoard | 任務、通知、審核、稽核、權限、報表與證據匯出 |

## 4. 測試層級

| 層級 | 目的 | 必測範圍 |
|---|---|---|
| Unit Test | 驗證最小邏輯單元 | mapping、business rules、permission helper、feature calculation、solver constraint |
| Component Test | 驗證可組合元件 | API service、job handler、event consumer、前端 card/table/map/chart/form |
| Contract Test | 驗證跨模組契約 | OpenAPI、AsyncAPI、Data Contract、Event Schema、Model Input/Output |
| Integration Test | 驗證多元件串接 | Listing→Candidate、SiteScore job、Forecast→Alert、Alert→Intervention |
| E2E Test | 驗證完整業務閉環 | 展店、營運、調價、廣告、估值、NetPlan、模型發布、稽核 |
| Data Test | 驗證資料品質 | dbt tests、Great Expectations、freshness、lineage、PIT correctness |
| Model Test | 驗證模型可上線 | baseline、holdout、backtest、calibration、drift、rollback |
| Solver Test | 驗證最佳化安全 | constraints、feasibility、infeasibility diagnosis、runtime |
| Security Test | 驗證資安與權限 | RBAC/ABAC、OWASP、export、audit、dependency、secret scan |
| Performance Test | 驗證非功能 | API P95、Batch window、map render、solver runtime、BigQuery latency |
| UAT | 驗證業務可用 | 各角色腳本、正式簽核、補助查核證據 |

## 5. 測試責任

| 角色 | 責任 |
|---|---|
| Product Owner | 驗收標準、UAT 範圍、功能優先級 |
| QA Lead | 測試計畫、缺陷治理、測試報告、Release Gate |
| Backend Engineer | Unit、API、Integration、Contract Test |
| Frontend Engineer | Component、E2E、Accessibility、Visual Regression |
| Data Engineer | Data Quality、dbt、Lineage、Backfill Test |
| ML Engineer | Model Validation、Model Card、Backtest、Drift Test |
| OR Engineer | Solver、Constraint、Scenario Regression |
| DevOps/SRE | CI/CD、Performance、DR、Observability |
| Security Owner | Auth、Permission、Privacy、Pen Test |
| Business Owner | UAT Sign-off、營運驗收 |
| Audit Owner | Evidence Matrix、Audit Export 驗收 |

## 6. 測試環境

| Environment | 用途 | 資料策略 |
|---|---|---|
| Local | 開發者自測 | synthetic seed、mock service |
| Dev | 功能早期驗證 | synthetic + fixtures |
| Integration | 跨模組整合 | deterministic integration dataset |
| Staging | UAT、release validation | masked production-like + frozen snapshots |
| Production | smoke、canary、monitoring | real data，僅 synthetic probe |
| Sandbox | Demo、教育訓練 | synthetic / anonymized |

## 7. 缺陷管理

| Severity | 定義 | 範例 |
|---|---|---|
| S0 Blocker | 阻斷測試或重大資安／資料風險 | 權限繞過、資料污染、核准失效 |
| S1 Critical | 核心流程不可用 | SiteScore 無法產生、紅燈無法處理 |
| S2 Major | 重要功能異常但有 workaround | 去重失準、報表匯出失敗 |
| S3 Minor | 局部錯誤 | 次要 filter 錯誤、文案不清 |
| S4 Trivial | 不影響操作 | icon、間距、非關鍵文案 |

缺陷記錄必須包含 module、environment、steps、expected、actual、evidence、correlation_id、data_snapshot、model_version、root_cause、fix_version、regression_test。

## 8. 進出準則

### 8.1 測試開始準則

需求、API contract、data contract、event contract、測試環境、測試帳號、測試資料、feature flag 與 smoke deployment 均已就緒。

### 8.2 測試完成準則

P0/P1 defect 為 0，critical E2E 通過，Data Gate、Model Gate、Security Gate、Performance Gate、UAT Gate、Audit Gate 皆通過，並產出測試報告與簽核紀錄。

## 9. Release Gate

| Gate | 通過條件 |
|---|---|
| Code Gate | lint、typecheck、unit、component test 通過 |
| API Gate | OpenAPI contract 無 breaking change |
| Data Gate | dbt/Great Expectations/freshness/lineage 通過 |
| Model Gate | baseline、holdout、calibration、model card 通過 |
| Security Gate | 無未處理 critical/high finding |
| E2E Gate | P0 flow 通過 |
| UAT Gate | 相關 Business Owner 簽核 |
| Ops Gate | runbook、monitoring、rollback、on-call 就緒 |
| Audit Gate | 高風險操作 100% 留痕，可匯出證據 |

## 10. 測試交付物

每次正式 release 至少產出：Test Plan、Test Cases、Test Execution Report、Defect Summary、E2E Evidence、Data Quality Report、Model Validation Report、Security Test Report、Performance Test Report、UAT Sign-off、Audit Evidence Package、Release Readiness Checklist。

## 11. 驗收條件

本文件完成後，必須能指導全平台 QA；覆蓋功能、資料、模型、決策、資安、效能、UAT 與補助查核；並明確定義責任、環境、缺陷、Release Gate 與交付物。
