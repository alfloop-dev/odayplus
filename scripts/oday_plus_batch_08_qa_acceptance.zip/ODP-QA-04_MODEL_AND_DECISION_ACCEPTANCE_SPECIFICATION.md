---
id: ODP-QA-04
title: 模型與決策驗收規格
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-04 模型與決策驗收規格

## 1. 文件目的

本文件定義 ODay Plus 模型、因果估計、最佳化與決策政策的驗收標準。核心原則：模型準確不等於決策正確；模型輸出不等於系統建議；系統建議不等於最終人工決策。

## 2. 驗收層級

| 層級 | 目的 | 阻擋條件 |
|---|---|---|
| Data Readiness | 資料可用、可追溯、無洩漏 | schema fail、freshness fail、PIT fail |
| Model Validity | 模型優於 baseline 且校準 | holdout 不佳、segment 重大退化 |
| Decision Safety | 決策符合 hard constraints | 高風險無核准、限制違反 |
| Business Outcome | 線上產生業務價值 | 無採用、無改善、負面影響未處理 |

## 3. 共用模型驗收標準

每個 production model 必須具備 Model Specification、Training Dataset Snapshot、Feature List、Label Definition、Evaluation Report、Segment Performance、Calibration Report、Model Card、Risk Assessment、Release Approval、Rollback Target、Monitoring Plan。

每個模型必須與 baseline 比較。Segment evaluation 至少依 region、store_age、location_type、brand、format、machine_mix、rent_level、data_confidence、new_store_vs_mature_store 檢查。區間預測必須檢查 P80/P90 coverage。

## 4. HeatZone 驗收

### 輸出

heat_zone_score、priority_rank、unmet_demand_score、format_fit_score、cannibalization_risk、rent_feasibility、confidence、status。

### 指標

| 指標 | 目標 |
|---|---|
| 排名優於人口排序 baseline | 必須 |
| Top-K business review pass rate | 達業務門檻 |
| High confidence > low confidence | 應成立 |
| Explanation completeness | Top-K 100% 有主要因子 |
| Data coverage | 不足時降 confidence |

### 決策安全

HeatZone 不可直接給 GO 開店；SATURATED 不建議新增開店；UNDER_REALIZED 必須進入模型或營運檢查。

## 5. Listing 驗收

Listing 是資料管線，不是模型，但會影響 SiteScore。驗收指標：address parse success、geocode accuracy、dedup precision、hard rule false negative、source lineage completeness。低 geocode confidence 不可進入 GO；hard rule fail 不可建議 GO；duplicate unresolved 不可轉候選點。

## 6. SiteScore 驗收

### 輸出

M1/M3/M6/M12/Mature 的 P10/P50/P90、payback_period、rent_reasonableness、cannibalization_risk、recommendation、confidence、主要正向與負向因子。

### 模型指標

| 指標 | 目標 |
|---|---|
| M3 revenue MAPE | ≤ ±12% 作為主驗收參考 |
| M6/M12 error | 優於人工估計 baseline |
| P80/P90 coverage | 達校準門檻 |
| ODay holdout | 優於直接跨品牌模型 |
| High-risk false GO | 嚴格限制 |

### 決策政策

GO 必須同時滿足預測、回本期、租金、硬性條件與稀釋風險；WAIT 用於資料不足或需議價；REJECT 用於硬限制失敗或風險過高；INVESTIGATE 用於現場調查。

## 7. ForecastOps 驗收

| 指標 | 目標 |
|---|---|
| Forecast error | 優於 seasonal naive |
| Interval calibration | 達 P80/P90 coverage |
| New/mature store segment | 無重大退化 |
| Alert precision / recall | 達營運可接受門檻 |
| Lead time | 平均提前預警 ≥ 7 天作為計畫目標 |
| Alert load | 營運團隊可承擔 |

ForecastOps 只判斷發生什麼與未來如何，不得直接調價、投廣告或決定退店。

## 8. InterventionOps 驗收

Eligibility、Conflict detection、Approval audit、Observation window、Outcome collection、Evidence level 必須完整。Conflict 未處理不可核准；Outcome 未成熟不可回訓；多重干預需標示 contamination。

## 9. PriceOps 驗收

| 指標 | 目標 |
|---|---|
| Elasticity sanity check | 通過 |
| Demand / GM simulation | 通過 |
| Hard constraint violation | 0 |
| Pilot negative impact | 不超過安全門檻 |
| Rollback drill | 100% 成功 |

Hard constraints 包含毛利底線、價格變動上限、品牌政策、促銷衝突、資料信心門檻。PriceOps 不可自動執行，需人工核准。

## 10. AdLift 驗收

Control match quality、Pre-trend test、Incremental GM、iROMI、Contamination detection、Evidence level 必須可檢查。Pre-trend failed 或無 control 時不得宣稱因果；報告以 incremental gross margin 為核心，不只 ROAS。

## 11. DealRoomAVM 驗收

| 指標 | 目標 |
|---|---|
| Valuation MAPE | ≤ 15% 作為主驗收參考 |
| Valuation interval coverage | 成交價落入估值區間 ≥ 80% 作為主驗收參考 |
| Report generation time | ≤ 3 個工作日作為計畫目標 |
| Data room completeness | 達財務／法務門檻 |
| Normalized GM approval | 高風險估值需財務核准 |

Fair value、reserve price、asking price 必須分離；估值不等於交易價格；資料不足不得產生高信心估值。

## 12. NetPlan 驗收

| 指標 | 目標 |
|---|---|
| Hard constraint satisfaction | 100% |
| Solver status mapping | 正確 |
| Runtime | 達 SLA，提案回覆 ≤ 48 小時作為計畫目標 |
| Baseline comparison | 優於維持現況或可解釋 |
| Alternative plans | 可產出 |
| Infeasibility diagnosis | 必須可用 |
| Outcome tracking | 90/180/365 日 |

無可行解時不可任意放寬限制；OPEN/KEEP/IMPROVE/MOVE/EXIT 需管理層核准與理由。

## 13. Learning Hub 驗收

Feature registry、Label registry、Dataset snapshot、Model card、Backtest、Drift monitor、Release / Rollback 對 production model 覆蓋率 100%。Data quality fail 可阻擋 release；Champion/Challenger 狀態不得混亂。

## 14. OpsBoard 決策驗收

Decision log completeness、Audit trail completeness、Task SLA、Export evidence、Role-based access、Monthly audit report 必須可用。每筆高風險決策必須包含 decision_id、module、entity_id、system_prediction、system_recommendation、human_decision、actor、reason、model_version、policy_version、feature_snapshot_time、execution_status、outcome_status。

## 15. 驗收失敗處理

模型失敗不得 promote；決策政策失敗阻擋 release；資料失敗 block model run；線上成效不佳需 rollback review、暫停自動建議、降級為 advisory-only 並啟動 postmortem。

## 16. 驗收條件

所有模型都有指標、baseline、calibration、segment review、model card、rollback；所有決策都有 hard constraints、人工核准與 audit；SiteScore、ForecastOps、AVM、NetPlan、OpsBoard 的計畫驗證指標可被量測。
