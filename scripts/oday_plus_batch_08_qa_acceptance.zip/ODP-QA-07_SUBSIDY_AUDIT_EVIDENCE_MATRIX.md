---
id: ODP-QA-07
title: 補助計畫查核證據矩陣
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-07 補助計畫查核證據矩陣

## 1. 文件目的

本文件定義 ODay Plus 對應 DIGITAL+ 補助計畫與內部驗收的查核證據矩陣。目的在於把計畫承諾、系統功能、測試結果、操作紀錄、報表、截圖、影片、模型驗證與 UAT 簽核建立一一對應。

查核時需回答：計畫書承諾了什麼、系統做到哪裡、在哪個畫面可看到、哪支 API 或 Job 支援、哪份測試報告證明、哪個 Audit Log 可追溯、哪個人驗收、證據檔在哪裡。

## 2. 證據管理原則

每項承諾都要有證據；證據需可追溯；證據需版本化；不得只用人工截圖取代正式紀錄。每份證據需包含 evidence_id、evidence_type、related_requirement、module、environment、build_version、data_snapshot、model_version、generated_at、generated_by、file_path、hash。

## 3. 證據類型

| Evidence Type | 說明 |
|---|---|
| SCREENSHOT | 系統畫面截圖 |
| VIDEO | 操作錄影 |
| API_RESPONSE | API 回應 JSON |
| JOB_LOG | Job 執行紀錄 |
| TEST_REPORT | 自動化測試報告 |
| MODEL_REPORT | 模型驗證報告 |
| DATA_REPORT | 資料品質或血緣報告 |
| AUDIT_EXPORT | 決策稽核匯出 |
| UAT_SIGNOFF | 使用者驗收簽核 |
| SECURITY_REPORT | 資安測試報告 |
| DR_REPORT | 災難復原演練報告 |
| SLA_REPORT | SLA / uptime 報告 |
| DEPLOYMENT_RECORD | 部署紀錄 |

## 4. 系統模組完成度矩陣

| ID | 計畫承諾 / 查核點 | 系統模組 | 證據 |
|---|---|---|---|
| AUD-MOD-001 | SiteScore 智慧選址系統 | SiteScore | report screenshot、API response、model report、UAT |
| AUD-MOD-002 | ForecastOps 四燈預警模組 | ForecastOps | alert center screenshot、forecast report、test report |
| AUD-MOD-003 | DealRoomAVM 自動估值模組 | DealRoomAVM | valuation card、AVM report、finance approval audit |
| AUD-MOD-004 | NetPlan 三案決策模擬 | NetPlan | scenario result、solver log、alternative plan screenshot |
| AUD-MOD-005 | OpsBoard 治理平台 | OpsBoard | dashboard screenshot、decision log export、monthly report |
| AUD-MOD-006 | Integration Layer 與資料底座整合 | Integration / Data | data lineage、mapping report、data quality report |
| AUD-MOD-007 | Learning Hub / MLOps | Learning Hub | model registry、model card、release approval |

## 5. SiteScore 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-SITE-001 | 輸入候選地點產出選址評分卡 | 操作候選點評分 | 報告可生成 | Screenshot、API response |
| AUD-SITE-002 | 預估回本期 | 報告欄位檢查 | 顯示 payback period | SiteScore report |
| AUD-SITE-003 | 營收路徑預測 | 檢查 M1/M3/M6/M12 | 顯示 P10/P50/P90 | Report screenshot |
| AUD-SITE-004 | 預測誤差 | 新店實績比對 | M3 MAPE ≤ ±12% 作為主目標 | Model validation report |
| AUD-SITE-005 | 報告產出時間 | Job log | ≤ 24 小時 | Job execution log |
| AUD-SITE-006 | API 回應時間 | Performance test | P95 ≤ 3 秒 | Performance report |
| AUD-SITE-007 | GO/WAIT/REJECT | Decision policy test | 建議產出且可人工核准 | E2E report、Decision log |
| AUD-SITE-008 | 自家稀釋風險 | 報告欄位檢查 | 顯示 cannibalization risk | Screenshot |
| AUD-SITE-009 | 人工核准與留痕 | Audit check | 100% high-risk decision logged | Audit export |
| AUD-SITE-010 | 開店後回收實績 | Realization test | M1/M3/M6 outcome linked | Realization report |

## 6. ForecastOps 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-FCST-001 | 多週營收預測 | Forecast report | 4/8/12/24 週或 28 天輸出 | Screenshot、API |
| AUD-FCST-002 | 四燈預警 | Alert center test | GREEN/YELLOW/ORANGE/RED 正確 | E2E report |
| AUD-FCST-003 | 整合營收、費用、客服、維修 | Data lineage | 四類資料可追溯 | Data lineage report |
| AUD-FCST-004 | 平均異常提前預測 | Historical backtest | ≥ 7 天作為主目標 | Model validation report |
| AUD-FCST-005 | 預警準確率 | Backtest / UAT | ≥ 90% 作為主目標或分階段驗證 | Model report |
| AUD-FCST-006 | 預警後處置單 | Intervention flow | 可建立處置單 | E2E report |
| AUD-FCST-007 | 14 天內恢復率 | Outcome report | ≥ 70% 作為營運目標 | Intervention outcome report |
| AUD-FCST-008 | Root Cause Evidence | UI check | 顯示原因候選與證據 | Screenshot |
| AUD-FCST-009 | 每日更新 | Job log | Daily scoring job 可執行 | Job log |
| AUD-FCST-010 | SiteScore Realization | Report | 實績與預測差距可見 | Screenshot |

## 7. DealRoomAVM 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-AVM-001 | 產出中位價與估值區間 | AVM report | 顯示 P10/P50/P90 | Screenshot |
| AUD-AVM-002 | 整合 GM_TTM / GM_FWD | Data lineage | 欄位可追溯 | Data lineage |
| AUD-AVM-003 | 整合折舊台帳與資產清單 | Data lineage | 資產資料可追溯 | Data report |
| AUD-AVM-004 | 估值誤差 | 成交價比對 | MAPE ≤ 15% 作為主目標 | Model validation |
| AUD-AVM-005 | 成交價落於估值區間 | Coverage report | ≥ 80% 作為主目標 | Model validation |
| AUD-AVM-006 | 估值卡產出時間 | Job log | ≤ 3 工作日 | Job log |
| AUD-AVM-007 | Reserve price | Finance approval | 與 Fair / Asking 分離 | Approval audit |
| AUD-AVM-008 | Data Room | Checklist | 文件完整度可見 | Screenshot |
| AUD-AVM-009 | 財務／法務核准 | Audit | actor / reason / time | Audit export |

## 8. NetPlan 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-NET-001 | 三案對比 | Scenario report | 留守／遷點／退出或 OPEN/KEEP/IMPROVE/MOVE/EXIT | Screenshot |
| AUD-NET-002 | ROI / 風險等指標 | Report check | 每案至少五項指標 | Scenario report |
| AUD-NET-003 | 季度甘特圖 | UI / export | 可產出時序圖 | Screenshot / export |
| AUD-NET-004 | 提案回覆時間 | Job / workflow log | ≤ 48 小時作為主目標 | Job log |
| AUD-NET-005 | Hard constraints | Solver report | 100% 滿足 | Solver report |
| AUD-NET-006 | Alternative plan | Scenario comparison | 可比較 | Screenshot |
| AUD-NET-007 | Infeasibility diagnosis | Infeasible scenario | 有診斷，不自動放寬 | E2E report |
| AUD-NET-008 | 管理層核准 | Decision log | actor / reason / time | Audit export |
| AUD-NET-009 | 90/180/365 outcome | Tracking report | outcome 可回收 | Outcome report |

## 9. OpsBoard 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-OPSBD-001 | 統整全模組結果 | Dashboard | 模組入口與摘要可見 | Screenshot |
| AUD-OPSBD-002 | 決策紀錄 | Decision log | 100% high-risk decision logged | Audit export |
| AUD-OPSBD-003 | 責任人、參數、成效 | Audit detail | 欄位完整 | Audit export |
| AUD-OPSBD-004 | 月度稽核 | Report | 可匯出月度報表 | Report export |
| AUD-OPSBD-005 | SLA | Monitoring | SLA report 可產出 | SLA report |
| AUD-OPSBD-006 | 自動報表匯出 | Export test | CSV/PDF/JSON | Export evidence |
| AUD-OPSBD-007 | 權限管理 | Permission test | RBAC / ABAC 通過 | Security report |
| AUD-OPSBD-008 | 加盟主入口 | UAT | 自店資料隔離 | UAT sign-off |

## 10. 雲端架構、SLA、資安查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-CLOUD-001 | GCP 部署 | Deployment record | Cloud Run / BigQuery / Cloud SQL / Vertex 等 | Architecture evidence |
| AUD-CLOUD-002 | IAM 權限 | Security test | 最小權限 | Security report |
| AUD-CLOUD-003 | Cloud Logging | Log check | 操作與錯誤可查 | Log screenshot |
| AUD-CLOUD-004 | API 機制 | OpenAPI / test | RESTful API 可用 | API test report |
| AUD-CLOUD-005 | OAuth 2.0 / Auth | Auth test | 授權安全 | Security report |
| AUD-CLOUD-006 | 資料可攜 | Export test | CSV/JSON | Export evidence |
| AUD-CLOUD-007 | 系統可用率 | Monitoring | 99.95% 作為服務規劃目標 | SLA report |
| AUD-CLOUD-008 | RPO | DR drill | ≤ 1 小時 | DR report |
| AUD-CLOUD-009 | RTO | DR drill | ≤ 4 小時 | DR report |
| AUD-CLOUD-010 | 備份 | Backup report | 每日或依策略 | Backup evidence |
| AUD-SEC-001 | TLS / transport encryption | Security config | 通過 | Security report |
| AUD-SEC-002 | 靜態資料加密 | Cloud config | 通過 | Security report |
| AUD-SEC-003 | 第三方滲透測試 | Pen test | 無重大漏洞 | Pen test report |
| AUD-SEC-004 | 個資下載／刪除權利 | Function test | 可支援或有程序 | Privacy test |

## 11. 模型與 AI 查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-ML-001 | 模型版本可追溯 | Model registry | 版本與狀態正確 | Registry screenshot |
| AUD-ML-002 | Forecasting | Model validation | 預測誤差達標或分階段目標 | Model report |
| AUD-ML-003 | Dynamic pricing | PriceOps test | 可產生建議並人工核准 | E2E report |
| AUD-ML-004 | Model card | Document | production model 100% | Model card |
| AUD-ML-005 | Drift monitor | Monitoring | 可偵測 | Drift report |
| AUD-ML-006 | Rollback | Release drill | 成功 | Rollback report |
| AUD-ML-007 | Data leakage prevention | PIT test | 通過 | Data test report |
| AUD-ML-008 | Champion / Challenger | Registry test | 狀態正確 | Registry screenshot |

## 12. UAT 與導入成效查核矩陣

| ID | 承諾 | 驗證方式 | 目標 / 口徑 | 證據 |
|---|---|---|---|---|
| AUD-UAT-001 | 展店角色可使用 | UAT | sign-off | UAT report |
| AUD-UAT-002 | 營運角色可使用 | UAT | sign-off | UAT report |
| AUD-UAT-003 | 財務／法務可使用 | UAT | sign-off | UAT report |
| AUD-UAT-004 | 管理層可使用 | UAT | sign-off | UAT report |
| AUD-UAT-005 | 加盟主可使用 | UAT | sign-off | UAT report |
| AUD-UAT-006 | 教育訓練 | Training record | 完成 | Training evidence |
| AUD-UAT-007 | 作業手冊 | Document | 完成 | Manual |
| AUD-UAT-008 | 示範說明會 | Event record | 完成 | Photos / agenda / sign-in |

## 13. 證據檔案命名規則

格式：`{evidence_id}_{module}_{yyyymmdd}_{version}.{ext}`。例：`AUD-SITE-001_sitescore_20260626_v1.png`、`AUD-FCST-004_forecast_validation_20260626_v1.pdf`。

## 14. Evidence Manifest

```yaml
project: ODay Plus
evidence_package_version: 1.0.0
generated_at:
generated_by:
environment:
build_version:
items:
  - evidence_id:
    title:
    requirement_id:
    module:
    evidence_type:
    file:
    hash:
    generated_at:
    reviewed_by:
    status:
```

## 15. 查核前準備清單

所有證據檔存在；manifest hash 正確；每項承諾至少一筆證據；截圖顯示版本與時間；測試報告標示環境與 build；模型報告標示 dataset 與 model version；Audit export 可重新查詢；UAT sign-off 完成；資安與 DR 報告完成。

## 16. 驗收條件

計畫承諾到系統證據有一一對應；SiteScore、ForecastOps、DealRoomAVM、NetPlan、OpsBoard 均有查核矩陣；雲端架構、SLA、資安、個資、資料可攜均有證據口徑；Evidence package 可依 manifest 打包與重現。
