---
id: ODP-QA-03
title: 端到端測試情境
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-03 端到端測試情境

## 1. 文件目的

本文件定義 ODay Plus 全平台 E2E 測試情境。每條 E2E 必須覆蓋前端操作、API、權限、Job/Workflow、資料寫入、模型或規則輸出、人工決策、Audit Log、結果回收或狀態更新。

## 2. E2E 命名

格式：`E2E-{DOMAIN}-{NNN}`。Domain 包含 EXP、OPS、INT、PRICE、AD、AVM、NET、LEARN、AUDIT、SEC、DATA、FRAN。

## 3. E2E 情境總覽

| ID | 名稱 | 優先級 |
|---|---|---|
| E2E-EXP-001 | HeatZone 到 SiteScore 開店決策 | P0 |
| E2E-EXP-002 | Listing 匯入、解析、去重與候選物件建立 | P0 |
| E2E-EXP-003 | SiteScore 報告退回補件後重新評分 | P1 |
| E2E-OPS-001 | 開店後 SiteScore Realization 驗證 | P0 |
| E2E-OPS-002 | ForecastOps 四燈警示到 Root Cause | P0 |
| E2E-INT-001 | 紅燈警示到干預處置與觀察窗成熟 | P0 |
| E2E-PRICE-001 | PriceOps 調價方案、核准、執行與回滾 | P0 |
| E2E-AD-001 | AdLift 活動建立、對照組、增量分析 | P0 |
| E2E-AVM-001 | 長期紅燈門市到 AVM 估值與 Data Room | P0 |
| E2E-NET-001 | NetPlan 情境建立、求解、替代方案與核准 | P0 |
| E2E-LEARN-001 | 模型訓練、驗證、Shadow、Canary、Production | P0 |
| E2E-LEARN-002 | 模型發布後 Rollback | P0 |
| E2E-DATA-001 | 資料品質失敗阻擋模型評分 | P0 |
| E2E-AUDIT-001 | 決策稽核證據匯出 | P0 |
| E2E-SEC-001 | 角色權限與資料隔離 | P0 |
| E2E-FRAN-001 | 加盟主查看自店狀態與回報處置結果 | P1 |

## 4. E2E-EXP-001 HeatZone 到 SiteScore 開店決策

### 目的

驗證展店流程能從熱區發現一路走到候選店址評估與人工核准。

### 步驟

1. 使用展店業務帳號登入 OpsBoard。
2. 進入 HeatZone Map。
3. 篩選 `STILL_EXPANDABLE` 且 confidence ≥ medium 的熱區。
4. 點擊 HeatZone，查看 Detail Drawer。
5. 點擊「查看區域 Listing」。
6. 選擇已 geocode 且通過 hard rule 的 listing。
7. 轉為 Candidate Site。
8. 進入 Candidate Site Detail。
9. 執行 SiteScore。
10. 系統建立 `sitescore_score` job。
11. Job 成功後開啟 SiteScore Report。
12. 檢查 M1/M3/M6/M12 的 P10/P50/P90、回本期、租金合理性、自家稀釋。
13. 送審。
14. 使用展店審查帳號核准或退回。
15. 檢查 Decision Log 與 Audit Timeline。

### 預期結果

HeatZone、Listing、Candidate Site、SiteScore Report、人工核准與 Audit 均可串接；系統建議與人工決策分離；Report 顯示 model_version、feature_snapshot_time、confidence；Audit 包含 actor、decision_time、reason。

## 5. E2E-EXP-002 Listing 匯入、解析、去重與候選物件建立

步驟：上傳 CSV/Excel、欄位 mapping、address normalization、geocode、dedup、hard rule、錯誤列下載、轉 Candidate Site。預期：duplicate group 正確，hard rule failed 不可直接轉候選點，source lineage 完整。

## 6. E2E-EXP-003 SiteScore 報告退回補件後重新評分

步驟：產生報告、審查退回、補租金或物件條件、重新評分、產生新版 report、顯示差異、再次核准。預期：舊版不可覆蓋，version +1，退回與補件理由留痕。

## 7. E2E-OPS-001 開店後 SiteScore Realization 驗證

步驟：使用已核准 GO 的候選點建立 opening record，匯入新店 M1/M3/M6 實績，計算 realization ratio，標記 under-realized 或 achieved，寫入 Label Registry。預期：outcome 與原 report_id/model_version 綁定，label maturity 前不得訓練。

## 8. E2E-OPS-002 ForecastOps 四燈警示到 Root Cause

步驟：匯入 store_machine_timeseries_view，執行 forecast batch，產生 4/8/12/24 週預測，判斷 residual 與 trajectory，產生 orange/red alert，開啟 Root Cause Evidence，建立 intervention proposal。預期：forecast band 顯示 P10/P50/P90，root cause 顯示 supporting/contradicting signals，alert 連結 forecast_run_id。

## 9. E2E-INT-001 紅燈警示到干預處置與觀察窗成熟

步驟：從 red alert 建立 intervention，執行 eligibility、action candidate、conflict check、人工核准、execution update、observation window、outcome collection、effect evaluation、Label Registry write-back。預期：conflict 未處理不可核准；observation window 不可早於 execution；outcome maturity 前不可宣稱結果。

## 10. E2E-PRICE-001 PriceOps 調價方案、核准、執行與回滾

步驟：產生 pricing candidate，開啟 demand/gross margin simulation，檢查 hard constraints，建立 price plan，人工核准，發出 execution event，進入 observation window，必要時 rollback。預期：hard constraint violation 為 0 才能核准；rollback plan 在核准前已存在；before/after price 留痕。

## 11. E2E-AD-001 AdLift 活動建立、對照組、增量分析

步驟：產生 ad need score，建立 campaign，配對 control stores，執行 pre-trend test，活動後計算 incremental revenue、incremental GM、iROMI，產生 continue/stop 建議。預期：pre-trend failed 不可宣稱因果；重疊調價或促銷需標示 contamination。

## 12. E2E-AVM-001 長期紅燈門市到 AVM 估值與 Data Room

步驟：ForecastOps 標記長期偏離，建立 AVM request，執行 GM normalization、Income/Asset/Market valuation，產生 P10/P50/P90，財務核准 reserve price，建立 Data Room checklist，匯出 valuation card。預期：Fair/Reserve/Asking 分離；財務核准有 reason；匯出有 Audit。

## 13. E2E-NET-001 NetPlan 情境建立、求解、替代方案與核准

步驟：建立 scenario、設定 horizon、candidate actions、budget/lease/construction/equipment constraints，執行 solver，檢視 OPEN/KEEP/IMPROVE/MOVE/EXIT、binding constraints、alternative plans、infeasibility diagnosis，管理層核准，建立 90/180/365 outcome tracking。預期：Hard constraints 100% 滿足；無可行解時只診斷，不自動放寬限制。

## 14. E2E-LEARN-001 模型訓練、驗證、Shadow、Canary、Production

步驟：建立 dataset snapshot，執行 training job，記錄 MLflow run，產生 model card，Backtest 通過，建立 release request，Shadow、Canary、Production promote，更新 model registry alias。預期：Production alias 只有一個 active champion；Release approval 有 actor；model card 完整。

## 15. E2E-LEARN-002 模型發布後 Rollback

步驟：Production model 發布後，drift monitor 觸發異常，release controller 建立 rollback recommendation，AI owner 核准 rollback，系統切回 previous champion。預期：Rollback 不刪新模型紀錄；prediction 使用舊 model_version；audit 記錄 rollback reason。

## 16. E2E-DATA-001 資料品質失敗阻擋模型評分

步驟：注入 stale/missing/invalid 資料，執行 data quality worker，Data Quality Center 顯示 failure，系統阻擋 SiteScore 或 ForecastOps scoring，Data owner 修正後重跑。預期：Failed QA 可見；blocked model list 正確；修復後保留 failure history。

## 17. E2E-AUDIT-001 決策稽核證據匯出

步驟：搜尋一筆高風險決策，開啟 Decision Audit Detail，檢查 prediction、recommendation、human decision、execution、outcome，執行 Export Evidence。預期：證據包包含 decision_id、entity_id、input snapshot、model version、policy version、actor、reason、approval chain、execution、outcome、hash。

## 18. E2E-SEC-001 角色權限與資料隔離

步驟：使用 franchisee_user 嘗試查看其他門市與敏感估值；使用 ops_manager 嘗試核准 price plan；使用 pricing_user 核准 price plan。預期：未授權動作回傳 403 並寫入 security audit；加盟主只看自店。

## 19. E2E-FRAN-001 加盟主查看自店狀態與回報處置結果

步驟：加盟主登入 My Store Overview，查看建議處置，上傳回報，區域督導確認，觀察窗成熟後查看結果。預期：加盟主入口不暴露其他門市、模型內部參數或敏感底價。

## 20. 自動化策略

Smoke suite 每次部署執行；critical E2E 每日或 release 執行；full E2E nightly；model E2E 於模型發布執行；data E2E 每次資料更新執行；security E2E 每次 release 執行；subsidy evidence suite 於查核里程碑執行。

## 21. 驗收條件

P0 E2E 全部可執行且通過；每條 E2E 有測試資料、角色、API、預期結果；所有高風險決策均覆蓋 Audit；資料品質、模型發布、權限與查核證據均納入 E2E。
