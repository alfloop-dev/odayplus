---
id: ODP-QA-02
title: 測試資料與環境策略
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-02 測試資料與環境策略

## 1. 文件目的

本文件定義 ODay Plus 測試資料、測試環境、資料遮罩、Synthetic Data、Golden Dataset、Frozen Snapshot、Masked Production Extract、資料保留、環境重置與測試帳號策略。ODay Plus 的模型、決策與查核證據高度依賴資料版本，因此測試資料必須可重建、可追溯、可遮罩、可回放。

## 2. 測試資料原則

1. 非正式環境不得使用未遮罩個資。
2. 所有測試資料必須可由 seed、fixture、snapshot、generator 或授權抽取重建。
3. 模型驗證必須使用 frozen dataset，不可使用會飄移的 live dataset。
4. E2E 測試必須 deterministic，包含固定 ID、固定時間、固定資料狀態與固定模型輸出。
5. 補助查核證據需保存 artifact_id、data_snapshot、model_version、build_version、hash。

## 3. 資料分類

| Data Class | 說明 | 非正式環境使用規則 |
|---|---|---|
| Public | 公開地理、行政區資料 | 可使用 |
| Internal | 內部非敏感設定 | 可使用 |
| Confidential | 營收、租約、估值、模型特徵 | 遮罩或合成 |
| Restricted | 會員個資、支付識別、敏感交易 | 原則不可使用 |
| Secret | token、API key、credential | 禁止出現在資料集 |
| Regulated | 個資法或契約限制資料 | 需資料保護與資安核准 |

## 4. Synthetic Data

Synthetic Data 用於 local、dev、sandbox、edge case 與權限測試。產生範圍包含 stores、machines、transactions、members_masked、candidate_sites、listings、heat_zones、forecasts、alerts、interventions、price_plans、campaigns、valuations、netplan_scenarios、models、audit_events。

Synthetic Data 必須能模擬正常、異常、資料缺漏、低信心、資料過期、重複物件、紅燈門市、調價衝突、廣告對照組不足、估值資料不足與 NetPlan infeasible。

## 5. Golden Dataset

Golden Dataset 用於回歸測試。至少建立：

| Dataset | 用途 |
|---|---|
| golden_heatzone_dataset | 驗證熱區分數與排名回歸 |
| golden_listing_dataset | 驗證匯入、geocode、dedup、hard rules |
| golden_sitescore_dataset | 驗證營收路徑、回本期、建議 |
| golden_forecastops_dataset | 驗證預測、四燈、根因 |
| golden_intervention_dataset | 驗證處置流程與觀察窗 |
| golden_priceops_dataset | 驗證價格限制與模擬 |
| golden_adlift_dataset | 驗證 treatment/control 與 iROMI |
| golden_avm_dataset | 驗證估值區間與 Data Room |
| golden_netplan_dataset | 驗證 solver、替代方案、無可行解 |
| golden_learninghub_dataset | 驗證 model release / rollback |

每份 Golden Dataset 必須包含 dataset_id、version、purpose、source、input_tables、expected_outputs、known_limitations、hash。

## 6. Frozen Snapshot

Frozen Snapshot 用於模型訓練回測、Model Card、UAT 重現、補助驗證、事故回放。Snapshot 類型包含 feature_snapshot、dataset_snapshot、model_ready_view_snapshot、prediction_snapshot、decision_snapshot、outcome_snapshot、audit_snapshot。

必要欄位：snapshot_id、snapshot_time、source_system、schema_version、created_by、created_at、retention_until、hash。

## 7. Masked Production Extract

當 synthetic data 無法覆蓋真實複雜度時，可使用遮罩後 production extract。抽取前需資料 owner 與 security owner 核准。

| 欄位 | 處理 |
|---|---|
| member_name | remove |
| phone/email | hash or synthetic replacement |
| payment_id | tokenize |
| full address | generalize unless needed |
| transaction_id | re-key |
| store_id | preserve only if authorized |
| revenue | retain、bucket 或 noise，依敏感度 |
| valuation | bucket 或 synthetic |
| comments | scrub PII |

## 8. 環境資料配置

| Environment | 資料 | 模型 | Audit | Reset |
|---|---|---|---|---|
| Local | synthetic | stub/local small model | optional | developer |
| Dev | synthetic + fixtures | candidate/stub | enabled light | daily/on demand |
| Integration | deterministic dataset | fixed test artifacts | enabled | scheduled |
| Staging | masked + frozen snapshots | release candidate | required | controlled |
| Production | real | production | required | no reset |
| Sandbox | synthetic/anonymized | canned acceptable | optional | on demand |

## 9. 測試資料主檔矩陣

### 9.1 Store Matrix

需包含 new_store、ramping_store、mature_store、plateau_store、declining_store、high_capacity_store、low_capacity_store、high_rent_store、low_confidence_store、intervention_active_store、red_alert_store、avm_candidate_store、netplan_move_candidate。

### 9.2 Candidate Site Matrix

需包含 valid_go_site、wait_site、reject_site、no_geocode_site、low_confidence_geocode、high_rent_site、hard_rule_fail_site、cannibalization_high_site、saturated_heat_zone_site、duplicate_listing_site。

### 9.3 Intervention Matrix

需包含 price_intervention、ad_intervention、promotion_intervention、crm_intervention、maintenance_intervention、cleaning_intervention、conflict_intervention、overlapping_treatment、evidence_insufficient、outcome_matured。

## 10. 時間語意測試資料

每筆事件必須具備 event_time、observation_time、decision_time、outcome_time、label_maturity_time、ingested_at、updated_at。必測情境：late_arriving_transaction、corrected_transaction、future_leakage_blocked、immature_label、stale_external_data、intervention_overlap。

## 11. Data Quality Fixtures

建立 missing_required_field、duplicate_primary_key、invalid_foreign_key、invalid_enum_value、negative_revenue、impossible_machine_capacity、future_event_time、stale_source、low_coverage_source、schema_breaking_change、distribution_shift、geocode_conflict。每個 fixture 需定義 expected behavior：warn、block、quarantine、fallback、manual_review。

## 12. 測試帳號

需建立 qa_admin、executive_user、expansion_user、site_reviewer、ops_manager、field_supervisor、marketing_user、pricing_user、finance_user、legal_user、data_scientist、mlops_user、franchisee_user、audit_user、readonly_user、no_permission_user。每個帳號需記錄 role、region_scope、store_scope、permissions、expected_visible_routes、expected_allowed_actions、expected_denied_actions。

## 13. 環境重置

| Level | 說明 |
|---|---|
| L1 | 清除 UI preferences |
| L2 | 清除 workflow/job records |
| L3 | 重建 domain seed data |
| L4 | 重建 canonical tables |
| L5 | 重建 full environment |

不得重置 production，不得刪除查核證據，不得讓 reset script 存取 production credentials。

## 14. 測試資料產生器

建立 `odp-testdata` CLI，支援 `generate`、`reset`、`snapshot`、`mask`。範例：

```bash
odp-testdata generate --scenario sitescore-go --seed 1001 --env integration
odp-testdata generate --scenario red-alert-intervention --seed 2001 --env integration
odp-testdata reset --level L3 --env integration
```

## 15. 保存期限

CI artifacts 保存 30-90 天；Release test report 至少 1 年；UAT evidence 與補助查核證據依計畫與契約要求保存；Model validation snapshot 至少模型生命週期加 1 年；Masked production extract 預設 90 天或依核准單。

## 16. 驗收條件

本文件完成後，非正式環境不可使用未遮罩個資，Golden Dataset 與 Frozen Snapshot 有版本規則，E2E 資料 deterministic，模型驗證可重現，測試帳號覆蓋主要角色，查核證據有保存策略。
