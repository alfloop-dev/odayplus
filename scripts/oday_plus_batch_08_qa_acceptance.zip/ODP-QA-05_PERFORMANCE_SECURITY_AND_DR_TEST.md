---
id: ODP-QA-05
title: 效能、資安與災難復原測試
batch: 8
category: QA
doc_type: quality-assurance
version: 1.0.0
status: draft
formal_deliverable: true
owner: QA Lead / Product Owner / Engineering Lead
updated_at: 2026-06-26
---


# ODP-QA-05 效能、資安與災難復原測試

## 1. 文件目的

本文件定義 ODay Plus 的效能測試、資安測試、個資測試、可靠性測試、備份還原測試、災難復原測試、SLA 測試與上線前非功能驗收。ODay Plus 涉及門市營收、會員、租約、估值、模型決策與稽核證據，因此非功能測試需與功能測試同等嚴格。

## 2. 非功能範圍

| 類型 | 範圍 |
|---|---|
| Performance | API、前端、地圖、查詢、Batch、Job、Solver |
| Scalability | Cloud Run、Worker、Queue、BigQuery、PostGIS |
| Security | Auth、RBAC/ABAC、OWASP、dependency、secret scan |
| Privacy | 個資遮罩、匯出、資料刪除、最小存取 |
| Reliability | retry、timeout、idempotency、dead letter |
| DR | backup、restore、RPO、RTO、multi-region |
| Observability | logs、metrics、traces、alerts |
| Audit | 高風險操作留痕與證據完整性 |

## 3. API 效能測試

測試 API 包含 `/heatzones/map`、`/listings`、`/sitescore/reports`、`/stores/{id}/forecast`、`/alerts`、`/interventions`、`/pricing/plans`、`/adlift/campaigns`、`/avm/reports`、`/netplan/scenarios`、`/audit/decisions`。

| API 類型 | P95 目標 |
|---|---|
| 一般查詢 | ≤ 1.5 秒 |
| Detail 查詢 | ≤ 2 秒 |
| 建立 Job | ≤ 1 秒回傳 job_id |
| SiteScore 報告讀取 | ≤ 3 秒 |
| 大型列表查詢 | ≤ 3 秒 |
| Audit 查詢 | ≤ 3 秒 |
| Export job 建立 | ≤ 1 秒 |

測試條件需包含 10、50、100、200 concurrent users、burst traffic 與 long-running jobs 同時存在。

## 4. 前端與地圖效能

| 項目 | 目標 |
|---|---|
| App shell first usable | ≤ 3 秒 |
| Route transition | ≤ 1 秒 |
| Listing first page render | ≤ 2 秒 |
| SiteScore report render | ≤ 2 秒 |
| Store detail render | ≤ 2 秒 |
| Map initial layer | ≤ 3 秒 |
| Chart interaction | ≤ 500ms |
| Command palette open | ≤ 300ms |

地圖需測試全台 HeatZone layer、高密度 listing cluster、多圖層、低規格筆電與高延遲網路。若資料量過大，需使用 vector tile、server-side aggregation 或 clustering。

## 5. Batch / Job / Solver 效能

| Job | 目標 |
|---|---|
| Listing import 1,000 筆 | ≤ 10 分鐘 |
| Geocode batch | 遵守 rate limit 且可恢復 |
| HeatZone batch score | 夜間 batch window 完成 |
| SiteScore scoring | 報告 ≤ 24 小時內完成作為計畫目標 |
| Forecast daily score | 每日營運前完成 |
| AVM report | ≤ 3 個工作日作為計畫目標 |
| NetPlan solver | ≤ 48 小時內可回覆方案作為計畫目標 |

## 6. Scalability 測試

測試 normal_day、monthly_review_day、quarterly_netplan_day、model_release_day、external_data_refresh_day、incident_spike。需確認 queue depth 上升時 worker 可擴展，worker crash 後 job 可 retry，DLQ 可接 poison message，idempotency 防止重複寫入，long-running solver 不阻塞一般 job。

## 7. 資安測試

### 7.1 Authentication

測試未登入、token expired、refresh token、logout、session timeout、MFA、stolen token simulation。

### 7.2 Authorization

必測 horizontal privilege escalation、vertical privilege escalation、direct URL access、API parameter tampering、store scope bypass、export permission bypass、model release permission bypass。加盟主只能看自店，稽核只能查不可改，營運不可核准價格，定價角色不可發布模型。

### 7.3 OWASP 與 API Security

涵蓋 injection、broken auth、sensitive data exposure、broken access control、security misconfiguration、XSS、insecure deserialization、vulnerable dependencies、SSRF、CSRF。API 必測 missing token、invalid token、scope mismatch、rate limit、payload size、schema validation、idempotency key、replay、correlation id、錯誤訊息不洩漏敏感資訊。

### 7.4 CI Security

CI 必須執行 secret scanning、dependency vulnerability scan、container image scan、IaC scan、license scan、SAST。High/Critical finding 不得未核准上線。

## 8. 個資與敏感資料測試

測試會員姓名、電話、email、支付識別、地址、租約、估值底價、財務資訊的遮罩。匯出需測試權限、理由、敏感資料標示、Audit、watermark、expiration、下載連結權限。若支援資料主體請求，需測試查詢、匯出、更正、停止利用、刪除或去識別。

## 9. Reliability 測試

測試 external API timeout、geocode rate limit、Pub/Sub redelivery、worker crash、BigQuery transient failure、model endpoint timeout、solver timeout。可重試錯誤進 retry，不可重試進 failed，超過上限進 DLQ，且不可產生重複結果。

必測 idempotency：listing import、candidate site create、sitescore job create、intervention approve、price plan approve、campaign create、avm report create、netplan solver run、model release、export evidence。

## 10. 備份與復原測試

| 資源 | 測試 |
|---|---|
| Cloud SQL / PostGIS | automated backup、point-in-time recovery |
| BigQuery | table snapshot / export restore |
| Cloud Storage | versioning restore |
| Model artifacts | artifact restore |
| MLflow metadata | DB restore |
| Audit logs | retention and export restore |
| Terraform state | secured backend restore |
| Secrets | rotation and access recovery |

RPO ≤ 1 小時、RTO ≤ 4 小時作為營運服務規劃主驗收參考。每季至少演練 Cloud SQL restore、BigQuery restore、model artifact restore、audit evidence restore、IaC state recovery。

## 11. Disaster Recovery 測試

情境包含 Cloud SQL region failure、BigQuery dataset corruption、Cloud Run outage、Pub/Sub backlog、model endpoint failure、object storage accidental deletion、secret rotation failure、IAM misconfiguration、external data source unavailable。

演練步驟：宣告事故、建立 incident channel、模擬故障、啟動 runbook、restore/failover、驗證核心服務、驗證資料完整、驗證 Audit continuity、宣告恢復、產生 DR report。

## 12. SLA 測試

驗證系統可用率、緊急問題 4 小時內回應、一般問題 12 小時內回應、AI 客服 24/7、人工客服時段、每日備份、服務中斷補償口徑。中斷補償需以 system log 計算。

## 13. Observability 測試

Logs 必須包含 timestamp、service、environment、severity、correlation_id、user_id/service_account、request_id、entity_id、error_code。Metrics 必須包含 API latency、error rate、job failure、queue depth、batch duration、data freshness、model prediction volume、drift alert、audit export count、login failure rate。高風險 flow 需 trace：UI→API→job→worker→database→model endpoint→decision log。

## 14. 非功能 Gate

Performance Gate、Security Gate、Privacy Gate、Reliability Gate、DR Gate、Observability Gate、SLA Gate、Audit Gate 全部通過後才可正式上線。

## 15. 驗收條件

本文件完成後，效能、資安、個資、DR、SLA、可靠性與 Observability 測試口徑明確；RPO/RTO/API P95/SLA 可被驗證；高風險流程具 idempotency 與 audit；補助查核所需非功能證據可產出。
