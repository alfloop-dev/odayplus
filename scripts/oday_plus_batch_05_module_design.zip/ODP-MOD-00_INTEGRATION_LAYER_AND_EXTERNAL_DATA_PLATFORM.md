---
doc_id: ODP-MOD-00
title: "Integration Layer／External Data Platform 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Integration Owner / Data Architect"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# Integration Layer／External Data Platform 模組詳細設計

## 1. 文件目的

Integration Layer 與 External Data Platform 是 ODay Plus 的資料入口與反腐化層，負責將上游 IoT／內部資料底座、外部地理資料、出租物件資料、天氣與市場資料轉換為 ODay Plus 可治理的 Canonical Model 與 Model-ready Views。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 上游 IoT／交易／會員／維修／客服／價格／租約資料交換接收
- 外部資料 Connector、Snapshot、授權、來源版本與新鮮度管理
- 地址正規化、Geocode、H3、行政區、等時圈、POI、路網與租金特徵建立
- Source-to-Canonical Mapping、Identity Resolution、Data Quality Gate、Backfill 與重算
- 發布 Canonical Dataset、Feature Mart 與 Model-ready Views 給下游模組

### 2.2 Out of Scope

- 不負責 IoT 裝置、內部交易系統或上游資料底座本身的實作
- 不直接產生 GO／WAIT／REJECT、四燈、估值或店網方案等業務決策
- 不將未經授權或不具可追溯性的外部資料發布為正式特徵

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-00]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 資料工程師
- Integration Owner
- GIS／外部資料維護者
- Data Owner
- AI／模型團隊
- 系統管理員

### 3.2 核心使用情境

- 設定新的外部資料來源並建立抓取排程
- 匯入上游交易、機台、會員、客服、維修與租約資料
- 重新 Geocode 候選物件與門市地址
- 重建某日期區間的 Canonical Dataset 與 Feature Mart
- 查看資料品質失敗、來源延遲與欄位異常
- 發布新的 geo_grid_view 或 candidate_site_view 版本

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- IoT／內部資料底座：store、machine、transaction、machine status、member、price、promotion、repair ticket、customer support、lease、asset ledger
- 外部資料：人口、戶數、POI、道路、停車、租金、競店、行政區、天氣、學期、重大建設、出租物件
- 治理資料：資料來源授權、來源 owner、更新頻率、SLA、欄位口徑、品質規則

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- Canonical Tables：store、machine、transaction、member、candidate_site、listing、geo_cell、intervention、campaign、price_action、decision、outcome
- Source Snapshot 與 Raw Object
- Data Quality Report、Lineage Report、Source Freshness Dashboard
- Model-ready Views：geo_grid_view、candidate_site_view、store_machine_timeseries_view、intervention_panel_view、valuation_view、network_plan_view
- 事件：source.ingested、canonical.upserted、data_quality.failed、feature_mart.published

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 資料來源註冊、授權與連線設定 | MUST | ODP-FR-INT-001 |
| 2 | Batch／CDC／API／檔案匯入 | MUST | ODP-FR-INT-002 |
| 3 | Schema Validation 與欄位型別檢查 | MUST | ODP-FR-INT-003 |
| 4 | Source-to-Canonical Mapping | MUST | ODP-FR-INT-004 |
| 5 | Identity Resolution 與主鍵對位 | MUST | ODP-FR-INT-005 |
| 6 | Geocode、H3、等時圈與空間特徵產生 | MUST | ODP-FR-INT-006 |
| 7 | 資料品質 Gate、隔離區、重送、Backfill | MUST | ODP-FR-INT-007 |
| 8 | Feature Mart 發布與版本化 | MUST | ODP-FR-INT-008 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `REGISTERED` | REGISTERED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `CONFIGURED` | CONFIGURED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `TESTED` | TESTED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `ACTIVE` | 正式啟用 |
| `DEGRADED` | DEGRADED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SUSPENDED` | SUSPENDED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `RETIRED` | RETIRED 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `POST` | `/integration/sources` | 建立資料來源設定 |
| `GET` | `/integration/sources/{source_id}/status` | 查詢來源新鮮度與 SLA |
| `POST` | `/integration/ingest-jobs` | 建立匯入或重跑工作 |
| `GET` | `/integration/ingest-jobs/{job_id}` | 查詢工作進度 |
| `POST` | `/geo/geocode` | 地址解析與經緯度查詢 |
| `POST` | `/features/publish` | 發布 Feature Mart 或 Model-ready View 版本 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `source.ingested.v1` | Produced | source 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `source.ingestion_failed.v1` | Produced | source 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `canonical.upserted.v1` | Produced | canonical 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `canonical.mapping_failed.v1` | Produced | canonical 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `geocode.completed.v1` | Produced | geocode 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `data_quality.failed.v1` | Produced | data_quality 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `feature_mart.published.v1` | Produced | feature_mart 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `upstream.snapshot.available.v1` | Consumed | upstream 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `manual.backfill.requested.v1` | Consumed | manual 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `schema.contract.changed.v1` | Consumed | schema 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-00",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `source-adapter-worker` | source adapter worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `canonical-transform-worker` | canonical transform worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `geocode-worker` | geocode worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `h3-feature-worker` | h3 feature worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `poi-feature-worker` | poi feature worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `rent-feature-worker` | rent feature worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `competitor-feature-worker` | competitor feature worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `data-quality-worker` | data quality worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `feature-publish-worker` | feature publish worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `backfill-worker` | backfill worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `source_system` | source system，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `source_contract` | source contract，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `source_snapshot` | source snapshot，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `raw_record_index` | raw record index，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `canonical_mapping_rule` | canonical mapping rule，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `identity_resolution_map` | identity resolution map，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `canonical_import_run` | canonical import run，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `geocode_result` | geocode result，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `geo_feature_snapshot` | geo feature snapshot，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `data_quality_result` | data quality result，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `feature_mart_version` | feature mart version，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `geo_grid_view`
- `candidate_site_view`
- `store_machine_timeseries_view`
- `intervention_panel_view`
- `valuation_view`
- `network_plan_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

規則型轉換、Geocode 信心評分、地址去重、POI 去重、租金異常偵測、競店匹配、資料品質計分。第一版以透明規則與人工覆核為主；後續可加入 ML-based entity matching。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 資料來源清單 | 供使用者檢視、篩選、操作或核准「資料來源清單」相關資料，所有動作需經 API 與權限檢查 |
| 2 | 來源狀態與新鮮度看板 | 供使用者檢視、篩選、操作或核准「來源狀態與新鮮度看板」相關資料，所有動作需經 API 與權限檢查 |
| 3 | 匯入 Job 監控 | 供使用者檢視、篩選、操作或核准「匯入 Job 監控」相關資料，所有動作需經 API 與權限檢查 |
| 4 | Geocode 檢查頁 | 供使用者檢視、篩選、操作或核准「Geocode 檢查頁」相關資料，所有動作需經 API 與權限檢查 |
| 5 | 資料品質報告 | 供使用者檢視、篩選、操作或核准「資料品質報告」相關資料，所有動作需經 API 與權限檢查 |
| 6 | Feature Mart 發布紀錄 | 供使用者檢視、篩選、操作或核准「Feature Mart 發布紀錄」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- Integration Admin 可建立來源與修改 Mapping
- Data Owner 可核准 Canonical Schema 變更
- Model Owner 可申請 Feature Mart 發布
- 一般使用者不得查閱 Raw PII 或未遮罩交易明細

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-00-01 | 來源資料可重跑指定期間且結果具冪等性 |
| AC-00-02 | 每筆正式 Canonical 記錄可追溯至 source_system、source_record_id、source_snapshot_id |
| AC-00-03 | 資料品質失敗不得自動發布至 Production Model-ready View |
| AC-00-04 | Geocode 結果必須包含 confidence 與人工覆核狀態 |
| AC-00-05 | Feature Mart 發布必須產生版本、時間、來源 snapshot 與品質分數 |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
