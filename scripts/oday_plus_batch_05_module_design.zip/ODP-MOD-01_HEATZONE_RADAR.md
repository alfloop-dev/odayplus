---
doc_id: ODP-MOD-01
title: "HeatZone Radar 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Expansion Product Owner / Geo Model Owner"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# HeatZone Radar 模組詳細設計

## 1. 文件目的

HeatZone Radar 負責回答「全台哪些區域最值得優先展店」，以 H3／生活圈為分析單位，估計外部洗衣需求、競爭缺口、ODay G2 適配度、自家稀釋風險、租金可行性與需求吸收狀態。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 全台或指定縣市的空間單元建立與熱區評分
- 需求缺口、ODay G2 適配度、競店缺口、自家稀釋風險與租金可行性計算
- 熱區狀態 UNTOUCHED／PARTIALLY_ABSORBED／SATURATED／UNDER_REALIZED／STILL_EXPANDABLE
- 展店優先序、可解釋因子、Confidence 與熱區地圖輸出
- 將熱區結果提供 Listing Pipeline、SiteScore 與 NetPlan 使用

### 2.2 Out of Scope

- 不評估單一出租物件的水電、坪數、租約或裝修可行性
- 不直接核准展店
- 不以熱度顏色取代 SiteScore 的具體營收路徑預測

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-01]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 展店業務
- 展店主管
- 管理層
- GIS／資料團隊
- AI／模型團隊

### 3.2 核心使用情境

- 查看全台或縣市熱區地圖
- 依展店優先序指派業務找物件
- 查看某熱區的需求缺口與自家稀釋風險
- 比對新店開幕後熱區需求是否被吸收
- 將熱區清單送入 Listing Pipeline 產生找店任務

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- geo_grid_view
- ODay 既有店與競店位置
- Listing 活躍物件數
- 租金與可達性特徵
- SiteScore Realization 與新店實績
- 外部商圈變動資料

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- HeatZone Score、Priority Rank、Demand Gap、Format Fit、Competition Gap、Cannibalization Risk、Rent Feasibility、Confidence
- HeatZone State
- 推薦租金區間與建議店面條件
- 熱區任務與 Listing 搜尋範圍
- HeatZone Score Snapshot 與模型版本

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | H3 多尺度區域評分 | MUST | ODP-FR-HZ-001 |
| 2 | 透明加權 Baseline | MUST | ODP-FR-HZ-002 |
| 3 | Demand Model 批次評分 | MUST | ODP-FR-HZ-003 |
| 4 | 熱區狀態轉換 | MUST | ODP-FR-HZ-004 |
| 5 | 需求吸收監控 | MUST | ODP-FR-HZ-005 |
| 6 | 相鄰熱區合併與拆分 | MUST | ODP-FR-HZ-006 |
| 7 | Top-K 熱區推薦 | MUST | ODP-FR-HZ-007 |
| 8 | 地圖圖層與解釋因子 | MUST | ODP-FR-HZ-008 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `UNTOUCHED` | UNTOUCHED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `PARTIALLY_ABSORBED` | PARTIALLY_ABSORBED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SATURATED` | SATURATED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `UNDER_REALIZED` | UNDER_REALIZED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `STILL_EXPANDABLE` | STILL_EXPANDABLE 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SUPPRESSED_LOW_CONFIDENCE` | SUPPRESSED_LOW_CONFIDENCE 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `GET` | `/heatzones` | 查詢熱區清單與排序 |
| `GET` | `/heatzones/{h3_index}` | 查詢熱區詳情 |
| `POST` | `/heatzones/score-jobs` | 建立批次評分工作 |
| `GET` | `/heatzones/snapshots/{snapshot_id}` | 查詢熱區快照 |
| `POST` | `/heatzones/{h3_index}/assignments` | 建立業務找區任務 |
| `GET` | `/heatzones/{h3_index}/explanations` | 查詢特徵解釋與信心 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `heatzone.scored.v1` | Produced | heatzone 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `heatzone.state_changed.v1` | Produced | heatzone 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `heatzone.assignment_created.v1` | Produced | heatzone 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `heatzone.low_confidence_detected.v1` | Produced | heatzone 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `feature_mart.published.v1` | Consumed | feature_mart 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `store.opened.v1` | Consumed | store 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.realization_completed.v1` | Consumed | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `listing.market_changed.v1` | Consumed | listing 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-01",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `heatzone-feature-builder` | heatzone feature builder，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `heatzone-baseline-score` | heatzone baseline score，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `heatzone-ml-training` | heatzone ml training，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `heatzone-batch-score` | heatzone batch score，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `heatzone-state-updater` | heatzone state updater，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `heatzone-map-tile-builder` | heatzone map tile builder，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `heatzone_snapshot` | heatzone snapshot，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_score` | heatzone score，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_component_score` | heatzone component score，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_state_history` | heatzone state history，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_assignment` | heatzone assignment，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_model_run` | heatzone model run，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `heatzone_explanation` | heatzone explanation，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `geo_grid_view`
- `sitescore_realization_view`
- `network_plan_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

第一層為透明加權 Baseline：需求人口、POI、租金、競店、自家稀釋與 Listing 機會。第二層為 CatBoost／LightGBM Demand Model，輸出 P10／P50／P90 或分數區間。所有模型必須保存 snapshot time、model version、feature version 與 calibration 報告。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | HeatZone 全台地圖 | 供使用者檢視、篩選、操作或核准「HeatZone 全台地圖」相關資料，所有動作需經 API 與權限檢查 |
| 2 | 縣市／商圈排行榜 | 供使用者檢視、篩選、操作或核准「縣市／商圈排行榜」相關資料，所有動作需經 API 與權限檢查 |
| 3 | 熱區詳情抽屜 | 供使用者檢視、篩選、操作或核准「熱區詳情抽屜」相關資料，所有動作需經 API 與權限檢查 |
| 4 | 業務指派頁 | 供使用者檢視、篩選、操作或核准「業務指派頁」相關資料，所有動作需經 API 與權限檢查 |
| 5 | 需求吸收趨勢 | 供使用者檢視、篩選、操作或核准「需求吸收趨勢」相關資料，所有動作需經 API 與權限檢查 |
| 6 | 低信心熱區待覆核清單 | 供使用者檢視、篩選、操作或核准「低信心熱區待覆核清單」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 展店業務可查看與被指派區域
- 展店主管可指派熱區與修改優先序
- 管理層可查看全台策略視圖
- Model Owner 可發布 HeatZone 模型版本

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-01-01 | 熱區排序必須優於單純人口排序或人工 baseline |
| AC-01-02 | 每一個 Top-K 熱區必須顯示主要正負因子與 confidence |
| AC-01-03 | 熱區狀態變更必須有觸發來源與版本 |
| AC-01-04 | 低信心區不得直接用於自動任務指派 |
| AC-01-05 | HeatZone 結果必須可被 Listing 與 SiteScore 追溯使用 |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
