---
doc_id: ODP-MOD-04
title: "ForecastOps 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Operations Product Owner / Forecast Model Owner"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# ForecastOps 模組詳細設計

## 1. 文件目的

ForecastOps 負責開店後的店級與設備級營運預測，輸出 4／8／12／24 週成長軌跡、成長階段、轉折風險、SiteScore Gap、四燈與 Root Cause Evidence。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 店級與設備級時序特徵建立
- 4／8／12／24 週 P10／P50／P90 預測
- 成長／平台／衰退軌跡分類
- Change-point、CUSUM／EWMA 與異常偵測
- SiteScore Realization Monitor
- 四燈政策輸入與 Root Cause Candidate Ranking

### 2.2 Out of Scope

- 不直接改價、投廣告、發促銷或派維修
- 不估計廣告與價格因果效果
- 不決定門市退出或資產出售

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-04]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 營運主管
- 區域督導
- 加盟主
- AI／模型團隊
- 管理層

### 3.2 核心使用情境

- 查看門市未來 4／8／12／24 週營收與毛利軌跡
- 查看四燈與根因候選
- 追蹤新店是否符合 SiteScore 原始預測
- 建立干預建議或轉交 InterventionOps
- 回報誤報與實際原因

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- store_machine_timeseries_view
- forecast_training_view
- sitescore_realization_view
- 價格、廣告、促銷、維修、清潔與客服標籤
- 天氣、假日、學期與外部競店變動

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- Growth Forecast Output
- Alert Evidence Output
- Four-light Input
- Trajectory Class
- Turning Point Probability
- SiteScore Gap
- Root Cause Candidates
- Recommended Intervention Type

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 每日批次預測 | MUST | ODP-FR-FCT-001 |
| 2 | Seasonal Naive 與 StatsForecast baseline | MUST | ODP-FR-FCT-002 |
| 3 | Global MLForecast + CatBoost／LightGBM | MUST | ODP-FR-FCT-003 |
| 4 | 預測區間校準 | MUST | ODP-FR-FCT-004 |
| 5 | 軌跡分類 | MUST | ODP-FR-FCT-005 |
| 6 | Change-point 偵測 | MUST | ODP-FR-FCT-006 |
| 7 | 四燈計算 | MUST | ODP-FR-FCT-007 |
| 8 | Feedback 修正 | MUST | ODP-FR-FCT-008 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `NORMAL` | NORMAL 狀態，依本模組流程定義保存原因、時間與責任人 |
| `WATCH` | WATCH 狀態，依本模組流程定義保存原因、時間與責任人 |
| `WARNING` | WARNING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `CRITICAL` | CRITICAL 狀態，依本模組流程定義保存原因、時間與責任人 |
| `ACKNOWLEDGED` | ACKNOWLEDGED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `ACTION_RECOMMENDED` | ACTION_RECOMMENDED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `ESCALATED_TO_INTERVENTION` | ESCALATED_TO_INTERVENTION 狀態，依本模組流程定義保存原因、時間與責任人 |
| `FALSE_POSITIVE` | FALSE_POSITIVE 狀態，依本模組流程定義保存原因、時間與責任人 |
| `RESOLVED` | RESOLVED 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `GET` | `/forecastops/stores/{store_id}/forecast` | 查詢門市預測 |
| `GET` | `/forecastops/stores/{store_id}/alerts` | 查詢警示 |
| `GET` | `/forecastops/alerts` | 查詢全店警示清單 |
| `POST` | `/forecastops/alerts/{alert_id}/ack` | 確認警示 |
| `POST` | `/forecastops/alerts/{alert_id}/feedback` | 回報警示結果 |
| `POST` | `/forecastops/score-jobs` | 建立批次預測工作 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `forecast.scored.v1` | Produced | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.alert_created.v1` | Produced | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.alert_status_changed.v1` | Produced | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.intervention_recommended.v1` | Produced | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.feedback_recorded.v1` | Produced | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `store.daily_actual_ready.v1` | Consumed | store 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `machine.outage_detected.v1` | Consumed | machine 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `price.changed.v1` | Consumed | price 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `ad.campaign_started.v1` | Consumed | ad 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `intervention.executed.v1` | Consumed | intervention 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `model.released.v1` | Consumed | model 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-04",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `forecast-feature-worker` | forecast feature worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `forecast-baseline-worker` | forecast baseline worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `forecast-ml-training` | forecast ml training，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `forecast-batch-score` | forecast batch score，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `trajectory-classifier` | trajectory classifier，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `changepoint-worker` | changepoint worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `alert-engine` | alert engine，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `root-cause-worker` | root cause worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `forecast_run` | forecast run，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `store_forecast_path` | store forecast path，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `forecast_interval` | forecast interval，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `trajectory_state` | trajectory state，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `changepoint_result` | changepoint result，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `alert` | alert，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `alert_evidence` | alert evidence，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `alert_feedback` | alert feedback，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `root_cause_candidate` | root cause candidate，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `store_machine_timeseries_view`
- `forecast_training_view`
- `sitescore_realization_view`
- `intervention_panel_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

v1：Seasonal Naive、AutoARIMA／AutoETS／MSTL、MLForecast + CatBoost／LightGBM、Quantile／Conformal Calibration。v2：設備級序列、Trajectory Classifier、ruptures、CUSUM／EWMA、Deep Challenger。ForecastOps 輸出 Prediction 與 Evidence，Decision Layer 才產生四燈與處置建議。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 門市成長軌跡頁 | 供使用者檢視、篩選、操作或核准「門市成長軌跡頁」相關資料，所有動作需經 API 與權限檢查 |
| 2 | 四燈事件中心 | 供使用者檢視、篩選、操作或核准「四燈事件中心」相關資料，所有動作需經 API 與權限檢查 |
| 3 | Root Cause Evidence 面板 | 供使用者檢視、篩選、操作或核准「Root Cause Evidence 面板」相關資料，所有動作需經 API 與權限檢查 |
| 4 | SiteScore Gap 追蹤 | 供使用者檢視、篩選、操作或核准「SiteScore Gap 追蹤」相關資料，所有動作需經 API 與權限檢查 |
| 5 | 預測模型比較頁 | 供使用者檢視、篩選、操作或核准「預測模型比較頁」相關資料，所有動作需經 API 與權限檢查 |
| 6 | 誤報回饋頁 | 供使用者檢視、篩選、操作或核准「誤報回饋頁」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 營運主管可查看全店與指派處理
- 區域督導可處理轄區警示
- 加盟主只能查看自身門市可見資訊
- Model Owner 可管理模型但不得直接關閉業務警示

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-04-01 | 核心 horizon 預測需優於 Seasonal Naive baseline |
| AC-04-02 | P80／P90 區間需完成校準 |
| AC-04-03 | 橙／紅燈需有可追溯 Evidence Vector |
| AC-04-04 | 警示量不得超過營運團隊每日可處理容量門檻 |
| AC-04-05 | Feedback 必須可回寫 Label Registry 供後續改善 |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
