---
doc_id: ODP-MOD-11
title: "OpsBoard 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "OpsBoard Product Owner / Frontend Lead"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# OpsBoard 模組詳細設計

## 1. 文件目的

OpsBoard 是 ODay Plus 的統一工作台與治理入口，負責呈現各模組結果、承接任務、人工核准、操作留痕、稽核查詢、通知與角色化工作區。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 全平台 Shell、導覽、角色化工作區與任務中心
- HeatZone、Listing、SiteScore、ForecastOps、Intervention、PriceOps、AdLift、AVM、NetPlan、Learning Hub 等前端工作區
- 人工核准、Override Reason、Decision Card、Audit Trail
- 通知、工作流、報表匯出與查核證據
- 權限控管、資料可見範圍與加盟主入口

### 2.2 Out of Scope

- 不在前端實作模型、Solver 或資料清洗邏輯
- 不繞過 API 權限直接讀取資料庫
- 不允許前端狀態成為正式決策來源，正式狀態以後端工作流為準

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-11]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 展店業務
- 展店審查
- 營運主管
- 區域督導
- 行銷與定價團隊
- 財務／法務
- 管理層
- 加盟主
- AI／資料團隊
- 稽核人員
- 系統管理員

### 3.2 核心使用情境

- 查看個人待辦任務
- 在地圖查看熱區與物件
- 核准 SiteScore GO／WAIT／REJECT
- 處理四燈警示與干預案件
- 核准價格、廣告、估值或 NetPlan 方案
- 查看 Learning Hub 模型發布狀態
- 匯出查核證據與操作紀錄

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- 所有 Domain API
- Workflow Tasks
- Audit Log
- Notification Events
- RBAC／ABAC Policy
- Report／Data Room Objects

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- User Actions
- Approval Records
- Decision Cards
- Feedback
- Manual Overrides
- Audit Queries
- Export Requests
- Notification Acknowledgement

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 統一登入與角色化導覽 | MUST | ODP-FR-OPS-001 |
| 2 | 任務中心 | MUST | ODP-FR-OPS-002 |
| 3 | 地圖工作區 | MUST | ODP-FR-OPS-003 |
| 4 | 評分卡與報告檢視 | MUST | ODP-FR-OPS-004 |
| 5 | 核准工作流 | MUST | ODP-FR-OPS-005 |
| 6 | 四燈與干預中心 | MUST | ODP-FR-OPS-006 |
| 7 | 方案比較與甘特圖 | MUST | ODP-FR-OPS-007 |
| 8 | Learning Hub 管理頁 | MUST | ODP-FR-OPS-008 |
| 9 | Audit Explorer | MUST | ODP-FR-OPS-009 |
| 10 | 報表與證據匯出 | MUST | ODP-FR-OPS-010 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `UI_DRAFT` | UI_DRAFT 狀態，依本模組流程定義保存原因、時間與責任人 |
| `FORM_VALIDATING` | FORM_VALIDATING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SUBMITTING` | SUBMITTING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SUBMITTED` | 已提交，等待系統或人工處理 |
| `APPROVAL_PENDING` | APPROVAL_PENDING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `APPROVED` | 已核准，可進入下一步 |
| `REJECTED` | 已拒絕，需保存原因 |
| `FAILED` | 處理失敗 |
| `READ_ONLY` | READ_ONLY 狀態，依本模組流程定義保存原因、時間與責任人 |
| `LOCKED_BY_WORKFLOW` | LOCKED_BY_WORKFLOW 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `GET` | `/opsboard/me` | 取得使用者與權限 |
| `GET` | `/opsboard/tasks` | 取得待辦任務 |
| `POST` | `/opsboard/tasks/{task_id}/actions` | 提交任務動作 |
| `GET` | `/opsboard/audit` | 查詢稽核紀錄 |
| `POST` | `/opsboard/exports` | 建立匯出工作 |
| `GET` | `/opsboard/notifications` | 查詢通知 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `opsboard.user_action_recorded.v1` | Produced | opsboard 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `approval.submitted.v1` | Produced | approval 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `override.reason_recorded.v1` | Produced | override 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `feedback.submitted.v1` | Produced | feedback 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `export.requested.v1` | Produced | export 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `notification.acknowledged.v1` | Produced | notification 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `workflow.task_created.v1` | Consumed | workflow 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `workflow.task_escalated.v1` | Consumed | workflow 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.alert_created.v1` | Consumed | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.scored.v1` | Consumed | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `intervention.approved.v1` | Consumed | intervention 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `model.released.v1` | Consumed | model 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `audit.event_recorded.v1` | Consumed | audit 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-11",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `report-export-worker` | report export worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `evidence-package-worker` | evidence package worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `notification-worker` | notification worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `audit-index-worker` | audit index worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `frontend-sourcemap-release-worker` | frontend sourcemap release worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `user_workspace_preference` | user workspace preference，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `opsboard_task_view` | opsboard task view，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `user_action_log` | user action log，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `approval_action` | approval action，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `manual_override` | manual override，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `notification` | notification，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `export_job` | export job，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `audit_query_log` | audit query log，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `All domain read models via API only; frontend must not directly consume raw DB tables`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

OpsBoard 無 ML 模型。核心邏輯為 UI 狀態、表單驗證、權限 guard、BFF aggregation、workflow action mapping 與 audit evidence rendering。所有業務規則必須在後端 Domain API 或 Workflow 中驗證，前端驗證只作為 UX 輔助。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 首頁與任務中心 | 供使用者檢視、篩選、操作或核准「首頁與任務中心」相關資料，所有動作需經 API 與權限檢查 |
| 2 | HeatZone 地圖 | 供使用者檢視、篩選、操作或核准「HeatZone 地圖」相關資料，所有動作需經 API 與權限檢查 |
| 3 | Listing 工作台 | 供使用者檢視、篩選、操作或核准「Listing 工作台」相關資料，所有動作需經 API 與權限檢查 |
| 4 | SiteScore 評分卡 | 供使用者檢視、篩選、操作或核准「SiteScore 評分卡」相關資料，所有動作需經 API 與權限檢查 |
| 5 | ForecastOps 四燈中心 | 供使用者檢視、篩選、操作或核准「ForecastOps 四燈中心」相關資料，所有動作需經 API 與權限檢查 |
| 6 | Intervention 案件頁 | 供使用者檢視、篩選、操作或核准「Intervention 案件頁」相關資料，所有動作需經 API 與權限檢查 |
| 7 | PriceOps 方案頁 | 供使用者檢視、篩選、操作或核准「PriceOps 方案頁」相關資料，所有動作需經 API 與權限檢查 |
| 8 | AdLift 報告頁 | 供使用者檢視、篩選、操作或核准「AdLift 報告頁」相關資料，所有動作需經 API 與權限檢查 |
| 9 | DealRoomAVM 資料室 | 供使用者檢視、篩選、操作或核准「DealRoomAVM 資料室」相關資料，所有動作需經 API 與權限檢查 |
| 10 | NetPlan 情境頁 | 供使用者檢視、篩選、操作或核准「NetPlan 情境頁」相關資料，所有動作需經 API 與權限檢查 |
| 11 | Learning Hub | 供使用者檢視、篩選、操作或核准「Learning Hub」相關資料，所有動作需經 API 與權限檢查 |
| 12 | Audit Explorer | 供使用者檢視、篩選、操作或核准「Audit Explorer」相關資料，所有動作需經 API 與權限檢查 |
| 13 | 系統管理 | 供使用者檢視、篩選、操作或核准「系統管理」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 前端路由必須套用 RBAC／ABAC guard
- 資料查詢必須依 tenant／brand／region／store scope 過濾
- 高風險動作必須要求二次確認與後端核准
- 加盟主入口只能查看自身門市與授權報告

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-11-01 | 所有使用者動作必須產生 user_action_log 或 audit event |
| AC-11-02 | 前端不得直接連資料庫或模型檔案 |
| AC-11-03 | 每個核准頁必須顯示模型版本、主要依據與風險 |
| AC-11-04 | Override 必須填寫原因 |
| AC-11-05 | Audit Explorer 必須可依 actor、entity、time、decision、model_version 查詢 |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
