---
doc_id: ODP-MOD-09
title: "NetPlan 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Network Planning Product Owner / OR Model Owner"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# NetPlan 模組詳細設計

## 1. 文件目的

NetPlan 負責店網重配與多期規劃，將 HeatZone、SiteScore、ForecastOps、AVM、資本、租約、人力、施工、設備與稀釋限制整合為 OPEN／KEEP／IMPROVE／MOVE／EXIT 方案。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 年度／季度 Network Planning Scenario
- OPEN／KEEP／IMPROVE／MOVE／EXIT 候選行動
- 資本、租約、施工、人力、設備、保底資金、自家稀釋等硬限制
- OR-Tools CP-SAT 求解與 Alternative Plans
- Solver Status、Binding Constraints、Infeasibility Explanation
- 管理層核准與 90／180／365 日 Outcome 回收

### 2.2 Out of Scope

- 不任意放寬硬限制產生不可執行方案
- 不取代管理層最終資本配置決策
- 不在估值或 SiteScore 未校準時啟用 Robust 高階情境

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-09]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 管理層
- 展店主管
- 營運主管
- 財務
- 法務
- OR／AI 團隊

### 3.2 核心使用情境

- 建立季度店網規劃情境
- 比較新開、留守、改善、遷點、退出方案
- 查看資本與租約限制下最優方案
- 查看替代方案與不可行診斷
- 核准年度／季度 RoutePlan
- 追蹤執行後 Outcome

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- network_plan_view
- HeatZone Priority
- SiteScore candidate paths
- ForecastOps future GM
- AVM Fair／Reserve Price
- 租約與施工時程
- 資本預算、人力、設備庫存、品牌策略限制

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- Network Plan Scenario
- Recommended Actions
- Quarterly Gantt
- Objective Value
- Constraint Report
- Alternative Plans
- Infeasibility Diagnosis
- Approved RoutePlan
- Outcome Tracking

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 情境建立 | MUST | ODP-FR-NET-001 |
| 2 | 候選行動生成 | MUST | ODP-FR-NET-002 |
| 3 | 限制條件建模 | MUST | ODP-FR-NET-003 |
| 4 | CP-SAT 求解 | MUST | ODP-FR-NET-004 |
| 5 | 替代方案產生 | MUST | ODP-FR-NET-005 |
| 6 | 不可行診斷 | MUST | ODP-FR-NET-006 |
| 7 | 季度甘特圖 | MUST | ODP-FR-NET-007 |
| 8 | 管理層核准 | MUST | ODP-FR-NET-008 |
| 9 | Outcome 回收 | MUST | ODP-FR-NET-009 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `DRAFT` | 草稿，尚未提交或尚未完整設定 |
| `INPUT_VALIDATING` | INPUT_VALIDATING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `READY_TO_SOLVE` | READY_TO_SOLVE 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SOLVING` | SOLVING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `SOLVED` | SOLVED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `INFEASIBLE` | INFEASIBLE 狀態，依本模組流程定義保存原因、時間與責任人 |
| `EXPLAINING` | EXPLAINING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `UNDER_REVIEW` | 人工審查中 |
| `APPROVED` | 已核准，可進入下一步 |
| `REJECTED` | 已拒絕，需保存原因 |
| `EXECUTING` | EXECUTING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `OUTCOME_TRACKING` | OUTCOME_TRACKING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `CLOSED` | CLOSED 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `POST` | `/netplan/scenarios` | 建立規劃情境 |
| `GET` | `/netplan/scenarios/{scenario_id}` | 查詢情境 |
| `POST` | `/netplan/scenarios/{scenario_id}/solve` | 執行求解 |
| `GET` | `/netplan/scenarios/{scenario_id}/plans` | 查詢方案 |
| `GET` | `/netplan/scenarios/{scenario_id}/infeasibility` | 查詢不可行診斷 |
| `POST` | `/netplan/plans/{plan_id}/approve` | 核准方案 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `netplan.scenario_created.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.solve_started.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.solved.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.infeasible.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.plan_approved.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.action_due.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `netplan.outcome_collected.v1` | Produced | netplan 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `heatzone.scored.v1` | Consumed | heatzone 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.scored.v1` | Consumed | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.scored.v1` | Consumed | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `avm.valued.v1` | Consumed | avm 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `lease.updated.v1` | Consumed | lease 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `budget.updated.v1` | Consumed | budget 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-09",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `scenario-builder` | scenario builder，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `netplan-input-validator` | netplan input validator，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `netplan-model-builder` | netplan model builder，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `netplan-cpsat-solver` | netplan cpsat solver，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `alternative-plan-worker` | alternative plan worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `solver-explain-worker` | solver explain worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `infeasibility-worker` | infeasibility worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `netplan-outcome-worker` | netplan outcome worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `network_scenario` | network scenario，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_candidate_action` | network candidate action，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_constraint` | network constraint，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_solver_run` | network solver run，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_plan` | network plan，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_plan_action` | network plan action，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_plan_alternative` | network plan alternative，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_infeasibility` | network infeasibility，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_plan_approval` | network plan approval，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `network_plan_outcome` | network plan outcome，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `network_plan_view`
- `geo_grid_view`
- `candidate_site_view`
- `valuation_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

v1 採 P50 Deterministic CP-SAT：最大化未來總毛利或風險調整價值，滿足資本、租約、人力、施工、設備、自家稀釋、最低覆蓋與時間窗限制。v2 加入 Downside／Base／Upside、Rolling Horizon、Robust／Stochastic Optimization。無可行解時必須產生診斷而非任意放寬硬限制。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 情境設定頁 | 供使用者檢視、篩選、操作或核准「情境設定頁」相關資料，所有動作需經 API 與權限檢查 |
| 2 | 候選行動清單 | 供使用者檢視、篩選、操作或核准「候選行動清單」相關資料，所有動作需經 API 與權限檢查 |
| 3 | Solver 結果頁 | 供使用者檢視、篩選、操作或核准「Solver 結果頁」相關資料，所有動作需經 API 與權限檢查 |
| 4 | 季度甘特圖 | 供使用者檢視、篩選、操作或核准「季度甘特圖」相關資料，所有動作需經 API 與權限檢查 |
| 5 | Alternative Plans | 供使用者檢視、篩選、操作或核准「Alternative Plans」相關資料，所有動作需經 API 與權限檢查 |
| 6 | Binding Constraints | 供使用者檢視、篩選、操作或核准「Binding Constraints」相關資料，所有動作需經 API 與權限檢查 |
| 7 | 不可行診斷頁 | 供使用者檢視、篩選、操作或核准「不可行診斷頁」相關資料，所有動作需經 API 與權限檢查 |
| 8 | 管理層核准頁 | 供使用者檢視、篩選、操作或核准「管理層核准頁」相關資料，所有動作需經 API 與權限檢查 |
| 9 | Outcome 追蹤頁 | 供使用者檢視、篩選、操作或核准「Outcome 追蹤頁」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 管理層可核准最終方案
- 財務可維護資本與成本限制
- 法務可維護租約限制
- OR Model Owner 可管理 Solver 版本但不得直接核准方案

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-09-01 | NetPlan 方案必須 100% 滿足硬限制 |
| AC-09-02 | 每次求解必須保存輸入 snapshot、solver version 與 status |
| AC-09-03 | 至少提供維持現況或 Greedy baseline 比較 |
| AC-09-04 | 不可行時必須輸出最主要衝突限制 |
| AC-09-05 | 核准方案必須產生 90／180／365 日 Outcome 回收任務 |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
