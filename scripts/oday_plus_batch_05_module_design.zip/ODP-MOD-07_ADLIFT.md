---
doc_id: ODP-MOD-07
title: "AdLift 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Marketing Product Owner / Causal Model Owner"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# AdLift 模組詳細設計

## 1. 文件目的

AdLift 負責判斷哪些門市適合投放廣告，建立實驗店與對照店，估計廣告增量營收與增量毛利，計算 iROMI，並產生 Continue／Stop／Adjust 建議。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- Ad Need Score 與投放候選門市
- Campaign 設定、渠道、預算、期間與素材紀錄
- Matched Controls、Pre-trend Check、DiD／Synthetic Control
- Incremental Revenue、Incremental Gross Margin、iROMI
- 活動結束後效果報告與 Evidence Level
- 將廣告 Treatment 回寫 InterventionOps 與 Label Registry

### 2.2 Out of Scope

- 不以 ROAS 單獨判定有效
- 不在 pre-trend 失敗時宣稱因果
- 不覆蓋行銷平台的投放執行細節

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-07]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 行銷團隊
- 營運主管
- 區域督導
- 加盟主
- AI／因果模型團隊

### 3.2 核心使用情境

- 挑選適合投廣告門市
- 建立活動與預算
- 匹配對照組
- 檢查投放前趨勢
- 活動期間追蹤表面指標
- 活動後產生增量毛利與 iROMI 報告

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- matched_control_view
- intervention_panel_view
- store_machine_timeseries_view
- Campaign Spend、Channel、Creative、Audience、Start／End
- ForecastOps Alert 與營運狀態
- 地理、區位、店齡與季節特徵

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- Ad Need Score
- Campaign Candidate List
- Matched Control Set
- Pre-trend Result
- Ad Incrementality Estimate
- Incremental GM
- iROMI
- Continue／Stop／Adjust Recommendation

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 廣告需求評分 | MUST | ODP-FR-AD-001 |
| 2 | 活動設定 | MUST | ODP-FR-AD-002 |
| 3 | 對照組搜尋 | MUST | ODP-FR-AD-003 |
| 4 | Pre-trend 檢查 | MUST | ODP-FR-AD-004 |
| 5 | DiD 效果估計 | MUST | ODP-FR-AD-005 |
| 6 | iROMI 計算 | MUST | ODP-FR-AD-006 |
| 7 | Evidence Level | MUST | ODP-FR-AD-007 |
| 8 | 活動後報告 | MUST | ODP-FR-AD-008 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `DRAFT` | 草稿，尚未提交或尚未完整設定 |
| `CONTROL_MATCHING` | CONTROL_MATCHING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `PRETREND_CHECKING` | PRETREND_CHECKING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `PRETREND_FAILED` | PRETREND_FAILED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `READY_FOR_APPROVAL` | READY_FOR_APPROVAL 狀態，依本模組流程定義保存原因、時間與責任人 |
| `APPROVED` | 已核准，可進入下一步 |
| `RUNNING` | 執行中 |
| `OBSERVING` | OBSERVING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `EVALUATING` | EVALUATING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `CONTINUE` | CONTINUE 狀態，依本模組流程定義保存原因、時間與責任人 |
| `STOP` | STOP 狀態，依本模組流程定義保存原因、時間與責任人 |
| `ADJUST` | ADJUST 狀態，依本模組流程定義保存原因、時間與責任人 |
| `CLOSED` | CLOSED 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `GET` | `/adlift/opportunities` | 查詢廣告投放候選 |
| `POST` | `/adlift/campaigns` | 建立活動 |
| `POST` | `/adlift/campaigns/{campaign_id}/match-controls` | 匹配對照組 |
| `GET` | `/adlift/campaigns/{campaign_id}/pretrend` | 查詢 pre-trend |
| `POST` | `/adlift/campaigns/{campaign_id}/evaluate` | 評估效果 |
| `GET` | `/adlift/campaigns/{campaign_id}/report` | 查詢報告 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `adlift.opportunity_detected.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `adlift.control_matched.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `adlift.pretrend_failed.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `adlift.campaign_approved.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `adlift.campaign_started.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `adlift.effect_evaluated.v1` | Produced | adlift 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `intervention.created.v1` | Consumed | intervention 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `campaign.spend_updated.v1` | Consumed | campaign 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `store.daily_actual_ready.v1` | Consumed | store 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `forecast.alert_created.v1` | Consumed | forecast 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `promotion.executed.v1` | Consumed | promotion 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-07",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `ad-need-score-worker` | ad need score worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `control-matching-worker` | control matching worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `pretrend-check-worker` | pretrend check worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `adlift-did-estimator` | adlift did estimator，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `synthetic-control-worker` | synthetic control worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `adlift-report-worker` | adlift report worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `ad_opportunity` | ad opportunity，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_campaign` | ad campaign，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_campaign_store` | ad campaign store，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_control_match` | ad control match，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_pretrend_result` | ad pretrend result，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_effect_estimate` | ad effect estimate，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `adlift_report` | adlift report，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `ad_evidence_level` | ad evidence level，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `matched_control_view`
- `intervention_panel_view`
- `store_machine_timeseries_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

v1 使用 Matched Controls + Difference-in-Differences，必要時搭配 Synthetic Control。輸出以 Incremental Gross Margin 與 iROMI 為核心。v2 可加入 Uplift／HTE；MMM 需多渠道、長期間、預算變化與共線性可控後才啟用。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 投放機會清單 | 供使用者檢視、篩選、操作或核准「投放機會清單」相關資料，所有動作需經 API 與權限檢查 |
| 2 | Campaign 設定頁 | 供使用者檢視、篩選、操作或核准「Campaign 設定頁」相關資料，所有動作需經 API 與權限檢查 |
| 3 | 對照組與 pre-trend 頁 | 供使用者檢視、篩選、操作或核准「對照組與 pre-trend 頁」相關資料，所有動作需經 API 與權限檢查 |
| 4 | 活動進行中監控 | 供使用者檢視、篩選、操作或核准「活動進行中監控」相關資料，所有動作需經 API 與權限檢查 |
| 5 | 增量效果報告 | 供使用者檢視、篩選、操作或核准「增量效果報告」相關資料，所有動作需經 API 與權限檢查 |
| 6 | iROMI 與 Continue／Stop 建議頁 | 供使用者檢視、篩選、操作或核准「iROMI 與 Continue／Stop 建議頁」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 行銷團隊可建立活動與上傳成本
- 營運主管可核准門市級投放
- 加盟主可查看自身門市活動與結果
- Model Owner 可發布因果模型但不得自行宣稱活動成功

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-07-01 | 每個廣告活動必須保存渠道、預算、期間與 Treatment 範圍 |
| AC-07-02 | Pre-trend 未通過時不得產生高 Evidence Level |
| AC-07-03 | 報告必須分開表面營收、增量營收與增量毛利 |
| AC-07-04 | iROMI 必須使用增量毛利而非單純營收 |
| AC-07-05 | 活動結果必須回寫 InterventionOps 與 Label Registry |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
