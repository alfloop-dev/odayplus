---
doc_id: ODP-MOD-03
title: "SiteScore 模組詳細設計"
version: 0.1.0
status: draft-for-review
document_class: module-detailed-design
batch: 5
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Expansion Product Owner / SiteScore Model Owner"
approvers: "Product Owner / Architecture Owner / Data Owner / Model Owner / Security Owner"
content_format: markdown
---


# SiteScore 模組詳細設計

## 1. 文件目的

SiteScore 負責回答「某個具體出租物件是否適合開 ODay G2」，輸出 M1／M3／M6／M12 與成熟期的營收路徑、P10／P50／P90、回本期、租金合理性、自家稀釋、Comparable Stores、Feasibility Rules 與 GO／WAIT／REJECT 建議。

本文件將該模組落到可實作的 SD 層級，明確定義模組邊界、使用者、輸入輸出、功能、狀態機、API、Event、Batch／Worker、資料表、Model-ready Views、模型／規則／Solver、前端畫面、權限、稽核、例外處理、效能與驗收條件。


## 0. 文件基線與引用規則

本文件屬於第 5 批「模組詳細設計」正式交付文件，必須與前四批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模組定位與責任邊界

### 2.1 In Scope

- 候選物件評分與報告產生
- External Demand、ODay Brand Transfer、G2 Format Conversion、Ramp、Seasonality
- 營收路徑與預測區間
- Feasibility Rules 與硬性條件檢查
- Comparable Stores、主要正負因子、信心與人工核准
- 開店後 M1／M3／M6／M12 Realization 回收

### 2.2 Out of Scope

- 不自動核准開店或簽約
- 不取代現場勘查與法務租約審查
- 不將未成熟實績回灌訓練

### 2.3 上下游關係

```mermaid
flowchart LR
  UP[上游資料／事件／人工輸入] --> MOD[ODP-MOD-03]
  MOD --> API[Domain API]
  MOD --> EVT[Domain Events]
  MOD --> DB[(Module Tables / Read Models)]
  MOD --> VIEW[Model-ready Views / Feature Marts]
  MOD --> OPS[OpsBoard / Workflow / Audit]
  OPS --> USER[使用者與核准者]
```

## 3. 使用者與使用情境

### 3.1 主要使用者

- 展店審查人員
- 展店主管
- 管理層
- 財務
- 法務
- AI／模型團隊

### 3.2 核心使用情境

- 提交候選物件評分
- 查看 SiteScore 評分卡與報告
- 比較多個候選地點
- 人工核准 GO／WAIT／REJECT
- 追蹤開店後 Realization Ratio
- 回溯某次決策使用的模型與特徵版本

### 3.3 使用者責任原則

1. 模型輸出、系統建議、人工核准、實際執行與實際結果必須分開保存。
2. 任何高風險動作都必須經由 Workflow 產生任務與核准紀錄。
3. 使用者只能在授權的品牌、區域、門市、任務與資料範圍內操作。
4. 使用者 override 系統建議時必須填寫原因，並進入 Audit Trail。

## 4. 輸入資料與前置依賴

- candidate_site_view
- brand_transfer_view
- ramp_curve_view
- geo_grid_view
- ODay G2 固定配置
- 設備與裝修成本假設
- 租金與租約條件
- Comparable Store 資料

### 4.1 最低資料品質要求

| 類別 | 要求 |
|---|---|
| 主鍵 | 所有輸入必須能對位至 Canonical ID 或保留 source id 與 mapping 狀態 |
| 時間 | 必須區分 event_time、observation_time、decision_time、outcome_time；模型資料必須符合 point-in-time correctness |
| 來源 | 每筆正式資料必須有 source_system、source_snapshot_id 或等價 lineage |
| 品質 | 資料完整度、新鮮度、唯一性、有效性未達門檻時，模組必須降級、阻擋或標示低信心 |
| 權限 | 涉及個資、交易明細或商業敏感資料時，必須依資料分類套用遮罩與存取控管 |

## 5. 輸出與下游消費者

- M1／M3／M6／M12／Mature P10／P50／P90
- 回本期區間
- SiteScore Composite Score
- GO／WAIT／REJECT／INVESTIGATE 建議
- Feasibility Result
- Comparable Stores
- SiteScore Report
- Realization Ratio

### 5.1 輸出契約原則

1. 所有 Prediction Output 必須包含 `model_version`、`feature_version`、`prediction_origin_time`、`horizon` 與 `confidence`。
2. 所有 Decision Output 必須包含 `decision_id`、`policy_version`、`actor_id`、`approved_at` 與 `decision_reason`。
3. 所有 Execution Output 必須包含 `execution_id`、`executed_at`、`executor`、`status` 與 `correlation_id`。
4. 所有 Outcome Output 必須包含 `outcome_window`、`label_maturity_time`、`measurement_method` 與 `evidence_level`。

## 6. 功能清單

| 序號 | 功能 | 優先級 | Trace |
|---:|---|---|---|
| 1 | 候選點同步或非同步評分 | MUST | ODP-FR-SITE-001 |
| 2 | 營收路徑預測 | MUST | ODP-FR-SITE-002 |
| 3 | 租金合理性與回本期計算 | MUST | ODP-FR-SITE-003 |
| 4 | Feasibility Rules | MUST | ODP-FR-SITE-004 |
| 5 | Comparable Retrieval | MUST | ODP-FR-SITE-005 |
| 6 | 模型解釋與信心 | MUST | ODP-FR-SITE-006 |
| 7 | 人工核准與 Decision Card | MUST | ODP-FR-SITE-007 |
| 8 | 開店後 Outcome 回收 | MUST | ODP-FR-SITE-008 |

## 7. 狀態機

| 狀態 | 說明 |
|---|---|
| `DRAFT` | 草稿，尚未提交或尚未完整設定 |
| `SUBMITTED` | 已提交，等待系統或人工處理 |
| `SCORING` | 評分或推論中 |
| `SCORE_READY` | 評分完成，可進入審查 |
| `UNDER_REVIEW` | 人工審查中 |
| `APPROVED_GO` | APPROVED_GO 狀態，依本模組流程定義保存原因、時間與責任人 |
| `WAIT` | WAIT 狀態，依本模組流程定義保存原因、時間與責任人 |
| `REJECTED` | 已拒絕，需保存原因 |
| `EXPIRED` | 逾期或失效 |
| `OPENED` | OPENED 狀態，依本模組流程定義保存原因、時間與責任人 |
| `REALIZATION_TRACKING` | REALIZATION_TRACKING 狀態，依本模組流程定義保存原因、時間與責任人 |
| `REALIZATION_COMPLETED` | REALIZATION_COMPLETED 狀態，依本模組流程定義保存原因、時間與責任人 |

### 7.1 狀態轉換規則

1. 狀態轉換必須由 Domain API 或 Workflow Action 觸發，不得由前端直接改資料庫。
2. 每次狀態轉換必須寫入 `status_history` 類資料表，包含前狀態、後狀態、actor、reason、timestamp 與 correlation_id。
3. 失敗、取消、逾期、低信心與人工覆核狀態不得被靜默略過。
4. 批次或非同步工作重送時必須具備 idempotency key，避免重複產生結果。

## 8. API 設計

| Method | Endpoint | 說明 |
|---|---|---|
| `POST` | `/sitescore/evaluations` | 建立 SiteScore 評估 |
| `GET` | `/sitescore/evaluations/{evaluation_id}` | 查詢評估結果 |
| `POST` | `/sitescore/evaluations/{evaluation_id}/approve` | 提交人工核准 |
| `POST` | `/sitescore/evaluations/{evaluation_id}/report` | 產生報告 |
| `GET` | `/sitescore/evaluations/{evaluation_id}/comparables` | 查詢相似店 |
| `GET` | `/sitescore/realizations/{store_id}` | 查詢實績達成 |

### 8.1 API 共用要求

| 項目 | 規格 |
|---|---|
| Auth | OAuth2／OIDC JWT；Service-to-Service 使用 service account |
| Authorization | RBAC + ABAC；至少依 tenant、brand、region、store、role、action 判斷 |
| Idempotency | 建立工作、核准、執行與匯入類 API 必須支援 idempotency key |
| Pagination | 清單 API 必須支援 cursor 或 page token |
| Error Format | 使用平台統一錯誤格式：`code`、`message`、`details`、`correlation_id` |
| Audit | 會改變狀態或產生決策的 API 必須寫入 Audit Trail |

## 9. Event 與訊息契約

### 9.1 Produced Events

| Event | Direction | 說明 |
|---|---|---|
| `sitescore.requested.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.scored.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.approved.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.rejected.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `site.opening_decision_recorded.v1` | Produced | site 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.realization_due.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `sitescore.realization_completed.v1` | Produced | sitescore 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.2 Consumed Events

| Event | Direction | 說明 |
|---|---|---|
| `candidate_site.created.v1` | Consumed | candidate_site 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `feature_mart.published.v1` | Consumed | feature_mart 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `store.opened.v1` | Consumed | store 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `store.monthly_actual_matured.v1` | Consumed | store 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |
| `model.released.v1` | Consumed | model 領域事件；payload 必須包含 entity_id、status/version、correlation_id 與發生時間 |

### 9.3 Event 共用要求

事件 payload 必須包含：

```json
{
  "event_id": "uuid",
  "event_type": "domain.event_name.v1",
  "event_version": "1",
  "occurred_at": "2026-06-26T00:00:00+08:00",
  "producer": "ODP-MOD-03",
  "correlation_id": "uuid",
  "idempotency_key": "domain-entity-action-version",
  "tenant_id": "tenant",
  "entity_type": "module_entity",
  "entity_id": "id",
  "payload": {}
}
```

## 10. Batch／Worker／Job 設計

| Job／Worker | 責任 | 類型 |
|---|---|---|
| `sitescore-score-worker` | sitescore score worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `external-demand-score-worker` | external demand score worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `brand-transfer-worker` | brand transfer worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `format-conversion-worker` | format conversion worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `ramp-curve-worker` | ramp curve worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `comparable-search-worker` | comparable search worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `sitescore-report-worker` | sitescore report worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |
| `sitescore-realization-worker` | sitescore realization worker，負責對應資料處理、模型計算、狀態更新或報告產生 | Batch／Worker |

### 10.1 Job 狀態

所有 Job 必須使用平台標準狀態：`QUEUED`、`RUNNING`、`SUCCEEDED`、`FAILED`、`CANCELLED`、`PARTIAL`、`RETRYING`。Job 結果必須保存 input snapshot、output location、error summary、started_at、ended_at、worker_version。

## 11. 資料設計

### 11.1 模組資料表

| Table | 說明 |
|---|---|
| `sitescore_evaluation` | sitescore evaluation，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_prediction_path` | sitescore prediction path，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_feasibility_result` | sitescore feasibility result，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_comparable` | sitescore comparable，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_decision` | sitescore decision，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_report` | sitescore report，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `sitescore_realization` | sitescore realization，保存本模組核心狀態、輸入輸出、版本或稽核資料 |
| `site_opening_outcome` | site opening outcome，保存本模組核心狀態、輸入輸出、版本或稽核資料 |

### 11.2 使用的 Model-ready Views

- `candidate_site_view`
- `brand_transfer_view`
- `ramp_curve_view`
- `geo_grid_view`
- `sitescore_realization_view`

### 11.3 資料保存與版本化

1. 模組核心決策資料不得 hard delete；必須用 status 或 valid_to 表示失效。
2. 模型輸出、核准、執行、Outcome 與 Audit 需保留至少符合補助查核、公司治理與營運追溯的保存期間。
3. 涉及個資的欄位必須支援遮罩、刪除請求或去識別化策略。
4. 所有報告與資料室檔案必須保留 object version 與 hash。

## 12. 模型／規則／Solver 設計

SiteScore 由 External Demand × BrandCapture × FormatConversion × RampCurve × Seasonality 組成。第一版可用固定 ODay 校正與簡化 Ramp；正式版需支援 Brand Transfer Matrix、階層式收縮、Conformal Calibration 與 Comparable Retrieval。輸出不得只給單一營收數字，必須給路徑與區間。

### 12.1 模型與規則治理

| 項目 | 要求 |
|---|---|
| Version | 每次模型、規則、Solver 或政策變更必須有版本 |
| Backtest | Production 前必須有 backtest 或等價驗證 |
| Explainability | 使用者可見結果必須提供主要因子、信心或限制說明 |
| Rollback | 模型與業務決策 rollback 必須分開設計 |
| Data Leakage | 訓練資料必須符合 point-in-time correctness |

## 13. 前端畫面與互動

| 序號 | 畫面 | 說明 |
|---:|---|---|
| 1 | 候選物件評分卡 | 供使用者檢視、篩選、操作或核准「候選物件評分卡」相關資料，所有動作需經 API 與權限檢查 |
| 2 | 營收路徑圖 | 供使用者檢視、篩選、操作或核准「營收路徑圖」相關資料，所有動作需經 API 與權限檢查 |
| 3 | P10／P50／P90 區間 | 供使用者檢視、篩選、操作或核准「P10／P50／P90 區間」相關資料，所有動作需經 API 與權限檢查 |
| 4 | 回本期與租金合理性 | 供使用者檢視、篩選、操作或核准「回本期與租金合理性」相關資料，所有動作需經 API 與權限檢查 |
| 5 | Comparable Stores | 供使用者檢視、篩選、操作或核准「Comparable Stores」相關資料，所有動作需經 API 與權限檢查 |
| 6 | GO／WAIT／REJECT 核准頁 | 供使用者檢視、篩選、操作或核准「GO／WAIT／REJECT 核准頁」相關資料，所有動作需經 API 與權限檢查 |
| 7 | Realization 追蹤頁 | 供使用者檢視、篩選、操作或核准「Realization 追蹤頁」相關資料，所有動作需經 API 與權限檢查 |

### 13.1 UI 共用規則

1. 所有列表必須支援搜尋、篩選、排序、匯出權限控管與空狀態。
2. 所有高風險動作必須二次確認，並顯示影響範圍。
3. 所有模型或方案結果頁必須顯示版本、資料時間、信心與主要限制。
4. 前端不得直接連資料庫；必須透過 API 或 BFF。

## 14. 權限與資料保護

- 展店審查可提交評估與撰寫審查意見
- 展店主管可核准 GO／WAIT／REJECT
- 財務可查看回本期與成本假設
- Model Owner 可發布模型但不得自行核准開店

### 14.1 權限矩陣

| 行為 | 一般使用者 | 模組操作人員 | 主管／核准者 | Model／Data Owner | 稽核 |
|---|---|---|---|---|---|
| 查看清單 | 依 scope | 依 scope | 依 scope | 依授權 | 唯讀 |
| 建立／更新 | 不可或限自身 | 可 | 可 | 視模組 | 不可 |
| 核准 | 不可 | 不可或低風險 | 可 | 不可替代業務核准 | 不可 |
| 發布模型／規則 | 不可 | 不可 | 不可 | 可，需治理流程 | 不可 |
| 查閱 Audit | 不可 | 限自身操作 | 限轄區 | 限模型與資料 | 可 |

## 15. 稽核與留痕

本模組必須至少記錄：

- 使用者查詢、建立、更新、核准、退回、override、匯出。
- 模型／規則／Solver／Feature／View 版本。
- 輸入資料 snapshot 與輸出 artifact location。
- 重要 API request id、correlation id、idempotency key。
- 人工核准與 override reason。
- Outcome 與 Evidence Level。

## 16. 例外處理與降級

| 情境 | 處理方式 |
|---|---|
| 上游資料延遲 | 使用上一版可用 snapshot，並標記 data_stale；高風險決策阻擋 |
| 資料品質失敗 | 進入 quarantine 或 low confidence，不發布正式結果 |
| 模型不可用 | 使用已核准 baseline 或停止自動建議，保留人工流程 |
| Job 失敗 | 依 retry policy 重試；超過次數進入 DLQ 並通知 owner |
| 權限不足 | 回傳 403 並記錄 security audit |
| 結果低信心 | 顯示低信心、要求人工覆核，不得自動核准 |

## 17. 效能、SLA 與可觀測性

| 類別 | 目標 |
|---|---|
| 同步 API | P95 依平台 NFR；長時間工作必須回傳 job_id |
| 批次工作 | 必須在設定的 batch window 內完成，失敗可重跑 |
| 地理／模型／Solver | 需保存資源用量、執行時間與失敗原因 |
| Logs | 每個 request、job、event 必須有 correlation_id |
| Metrics | 成功率、延遲、錯誤率、資料新鮮度、模型指標、業務採用率 |
| Traces | API → Event → Worker → DB／Model／Solver 的主要鏈路需可追蹤 |

## 18. 驗收條件

| 驗收編號 | 驗收條件 |
|---|---|
| AC-03-01 | 每次評分必須保存 feature_snapshot_time、model_version、view_version |
| AC-03-02 | GO 建議必須同時通過 Feasibility Rules |
| AC-03-03 | 報告必須顯示主要正負因子與信心 |
| AC-03-04 | 人工核准與模型建議不同時必須填寫 Override Reason |
| AC-03-05 | M3／M6／M12 Outcome 必須可自動回收並計算 Realization Ratio |


## 18. 追蹤與驗收

| Trace 類型 | 對應方式 |
|---|---|
| HLR | 對應 `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` 中同領域高階需求 |
| FR | 對應 `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` 中同領域功能需求 |
| NFR | 對應 `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` 的效能、資安、資料品質、可觀測性與治理要求 |
| Data | 對應 `ODP-DATA-04_CANONICAL_DATA_MODEL.md`、`ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATION.md` |
| API/Event | 後續必須落入 OpenAPI／AsyncAPI 或等價契約檔 |
| QA | 第 8 批 QA 文件必須將本模組轉為 Contract Test、Integration Test、E2E Test、Model／Solver Test、Security Test 與 Audit Evidence |

本模組列為「必須」的功能、狀態、API、Event、資料表、模型輸出與稽核欄位，後續至少需要有一項可查證交付物：程式碼、Migration、dbt model、OpenAPI、AsyncAPI、Workflow Definition、測試案例、Runbook、Model Card 或操作畫面。
