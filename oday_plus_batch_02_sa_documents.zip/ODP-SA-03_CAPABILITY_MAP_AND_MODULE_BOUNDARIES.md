---
doc_id: ODP-SA-03
title: "業務能力地圖與模組邊界"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Product Lead / Architecture Owner"
approvers: "Technology Lead / Domain Business Owners"
content_format: markdown
---

# ODay Plus 業務能力地圖與模組邊界

## 1. 文件目的

本文件定義 ODay Plus 全平台的業務能力地圖、模組分層、模組邊界、共用能力、跨模組依賴與禁止耦合。此文件用來避免不同開發者把模型、流程、資料與前端混成單體，也避免把每個演算法誤拆成獨立產品或微服務。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 能力分層

```mermaid
flowchart TB
  L0[Level 0: ODay Plus 決策與治理平台]
  L0 --> L1A[Level 1: 展店與選址]
  L0 --> L1B[Level 1: 營運預測與干預]
  L0 --> L1C[Level 1: 資產估值與店網重配]
  L0 --> L1D[Level 1: 學習治理與稽核]
  L0 --> L1E[Level 1: 資料整合與共用平台]
  L1A --> HZ[HeatZone]
  L1A --> LST[Listing]
  L1A --> SITE[SiteScore]
  L1B --> FCT[ForecastOps]
  L1B --> INTV[InterventionOps]
  L1B --> PRICE[PriceOps]
  L1B --> AD[AdLift]
  L1C --> AVM[DealRoomAVM]
  L1C --> NET[NetPlan]
  L1D --> LH[Learning Hub]
  L1D --> OPS[OpsBoard]
  L1E --> INT[Integration Layer]
  L1E --> SHARED[Shared Services]
```

## 3. Level 1 能力群

| 能力群 | 目標 | 主要輸入 | 主要輸出 |
|---|---|---|---|
| 展店與選址 | 找對區域、找對物件、降低開店誤判 | 外部地理、競店、租金、物件、跨品牌營收 | 熱區、物件清單、SiteScore Report、開店決策 |
| 營運預測與干預 | 及早發現偏離並形成可驗證處置 | 門市營收、設備、成本、客服、維修、價格、廣告 | 四燈、干預任務、增量效果、修復結果 |
| 資產與店網 | 對長期低效或變動商圈做資本決策 | Forecast、AVM、租約、資本、人力、物件 | 估值、Data Room、OPEN／KEEP／MOVE／EXIT 方案 |
| 學習與治理 | 讓模型與決策可追溯、可回訓、可回滾 | Feature、Label、Dataset、Prediction、Decision、Outcome | Model Card、Decision Card、Audit、Release、Rollback |
| 資料整合與共用平台 | 隔離上游並提供一致語意 | IoT／內部資料、外部資料、檔案、API、事件 | Canonical Data、Model-ready Views、Data Quality Result |

## 4. 模組邊界總表

| 模組 | 核心邊界 | 負責 | 不負責 |
|---|---|---|---|
| Integration Layer | 上游資料隔離、來源轉換、Canonical Model、Data Quality | 資料接入、清洗、對位、Quarantine、Snapshot、Lineage | 模型訓練、業務決策、前端決策呈現 |
| HeatZone Radar | 找區域 | H3／生活圈評分、需求缺口、競爭缺口、租金可行性、自家稀釋、熱區狀態 | 具體物件營收預測、開店核准 |
| Listing Pipeline | 找物件 | 人工／CSV／Feed／API 接入、地址解析、Geocode、去重、Hard Rules、物件狀態 | 自動簽約、房東談判、SiteScore 模型訓練 |
| SiteScore | 評估候選店址 | ODay G2 營收路徑、P10／P50／P90、回本期、租金合理性、GO／WAIT／REJECT 建議 | 取代人工核准、直接開店、開店後營運處置 |
| ForecastOps | 看懂既有店未來軌跡 | 4／8／12／24 週預測、成長階段、轉折、SiteScore Gap、四燈 Evidence | 直接改價格、直接投廣告、判定因果增量 |
| InterventionOps | 管理公司對門市做了什麼 | Eligibility、Action Set、Conflict、Approval、Execution、Observation Window、Outcome | 自行估計價格彈性或廣告因果效果 |
| PriceOps | 安全調價與價格效果 | Price Elasticity、Safe Action Set、Demand Simulation、Pricing Optimizer、價格實驗 | 繞過 InterventionOps 或人工核准直接改價 |
| AdLift | 廣告是否帶來增量 | Matched Controls、DiD、Incremental Revenue／GM、iROMI、Continue／Stop 建議 | 僅以 ROAS 判定成效、忽略重疊干預 |
| DealRoomAVM | 門市公允估值與交易支援 | 正常化毛利、Income／Asset／Market 估值、P10／P50／P90、Data Room | 自動強制出售、取代財務法務核准 |
| NetPlan | 店網級開留搬退最佳化 | OPEN／KEEP／IMPROVE／MOVE／EXIT、硬限制、Solver、Alternative Plans | 忽略硬限制、直接執行搬遷或退店 |
| Learning Hub | 資料、模型與發布治理 | Feature Contract、Label Registry、Dataset Snapshot、Model Registry、Backtest、Drift、Release／Rollback | 取代業務決策或現場執行 |
| OpsBoard | 統一工作台與稽核入口 | 工作區、任務、核准、留言、附件、Audit、證據匯出 | 在前端實作模型邏輯、直接改上游資料 |


## 5. 共用能力與不得重複實作原則

| 共用能力 | 應由誰提供 | 各模組使用方式 | 不得重複實作 |
|---|---|---|---|
| 身分與權限 | Shared Auth／OpsBoard | 以 Actor、Role、Scope 驗證操作 | 各模組各自建立登入系統 |
| Job 管理 | Shared Workflow／Job Engine | 長任務回傳 job_id，統一查詢狀態 | API 同步等待長任務 |
| Audit Trail | OpsBoard／Learning Hub | 每個決策、核准、執行、Outcome 都寫入 | 各模組只寫本地 log |
| Decision Log | Learning Hub／OpsBoard | Recommendation、Decision、Execution、Outcome 分離 | 模型結果直接覆蓋決策 |
| Report Generator | Shared Reporting | SiteScore、AVM、NetPlan 等共用模板引擎 | 各模組自行生成不一致報告 |
| Notification | Shared Notification | 任務、警示、逾時、核准通知 | 模組直接呼叫私人通知 API |
| Feature Access | Feature Marts／Model-ready Views | 模型只讀受控 View | 模型讀取上游原始表 |
| Model Registry Client | Learning Hub | 模型讀取 approved alias | 服務 hard-code 模型檔案位置 |
| Data Quality Gate | Data Platform／Learning Hub | 失敗可阻擋發布、訓練、評分 | 模組自行忽略資料品質 |
| Correlation ID | Platform | API、Event、Job 全鏈傳遞 | 各模組產生互不相容 trace id |

## 6. 跨模組依賴

| 來源模組 | 目標模組 | 依賴內容 | 依賴型態 |
|---|---|---|---|
| Integration Layer | HeatZone | `geo_grid_view`、外部需求特徵、租金、競店、自家店 | Batch／View |
| HeatZone | Listing | 熱區篩選、區域任務、建議物件條件 | API／View |
| Listing | SiteScore | 候選物件、地址、租金、坪數、物件條件 | API／Event |
| SiteScore | ForecastOps | 原始營收路徑、開店基準、M1/M3/M6/M12 | View／Event |
| ForecastOps | InterventionOps | 四燈、Root Cause Candidates、Recommended Intervention Type | Event／Task |
| InterventionOps | PriceOps | Price Action Request、Observation Window、Outcome | Workflow／Event |
| InterventionOps | AdLift | Campaign Treatment、Control Candidate、Outcome Window | Workflow／Event |
| ForecastOps | DealRoomAVM | 未來營運能力、長期偏離、正常化參考 | View／Event |
| DealRoomAVM | NetPlan | 估值區間、保留價、交易假設 | View／Report |
| SiteScore／HeatZone | NetPlan | 新開店候選與需求地圖 | View |
| 所有模組 | Learning Hub | Feature、Label、Prediction、Decision、Outcome | Event／Registry |
| 所有模組 | OpsBoard | 工作區、任務、核准、Audit、報表 | API／Event |

## 7. 模組與服務部署的差異

本文件的模組是業務責任邊界，不必等同 Production 微服務。部署服務應由 `ODP-SD-03` 決定。SA 層級只規定：

1. 模組之間不得直接讀取彼此內部表。
2. 模組之間必須透過 API、Event、Model-ready View 或 Report Artifact 串接。
3. 可在程式碼中以模組化 Monolith 或有限服務數量實作，但不可混淆業務責任。
4. 資源需求、執行型態、發布頻率、責任團隊明顯不同時，SD 可拆成獨立服務。

## 8. 禁止耦合清單

| 禁止耦合 | 原因 | 正確做法 |
|---|---|---|
| ForecastOps 直接修改價格 | 預測與執行責任混淆 | 由 ForecastOps 發出建議，InterventionOps 建立 Action，PriceOps 產生方案 |
| SiteScore 直接開店 | 模型輸出不得等於決策 | 進入人工審查 Workflow |
| AdLift 直接讀取行銷平台原始資料並下結論 | 缺少來源版本與重疊干預控制 | 經 Campaign Canonical 與 Intervention Log 分析 |
| NetPlan 自動執行退店 | 高風險資本決策需管理層核准 | NetPlan 輸出方案與替代方案，管理層核准 |
| 模型服務直接讀 IoT 上游表 | 上游格式變動會污染模型 | 經 Integration Layer 與 Model-ready Views |
| 前端保存業務規則 | 規則不可追溯且難測試 | Decision Policy Service 管理版本化規則 |
| 每個模組各自實作 Audit | 稽核不完整且不可串接 | 統一 Audit Trail 與 Correlation ID |

## 9. 能力成熟度

| 成熟度 | 定義 | 可上線範圍 |
|---|---|---|
| Level 0 概念 | 只有需求與設計 | 不可上線 |
| Level 1 分析原型 | Notebook 或離線資料集可驗證方向 | 僅內部分析 |
| Level 2 可重現批次 | Dataset Snapshot、模型版本與批次報告可重現 | 可供決策參考，需人工核准 |
| Level 3 產品化流程 | API／Job／Workflow／Audit／權限完整 | 可納入正式工作台 |
| Level 4 治理化 Production | Model Card、Decision Card、監控、回滾、Gate 完整 | 可作正式營運流程 |
| Level 5 最佳化與自動化 | 安全探索、因果驗證、策略自動化成熟 | 僅在 Gate 通過後局部啟用 |

## 10. SA 驗收要求

| 驗收項目 | 檢查方式 |
|---|---|
| 每個 HLR 都能映射到至少一個模組能力 | RTM review |
| 每個模組有清楚負責與不負責事項 | 模組邊界 review |
| 高風險決策不在模型層自動執行 | Decision Policy review |
| 共用能力不被各模組重複實作 | Architecture review |
| 後續 SD 可依此拆分服務與資料契約 | SD traceability review |
