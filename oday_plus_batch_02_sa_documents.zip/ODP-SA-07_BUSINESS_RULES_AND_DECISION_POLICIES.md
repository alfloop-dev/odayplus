---
doc_id: ODP-SA-07
title: "業務規則與決策政策"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Decision Policy Owner / Product Lead"
approvers: "Domain Business Owners / Risk Validation Owner"
content_format: markdown
---

# ODay Plus 業務規則與決策政策

## 1. 文件目的

本文件定義 ODay Plus 的業務規則、決策政策、硬限制、狀態轉移原則、人工核准與 Override 要求。此文件是 Decision Services、Workflow、Policy Engine、測試案例與稽核的 SA 基線。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 決策政策分層

| 層級 | 說明 | 例子 | 可否人工 Override |
|---|---|---|---|
| Hard Constraint | 不得違反的安全、法規、財務或技術限制 | 排水不合、價格低於毛利底線、租約不可行 | 原則上不得；需正式 ADR 或政策變更 |
| Eligibility Rule | 是否可進入某流程 | 紅燈門市是否可建立促銷處置 | 可由高權限人工覆核並留痕 |
| Ranking Policy | 排序、優先級與推薦 | HeatZone Rank、Listing Rank | 可調整權重版本，不得無痕覆寫 |
| Recommendation Policy | 系統建議 | GO／WAIT／REJECT、Continue／Stop | 可覆寫，但必須理由與責任人 |
| Execution Policy | 實際執行條件 | 調價發布、廣告投放、任務執行 | 高風險需人工核准 |
| Learning Policy | 資料是否進入回訓 | Label Maturity、Treatment 排除 | 需 Data／Model Owner 核准 |

## 3. 業務規則總表

| Rule ID | Domain | Rule | Rule Type | Enforcement Point | Evidence |
|---|---|---|---|---|---|
| `ODP-BR-GOV-001` | 治理與決策分離 | Prediction 不得直接寫入 Decision 欄位。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-GOV-002` | 治理與決策分離 | Recommendation 必須與 Approved Decision 分開保存。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-GOV-003` | 治理與決策分離 | 高風險 Override 必須填理由與 Actor。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-GOV-004` | 治理與決策分離 | 模型發布與業務核准必須分離。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-HZ-001` | HeatZone | 熱區狀態只能依核准狀態機轉移。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-HZ-002` | HeatZone | 資料 Coverage 低於門檻時需降低 Confidence 或阻擋。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-HZ-003` | HeatZone | 熱區排序必須提供主要正負因子。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-HZ-004` | HeatZone | 新店實績必須更新需求吸收狀態。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LST-001` | Listing | 無地址或 Geocode 失敗不得進入 SiteScore。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LST-002` | Listing | 去重不得刪除來源紀錄。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LST-003` | Listing | Hard Rule 失敗需保留拒絕原因。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LST-004` | Listing | 過期物件不得被評為可簽約。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-SITE-001` | SiteScore | Feasibility Hard Rule 失敗不得 Recommendation=GO。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-SITE-002` | SiteScore | P10/P50/P90 必須同時輸出。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-SITE-003` | SiteScore | 核准 GO 必須凍結版本與快照。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-SITE-004` | SiteScore | WAIT 必須有重評條件或時間。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-FCT-001` | ForecastOps | 四燈由 Decision Policy 產生。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-FCT-002` | ForecastOps | 紅燈需建立處置或關閉理由。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-FCT-003` | ForecastOps | 資料 Stale 不得產生高信心警示。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-FCT-004` | ForecastOps | SiteScore Gap 必須使用原始核准快照。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-INTV-001` | InterventionOps | 重疊 Treatment 必須做 Conflict Review。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-INTV-002` | InterventionOps | Observation Window 未成熟不得宣稱效果。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-INTV-003` | InterventionOps | 所有處置都需有可回收 Outcome。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-INTV-004` | InterventionOps | Rollback 與 Stop 需留原因。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-PRICE-001` | PriceOps | 價格不得低於毛利底線。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-PRICE-002` | PriceOps | 價格變動需符合品牌政策與法規。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-PRICE-003` | PriceOps | 無可行解不得自動放寬硬限制。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-PRICE-004` | PriceOps | Bandit 未通過 Gate 不得自動探索。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AD-001` | AdLift | Pre-trend 未通過不得宣稱 DiD 因果。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AD-002` | AdLift | 重疊促銷需標記或排除。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AD-003` | AdLift | 核心指標必須含 Incremental GM。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AD-004` | AdLift | Evidence 不足需輸出 INSUFFICIENT_EVIDENCE。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AVM-001` | DealRoomAVM | Fair Value、Reserve Price、Asking Price 必須分離。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AVM-002` | DealRoomAVM | 正常化調整需財務核准。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AVM-003` | DealRoomAVM | 估值區間需保存信心水準。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-AVM-004` | DealRoomAVM | 成交結果必須回收。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-NET-001` | NetPlan | 硬限制不得被 Solver 自動放寬。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-NET-002` | NetPlan | MOVE/EXIT 需管理層核准。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-NET-003` | NetPlan | 無可行解需輸出診斷。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-NET-004` | NetPlan | 方案需回收 90/180/365 日 Outcome。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LH-001` | Learning Hub | Data Quality Fail 可阻擋模型發布。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LH-002` | Learning Hub | Label 未成熟不得進訓練集。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LH-003` | Learning Hub | Model Alias 切換需有核准紀錄。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-LH-004` | Learning Hub | 模型回滾不等於業務決策回滾。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-OPS-001` | OpsBoard | 所有核准需有 Actor 與時間。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-OPS-002` | OpsBoard | 敏感資料匯出需記錄與遮罩。 | Policy | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-OPS-003` | OpsBoard | 加盟主只可看自身門市。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |
| `ODP-BR-OPS-004` | OpsBoard | Audit Log 不得由一般使用者修改。 | Hard Constraint | API／Workflow／Decision Service／UI | Audit Log + Policy Version |


## 4. SiteScore 決策政策

| Recommendation | 條件 | 後續動作 |
|---|---|---|
| `GO` | Predictive Score 達門檻、P50 回本期可接受、P10 風險可承受、Hard Rules 全通過 | 送開店核准；需人工核准 |
| `GO_WITH_CONDITION` | 主要條件可改善，例如租金議價、工程補件、現勘確認 | 建立條件任務；條件完成後才可核准 |
| `WAIT` | 資料不足、商圈需觀察、租約或重大建設時間未成熟 | 設定重評時間與條件 |
| `REJECT` | Hard Rules 失敗、租金不可行、稀釋過高或 P10 風險不可接受 | 保存拒絕理由，禁止直接轉 GO |
| `FIELD_SURVEY` | 模型信心不足或關鍵資料需現場確認 | 建立現勘任務與補件清單 |

硬規則失敗時，Recommendation 不得為 `GO`。人工若要推翻 `WAIT` 或 `REJECT`，必須使用 Override 流程，並由展店審查 Owner 及授權主管核准。

## 5. 四燈政策

| 燈號 | 語意 | 建議動作 | 是否必須建立任務 |
|---|---|---|---|
| 綠燈 | 實績在合理區間，無顯著偏離 | 持續監控 | 否 |
| 黃燈 | 輕微偏離或資料需觀察 | 建立觀察或低風險任務 | 視政策 |
| 橙燈 | 明顯偏離，需主動處理 | 建立 Intervention Candidate | 是 |
| 紅燈 | 高風險或重大異常 | 建立高優先處置並升級主管 | 是 |

四燈政策輸入至少包括：預測殘差、Prediction Interval、SiteScore Gap、成本異常、設備可用率、客服主題、維修工單、外部因素、重疊干預與資料品質。

## 6. 干預效果 Evidence Level

| Evidence Level | 定義 | 可用決策 |
|---|---|---|
| `L0_OBSERVED` | 只觀察到前後變化，未建立對照 | 不得宣稱因果；只能作參考 |
| `L1_ADJUSTED` | 已控制部分季節、店齡或外部因素 | 可作低風險決策參考 |
| `L2_MATCHED_CONTROL` | 有相似對照且通過基本檢查 | 可作 Continue／Stop 建議 |
| `L3_DID_VALIDATED` | DiD 且 Pre-trend 通過 | 可作主要業務決策依據 |
| `L4_EXPERIMENTAL` | 隨機或準實驗設計，偏誤控制完整 | 可作策略推廣依據 |
| `INSUFFICIENT_EVIDENCE` | 樣本、對照、重疊或資料品質不足 | 不得宣稱有效或無效 |

## 7. Override 規則

| Override 類型 | 允許情境 | 必填欄位 | 額外核准 |
|---|---|---|---|
| Recommendation Override | 人工掌握模型未納入資訊 | 理由、證據、責任人、期限 | Domain Owner |
| Hard Constraint Exception | 法務／工程確認原限制不適用 | ADR、替代控制、有效期限 | Steering Committee |
| Data Quality Override | 資料缺陷不影響特定低風險用途 | 影響範圍、補救計畫、到期日 | Data Governance Owner |
| Model Release Override | 指標小幅未達但業務需 Shadow | Model Card、風險、回滾條件 | Validation Owner + Technology Lead |

## 8. 決策政策版本化

每個 Decision Policy 必須有：

```yaml
policy_id: string
policy_version: semver
effective_from: datetime
effective_to: datetime|null
owner: role
approved_by: role/person
input_contract: reference
output_contract: reference
change_reason: string
rollback_policy_version: string|null
```

任何正式 Decision 必須保存當時使用的 `policy_id` 與 `policy_version`。

## 9. 驗收需求

| 驗收 ID | 內容 |
|---|---|
| `ODP-AC-BR-001` | 任一 Hard Constraint 失敗時，系統不得輸出可執行的高風險行動。 |
| `ODP-AC-BR-002` | 任一人工 Override 必須可追溯原因、Actor、核准者、時間與後續 Outcome。 |
| `ODP-AC-BR-003` | 任一 Decision Policy 修改都必須升版且保留舊版。 |
| `ODP-AC-BR-004` | 四燈、SiteScore、Price、AdLift、AVM、NetPlan 的決策結果均能查到政策版本。 |
| `ODP-AC-BR-005` | Evidence 不足時，AdLift 與干預效果報告不得顯示因果確定結論。 |
