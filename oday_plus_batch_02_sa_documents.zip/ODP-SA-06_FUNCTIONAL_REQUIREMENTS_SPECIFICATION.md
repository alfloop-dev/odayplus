---
doc_id: ODP-SA-06
title: "功能需求規格書"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Product Lead"
approvers: "Domain Business Owners / Architecture Owner / QA Lead"
content_format: markdown
---

# ODay Plus 功能需求規格書

## 1. 文件目的

本文件將第 1 批 RTM 的 High-Level Requirements 拆成 SA 層級可開發、可測試、可追蹤的 Functional Requirements。每一條 FR 必須在後續資料契約、平台 SD、模組設計、API/Event/Workflow、測試案例與驗收證據中被引用。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. FR 欄位定義

| 欄位 | 定義 |
|---|---|
| FR ID | `ODP-FR-<DOMAIN>-NNN`，永久不重用 |
| Requirement | 系統必須滿足的可測試行為 |
| Primary Module | 主要負責模組 |
| Trigger/Input | 觸發條件或主要輸入 |
| Output/Acceptance | 輸出或驗收重點 |
| Priority | `MUST`／`SHOULD`／`CONDITIONAL` |
| Trace | 對應 HLR 或來源 |

## 3. 功能需求總表

| FR ID | Requirement | Primary Module | Trigger/Input | Output/Acceptance | Priority | Trace |
|---|---|---|---|---|---|---|
| `ODP-FR-INT-001` | 系統必須支援 Batch/CDC/API/檔案/Event 來源接入。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-002` | 系統必須保存來源識別、事件時間、觀察時間與 ingested_at。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-003` | 系統必須建立 Identity Mapping 而非直接使用上游主鍵。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-004` | 系統必須支援 Backfill、重送、Quarantine 與 Snapshot 重現。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-005` | 系統必須保存外部資料授權、覆蓋率、新鮮度與 Confidence。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-006` | 系統必須地址正規化、Geocode、H3、行政區與人工校正。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-007` | 系統必須模型只能讀 Canonical 或 Model-ready View。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-INT-008` | 系統必須訓練與回測符合 Point-in-time Correctness。 | Integration Layer | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INT-*` |
| `ODP-FR-HZ-001` | 系統必須產生全台空間單元外部需求與機會缺口。 | HeatZone Radar | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-HZ-*` |
| `ODP-FR-HZ-002` | 系統必須輸出熱區分數、優先排名、未滿足需求與 Confidence。 | HeatZone Radar | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-HZ-*` |
| `ODP-FR-HZ-003` | 系統必須管理 UNTOUCHED/PARTIALLY_ABSORBED/SATURATED/UNDER_REALIZED/STILL_EXPANDABLE 狀態。 | HeatZone Radar | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-HZ-*` |
| `ODP-FR-HZ-004` | 系統必須依新店實績更新需求吸收與剩餘需求。 | HeatZone Radar | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-HZ-*` |
| `ODP-FR-HZ-005` | 系統必須提供可解釋排名與主要因子。 | HeatZone Radar | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-HZ-*` |
| `ODP-FR-LST-001` | 系統必須支援人工、CSV/Excel、合作 Feed 與 API 建立 Listing。 | Listing Pipeline | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LST-*` |
| `ODP-FR-LST-002` | 系統必須執行地址解析、Geocode、H3 與欄位正規化。 | Listing Pipeline | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LST-*` |
| `ODP-FR-LST-003` | 系統必須跨來源去重並保存判定信心。 | Listing Pipeline | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LST-*` |
| `ODP-FR-LST-004` | 系統必須套用 Hard Rules 與 HeatZone Filter。 | Listing Pipeline | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LST-*` |
| `ODP-FR-LST-005` | 系統必須管理 Listing 生命週期與任務。 | Listing Pipeline | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LST-*` |
| `ODP-FR-SITE-001` | 系統必須組合 External Demand、Brand Transfer、Format Conversion、Ramp、Seasonality。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-002` | 系統必須輸出 M1/M3/M6/M12 與成熟期 P10/P50/P90。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-003` | 系統必須輸出回本期、租金合理性、稀釋、正負因子與 Comparable。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-004` | 系統必須同時執行 Predictive Score 與 Feasibility Rules。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-005` | 系統必須分離 Recommendation 與 Approved Decision。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-006` | 系統必須核准時凍結 Input Snapshot、模型版本、政策版本與報告。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-SITE-007` | 系統必須支援 SiteScore Realization 回收。 | SiteScore | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-SITE-*` |
| `ODP-FR-FCT-001` | 系統必須產生每店 4/8/12/24 週成長軌跡與 28 日預測視窗。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-FCT-002` | 系統必須整合營收、成本、客服、維修與設備風險證據。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-FCT-003` | 系統必須比較實績與 SiteScore 原始預測產生 Realization Ratio。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-FCT-004` | 系統必須輸出成長階段、轉折機率、異常證據與根因候選。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-FCT-005` | 系統必須由 Decision Policy 產生四燈。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-FCT-006` | 系統必須追蹤預警提前天數與 Precision。 | ForecastOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-FCT-*` |
| `ODP-FR-INTV-001` | 系統必須統一 Eligibility、Action Set、Conflict、Approval、Execution、Observation Window、Outcome。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-INTV-002` | 系統必須讓 Price/Ad/Promotion/CRM/Maintenance/Cleaning 共用主流程。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-INTV-003` | 系統必須識別重疊干預與衝突活動。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-INTV-004` | 系統必須保存 Treatment、執行範圍、期間與實際結果。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-INTV-005` | 系統必須結果回寫 Label Registry。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-INTV-006` | 系統必須支援 Continue/Adjust/Stop/Rollback。 | InterventionOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-INTV-*` |
| `ODP-FR-PRICE-001` | 系統必須估計價格彈性並保存適用範圍與不確定性。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-PRICE-002` | 系統必須建立 Safe Action Set 與毛利底線。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-PRICE-003` | 系統必須產生需求與毛利模擬。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-PRICE-004` | 系統必須受限制最佳化產生候選價格方案。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-PRICE-005` | 系統必須硬限制零違反且無可行解輸出原因。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-PRICE-006` | 系統必須Bandit 框架受 Gate 控制啟用。 | PriceOps | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-PRICE-*` |
| `ODP-FR-AD-001` | 系統必須保存 Campaign、渠道、預算、店群、期間、受眾與執行資料。 | AdLift | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AD-*` |
| `ODP-FR-AD-002` | 系統必須建立 Matched Controls 與 DiD 分析。 | AdLift | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AD-*` |
| `ODP-FR-AD-003` | 系統必須檢查 Pre-trend 並處理證據不足。 | AdLift | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AD-*` |
| `ODP-FR-AD-004` | 系統必須輸出 Incremental Revenue、Incremental GM 與 iROMI。 | AdLift | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AD-*` |
| `ODP-FR-AD-005` | 系統必須產生 Continue/Stop/Scale/Change Channel 建議並需核准。 | AdLift | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AD-*` |
| `ODP-FR-AVM-001` | 系統必須整合 GM_TTM、GM_FWD、折舊、資產、租約與正常化調整。 | DealRoomAVM | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AVM-*` |
| `ODP-FR-AVM-002` | 系統必須產生 Income/Asset/Market 三鏡頭估值。 | DealRoomAVM | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AVM-*` |
| `ODP-FR-AVM-003` | 系統必須輸出 P10/P50/P90 與 Fair/Reserve/Asking 分離。 | DealRoomAVM | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AVM-*` |
| `ODP-FR-AVM-004` | 系統必須產生估值卡與 Data Room。 | DealRoomAVM | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AVM-*` |
| `ODP-FR-AVM-005` | 系統必須回收成交價、成交期間、未成交原因與交易條件。 | DealRoomAVM | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-AVM-*` |
| `ODP-FR-NET-001` | 系統必須支援 OPEN/KEEP/IMPROVE/MOVE/EXIT/TRANSFER 情境。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-NET-002` | 系統必須考量資本、租約、施工、設備、人力、覆蓋、稀釋與時序硬限制。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-NET-003` | 系統必須提供 P50 Deterministic 與情境擴充。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-NET-004` | 系統必須輸出 Alternative Plans、Binding Constraints、Solver Status 與 Infeasibility。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-NET-005` | 系統必須每案比較 ROI、現金流、風險、稀釋與時程。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-NET-006` | 系統必須回收 90/180/365 日 Outcome。 | NetPlan | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-NET-*` |
| `ODP-FR-LH-001` | 系統必須管理 Feature Contract、Label Registry、Outcome Maturity 與 Dataset Snapshot。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-LH-002` | 系統必須管理 Experiment Tracking、Model Registry、Model Alias。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-LH-003` | 系統必須支援 Backtest、Champion/Challenger、Shadow、Canary、Rollback。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-LH-004` | 系統必須Data Quality Fail 可阻擋發布/訓練/評分。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-LH-005` | 系統必須監控 Data/Feature/Prediction/Performance Drift。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-LH-006` | 系統必須Prediction 與 Decision 可追溯版本。 | Learning Hub | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-LH-*` |
| `ODP-FR-OPS-001` | 系統必須提供所有模組工作區。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |
| `ODP-FR-OPS-002` | 系統必須支援任務、指派、留言、附件、核准、升級與通知。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |
| `ODP-FR-OPS-003` | 系統必須依 Tenant/Brand/Region/Store/Role/Attribute 控制資料。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |
| `ODP-FR-OPS-004` | 系統必須決策留痕完整度 100%。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |
| `ODP-FR-OPS-005` | 系統必須呈現版本、資料新鮮度、Confidence、Prediction Interval 與 Evidence Level。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |
| `ODP-FR-OPS-006` | 系統必須提供查核證據匯出。 | OpsBoard | 依模組流程或資料更新觸發 | 可由 API／UI／Job／報表或 Audit 驗證 | MUST | `ODP-HLR-OPS-*` |


## 4. 共用平台功能需求

| FR ID | Requirement | Primary Module | Acceptance |
|---|---|---|---|
| `ODP-FR-SHARED-001` | 系統必須提供全域 `job_id` 查詢機制，所有長時間任務都能查詢 `QUEUED/RUNNING/SUCCEEDED/FAILED/CANCELLED/PARTIAL`。 | Shared Workflow | 任一長任務不得要求使用者同步等待完整計算。 |
| `ODP-FR-SHARED-002` | 系統必須在所有 API、Event、Job、Report 與 Audit 中傳遞 `correlation_id`。 | Platform | 任一 E2E trace 可串起來源、模型、決策、執行與結果。 |
| `ODP-FR-SHARED-003` | 系統必須支援 Idempotency Key，避免重送事件或重試 Job 產生重複副作用。 | Platform | 重複送出同一核准或執行事件不得產生重複任務或重複交易。 |
| `ODP-FR-SHARED-004` | 系統必須在高風險動作使用 Feature Flag 與角色限制控制啟用範圍。 | Platform／OpsBoard | 未啟用 Feature Flag 時 UI、API、Job 均不得執行該功能。 |
| `ODP-FR-SHARED-005` | 系統必須提供統一報告產生能力，支援 SiteScore、AVM、NetPlan、模型驗證與查核證據。 | Shared Reporting | 報告保存版本、產生時間、輸入版本與下載 Audit。 |
| `ODP-FR-SHARED-006` | 系統必須提供通知能力，支援站內、Email、Webhook 或後續擴充通道。 | Notification | 任務指派、逾時、核准、失敗、回滾均可通知相關 Actor。 |
| `ODP-FR-SHARED-007` | 系統必須提供資料匯出能力，支援 CSV／JSON 並依資料敏感度遮罩。 | OpsBoard／API | 匯出紀錄可稽核且符合授權 Scope。 |
| `ODP-FR-SHARED-008` | 系統必須支援多環境設定與資料隔離，不得讓 Dev／Staging／Production 共用 Production Secret。 | Platform | 環境變數、Secret、資料庫、Bucket 與模型 Alias 可分離。 |

## 5. 需求衝突與 Deviation

1. 任一 FR 若與已核准文件或實作限制衝突，必須提交 Deviation 或 ADR。
2. 任一 FR 若因資料尚未成熟而無法正式啟用，仍必須完成資料契約、API／UI 框架、Feature Flag 與測試替身。
3. `CONDITIONAL` 不代表不做；代表正式啟用受 Gate 控制。

## 6. FR 驗收策略

| 層級 | 驗收方式 |
|---|---|
| SA Review | Domain Owner 確認需求語意與責任正確 |
| SD Trace | 每條 FR 映射到資料契約、API、Event、Workflow 或模組設計 |
| QA Trace | 每條 MUST FR 至少有一個測試案例或人工驗收項 |
| Audit Trace | 高風險 FR 必須能輸出查核證據 |
