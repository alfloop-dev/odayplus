---
doc_id: ODP-SA-10
title: "KPI、報表與稽核需求"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Product Lead / QA Lead / Operations Governance Head"
approvers: "Executive Sponsor / Domain Business Owners / Program Manager"
content_format: markdown
---

# ODay Plus KPI、報表與稽核需求

## 1. 文件目的

本文件定義 ODay Plus 的 KPI、驗證指標、報表需求、稽核需求、查核證據、資料口徑與指標治理。此文件是 QA 驗收、OpsBoard 報表、Learning Hub 監控與補助查核證據矩陣的 SA 基線。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. KPI 設計原則

1. KPI 必須有明確口徑、分母、分子、時間窗口、資料來源與成熟時間。
2. 模型準確不等於決策正確；模型 KPI、流程 KPI、業務 Outcome 與治理 KPI 必須分開。
3. 干預效果不得只看前後變化；必須標記 Evidence Level。
4. 查核指標必須可由系統自動產生證據或由人工核准文件佐證。
5. KPI 不達標時必須能追溯是 Data、Model、Decision、Execution 或 External Shock 問題。

## 3. KPI 總表

| KPI ID | KPI | 目標值 | 計算口徑 | 頻率 | 系統來源 |
|---|---|---|---|---|---|
| `ODP-KPI-SITE-001` | 新店 3 個月營收誤差 MAPE | ≤ ±12% | 開幕後實績 vs SiteScore M3 | 月/季 | SiteScore Realization |
| `ODP-KPI-SITE-002` | 新店首年達標率 | ≥ 90% | 達標定義由業務核准 | 年 | SiteScore + Finance |
| `ODP-KPI-SITE-003` | 自家稀釋率 | ≤ 10% | 新店對既有店影響 | 季 | HeatZone/SiteScore |
| `ODP-KPI-FCT-004` | 平均異常提前預測 | ≥ 7 天 | 警示時間 vs 實際異常成熟時間 | 月 | ForecastOps |
| `ODP-KPI-FCT-005` | 預警 Precision | ≥ 90% | 有效警示 / 全部警示 | 月 | ForecastOps + Outcome |
| `ODP-KPI-INTV-006` | 預警後 14 天內恢復率 | ≥ 70% | 有處置且恢復門檻通過 | 月 | InterventionOps |
| `ODP-KPI-AD-007` | iROMI | 依活動政策 | Incremental GM / Ad Spend | 活動結束後 | AdLift |
| `ODP-KPI-AVM-008` | 估值 MAPE | ≤ 15% | 成交價 vs P50 或指定口徑 | 季 | DealRoomAVM |
| `ODP-KPI-AVM-009` | 成交價落於估值區間 Coverage | ≥ 80% | 成交價在 P10-P90 或核准區間 | 季 | DealRoomAVM |
| `ODP-KPI-AVM-010` | 估值卡產出時間 | ≤ 3 工作日 | 資料齊備起算 | 月 | AVM Job |
| `ODP-KPI-NET-011` | 提案回覆時間 | ≤ 48 小時 | NetPlan Request 到 Report Ready | 月 | NetPlan Job |
| `ODP-KPI-NET-012` | 不良門店調整完成率 | = 100% for approved actions | 核准方案完成 / 核准方案 | 季 | NetPlan + OpsBoard |
| `ODP-KPI-NET-013` | 店均毛利提升 | +8%~12% 目標 | 導入前後同群比較 | 季/年 | Finance |
| `ODP-KPI-OPS-014` | 決策留痕完整度 | 100% | 必要欄位完整率 | 月 | Audit Trail |
| `ODP-KPI-OPS-015` | 月度稽核通過率 | ≥ 98% | 稽核項目通過率 | 月 | Audit |
| `ODP-KPI-OPS-016` | OpsBoard 可用率 | ≥ 99.5% | 月可用率 | 月 | Monitoring |
| `ODP-KPI-FRAN-017` | 加盟主 NPS | +10 分 | 導入前後或年度比較 | 季/年 | Survey |
| `ODP-KPI-FRAN-018` | 問卷回收率 | ≥ 80% | 已回收 / 發送 | 季 | Survey |


## 4. 報表需求

| 報表 ID | 報表名稱 | 使用者 | 內容 | 更新頻率 | 匯出需求 |
|---|---|---|---|---|---|
| `ODP-RPT-EXP-001` | HeatZone 展店機會報表 | 展店主管、管理層 | 熱區排名、需求缺口、租金區間、競爭、自家稀釋、Confidence | 每批次／每月 | CSV／PDF／地圖截圖 |
| `ODP-RPT-LST-001` | Listing 物件漏斗報表 | 展店業務、展店主管 | NEW、SHORTLISTED、CONTACTING、FIELD_SURVEY、REJECTED、CONVERTED | 每日 | CSV |
| `ODP-RPT-SITE-001` | SiteScore 評分卡 | 展店審查、加盟主 | M1/M3/M6/M12、P10/P50/P90、回本期、正負因子、硬規則 | 按需求 | PDF／HTML |
| `ODP-RPT-SITE-002` | SiteScore Realization | 展店主管、AI/資料 | 預測 vs 實績、Realization Ratio、誤差分段 | 月／季 | CSV／Dashboard |
| `ODP-RPT-FCT-001` | ForecastOps 四燈總覽 | 營運主管、區域督導 | 門市燈號、Evidence、根因、任務狀態 | 每日 | Dashboard／CSV |
| `ODP-RPT-INTV-001` | 干預處置成效 | 營運主管 | Action、Observation Window、Outcome、Evidence Level | 每週／月 | CSV／PDF |
| `ODP-RPT-PRICE-001` | PriceOps 方案比較 | 定價團隊 | 方案、需求模擬、毛利、限制、風險 | 按需求 | PDF／Dashboard |
| `ODP-RPT-AD-001` | AdLift 活動增量報告 | 行銷團隊 | Treatment、Control、Pre-trend、Incremental GM、iROMI | 活動結束後 | PDF／CSV |
| `ODP-RPT-AVM-001` | DealRoomAVM 估值卡 | 財務、法務、管理層 | 三鏡頭估值、P10/P50/P90、Reserve、Data Room | 按需求 | PDF／Data Room |
| `ODP-RPT-NET-001` | NetPlan 方案報告 | 管理層 | OPEN/KEEP/IMPROVE/MOVE/EXIT、替代方案、硬限制、ROI | 季／按需求 | PDF／Gantt |
| `ODP-RPT-GOV-001` | 模型治理報表 | AI/資料、稽核 | Model Card、版本、指標、Drift、發布狀態 | 月／發布時 | HTML／PDF |
| `ODP-RPT-AUD-001` | 查核證據包 | 稽核、Program Manager | Requirement、Decision、Execution、Outcome、測試、版本 | 按需求 | ZIP／PDF／CSV |

## 5. 稽核需求

### 5.1 決策稽核

每一正式 Decision 必須可查到：

| 欄位 | 說明 |
|---|---|
| Requirement ID | 對應需求 |
| Decision Type | Site、Intervention、Price、Ad、AVM、NetPlan、Model Release 等 |
| Actor | 操作者與角色 |
| Data Scope | Tenant、Brand、Region、Store |
| Input Snapshot | 特徵與資料版本 |
| Model Version | 若有模型輸出，需保存版本 |
| Policy Version | Decision Policy 版本 |
| Recommendation | 系統建議 |
| Approved Decision | 人工核准結果 |
| Override Reason | 若有覆寫需必填 |
| Execution | 實際執行動作 |
| Outcome | 結果與成熟時間 |
| Evidence | 報表、截圖、測試或文件連結 |

### 5.2 模型稽核

| 稽核項 | 要求 |
|---|---|
| Model Card | Production 模型必須具備 |
| Training Dataset | Dataset Snapshot 可重現 |
| Feature Contract | 特徵定義、來源與版本可追溯 |
| Label Maturity | Label 需成熟且未污染 |
| Backtest | 至少與 Baseline 比較 |
| Segment Metrics | 區域、店齡、店型、資料品質等分層 |
| Release | Shadow／Canary／Rollback 流程可查 |
| Drift | Data／Feature／Prediction／Performance Drift 可查 |

### 5.3 資料稽核

| 稽核項 | 要求 |
|---|---|
| Source | 每筆重要資料有來源與取得時間 |
| License | 外部資料有授權與用途限制 |
| Quality Result | 完整性、新鮮度、唯一性、合法值、Coverage |
| Quarantine | 錯誤資料不可進正式模型 |
| Backfill | 重算與重送有紀錄 |
| Point-in-time | 回測與訓練無資料洩漏 |

## 6. 指標成熟時間

| Outcome | Label Maturity 原則 |
|---|---|
| SiteScore M1/M3/M6/M12 | 對應月份結束且營收、退款、補登完成後才成熟 |
| Forecast 異常 | 實際異常確認、處置狀態與觀察窗口完成後成熟 |
| PriceOps 效果 | 調價觀察窗口完成且排除重疊干預後成熟 |
| AdLift 效果 | 活動結束、Spend 完整、Control 檢查完成後成熟 |
| AVM 估值 | 成交或明確未成交原因回收後成熟 |
| NetPlan Outcome | 90／180／365 日營運與財務結果成熟後回收 |

## 7. 查核證據包結構

查核證據包應以 ZIP 或資料夾形式輸出，至少包含：

```text
ODP_EVIDENCE_PACKAGE_<scope>_<date>/
├── 00_manifest.json
├── 01_requirements.csv
├── 02_decisions.csv
├── 03_executions.csv
├── 04_outcomes.csv
├── 05_model_versions.csv
├── 06_data_quality.csv
├── 07_test_results.csv
├── reports/
│   ├── sitescore_*.pdf
│   ├── forecastops_*.pdf
│   ├── avm_*.pdf
│   └── netplan_*.pdf
└── audit_logs/
    └── audit_events_*.jsonl
```

## 8. KPI 不達標分析分類

| 分類 | 說明 | 例子 |
|---|---|---|
| Data Issue | 來源錯誤、缺漏、延遲、語意不一致 | 交易退款延遲導致 MAPE 偏高 |
| Model Issue | 模型偏誤、漂移、校準失敗 | 新興重劃區預測長期低估 |
| Decision Issue | 政策或人工核准不當 | 明知高租金仍核准 GO |
| Execution Issue | 任務未執行或執行不完整 | 橙燈處置單未在期限內完成 |
| External Shock | 不可控外部事件 | 重大道路施工、競店突然進場 |
| Measurement Issue | 指標定義或標籤成熟問題 | Observation Window 未滿即計算效果 |

## 9. 驗收要求

| 驗收 ID | 內容 |
|---|---|
| `ODP-AC-KPI-001` | 每一 KPI 都有 Owner、資料來源、計算週期與成熟時間。 |
| `ODP-AC-KPI-002` | SiteScore、ForecastOps、AVM、NetPlan 的核心 KPI 可由系統報表產生。 |
| `ODP-AC-KPI-003` | 干預與廣告報表必須顯示 Evidence Level，不得只顯示前後差。 |
| `ODP-AC-KPI-004` | 任一查核證據包能追溯 Requirement → Decision → Execution → Outcome。 |
| `ODP-AC-KPI-005` | 決策留痕完整度不足 100% 時，系統需產生治理缺失任務。 |
