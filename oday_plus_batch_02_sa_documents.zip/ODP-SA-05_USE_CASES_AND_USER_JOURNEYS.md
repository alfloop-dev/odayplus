---
doc_id: ODP-SA-05
title: "使用案例與使用者旅程"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Product Lead / UX Lead"
approvers: "Domain Business Owners / QA Lead"
content_format: markdown
---

# ODay Plus 使用案例與使用者旅程

## 1. 文件目的

本文件定義 ODay Plus 主要使用案例、角色旅程、前置條件、主流程、替代流程、例外、成功標準與後續測試映射。此文件是 UX、Workflow、API、E2E 測試與 UAT 的共同輸入。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 使用案例命名規則

Use Case ID 使用 `ODP-UC-<DOMAIN>-NNN`。每一個 Use Case 必須可追溯到 `ODP-00-05` 的 HLR，並在第 8 批 QA 文件中對應 E2E 或 UAT 測試。

## 3. 使用案例總覽

| Domain | 領域 | Use Case ID | 使用案例 |
|---|---|---|---|
| `EXP` | 展店與選址 | `ODP-UC-EXP-001` | 查看全台熱區並指派區域 |
| `EXP` | 展店與選址 | `ODP-UC-EXP-002` | 匯入出租物件並去重 |
| `EXP` | 展店與選址 | `ODP-UC-EXP-003` | 針對候選物件產出 SiteScore |
| `EXP` | 展店與選址 | `ODP-UC-EXP-004` | 完成開店審查與核准 |
| `EXP` | 展店與選址 | `ODP-UC-EXP-005` | 開店後回收 M1/M3/M6/M12 實績 |
| `OPS` | 營運與干預 | `ODP-UC-OPS-001` | 查看單店未來成長軌跡 |
| `OPS` | 營運與干預 | `ODP-UC-OPS-002` | 處理橙燈／紅燈警示 |
| `OPS` | 營運與干預 | `ODP-UC-OPS-003` | 建立並核准營運處置 |
| `OPS` | 營運與干預 | `ODP-UC-OPS-004` | 回報處置執行結果 |
| `OPS` | 營運與干預 | `ODP-UC-OPS-005` | 查看處置是否恢復或需升級 |
| `PRICE` | 價格 | `ODP-UC-PRICE-001` | 查看可調價門市候選 |
| `PRICE` | 價格 | `ODP-UC-PRICE-002` | 產生 Safe Action Set |
| `PRICE` | 價格 | `ODP-UC-PRICE-003` | 比較價格方案與毛利模擬 |
| `PRICE` | 價格 | `ODP-UC-PRICE-004` | 核准灰度調價 |
| `PRICE` | 價格 | `ODP-UC-PRICE-005` | 回收價格實驗結果 |
| `AD` | 廣告 | `ODP-UC-AD-001` | 建立廣告候選店群 |
| `AD` | 廣告 | `ODP-UC-AD-002` | 建立對照組與 Pre-trend 檢查 |
| `AD` | 廣告 | `ODP-UC-AD-003` | 查看增量毛利與 iROMI |
| `AD` | 廣告 | `ODP-UC-AD-004` | 核准 Continue／Stop／Scale |
| `AD` | 廣告 | `ODP-UC-AD-005` | 回寫活動結果 |
| `ASSET` | 資產與店網 | `ODP-UC-ASSET-001` | 產生單店估值卡 |
| `ASSET` | 資產與店網 | `ODP-UC-ASSET-002` | 建立 Data Room |
| `ASSET` | 資產與店網 | `ODP-UC-ASSET-003` | 比較留守／改善／遷點／退出 |
| `ASSET` | 資產與店網 | `ODP-UC-ASSET-004` | 核准 NetPlan 方案 |
| `ASSET` | 資產與店網 | `ODP-UC-ASSET-005` | 追蹤 90/180/365 日 Outcome |
| `GOV` | 學習治理 | `ODP-UC-GOV-001` | 查看資料品質 Gate |
| `GOV` | 學習治理 | `ODP-UC-GOV-002` | 審查 Model Card |
| `GOV` | 學習治理 | `ODP-UC-GOV-003` | 執行 Shadow／Canary 發布 |
| `GOV` | 學習治理 | `ODP-UC-GOV-004` | 回滾模型或業務決策 |
| `GOV` | 學習治理 | `ODP-UC-GOV-005` | 匯出查核證據包 |


## 4. 主要使用者旅程

### 4.1 展店業務旅程：從找區到現勘

```mermaid
journey
  title 展店業務旅程
  section 熱區探索
    查看熱區排名: 4: 展店業務
    篩選區域與租金條件: 4: 展店業務
    接受主管指派任務: 3: 展店業務
  section 物件處理
    匯入物件: 3: 展店業務
    查看去重與地址校正: 3: 展店業務
    安排聯繫與現勘: 4: 展店業務
  section 店址評估
    送出 SiteScore 評估: 4: 展店業務
    補充物件條件: 3: 展店業務
    查看審查結果: 4: 展店業務
```

### 4.2 營運主管旅程：從預警到修復

```mermaid
journey
  title 營運主管旅程
  section 監控
    查看全店四燈: 4: 營運主管
    進入紅燈明細: 3: 營運主管
    查看根因 Evidence: 4: 營運主管
  section 處置
    建立處置候選: 3: 營運主管
    檢查衝突與重疊: 3: 營運主管
    核准任務: 4: 營運主管
  section 驗證
    查看兩週觀察結果: 4: 營運主管
    Continue/Adjust/Stop: 4: 營運主管
    回饋模型標籤: 3: 營運主管
```

### 4.3 管理層旅程：從店網方案到資本配置

```mermaid
journey
  title 管理層旅程
  section 盤點
    查看低效店清單: 4: 管理層
    查看估值與租約節點: 4: 管理層
  section 比較
    比較 OPEN/KEEP/IMPROVE/MOVE/EXIT: 4: 管理層
    查看 Alternative Plans: 4: 管理層
    檢視硬限制與風險: 3: 管理層
  section 決策
    核准店網方案: 4: 管理層
    指派執行責任: 3: 管理層
    追蹤 90/180/365 Outcome: 4: 管理層
```

## 5. 使用案例詳細規格

### ODP-UC-EXP-001 查看全台熱區並指派區域

| 欄位 | 內容 |
|---|---|
| Primary Actor | 展店業務、展店主管 |
| Supporting Actor | External Data Owner、Geo Model Owner |
| Trigger | HeatZone 批次評分完成或管理層要求展店規劃 |
| Preconditions | `geo_grid_view` 已發布、資料品質 Gate 通過、使用者有 Region 權限 |
| Main Success Scenario | 使用者查看熱區地圖與排名；篩選城市、租金、競爭與 Confidence；選取熱區；建立找店任務；指定負責人與期限 |
| Alternate Flow | 熱區資料 Stale 時，系統顯示 Stale 並限制建立高優先任務；使用者可要求資料重算 |
| Failure Flow | 使用者無該 Region 權限時拒絕存取並記錄 Audit |
| Postconditions | 熱區任務建立，Listing Pipeline 可使用該熱區作 Filter |
| Traceability | `ODP-HLR-HZ-001` 至 `ODP-HLR-HZ-005` |

### ODP-UC-EXP-003 針對候選物件產出 SiteScore

| 欄位 | 內容 |
|---|---|
| Primary Actor | 展店業務、展店審查人員 |
| Trigger | 候選物件進入 `SHORTLISTED` 或人工要求評估 |
| Preconditions | 物件有地址、經緯度、租金、坪數與必要硬條件；Geocode Confidence 達門檻 |
| Main Success Scenario | 使用者建立評分 Job；系統凍結 Input Snapshot；產生營收路徑、回本期、租金合理性、稀釋、Comparable 與建議；報告送審 |
| Alternate Flow | 電力／排水／使用條件不合，系統仍可顯示預測但 Recommendation 不得為 GO |
| Failure Flow | 模型不可用時回傳 Job Failed 與可重試原因，不得產生空白報告 |
| Postconditions | `site_score.generated` Event 產生，報告進入審查工作台 |
| Traceability | `ODP-HLR-SITE-001` 至 `ODP-HLR-SITE-008` |

### ODP-UC-OPS-002 處理橙燈／紅燈警示

| 欄位 | 內容 |
|---|---|
| Primary Actor | 營運主管、區域督導 |
| Trigger | ForecastOps 產生橙燈或紅燈 |
| Preconditions | 預測資料未 Stale，使用者有該 Store Scope |
| Main Success Scenario | 使用者查看警示；檢視營收殘差、成本、設備、客服與外部因素；選擇處置候選；建立 Intervention Draft |
| Alternate Flow | Evidence 不足時可標記 `INSUFFICIENT_EVIDENCE` 並要求補資料或人工調查 |
| Failure Flow | 若同一門市已有重疊干預，系統要求 Conflict Review |
| Postconditions | 產生處置候選或關閉警示並留理由 |
| Traceability | `ODP-HLR-FCT-001` 至 `ODP-HLR-FCT-007`, `ODP-HLR-INTV-001` |

### ODP-UC-PRICE-004 核准灰度調價

| 欄位 | 內容 |
|---|---|
| Primary Actor | 定價團隊、營運主管 |
| Trigger | PriceOps 產生候選價格方案 |
| Preconditions | Safe Action Set 通過，毛利底線與品牌政策零違反 |
| Main Success Scenario | 使用者比較方案；查看需求／毛利模擬、風險與觀察窗口；核准小範圍測試；Execution Coordinator 執行 |
| Alternate Flow | 無可行方案時，系統顯示違反限制與建議修正輸入 |
| Failure Flow | 使用者嘗試手動輸入超出 Safe Action Set 價格時阻擋 |
| Postconditions | `pricing.approved` Event 與 Observation Window 建立 |
| Traceability | `ODP-HLR-PRICE-001` 至 `ODP-HLR-PRICE-005` |

### ODP-UC-AD-003 查看增量毛利與 iROMI

| 欄位 | 內容 |
|---|---|
| Primary Actor | 行銷團隊、營運主管 |
| Trigger | 廣告活動觀察窗口成熟 |
| Preconditions | Campaign Treatment、Control、預算與實績完整；Pre-trend 檢查完成 |
| Main Success Scenario | 使用者查看 Incremental Revenue、Incremental GM、iROMI、Confidence 與建議；選擇 Continue／Stop／Scale |
| Alternate Flow | Pre-trend 未通過時，系統標示證據不足，不宣稱因果增量 |
| Failure Flow | 活動與價格促銷高度重疊且無法識別時，系統輸出 `INSUFFICIENT_EVIDENCE` |
| Postconditions | 結果寫入 Label Registry 與 Decision Log |
| Traceability | `ODP-HLR-AD-001` 至 `ODP-HLR-AD-005` |

### ODP-UC-ASSET-003 比較留守／改善／遷點／退出

| 欄位 | 內容 |
|---|---|
| Primary Actor | 管理層、財務、法務、營運主管 |
| Trigger | 門市長期偏離、租約節點、商圈變動或季度 NetPlan |
| Preconditions | AVM 已產生；租約、資本、人力、施工與候選點資料可用 |
| Main Success Scenario | 使用者查看三案或多案比較；檢視 ROI、現金流、風險、稀釋、時程；查看 Binding Constraints 與 Alternative Plans；送核准 |
| Alternate Flow | Solver 無可行解時，系統顯示 Infeasibility Reason 與資料／限制修正建議 |
| Failure Flow | 缺少租約或資產資料時，方案不可正式核准 |
| Postconditions | 核准方案進入執行追蹤與 90／180／365 Outcome 回收 |
| Traceability | `ODP-HLR-AVM-*`, `ODP-HLR-NET-*` |

### ODP-UC-GOV-005 匯出查核證據包

| 欄位 | 內容 |
|---|---|
| Primary Actor | 稽核人員、Program Manager |
| Trigger | 月度稽核、補助查核、正式驗收或事故後檢討 |
| Preconditions | 使用者有稽核權限；資料範圍已核准 |
| Main Success Scenario | 使用者選擇模組、日期與需求 ID；系統彙整 Requirement、版本、決策、執行、Outcome、測試與截圖／報表連結；匯出 Evidence Package |
| Alternate Flow | 個資或估值資料需遮罩時，系統套用資料分類規則 |
| Failure Flow | 缺漏必要 Audit 欄位時，匯出失敗並建立治理缺失任務 |
| Postconditions | Evidence Package 產出並記錄匯出 Audit |
| Traceability | `ODP-HLR-OPS-004`, `ODP-HLR-OPS-007`, `ODP-HLR-GOV-005` |

## 6. 使用者旅程痛點與設計回應

| 角色 | 原痛點 | ODay Plus 回應 |
|---|---|---|
| 展店業務 | 不知道先去哪找店、現勘無效率 | HeatZone 排序、Listing Filter、任務管理 |
| 展店審查 | 缺乏標準化新店預測與風險報告 | SiteScore Report、硬規則、Comparable、人工核准 |
| 營運主管 | 營收下降後才知道，難找原因 | ForecastOps、四燈、根因 Evidence、干預閉環 |
| 區域督導 | 處置不一致，成效難回收 | InterventionOps 任務、觀察窗口、結果回報 |
| 行銷 | 廣告效果被自然成長或促銷混淆 | Matched Control、DiD、iROMI、Evidence Level |
| 定價 | 調價風險高，缺乏安全限制 | Safe Action Set、毛利模擬、灰度測試 |
| 財務／法務 | 估值缺乏一致標準與交易資料室 | DealRoomAVM、Data Room、Reserve Price |
| 管理層 | 店網決策零散，無法比較替代方案 | NetPlan、Alternative Plans、硬限制與 Outcome |
| 加盟主 | 看不懂總部建議，缺乏信任 | 自身門市狀態、建議、任務、結果透明呈現 |
| AI／資料團隊 | 模型與資料版本難追溯 | Learning Hub、Feature／Label／Model Registry |

## 7. 驗收要求

| 驗收項目 | 標準 |
|---|---|
| Use Case 完整性 | 第 2 批至少覆蓋展店、營運、干預、價格、廣告、估值、NetPlan、治理八大域 |
| 流程可測試 | 每個主要 Use Case 都有 Trigger、Precondition、Main Flow、Exception、Postcondition |
| 權限可測試 | 每個 Use Case 可映射到 `ODP-SA-04` 角色與 Scope |
| E2E 可串接 | 第 8 批 QA 可直接引用 Use Case 建立測試劇本 |
