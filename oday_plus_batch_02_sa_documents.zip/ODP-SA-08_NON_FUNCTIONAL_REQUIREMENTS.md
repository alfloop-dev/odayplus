---
doc_id: ODP-SA-08
title: "非功能需求規格"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Architecture Owner / SRE Owner / Security Owner"
approvers: "Technology Lead / Product Lead / Security Owner"
content_format: markdown
---

# ODay Plus 非功能需求規格

## 1. 文件目的

本文件定義 ODay Plus 全平台的非功能需求，包括效能、可用性、可靠性、資安、個資、資料品質、可觀測性、可維護性、可攜性、模型治理與查核要求。本文件是平台 SD、SRE、資安測試、效能測試與服務契約的 SA 基線。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. NFR 總表

| NFR ID | 類別 | Requirement |
|---|---|---|
| `ODP-NFR-PERF-001` | API Performance | 已完成結果查詢 API P95 ≤ 3 秒；長任務必須回傳 job_id；報告產生依模組 SLA。 |
| `ODP-NFR-BATCH-002` | Batch Window | 每日 ForecastOps、資料品質與必要營運批次應在營運日開始前完成；HeatZone 與 NetPlan 可用排程批次。 |
| `ODP-NFR-AVAIL-003` | Availability | OpsBoard 最低月可用率 99.5%；若採商用 SLA 承諾，需另依服務契約核准。 |
| `ODP-NFR-RPO-004` | RPO/RTO | 重要資料需定義 RPO/RTO；既有雲端承諾可作下限參考，但 ODay Plus 需由本文件與 OPS 文件核准。 |
| `ODP-NFR-SEC-005` | Security | 必須採最小權限、MFA、Service Account、Secret Manager、傳輸與靜態加密、完整 Audit。 |
| `ODP-NFR-PRIV-006` | Privacy | 個資需目的限制、資料最小化、遮罩/去識別、保留期限、下載與刪除流程。 |
| `ODP-NFR-OBS-007` | Observability | 所有 API/Event/Job/Workflow 必須有 Metrics、Logs、Traces、Business Events 與 Correlation ID。 |
| `ODP-NFR-IDEMP-008` | Idempotency | 會產生副作用的 API/Event/Job 必須支援 Idempotency Key 或等效去重。 |
| `ODP-NFR-DATA-009` | Data Quality | 資料完整性、新鮮度、唯一性、合法值、Coverage、Confidence 必須可監控且能阻擋高風險用途。 |
| `ODP-NFR-ML-010` | ML Reliability | 模型需有 Baseline、Backtest、Calibration、Segment Metrics、Drift、Model Card 與 Rollback。 |
| `ODP-NFR-UX-011` | Usability | 高風險決策 UI 必須顯示不確定性、Confidence、資料新鮮度與人工核准狀態。 |
| `ODP-NFR-EXPORT-012` | Data Portability | 資料與報表需支援 CSV/JSON 匯出、API 取得與資料字典。 |
| `ODP-NFR-MAINT-013` | Maintainability | 程式、資料、API、Event 與文件版本需可追蹤；重大選擇需 ADR。 |
| `ODP-NFR-COMPLY-014` | Compliance | 需支援補助查核、個資法、智慧財產、第三方資料授權與稽核要求。 |


## 3. 效能與延遲

| 工作負載 | 要求 | 備註 |
|---|---|---|
| 互動式 API 查詢 | P95 ≤ 3 秒，若查詢已完成結果 | 適用 HeatZone、Listing、SiteScore Report、Forecast、AVM 查詢 |
| 建立長任務 API | P95 ≤ 3 秒回傳 `job_id` | 不得同步執行全量模型或 Solver |
| SiteScore 報告 | ≤ 24 小時 | 計畫承諾下限；即時互動查詢另以已完成結果為準 |
| AVM 估值卡 | ≤ 3 個工作日 | 需資料齊備與財務核准流程可用 |
| NetPlan 提案回覆 | ≤ 48 小時 | 需基礎資料與 Solver 可用 |
| OpsBoard 主要頁面 | 初始載入應可接受；細部數值由 UX/SD 性能測試定義 | 地圖圖層可採延遲載入 |

## 4. 可用性、備份與災難復原

| 項目 | 需求 |
|---|---|
| OpsBoard 可用率 | 最低 99.5%；若對外服務契約採 99.95%，需另列商用 SLA 與補償條款 |
| 關鍵資料備份 | Production 關鍵資料需排程備份與還原演練 |
| RPO/RTO | 各資料域與服務需在 `ODP-OPS-05` 核准具體數值 |
| 降級模式 | 外部資料、模型或 Solver 不可用時需明確標記 Stale／Unavailable／Fallback |
| 還原測試 | 至少需有 Staging 還原驗證，不得只宣稱有備份 |

## 5. 資安與個資

| 控制 | 要求 |
|---|---|
| Authentication | 必須支援集中式登入、MFA 或企業級等效控制 |
| Authorization | 必須實作 RBAC + ABAC + Data Scope |
| Secrets | Secret 不得寫入程式碼、文件或前端設定 |
| Encryption | 對外傳輸必須 TLS；靜態資料需依雲端服務加密與敏感等級補強 |
| Audit | 高風險操作、權限失敗、匯出、模型發布與資料覆寫都必須留痕 |
| Personal Data | 個資需遮罩、去識別、最小化與保留期限控制 |
| Export | 敏感匯出需授權、浮水印、用途紀錄與下載追蹤 |
| Third-party Data | 外部資料需保存授權、用途限制、更新日期與可再散布條件 |

## 6. 資料品質與時間語意

| 品質面 | 需求 |
|---|---|
| Completeness | 必要欄位缺漏時不得進入高風險模型或決策 |
| Freshness | 每個 Model-ready View 必須保存資料新鮮度與可接受門檻 |
| Uniqueness | Store、Machine、Listing、Transaction、Decision 必須有去重或唯一性策略 |
| Validity | 金額、比率、日期、狀態、Enum 必須有合法值檢查 |
| Coverage | 外部資料需保存覆蓋範圍，低 Coverage 需降低 Confidence |
| Lineage | 每個預測與決策必須追溯到來源、Snapshot、Feature 與模型版本 |
| Point-in-time | 訓練、回測與決策模擬不得使用 Decision Time 之後才可知資料 |

## 7. 模型與最佳化 NFR

| 類別 | 需求 |
|---|---|
| Model Card | Production 模型必須有 Model Card |
| Baseline | 每個模型必須有可比較 Baseline |
| Calibration | P10／P50／P90 或區間預測需檢查 Coverage |
| Segment Metrics | 必須檢查區域、店齡、店型、資料品質分層表現 |
| Drift | 必須監控 Data、Feature、Prediction、Performance Drift |
| Rollback | 模型 Rollback 與業務 Decision Rollback 必須分離 |
| Solver | 無可行解必須輸出 Infeasibility，不得靜默放寬硬限制 |
| Reproducibility | 訓練 Dataset Snapshot 與模型版本需可重現 |

## 8. 可觀測性

| 訊號 | 必須包含 |
|---|---|
| Logs | timestamp、service、actor/service_account、correlation_id、resource、result、error_code |
| Metrics | latency、error_rate、job_duration、queue_depth、data_quality_fail、model_metric、business_kpi |
| Traces | API → Event → Worker → Data → Model → Decision → Report 的端到端 trace |
| Alerts | SLO breach、資料過期、模型漂移、Job 失敗、DLQ 堆積、權限異常 |
| Dashboards | 平台健康、資料健康、模型健康、業務流程、查核證據狀態 |

## 9. 可維護性與變更治理

1. 所有正式 API 必須版本化。
2. Event Schema 必須版本化且支援向後相容策略。
3. 資料庫 Migration 必須可重跑或可回滾，依 SD 決定具體策略。
4. 重大架構與技術選擇必須建立 ADR。
5. Feature Flag 必須有 Owner、啟用條件、停用條件與到期檢查。
6. 文件、程式、模型與資料契約應在 CI 中進行一致性檢查。

## 10. 驗收要求

| 驗收 ID | 內容 |
|---|---|
| `ODP-AC-NFR-001` | 長任務 API 回傳 `job_id`，不同步等待完整計算。 |
| `ODP-AC-NFR-002` | 權限測試覆蓋角色、資料範圍與高風險操作。 |
| `ODP-AC-NFR-003` | 至少一條 E2E Trace 能串起資料、模型、決策、執行與 Outcome。 |
| `ODP-AC-NFR-004` | Data Quality Gate 失敗時能阻擋指定模型或決策流程。 |
| `ODP-AC-NFR-005` | 敏感資料匯出有授權、遮罩與 Audit。 |
| `ODP-AC-NFR-006` | 模型發布、Canary 與 Rollback 流程可演練。 |
| `ODP-AC-NFR-007` | 備份資料可在 Staging 還原並驗證核心查詢。 |

## 11. 模組級 NFR 對照

| 模組 | 效能要求 | 資料新鮮度要求 | 可靠性要求 | 特殊治理要求 |
|---|---|---|---|---|
| HeatZone | 地圖查詢應回傳已完成批次結果；全量重算以排程 Job 執行 | 外部地理、競店、租金資料需顯示來源日期 | 資料過期時顯示 Stale 並降低 Confidence | 排名權重與模型版本需可回溯 |
| Listing | 清單篩選與分頁需可支援大量物件 | 來源資料需顯示取得時間與失效狀態 | 匯入失敗不得影響既有物件 | 去重合併／拆分需留 Audit |
| SiteScore | 已完成報告查詢 P95 ≤ 3 秒；評分 Job 可非同步 | 候選點特徵需標示 Snapshot Time | 模型不可用時不得產生無版本報告 | GO／WAIT／REJECT 建議需保存政策版本 |
| ForecastOps | 每日批次需在營運日開始前完成或明確標記延遲 | 交易、設備、客服、維修資料需有 Freshness | 預測失敗不得覆蓋前一版結果 | 四燈需保存 Evidence Vector |
| InterventionOps | 任務狀態操作需互動式回應 | Outcome 未成熟需標記 pending | 重送核准事件不得重複執行 | 高風險處置需雙重核准 |
| PriceOps | 價格方案查詢需互動式；最佳化可非同步 | 價格、毛利、成本資料需最新或標記 Stale | 硬限制失敗需阻擋方案 | 調價需可 Rollback 或 Stop |
| AdLift | 活動報告可在觀察窗口後批次產出 | Campaign、Spend、Outcome 需完整 | 對照組不足不得宣稱因果 | Evidence Level 必須可見 |
| DealRoomAVM | 估值卡在資料齊備後依 SLA 產出 | 財務、資產、租約需明確資料日期 | 估值產生失敗不得覆蓋已核准版本 | 財務正常化需核准 |
| NetPlan | Solver 可非同步，需有進度與失敗原因 | 候選店、租約、資本、人力資料需有版本 | 無可行解需可診斷 | 管理層核准前不得執行 |
| Learning Hub | Registry 查詢需穩定；訓練與回測可非同步 | Feature、Label、Dataset 需版本化 | Release 失敗需可回滾 | Model Card 與 Decision Card 必備 |
| OpsBoard | 工作台互動查詢需可接受；大圖層可延遲載入 | 每頁需顯示資料更新狀態 | 核准與 Audit 寫入需高可靠 | 決策留痕完整度必須 100% |

## 12. 服務等級分層

| 等級 | 代表工作負載 | 目標 | 失敗處理 |
|---|---|---|---|
| Tier 0 | 身分、授權、Audit、核心資料庫 | 平台基礎能力，不可長時間不可用 | 立即升級 Incident；限制高風險操作 |
| Tier 1 | OpsBoard、核心 API、任務與核准 | 日常營運使用 | 啟用降級、通知與 SRE 處理 |
| Tier 2 | ForecastOps、SiteScore、Intervention 工作流 | 決策支援能力 | 可保留前版結果並標記 Stale |
| Tier 3 | HeatZone 全量、AVM、NetPlan、模型訓練 | 批次與重算能力 | Job 重試、排程延後、人工通知 |
| Tier 4 | 實驗、Bandit、MMM、Deep Forecast Challenger | 進階能力 | Feature Flag 關閉，不影響核心流程 |

## 13. 不可接受情境

下列情境若發生，必須列為缺陷或事故，不得視為正常限制：

1. 使用者看到非授權區域或非自身門市資料。
2. 高風險動作未經核准即產生外部執行效果。
3. 同一核准事件因重送造成重複調價、重複投放或重複任務。
4. 資料品質 Gate 失敗但模型仍以高信心輸出正式建議。
5. 模型版本、Feature Snapshot 或 Policy Version 無法追溯。
6. 匯出敏感資料沒有 Audit 紀錄。
7. Solver 無可行解但系統輸出看似可執行方案。
8. 廣告或處置效果證據不足卻被標示為因果有效。
9. Production Secret 出現在文件、前端或程式庫中。
10. Audit Log 可被一般使用者修改或刪除。
