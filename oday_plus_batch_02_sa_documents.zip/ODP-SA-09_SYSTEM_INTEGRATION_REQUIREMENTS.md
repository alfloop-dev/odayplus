---
doc_id: ODP-SA-09
title: "系統整合需求書"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Integration Owner / Data Platform Owner"
approvers: "Architecture Owner / Data Governance Owner / Security Owner"
content_format: markdown
---

# ODay Plus 系統整合需求書

## 1. 文件目的

本文件定義 ODay Plus 與上游、外部資料、內部平台、雲端服務與下游通道的整合需求。此文件確認 IoT 與內部資料底座是上游供應者，ODay Plus 透過 Integration Layer 與 Canonical Data Model 隔離其內部實作。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 整合原則

1. 上游資料格式不得直接滲透到模型、前端或 Decision Policy。
2. 每個來源必須有 Data Contract、更新頻率、Owner、品質規則與錯誤處理。
3. 來源主鍵不得直接作為 ODay Plus 全域主鍵。
4. 外部資料必須保存授權、來源日期、覆蓋率、新鮮度與 Confidence。
5. 批次、CDC、API、檔案與事件均可支援，但每種模式需有重送與 Backfill 策略。
6. 任一整合失敗不得靜默污染正式資料；必須進入 Quarantine、Retry 或 Degraded Mode。

## 3. 整合總覽

| Integration ID | 整合對象 | 來源類型 | 主要資料 | 模式 | ODay Plus 目標 |
|---|---|---|---|---|---|
| `IOT-STORE` | 門市主檔 | 上游內部資料底座 | Store、Brand、Region、Open Date、Status | Batch/CDC/API | Canonical Store |
| `IOT-MACHINE` | 機台與設備狀態 | IoT/內部資料底座 | Machine、Equipment Brand、Capacity、Availability、Fault | Event/Batch | Machine Timeseries |
| `IOT-TXN` | 交易與營收 | IoT/支付/POS | Transaction、Amount、Payment、Refund、Time | CDC/Batch | Revenue/Margin View |
| `IOT-MEMBER` | 會員與顧客 | 會員系統 | Member、Segment、Visit、Consent | API/Batch | Member Features |
| `IOT-PRICE` | 價格與促銷 | 內部營運系統 | Price Table、Coupon、Promotion | API/Batch/Event | Treatment/Price Action |
| `IOT-MAINT` | 維修客服 | 客服/工單系統 | Ticket、Topic、TTR、Work Order | API/Batch | Risk Evidence |
| `EXT-GEO` | 地理與人口 | 外部資料來源 | 人口、POI、道路、租金、競店、天氣 | API/File/Scrape/Partner | Geo Features |
| `EXT-LISTING` | 出租物件 | 人工/CSV/Feed/API | 地址、租金、坪數、物件條件 | File/API/Manual | Listing |
| `ADS` | 廣告平台 | 廣告投放來源 | Campaign、Spend、Audience、Clicks、Impressions | API/Upload | Campaign Treatment |
| `NOTIFY` | 通知系統 | Email/LINE/Webhook | 任務與警示通知 | API/Event | Notification |
| `GCP` | 雲端平台 | GCP Services | BigQuery、Cloud SQL、GCS、Pub/Sub、Vertex、Logging | Managed Service | Platform |


## 4. Integration Layer 目標架構

```mermaid
flowchart LR
  subgraph UP[上游與外部來源]
    U1[IoT/交易/設備]
    U2[會員/客服/維修]
    U3[租約/資產/財務]
    U4[人口/POI/道路/租金/天氣]
    U5[Listing/仲介/CSV/API]
    U6[廣告/行銷平台]
  end
  subgraph INT[Integration Layer]
    A1[Source Adapter]
    A2[Raw Landing]
    A3[Validation]
    A4[Identity Mapping]
    A5[Canonical Transform]
    A6[Quarantine/Retry]
    A7[Snapshot/Lineage]
  end
  subgraph ODP[ODay Plus]
    C1[Canonical Data]
    C2[Model-ready Views]
    C3[Prediction/Decision Services]
    C4[OpsBoard]
    C5[Learning Hub]
  end
  UP --> A1 --> A2 --> A3 --> A4 --> A5 --> C1 --> C2 --> C3
  A3 --> A6
  A5 --> A7
  C3 --> C4
  C3 --> C5
```

## 5. 上游 IoT／內部資料交換需求

| 領域 | 最低欄位要求 | 資料品質要求 | 例外處理 |
|---|---|---|---|
| Store Master | `source_store_id`, `store_name`, `brand`, `address`, `open_date`, `status` | Store ID 穩定；地址可對位；狀態可追蹤 | 缺地址進人工校正 |
| Machine Master | `source_machine_id`, `store_id`, `machine_family`, `capacity_kg`, `install_date`, `status` | 機台編號變更需有映射 | 換機或退役不得覆蓋歷史 |
| Transaction | `transaction_id`, `store_id`, `machine_id`, `event_time`, `amount`, `status` | 交易 ID 唯一；退款/作廢可追蹤 | 更正需以 adjustment 或版本表達 |
| Price／Promotion | `price_plan_id`, `store_id`, `machine_family`, `effective_from`, `price` | 生效時間不可重疊或需規則解決 | 衝突進 Quarantine |
| Maintenance | `work_order_id`, `machine_id`, `fault_type`, `opened_at`, `closed_at` | 工單狀態與 TTR 可計算 | 無關聯機台需人工對位 |
| Customer Service | `ticket_id`, `store_id`, `topic`, `created_at`, `resolved_at` | 主題分類可版本化 | 個資需遮罩或去識別 |
| Lease／Asset | `store_id`, `lease_start`, `lease_end`, `rent`, `asset_list` | 財務數字需可對帳 | 缺失不得正式 AVM／NetPlan |

## 6. 外部資料 Connector 需求

| 資料類型 | 用途 | 版本化要求 | 風險 |
|---|---|---|---|
| 人口／戶數 | External Demand、HeatZone | 保存統計年度與發布日期 | 更新慢、行政區變更 |
| POI | 商圈結構、需求類型、Comparable | 保存來源、取得時間、分類版本 | 重複、過期、分類不一致 |
| 道路／交通／等時圈 | 可達性、服務範圍 | 保存路網版本與算法參數 | 直線距離不等於可達時間 |
| 租金 | 租金合理性、NetPlan | 保存區域、期間、分位 | 樣本偏誤與行情變動 |
| 競店／自家店 | 競爭缺口、自家稀釋 | 保存品牌、容量、位置、觀察時間 | 競店品質不一致 |
| 天氣／假日／學期 | ForecastOps、Seasonality | 保存地區、日期、來源 | 缺值、區域對位 |
| Listing | 物件機會 | 保留原始來源紀錄與快照 | 授權、重複、失效、地址錯誤 |

## 7. API 與 Event 整合需求

### 7.1 API 通用要求

| 要求 | 說明 |
|---|---|
| Authentication | 內部與外部 API 必須有服務身份或 OAuth／等效授權 |
| Authorization | 必須檢查資料範圍與動作權限 |
| Idempotency | 建立、核准、執行類 API 必須支援 Idempotency Key |
| Pagination | 清單 API 必須支援分頁、排序與篩選 |
| Error Code | 必須有穩定錯誤碼，錯誤訊息不得洩漏敏感資訊 |
| Correlation ID | 必須在 Request、Response、Log、Event 中保留 |
| Versioning | API 必須版本化，破壞性變更需新版本 |

### 7.2 Event 通用要求

| 要求 | 說明 |
|---|---|
| Event ID | 全域唯一，供去重使用 |
| Event Version | Schema 版本 |
| Occurred At | 事件真實發生時間 |
| Observed At | 系統觀察或接收時間 |
| Producer | 事件來源服務 |
| Subject | Store、Listing、Decision 等主要實體 |
| Idempotency | Consumer 重送不得造成重複副作用 |
| DLQ | 解析失敗或處理失敗需進 Dead Letter |

## 8. 資料可攜與匯出

系統必須提供：

1. CSV／JSON 格式匯出。
2. 依 Role 與 Scope 控制匯出範圍。
3. 匯出資料字典與欄位說明。
4. 敏感資料遮罩與水印。
5. 匯出 Audit，包括 Actor、時間、條件、筆數、資料分類。
6. 支援 ERP、CRM、BI 或後續第三方整合的版本化 API。

## 9. 整合驗收需求

| 驗收 ID | 內容 |
|---|---|
| `ODP-AC-INT-001` | 任一上游資料可重送相同批次而不造成重複 Canonical 實體。 |
| `ODP-AC-INT-002` | 上游 Store ID 改名或機台換編號仍可保留歷史連續性。 |
| `ODP-AC-INT-003` | 外部資料缺漏或過期時，模型輸出顯示 Stale／Confidence 降低或被阻擋。 |
| `ODP-AC-INT-004` | Listing 多來源重複能被群組並保留原始來源。 |
| `ODP-AC-INT-005` | 交易更正、退款、作廢可追溯，不得覆蓋無紀錄。 |
| `ODP-AC-INT-006` | 任一 API／Event 均可透過 Correlation ID 串接 Trace。 |
| `ODP-AC-INT-007` | 匯出資料符合權限、遮罩與 Audit 要求。 |

## 10. 後續文件

本文件將由 `ODP-DATA-01` 至 `ODP-DATA-07` 細化資料契約與來源盤點，由 `ODP-SD-06`、`ODP-SD-07`、`ODP-SD-10` 細化 API、Event 與可靠性設計。
