---
doc_id: ODP-SA-02
title: "AS-IS／TO-BE 業務流程"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Business Analyst / Product Lead"
approvers: "Domain Business Owners / Operations Governance Head"
content_format: markdown
---

# ODay Plus AS-IS／TO-BE 業務流程

## 1. 文件目的

本文件定義 ODay Plus 導入前後的主要業務流程差異，並以流程圖、泳道責任、例外情境與驗收要求描述完整平台的流程轉換。此文件是後續 Workflow、狀態機、任務中心、E2E 測試與 UAT 劇本的 SA 基線。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 流程設計總原則

1. 系統流程必須以資料、模型、政策、人工核准與 Outcome 回收組成閉環。
2. 系統不得把 Prediction 視為 Decision；不得把 Recommendation 視為 Execution。
3. 任何可造成資本支出、價格變動、廣告預算、估值、搬遷或退場的流程，都必須有人工作用點與 Audit Trail。
4. 長時間工作必須以 Job／Workflow 表達，不得讓使用者同步等待完整計算。
5. 每條流程必須有明確狀態、責任人、SLA、逾時升級、取消與重試規則。

## 3. AS-IS／TO-BE 總覽

| 流程 ID | 流程 | AS-IS 問題 | TO-BE 流程 |
|---|---|---|---|
| `P01` | 展店發現 | 業務依熟悉區域或仲介推薦找店，缺乏全台優先順序 | HeatZone 先掃描全台區域，產生熱區分數、需求缺口、租金區間與展店任務 |
| `P02` | 出租物件蒐集 | 物件由人工、零散仲介或臨時資料提供，重複與失效難管理 | Listing Pipeline 支援多來源接入、地址解析、去重、Hard Rules 與狀態追蹤 |
| `P03` | 店址審查 | 找到物件後才用經驗判斷商圈與租金，缺少可驗證預測 | SiteScore 對候選點輸出營收路徑、回本期、稀釋、租金合理性與決策建議 |
| `P04` | 新店驗證 | 開店後只看營收是否漂亮，少與原始假設比對 | 開店後自動計算 M1/M3/M6/M12 Realization，回饋 SiteScore 與 HeatZone |
| `P05` | 營運監控 | 營收下滑或客訴累積後才人工處理 | ForecastOps 每日／每週預測成長軌跡與四燈 Evidence，提前觸發處置 |
| `P06` | 營運處置 | 不同區域督導各自處理，缺少衝突、觀察窗口與結果回收 | InterventionOps 統一 Eligibility、Action、Approval、Execution、Outcome |
| `P07` | 價格調整 | 依經驗或短期促銷調價，無安全限制與效果驗證 | PriceOps 產生 Safe Action Set、需求／毛利模擬與核准後小範圍測試 |
| `P08` | 廣告活動 | 看活動前後或 ROAS，難分自然成長與廣告增量 | AdLift 建立對照組、檢查 Pre-trend、輸出 Incremental GM 與 iROMI |
| `P09` | 轉讓估值 | 轉手仰賴人工議價與零散資料，價格不透明 | DealRoomAVM 輸出三鏡頭估值、P10/P50/P90、Data Room 與交易結果回收 |
| `P10` | 店網重配 | 留守、遷點、退出多用會議主觀判斷 | NetPlan 在硬限制下產生 OPEN/KEEP/IMPROVE/MOVE/EXIT 方案與替代方案 |
| `P11` | 模型發布 | 模型與規則升版缺少業務可見版本與回滾 | Learning Hub 管理 Model Card、Champion/Challenger、Shadow/Canary/Rollback |
| `P12` | 治理稽核 | 決策分散在訊息、會議與報表，難以查核 | OpsBoard 保存任務、核准、執行、Outcome、版本與證據匯出 |


## 4. 端到端 TO-BE 主流程

```mermaid
flowchart TB
  subgraph EXP[展店前]
    A1[HeatZone 排序] --> A2[熱區指派]
    A2 --> A3[Listing 蒐集/去重/初篩]
    A3 --> A4[SiteScore 評估]
    A4 --> A5{人工開店審查}
    A5 -->|GO| A6[建立開店決策與 Snapshot]
    A5 -->|WAIT/REJECT/FIELD_SURVEY| A7[任務或拒絕理由]
  end
  subgraph OPS[開店後]
    A6 --> B1[Store Opened]
    B1 --> B2[SiteScore Realization]
    B2 --> B3[ForecastOps 預測與四燈]
    B3 --> B4{是否需干預}
    B4 -->|是| B5[InterventionOps]
    B4 -->|否| B6[持續監控]
    B5 --> B7[Outcome 與效果驗證]
  end
  subgraph ASSET[資產與店網]
    B3 --> C1{長期偏離/租約/商圈變動}
    C1 -->|是| C2[DealRoomAVM]
    C2 --> C3[NetPlan]
    C3 --> C4{管理層核准}
    C4 -->|核准| C5[執行開留改搬退]
    C5 --> C6[90/180/365 Outcome]
  end
  B7 --> L[Learning Hub]
  C6 --> L
  L --> A1
  L --> A4
  L --> B3
```

## 5. 關鍵流程詳細說明

### 5.1 P01 展店發現流程

**AS-IS：** 展店業務先找物件，再由人員用經驗判斷商圈。此流程造成熱門商圈不一定適合 ODay G2、低租金物件可能需求不足、業務未注意高需求區，以及大量無效現勘。

**TO-BE：**

```mermaid
flowchart LR
  A[外部資料快照完成] --> B[HeatZone 批次評分]
  B --> C[熱區狀態更新]
  C --> D[展店優先排名]
  D --> E[區域指派]
  E --> F[Listing Pipeline 啟動]
```

| 步驟 | Responsible | Accountable | 系統輸入 | 系統輸出 | Audit 要求 |
|---|---|---|---|---|---|
| 外部資料快照 | External Data Owner | Data Governance Owner | 人口、POI、租金、競店、自家店 | Data Snapshot | source、snapshot_time、coverage |
| 熱區評分 | Geo／Demand Model Owner | Expansion Director | `geo_grid_view` | HeatZone Score、Rank、Confidence | model_version、feature_snapshot |
| 區域指派 | 展店主管 | Expansion Director | Priority Rank | 熱區任務 | actor、理由、期限 |

### 5.2 P02 Listing 蒐集與初篩流程

```mermaid
flowchart LR
  A[人工/CSV/Feed/API] --> B[來源保存]
  B --> C[地址正規化]
  C --> D[Geocode + H3]
  D --> E[去重群組]
  E --> F[Hard Rules]
  F --> G[HeatZone Filter]
  G --> H[物件看板]
```

TO-BE 要求：Listing 不得直接覆蓋舊紀錄；每個來源紀錄必須保存 source_system、source_record_id、版本、取得時間與原始值。去重應保留信心值與人工拆分／合併能力。

### 5.3 P03 SiteScore 審查流程

```mermaid
flowchart TB
  A[候選物件進入 SiteScore] --> B[凍結 Input Snapshot]
  B --> C[Predictive Score]
  B --> D[Feasibility Rules]
  C --> E[營收路徑 P10/P50/P90]
  D --> F[硬限制結果]
  E --> G[SiteScore Report]
  F --> G
  G --> H{展店審查}
  H -->|GO| I[Approved Decision]
  H -->|GO_WITH_CONDITION| J[條件與任務]
  H -->|WAIT| K[等待原因與重評時間]
  H -->|REJECT| L[拒絕理由]
  H -->|FIELD_SURVEY| M[現勘任務]
```

TO-BE 要求：硬規則不得被高分抵銷。開店核准時必須保存模型版本、政策版本、Feature Snapshot、報告 PDF／HTML 與人工核准理由。

### 5.4 P05 ForecastOps 預警流程

```mermaid
flowchart LR
  A[每日營運資料完成] --> B[Forecast Feature Build]
  B --> C[4/8/12/24 週預測]
  C --> D[Trajectory / Change Point]
  D --> E[Evidence Vector]
  E --> F[四燈 Decision Policy]
  F --> G[OpsBoard Alert]
```

四燈不得由單一 LSTM 或單一模型直接輸出；四燈必須由 Decision Policy 結合預測殘差、成本、設備、客服、外部因素與 SiteScore Gap 形成。

### 5.5 P06 InterventionOps 處置閉環

```mermaid
stateDiagram-v2
  [*] --> CANDIDATE
  CANDIDATE --> ELIGIBLE: eligibility_passed
  CANDIDATE --> INELIGIBLE: eligibility_failed
  ELIGIBLE --> CONFLICT_CHECKED
  CONFLICT_CHECKED --> APPROVAL_PENDING
  APPROVAL_PENDING --> APPROVED
  APPROVAL_PENDING --> REJECTED
  APPROVED --> EXECUTING
  EXECUTING --> OBSERVING
  OBSERVING --> OUTCOME_PENDING
  OUTCOME_PENDING --> EFFECT_EVALUATED
  EFFECT_EVALUATED --> CLOSED_CONTINUE
  EFFECT_EVALUATED --> CLOSED_ADJUST
  EFFECT_EVALUATED --> CLOSED_STOP
  EFFECT_EVALUATED --> ROLLBACK_REQUESTED
```

TO-BE 要求：任何干預必須明確定義 Treatment、範圍、開始、結束、Observation Window、Reward／Outcome、衝突活動、Evidence Level。

### 5.6 P09／P10 AVM 與 NetPlan 流程

```mermaid
flowchart LR
  A[長期偏離/租約/商圈變動] --> B[AVM 正常化]
  B --> C[Income/Asset/Market]
  C --> D[Fair/Reserve/Asking]
  D --> E[Data Room]
  E --> F[NetPlan 情境]
  F --> G[Solver + Constraints]
  G --> H[Alternative Plans]
  H --> I[Management Approval]
  I --> J[Execution Tracking]
  J --> K[90/180/365 Outcome]
```

TO-BE 要求：Solver 無可行解時必須輸出 infeasibility reason，不得自動放寬硬限制。正式店網決策必須由管理層核准。

## 6. 流程例外處理

| 例外 | 適用流程 | 系統行為 | 人工責任 |
|---|---|---|---|
| 外部資料過期 | HeatZone、Listing、SiteScore、NetPlan | 標記 Stale、降低 Confidence 或阻擋評分 | Data Owner 判斷是否補資料或使用替代來源 |
| 地址解析失敗 | Listing、SiteScore | 進入人工校正 Queue | 展店人員或資料人員補正 |
| 模型不可用 | SiteScore、ForecastOps、AVM | 使用核准 fallback 或阻擋高風險決策 | Service Owner 與 Model Owner 處理 |
| 硬限制違反 | SiteScore、PriceOps、NetPlan | 不輸出 GO／不輸出可執行方案 | Decision Owner 判斷是否修正輸入，不得直接覆寫 |
| 干預衝突 | InterventionOps、AdLift、PriceOps | 顯示衝突、要求調整 Observation Window 或排除 | 業務 Owner 選擇優先動作 |
| Outcome 未成熟 | ForecastOps、AdLift、AVM、NetPlan | 不得進入訓練標籤；顯示 pending | Data Owner 與 Model Owner 等待成熟或標記不可用 |

## 7. 流程驗收要求

| 驗收類型 | 驗收內容 |
|---|---|
| E2E | 可從一筆外部熱區資料追蹤到物件、SiteScore、開店、Forecast、干預、Outcome 與回訓。 |
| 權限 | 不同角色只能看到或操作其授權流程。 |
| Audit | 每個人工核准、Override、執行與結果都可追溯 Actor、時間、版本與理由。 |
| 狀態機 | 每條流程不得跳過必要狀態；取消、失敗、重試、逾時需可測試。 |
| 資料語意 | Event Time、Decision Time、Outcome Time 與 Label Maturity Time 不得混用。 |

## 8. 後續設計輸入

本文件輸出將進入：`ODP-SD-08_WORKFLOW_JOB_AND_STATE_MACHINE_DESIGN.md`、各 `ODP-MOD-*` 文件、`ODP-QA-03_END_TO_END_TEST_SCENARIOS.md` 與 `ODP-UX-03_SCREEN_AND_INTERACTION_SPECIFICATIONS.md`。
