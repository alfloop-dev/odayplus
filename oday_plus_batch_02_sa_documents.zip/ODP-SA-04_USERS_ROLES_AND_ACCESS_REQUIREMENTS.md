---
doc_id: ODP-SA-04
title: "使用者、角色與權限需求"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Product Lead / Security Owner"
approvers: "Domain Business Owners / Security Owner / Privacy Owner"
content_format: markdown
---

# ODay Plus 使用者、角色與權限需求

## 1. 文件目的

本文件定義 ODay Plus 使用者類型、角色、資料範圍、功能權限、資料敏感度、高風險動作、核准需求與權限驗收標準。此文件為 `ODP-SD-09` 身分資安設計、OpsBoard 前端路由、API 授權與 UAT 權限測試的 SA 基線。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 2. 授權模型

ODay Plus 必須同時使用 RBAC 與 ABAC：

```text
Effective Permission = Role Permission × Data Scope × Object State × Risk Level × Policy Condition
```

| 控制面 | 說明 |
|---|---|
| Role | 使用者可執行哪些功能，例如查看 SiteScore、核准干預。 |
| Data Scope | 使用者可查看哪些 Tenant、Brand、Region、Store、Campaign 或 Deal。 |
| Object State | 物件狀態是否允許該操作，例如已核准價格不可直接修改。 |
| Risk Level | 高風險動作需要二次核准或更高角色。 |
| Policy Condition | 依業務規則限制，例如紅燈才可建立某些干預。 |

## 3. 角色總表

| Role ID | 角色 | 主要工作區 | 可做事項 | 限制 |
|---|---|---|---|---|
| `ROLE-EXEC` | 管理層 | 全平台 | 核准策略、資本配置、NetPlan 重大方案 | 不可修改模型參數或資料來源 |
| `ROLE-EXPANSION-REP` | 展店業務 | HeatZone、Listing | 查看熱區、建立/更新物件、安排現勘 | 不可核准開店或看非授權區域財務 |
| `ROLE-SITE-REVIEWER` | 展店審查人員 | SiteScore | 查看 SiteScore、提出 GO/WAIT/REJECT 建議、要求補件 | 不可覆寫模型版本或硬規則 |
| `ROLE-OPS-MANAGER` | 營運主管 | ForecastOps、InterventionOps | 查看四燈、核准處置、追蹤恢復 | 不可直接變更價格或模型 |
| `ROLE-SUPERVISOR` | 區域督導 | ForecastOps、InterventionOps | 執行處置、回報結果、管理任務 | 只能看轄區門市 |
| `ROLE-MARKETING` | 行銷團隊 | AdLift、Promotion、CRM | 建立活動、查看增量、核准投放建議 | 不可看無關財務估值 |
| `ROLE-PRICING` | 定價團隊 | PriceOps | 設定價格策略、核准安全方案 | 不可繞過毛利底線或執行未核准價格 |
| `ROLE-FINANCE` | 財務/資產 | DealRoomAVM | 查看估值、正常化毛利、設定 Reserve Price | 不可核准店網搬退最終方案 |
| `ROLE-LEGAL` | 法務 | DealRoom、NetPlan | 查看租約、交易、資料授權與風險 | 不可修改模型輸出 |
| `ROLE-FRANCHISEE` | 加盟主 | OpsBoard 加盟主入口 | 查看自身門市、任務、建議與執行結果 | 不可看其他加盟主資料 |
| `ROLE-DATA` | 資料工程/治理 | Integration、Learning Hub | 管理資料品質、來源、Snapshot、Feature Contract | 不可核准業務決策 |
| `ROLE-ML` | AI/模型團隊 | Learning Hub、模型服務 | 訓練、驗證、發布模型、監控漂移 | 不可單獨核准高風險業務行動 |
| `ROLE-SRE` | 平台/SRE | 全平台技術營運 | 部署、監控、事件處理、回滾服務 | 不可改業務規則或模型權重 |
| `ROLE-AUDIT` | 稽核/治理 | OpsBoard、Learning Hub | 查核決策、版本、證據與權限 | 不可修改原始紀錄 |
| `ROLE-ADMIN` | 系統管理員 | 平台管理 | 管理帳號、角色、設定、Feature Flag | 高風險 Feature Flag 需雙人核准 |


## 4. 資料範圍 Scope

| Scope | 定義 | 用途 |
|---|---|---|
| `tenant_scope` | 租戶資料範圍 | SaaS 與多客戶隔離 |
| `brand_scope` | 品牌資料範圍 | ODay 或其他品牌隔離 |
| `region_scope` | 管理區域範圍 | 展店、營運與督導權限 |
| `store_scope` | 單店資料範圍 | 加盟主、店長、區域督導 |
| `module_scope` | 模組功能範圍 | 只開啟必要模組 |
| `data_class_scope` | 資料敏感度範圍 | 個資、財務、估值、模型治理 |
| `time_scope` | 可查詢歷史區間 | 防止過度查詢歷史資料 |

## 5. 資料敏感度分級

| 等級 | 內容 | 預設可見角色 | 控制要求 |
|---|---|---|---|
| `PUBLIC_INTERNAL` | 不含個資與商業敏感的內部資訊 | 內部角色 | 登入後可見 |
| `BUSINESS_CONFIDENTIAL` | 營收、租金、模型輸出、熱區分數 | 授權業務與管理角色 | RBAC + Scope |
| `FINANCIAL_SENSITIVE` | 毛利、估值、Reserve Price、交易條件 | 財務、管理層、授權法務 | 強化 Audit、匯出限制 |
| `PERSONAL_DATA` | 會員、客服聯絡資訊、個資 | 最小授權角色 | 遮罩、目的限制、存取紀錄 |
| `MODEL_GOVERNANCE` | Model Card、訓練資料、漂移、發布 | AI／資料／稽核／管理授權 | 發布 Gate、不可任意下載 |
| `SECURITY_SECRET` | Secret、Token、金鑰、Service Account | 平台／資安 | 不得由一般 UI 顯示 |

## 6. 功能權限矩陣

| 功能 | 展店業務 | 展店審查 | 營運主管 | 區域督導 | 行銷 | 定價 | 財務 | 管理層 | 加盟主 | AI/資料 | 稽核 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 查看 HeatZone | R | R | V | V | V | V | V | V | - | V | V |
| 指派熱區任務 | C | - | - | - | - | - | - | A | - | - | V |
| 建立／匯入 Listing | R | C | - | - | - | - | - | V | - | C | V |
| 觸發 SiteScore | R | R | - | - | - | - | - | V | - | C | V |
| 核准開店 GO | C | R/A | - | - | - | - | C | A | I | - | V |
| 查看 ForecastOps | - | - | A | R | - | - | V | V | Own Store | C | V |
| 建立處置單 | - | - | A | R | C | C | - | V | C | - | V |
| 核准價格方案 | - | - | C | C | C | A/R | C | V | I | C | V |
| 核准廣告活動 | - | - | C | C | A/R | C | - | V | I | C | V |
| 查看 AVM | - | - | V | - | - | - | A/R | V | Conditional | C | V |
| 核准 NetPlan | - | - | C | C | C | C | C | A/R | I | C | V |
| 發布模型 | - | - | I | - | I | I | I | I | - | R/A | V |
| 查閱 Audit | - | - | V | V | V | V | V | V | Own Store | V | A/R |

符號：`R` 可執行；`A` 最終負責；`C` 需諮詢；`I` 被通知；`V` 可查看；`-` 不可存取；`Own Store` 僅限自身門市；`Conditional` 需依交易或授權情境開啟。

## 7. 高風險動作與核准要求

| 高風險動作 | 風險 | 最低核准要求 | 必須留存 |
|---|---|---|---|
| SiteScore GO | 資本投入與租約風險 | 展店審查 + 管理層或授權主管 | 報告、模型版本、理由、條件 |
| 覆寫 SiteScore 建議 | 模型建議與人工判斷衝突 | 展店主管 + 理由 | Override reason、Evidence |
| 調價上線 | 毛利、品牌、客訴與法規風險 | 定價 Owner + 營運主管 | Safe Action Set、Simulation、Approval |
| 廣告預算加碼 | 行銷成本與誤判增量 | 行銷 Owner + 預算 Owner | Campaign、Control、Budget、Expected Outcome |
| 停止或回滾干預 | 可能影響營收或顧客體驗 | 原核准者或更高層級 | Stop／Rollback reason、時間 |
| AVM Reserve Price | 交易價格與財務風險 | 財務 + 法務 | 估值版本、正常化調整、核准理由 |
| NetPlan MOVE／EXIT | 租約、人員、資本與品牌風險 | 管理層 + 財務／法務諮詢 | Alternative Plans、硬限制、核准紀錄 |
| 模型升級 Production | 決策品質風險 | Model Owner + Validation Owner + Release Owner | Model Card、Backtest、Canary、Rollback plan |
| Data Quality Gate Override | 污染模型與報表 | Data Governance Owner + Risk Owner | Gate result、例外期限、補救方案 |

## 8. 加盟主存取原則

1. 加盟主只能查看自身門市與被授權交易／估值資料。
2. 加盟主可查看自身門市的四燈狀態、建議處置、任務、執行結果與與自身相關的 SiteScore／AVM／NetPlan 摘要。
3. 加盟主不得查看其他門市的原始營收、估值、會員、客服個資或模型訓練資料。
4. 加盟主可對處置任務回報執行狀態與意見，但不得直接修改系統預測、模型輸出或 Decision Policy。
5. 加盟主可下載自身門市的授權報表；報表匯出必須有水印、時間、使用者與追蹤 ID。

## 9. 權限驗收需求

| 驗收 ID | 需求 | 測試方式 |
|---|---|---|
| `ODP-AC-AUTH-001` | 未登入使用者不得存取任一受保護 API 或頁面 | E2E + API test |
| `ODP-AC-AUTH-002` | 不同 Region 的督導不得查看彼此門市明細 | ABAC test |
| `ODP-AC-AUTH-003` | 加盟主只能查看自身門市資料 | Tenant／Store scope test |
| `ODP-AC-AUTH-004` | 高風險動作未具備核准角色時不可提交 | Permission test |
| `ODP-AC-AUTH-005` | 權限錯誤必須記錄 Actor、時間、IP、資源與原因 | Security audit test |
| `ODP-AC-AUTH-006` | 匯出個資、財務與估值資料必須記錄並套用遮罩／授權 | Export audit test |
| `ODP-AC-AUTH-007` | Service Account 權限不得超出最小必要範圍 | IAM review |

## 10. 後續 SD 輸入

- `ODP-SD-09` 必須將本文件轉為 IAM、RBAC、ABAC、Service Account、Secret、Audit 與個資設計。
- `ODP-UX-01` 與 `ODP-UX-03` 必須依本文件建立角色導覽與頁面可見性。
- `ODP-QA-05` 必須建立權限、資安與個資測試。
