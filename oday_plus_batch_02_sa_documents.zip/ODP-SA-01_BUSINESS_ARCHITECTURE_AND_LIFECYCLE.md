---
doc_id: ODP-SA-01
title: "業務架構與加盟生命週期"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Business Architecture Owner / Product Lead"
approvers: "Executive Sponsor / Domain Business Owners / Architecture Owner"
content_format: markdown
---

# ODay Plus 業務架構與加盟生命週期

## 1. 文件目的

本文件定義 ODay Plus 的業務架構、加盟生命週期、決策閉環、價值流、主要業務事件、跨模組業務關係與 SA 層級的驗收邊界。它回答「ODay Plus 到底支援哪些業務活動、每一活動如何形成可追蹤決策，以及系統如何把真實結果回饋下一次決策」。

## 0. 文件基線與引用規則

本文件屬於第 2 批 SA 主文件，必須與第一批治理文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、上游邊界、完整目標架構 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞、代碼、狀態與業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、治理會議與責任分離 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、批次、ADR 與變更治理 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、需求追蹤與後續測試證據鏈 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第一批治理文件衝突，以第一批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選能力或延伸能力。


## 1.1 SA 邊界

本文件屬 SA，不定義資料表欄位、API Schema、部署拓樸或前端元件。後續 SD 與模組詳細設計不得改變本文件定義的業務生命週期、責任分離與 Outcome 回收要求；如需調整生命週期或決策邊界，必須建立 ADR。

## 2. 業務願景

ODay Plus 必須把自助洗衣品牌從「靠經驗展店、事後看報表、營運異常再處理」轉為「以資料、模型、人工核准與實績回收共同運作」的可治理加盟生命週期平台。

ODay Plus 的核心業務閉環如下：

```mermaid
flowchart LR
  D0[資料與語意治理] --> D1[展店發現]
  D1 --> D2[物件蒐集]
  D2 --> D3[店址評估]
  D3 --> D4[開店核准]
  D4 --> D5[開店與實績]
  D5 --> D6[營運預測]
  D6 --> D7[營運干預]
  D7 --> D8[效果驗證]
  D6 --> D9[估值]
  D9 --> D10[店網重配]
  D8 --> D11[學習與治理]
  D10 --> D11
  D11 --> D0
  D11 --> D1
  D11 --> D3
  D11 --> D6
```

## 3. 加盟生命週期階段


| 生命週期階段 | 主要業務問題 | 核心模組 | 主要決策 | 主要 Outcome |
|---|---|---|---|---|
| 0. 資料接入與語意治理 | 內部、IoT 與外部資料是否可被同一平台理解？ | Integration Layer、Learning Hub | 資料是否可發布、是否可用於模型 | Canonical Data、Model-ready Views、資料品質結果 |
| 1. 展店發現 | 全台哪些區域值得優先找店？ | HeatZone Radar | 熱區優先順序與區域指派 | 熱區任務、候選區域、需求吸收狀態 |
| 2. 物件蒐集與初篩 | 熱區內有哪些可評估物件？ | Listing Pipeline | 是否進入現勘或 SiteScore | 物件清單、去重群組、初篩結果 |
| 3. 候選店址評估 | 具體物件是否適合 ODay G2？ | SiteScore | GO／WAIT／REJECT／FIELD_SURVEY | SiteScore Report、開店核准或拒絕 |
| 4. 開店與實績回收 | 原始預測是否實現？ | SiteScore Realization、ForecastOps | 是否需校正模型或啟動營運追蹤 | M1／M3／M6／M12 Realization Ratio |
| 5. 營運預測與預警 | 門市未來會成長、平台或衰退？ | ForecastOps | 四燈與根因候選 | 4／8／12／24 週 Forecast、Evidence Vector |
| 6. 營運干預 | 應採取哪種處置？ | InterventionOps、PriceOps、AdLift、Promotion、CRM、Maintenance | 處置核准、執行與觀察 | Action、Observation Window、Outcome |
| 7. 干預效果驗證 | 處置是否真的帶來增量？ | PriceOps、AdLift、Learning Hub | Continue／Adjust／Stop／Rollback | Incremental Revenue、Incremental GM、Evidence Level |
| 8. 資產估值 | 長期低效店值多少？是否可轉手？ | DealRoomAVM | Fair／Reserve／Asking、交易策略 | 估值區間、Data Room、交易結果 |
| 9. 店網重配 | 應開、留、改善、搬、退哪些店？ | NetPlan | OPEN／KEEP／IMPROVE／MOVE／EXIT | Network Plan、Alternative Plans、90／180／365 日 Outcome |
| 10. 學習與治理 | 下一次決策如何更準且可稽核？ | Learning Hub、OpsBoard | 模型發布、回滾、資料阻擋、稽核 | Model Card、Decision Card、Audit Trail、Evidence Package |


## 4. 價值流 Value Streams

### 4.1 展店價值流：從熱區到新店

```mermaid
flowchart LR
  A[全台外部資料與既有店實績] --> B[HeatZone 產生區域機會]
  B --> C[展店人員指派熱區]
  C --> D[Listing Pipeline 蒐集與去重物件]
  D --> E[SiteScore 評估候選點]
  E --> F[展店審查會核准或拒絕]
  F --> G[開店]
  G --> H[M1/M3/M6/M12 實績回收]
  H --> I[Realization 回饋 HeatZone 與 SiteScore]
```

展店價值流的核心 Outcome 不是「產生一張地圖」或「產生一份報告」，而是展店團隊是否能更早排除低品質區域、降低無效現勘、提升新店達標率、降低自家稀釋。

### 4.2 營運價值流：從預警到修復

```mermaid
flowchart LR
  A[每日交易/設備/成本/客服/維修] --> B[ForecastOps 預測與 Evidence]
  B --> C[四燈 Decision Policy]
  C --> D[InterventionOps 建立處置候選]
  D --> E[Conflict Check 與人工核准]
  E --> F[執行價格/廣告/促銷/CRM/維修/清潔]
  F --> G[Observation Window]
  G --> H[Outcome 與效果估計]
  H --> I[Continue/Adjust/Stop/Rollback]
  H --> J[Label Registry 與模型回訓]
```

營運價值流必須把「系統預測」「系統建議」「人工核准」「實際執行」「實際結果」分離保存。營收變好不得自動解讀為處置有效；需根據 Treatment、Control、Observation Window 與 Evidence Level 判定。

### 4.3 資產與店網價值流：從低效店到資本配置

```mermaid
flowchart LR
  A[長期偏離/平台/衰退/租約節點] --> B[DealRoomAVM 正常化營運]
  B --> C[估值三鏡頭與 P10/P50/P90]
  C --> D[NetPlan 情境建立]
  D --> E[OPEN/KEEP/IMPROVE/MOVE/EXIT 求解]
  E --> F[Alternative Plans 與管理層核准]
  F --> G[執行轉讓/遷點/退出/改善]
  G --> H[90/180/365 日 Outcome]
  H --> I[估值與店網模型回饋]
```

資產價值流必須避免把單店短期營收波動誤判為結構性退場訊號；需要 ForecastOps、InterventionOps、AVM 與租約時程共同形成證據。

## 5. 業務物件與事件

| 業務物件 | 生命週期中的角色 | 主要來源 | 主要消費者 |
|---|---|---|---|
| `geo_cell` | 熱區與需求分析單元 | 外部資料、GIS、既有店 | HeatZone、NetPlan |
| `listing` | 出租物件來源紀錄 | 人工、CSV、Feed、API | Listing、SiteScore |
| `candidate_site` | 具體候選店址 | Listing、人工建立 | SiteScore、展店審查 |
| `store` | 已開業或管理中的門市 | 內部資料底座 | ForecastOps、AVM、NetPlan |
| `machine` | 設備與產能單元 | IoT／內部資料底座 | ForecastOps、Maintenance、AVM |
| `prediction` | 模型輸出 | Prediction Services | Decision Policy、OpsBoard |
| `recommendation` | 系統建議 | Decision Services | 人工核准、任務建立 |
| `decision` | 人工或正式決策 | OpsBoard／Workflow | Execution、Audit、Outcome |
| `intervention` | 公司實際干預 | InterventionOps | ForecastOps、AdLift、PriceOps、Learning Hub |
| `outcome` | 成熟後結果 | 實績、交易、財務、人工回報 | Backtest、KPI、Model Retraining |

## 6. 關鍵業務事件

| Event | 觸發原因 | 必須保存的資訊 | 下游用途 |
|---|---|---|---|
| `heat_zone.scored` | 熱區批次評分完成 | 版本、資料快照、分數、Confidence | 熱區工作台、Listing Filter |
| `listing.created` | 新物件進入系統 | 來源、地址、租金、坪數、H3、版本 | 去重、現勘、SiteScore |
| `site_score.generated` | 候選點評估完成 | Input Snapshot、模型版本、M1/M3/M6/M12、P10/P50/P90 | 展店審查、報告 |
| `site_decision.approved` | 人工核准開店 | Actor、政策版本、理由、條件 | 開店流程、Realization 基線 |
| `store.opened` | 門市正式開幕 | 開幕日、店型、設備、初始價格 | Store Age、Ramp、ForecastOps |
| `forecast.scored` | 營運預測完成 | Horizon、Prediction Interval、Evidence | 四燈與干預候選 |
| `alert.raised` | 四燈達警示條件 | 燈號、根因候選、Evidence Vector | InterventionOps、OpsBoard |
| `intervention.approved` | 處置被核准 | Action、範圍、觀察窗口、衝突結果 | Execution、Outcome Collector |
| `intervention.outcome_matured` | 觀察結果成熟 | Outcome、Evidence Level、增量指標 | Learning Hub、KPI |
| `valuation.generated` | 估值產出 | 三鏡頭估值、P10/P50/P90、保留價 | DealRoom、NetPlan |
| `network_plan.approved` | 店網方案核准 | 方案、硬限制、替代方案、理由 | 執行追蹤、90/180/365 Outcome |
| `model.release.changed` | 模型發布／回滾 | 版本、Alias、Gate、核准者 | Prediction、Audit |

## 7. 決策責任分離

| 階段 | 系統輸出 | 人工責任 | 不允許的設計 |
|---|---|---|---|
| HeatZone | 熱區排序與 Confidence | 指派區域、調整展店策略 | 系統自動指定簽約物件 |
| Listing | 物件優先排序 | 聯繫、現勘、資料補正 | 物件高分即自動進入開店 |
| SiteScore | GO／WAIT／REJECT 建議與報告 | 展店審查核准 | 模型輸出直接等於開店決策 |
| ForecastOps | 四燈 Evidence 與根因候選 | 營運主管確認是否處置 | 預測模型直接改價格或投廣告 |
| InterventionOps | 候選 Action 與衝突結果 | 區域督導／主管核准執行 | 不經核准自動執行高風險干預 |
| PriceOps | 安全候選價格與模擬 | 定價 Owner 核准 | 忽略毛利底線與品牌限制 |
| AdLift | 增量與 iROMI | 行銷團隊核准 Continue／Stop | 只看 ROAS 宣稱因果有效 |
| AVM | Fair／Reserve／Asking 參考 | 財務／法務／管理層核准交易 | 系統自動成交或強制轉手 |
| NetPlan | 最佳化方案與替代方案 | 管理層核准店網調整 | Solver 自動執行搬遷或退出 |

## 8. 業務驗收標準

| 驗收項目 | 業務檢查方式 | 主要依賴文件 |
|---|---|---|
| 完整生命週期覆蓋 | 可從熱區一路追蹤到 Outcome 與回訓 | `ODP-SA-05`, `ODP-SA-10` |
| 決策責任分離 | Prediction、Recommendation、Approval、Execution、Outcome 欄位分離 | `ODP-SA-07`, `ODP-DATA-04` |
| 多角色可用 | 展店、營運、行銷、定價、財務、管理層、加盟主各有工作流 | `ODP-SA-04`, `ODP-UX-01` |
| Outcome 可回收 | SiteScore、干預、AVM、NetPlan 均有成熟結果回收 | `ODP-SA-10`, `ODP-MOD-10` |
| 可稽核 | 任一正式決策可追溯來源資料、模型、政策、人員與結果 | `ODP-SA-10`, `ODP-QA-07` |

## 9. 待後續文件細化項目

| 項目 | 後續文件 |
|---|---|
| Canonical Data Model 與來源 Mapping | `ODP-DATA-04`, `ODP-DATA-05` |
| 各模組 API、Event、Job 與狀態機 | `ODP-SD-06`, `ODP-SD-07`, `ODP-SD-08` |
| 模型 Input／Target／Output 與驗證 | `ODP-ML-03`, `ODP-ML-04` |
| 每個工作區畫面與互動 | `ODP-UX-03` |
| 端到端測試與查核證據 | `ODP-QA-03`, `ODP-QA-07` |
