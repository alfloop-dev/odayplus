---
doc_id: ODP-00-01
title: "系統範圍與邊界說明書"
version: 0.2.0
status: draft-for-review
document_class: project-governance
batch: 1
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Product Lead / Architecture Owner"
approvers: "Executive Sponsor / Technology Lead / Domain Business Owners"
content_format: markdown
---

# ODay Plus 系統範圍與邊界說明書

## 1. 文件目的

本文件定義 ODay Plus 的產品範圍、系統邊界、資料責任、外部依賴、工程責任與驗收下限。任何模組設計、API、資料表、模型、前端畫面、工作流程或部署變更，都不得與本文件衝突；如需變更，必須建立 ADR 並更新需求追蹤矩陣。

## 1.1 基準來源與適用優先序

本文件以以下來源建立範圍基線：

| Source ID | 來源 | 用途 | 權威範圍 |
|---|---|---|---|
| `SRC-ODP-ARCH` | 《ODay Plus 展店管理系統》完整目標架構 | 完整產品、資料、模型、決策、治理與工程目標 | 產品與技術目標架構 |
| `SRC-ODP-PLAN` | ODay Plus／自助洗衣店生命週期管理相關計畫書 | 核定模組、KPI、GCP 與查核承諾 | 對外承諾與最低驗收基線 |
| `SRC-WORKING-DECISIONS` | 本專案已確認之工作決策 | IoT 為上游供應者；ODay Plus 其餘完整平台由本案整合建置 | 專案分工與實作邊界 |
| `SRC-LEGACY-CLOUD` | 既有 AI 自助商店遠端雲服務與 AI 客服契約／計畫書 | 可重用能力與歷史限制參考 | 參考資料；除非明確納入，不自動成為 ODay Plus 需求 |

若來源衝突：對外義務依已簽署契約與核定變更；產品與技術設計依已核准 SA／SD 與 ADR；詳細規則見 `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md`。

> **範圍決議：** ODay Plus 以全模組完整建置為目標。Stage／Phase 只表示依賴、整合、驗證與啟用順序，不代表刪減最終功能範圍。資料成熟度不足的進階能力仍須完成程式框架、資料契約、測試與治理入口，正式啟用則受 Gate 與 Feature Flag 控制。

## 2. 系統願景

ODay Plus 是自助洗衣品牌的完整決策與治理平台，不是單純的加盟管理後台，也不是多個模型的拼裝。平台必須形成下列閉環：

```mermaid
flowchart LR
    A[外部與內部資料整合] --> B[HeatZone 展店發現]
    B --> C[Listing 物件蒐集]
    C --> D[SiteScore 店址評估]
    D --> E[人工開店決策]
    E --> F[開店與營運實績]
    F --> G[ForecastOps 成長與異常]
    G --> H[InterventionOps 干預管理]
    H --> I[PriceOps／AdLift／營運處置]
    I --> J[Outcome 與因果效果]
    G --> K[DealRoomAVM 估值]
    K --> L[NetPlan 店網重配]
    J --> M[Learning Hub]
    L --> M
    M --> B
    M --> D
    M --> G
    M --> I
    M --> K
    N[OpsBoard 治理與稽核] --- B
    N --- D
    N --- G
    N --- H
    N --- K
    N --- L
    N --- M
```

平台必須持續回答：

1. 全台哪些區域值得優先展店？
2. 哪些出租物件值得勘查？
3. 某一具體物件是否適合 ODay G2？
4. 新店第 1、3、6、12 個月及成熟期營收如何？
5. 開店後實績是否符合 SiteScore 原始預測？
6. 每家店未來 4、8、12、24 週如何發展？
7. 營收變化是自然需求、季節、價格、廣告、設備還是其他原因？
8. 哪一種營運干預最適合，是否真的產生增量效益？
9. 長期低效店應留守、改善、遷點、轉手或退出？
10. 真實結果如何回饋模型與決策政策？

## 3. 系統上下文與責任邊界

```mermaid
flowchart TB
    subgraph UP[上游／外部系統]
      IOT[IoT 與內部資料底座]
      EXT[外部資料供應者]
      ADS[廣告／CRM／通知平台]
      IDP[企業身分來源]
    end

    subgraph ODP[ODay Plus 責任範圍]
      INT[Integration & Canonical Layer]
      DATA[Data Products & Model-ready Views]
      MOD[全部產品與決策模組]
      GOV[Learning Hub／OpsBoard／治理]
      UI[Web 前端與報告]
    end

    IOT --> INT
    EXT --> INT
    ADS <--> INT
    IDP --> GOV
    INT --> DATA --> MOD --> GOV --> UI
```

### 3.1 上游 IoT／內部資料底座負責

- 提供門市、設備、交易、會員、價格、促銷、維修、客服、能源、租約與資產等可用資料。
- 提供穩定主鍵或可建立主鍵映射的來源鍵。
- 提供資料發生時間、上傳時間、更新時間與刪改語意。
- 支援指定日期重拉、Backfill 或快照重建。
- 對其來源資料的正確性、完整度與可用性負責。
- 提供約定的 Batch、CDC、API、Webhook 或 Event 介面。

### 3.2 上游不負責

- 不需理解或實作 HeatZone、SiteScore、ForecastOps 等模型。
- 不需依賴 ODay Plus 的內部資料表。
- 不需負責預測、決策政策、人工核准、估值或店網最佳化。
- 不需直接將資料轉成每一模型專用格式。

### 3.3 ODay Plus 負責

- 上游與外部資料的擷取、驗證、標準化、版本化及重送控制。
- Canonical Data Model、ID Mapping、時間語意與資料品質。
- 外部地理、人口、POI、競店、租金、物件、道路、天氣等資料整合。
- 所有 Model-ready Views、Feature、Label、Dataset Snapshot。
- 所有預測、因果、最佳化與決策政策。
- 所有同步 API、批次、Worker、Workflow、報告與通知。
- OpsBoard 全部前端與工作台。
- Model Registry、Release、Rollback、Drift、Audit 與 Outcome 回收。

## 4. In Scope：產品與業務模組

### 4.1 Integration Layer／External Data Platform

必須包含：

- 內部來源 Adapter。
- 外部來源 Connector。
- API／檔案／Batch／CDC／Event 接入。
- Schema Validation、Quarantine、Retry、Backfill。
- 地址標準化、Geocode、H3、行政區、等時圈及道路可達性。
- Source-to-Canonical Mapping。
- Snapshot、Lineage、License、Coverage、Freshness、Confidence。
- Feature Materialization 與資料產品發布。

### 4.2 HeatZone Radar

必須包含：

- 全台 H3／生活圈格網。
- 外部洗衣需求、ODay G2 適配度、競爭缺口、自家稀釋、租金可行性及物件機會。
- 熱區排序與置信度。
- `UNTOUCHED`、`PARTIALLY_ABSORBED`、`SATURATED`、`UNDER_REALIZED`、`STILL_EXPANDABLE` 狀態。
- 開店結果對熱區需求吸收與剩餘需求的回饋。

### 4.3 Listing Pipeline

必須包含：

- 人工輸入、CSV／Excel、合作來源 Feed 與正式 API。
- 地址解析、Geocode、H3 對位與來源追蹤。
- 去重、版本化、價格／坪數／樓層／租期等欄位標準化。
- Hard Rules、HeatZone Filter、優先排序。
- 勘查、聯絡、失效、拒絕及轉 SiteScore 的狀態管理。

### 4.4 SiteScore

必須包含：

- External Demand、Brand Transfer、ODay G2 Format Conversion、Ramp、Seasonality。
- M1／M3／M6／M12／成熟穩態的 P10／P50／P90。
- 回本期、租金合理性、自家稀釋、主要正負因子及 Comparable Stores。
- 可行性硬規則與 `GO`、`GO_WITH_CONDITION`、`WAIT`、`REJECT`、`FIELD_SURVEY`。
- 人工核准、報告、版本與實績回收。
- SiteScore Realization Ratio。

### 4.5 ForecastOps

必須包含：

- 店級與設備級時間序列。
- 4／8／12／24 週預測及 28 日承諾視窗。
- Seasonal Naive、Statistical、Global ML、LSTM／Deep Challenger 及 Ensemble。
- P10／P50／P90 或經校準的預測區間。
- 成長階段、轉折、異常、SiteScore Gap 與 Root-cause Evidence。
- 綠／黃／橙／紅四燈。

### 4.6 InterventionOps

必須包含：

- Eligibility、Action Set、衝突與重疊活動控制。
- 建議、核准、實際執行、Observation Window、Outcome、Effect Evaluation。
- 價格、廣告、促銷、CRM 召回、維修與清潔等 Action Adapter。
- Evidence Level、Continue／Adjust／Stop／Rollback。
- 干預資料回寫 Label Registry，避免模型資料污染。

### 4.7 PriceOps

必須包含：

- 價格彈性、候選價格集合、需求與毛利模擬。
- 毛利底線、價差、時段、設備、法規與人工核准等限制。
- OR-Tools／CVXPY 等受限制最佳化。
- Pilot、效果評估與回滾。
- 高階 Contextual Bandit 的程式與治理接口，預設由 Feature Flag 關閉。

### 4.8 AdLift

必須包含：

- Ad Need Score、活動登記、店群／渠道／預算資訊。
- Matched Controls、Pre-trend、DiD、Synthetic Control、Uplift／HTE 接口。
- Incremental Revenue、Incremental Gross Margin、iROMI。
- Continue／Stop／Scale／Change Channel 建議。
- 無可靠對照或證據時不得宣稱因果。

### 4.9 DealRoomAVM

必須包含：

- GM_TTM、GM_FWD、設備折舊、資產台帳、租約及營運正常化。
- Income、Asset、Market／Comparable 三鏡頭估值。
- P10／P50／P90、Fair、Reserve、Asking Price 分離。
- 流動性、成交期間、Data Room 與估值報告。
- 實際成交價及交易週期回收。

### 4.10 NetPlan

必須包含：

- `OPEN`、`KEEP`、`IMPROVE`、`MOVE`、`EXIT`，並可擴充 `TRANSFER`。
- P50 Deterministic、Downside／Base／Upside、Rolling Horizon。
- 資本、租約、設備、施工、人力、區域、稀釋與時序限制。
- Alternative Plans、Binding Constraints、Infeasibility 說明。
- 季度甘特圖、8–12 季路線圖與 90／180／365 日結果。

### 4.11 Learning Hub

必須包含：

- Feature Contract、Label Registry、Outcome Maturity。
- Dataset Snapshot、Experiment Tracking、Model Registry。
- Backtest、Champion／Challenger、Shadow、Canary、Rollback。
- Data／Feature／Prediction／Performance Drift。
- Model Card、Decision Card、Release Approval。

### 4.12 OpsBoard

必須包含：

- 全台熱區、物件、SiteScore、門市軌跡、四燈、干預、價格、廣告、估值、NetPlan 與模型治理工作區。
- Task、Assignment、Comment、Attachment、Approval、Escalation。
- 預測、建議、核准、執行及結果的全鏈路留痕。
- 角色、區域、品牌、門市層級權限。
- 月度稽核、KPI、報表與查核證據匯出。

## 5. In Scope：共用平台能力

- Tenant／Brand／Region／Store 資料隔離。
- 使用者、群組、角色、RBAC／ABAC。
- 共用 Job、Workflow、Notification、Report、Attachment、Comment。
- Decision Log、Audit Event、Correlation ID。
- API Gateway、OpenAPI、AsyncAPI、Schema Registry。
- Feature Flag、Configuration、Secret、Environment Promotion。
- Observability、SLO、Incident、Backup、Restore、DR。
- 多語系基礎；第一版介面以繁體中文為主。
- CSV／JSON／PDF 報表及資料可攜。

## 6. Out of Scope

以下不由 ODay Plus 本案直接實作，但可透過介面整合：

- IoT 韌體、硬體電路、設備控制協議與現場裝機。
- 上游交易、支付、會員、客服或工單系統本身的重建。
- 金流清算、會計總帳及法定電子發票核心。
- 房仲平台、廣告平台或 CRM 平台本身。
- 法律上具有約束力的鑑價、授信、仲介或交易履約服務；系統只提供決策支援與紀錄。
- 未經人工核准的自動開店、退店、遷點、資產成交或大範圍價格調整。
- 未經授權的大規模網站爬取。
- 無資料成熟度條件下直接啟用 Bandit、MMM 或 Robust Optimization。

## 7. 外部系統與介面

| 外部系統 | ODay Plus 需要的能力 | 主要介面 | 失效時策略 |
|---|---|---|---|
| IoT／內部資料底座 | 店、機台、交易、會員、價格、工單、客服、能源、租約、資產 | Batch、CDC、API、Event | 使用最後成功快照；標示 stale；支援 Backfill |
| 地理／地址服務 | 地址正規化、座標、行政區、道路與等時圈 | API／批次資料 | 多供應者、Cache、人工校正 |
| 人口／POI／競店／租金 | 外部需求與成本特徵 | API／檔案／授權資料集 | Snapshot 版本、覆蓋率與信心降級 |
| 物件來源 | Listing Feed | API／CSV／合作 Feed | 保留人工輸入，不阻斷選址流程 |
| 天氣／假日／學期 | Forecast 與 Seasonality | API／批次 | 使用已知日曆及最近預報版本 |
| 廣告／CRM | 活動、預算、曝光、受眾、執行結果 | API／Webhook／檔案 | 活動可登記但 Evidence Level 降級 |
| 通知服務 | Email、LINE、SMS、Webhook | API | Queue、Retry、替代渠道 |
| 身分來源 | 員工與合作角色登入 | OIDC／SAML | Break-glass 管理帳號 |

## 8. 資料所有權與使用原則

| 資料類型 | System of Record | ODay Plus 是否可修改來源 | ODay Plus 保存內容 |
|---|---|---:|---|
| IoT／交易原始資料 | 上游資料底座 | 否 | 不可變 Raw Snapshot、Canonical Copy、品質結果 |
| 門市／機台主檔 | 上游主檔 | 否；可提出修正 | ID Mapping、Canonical Master、來源版本 |
| 外部資料 | 各來源／ODay Connector | 依授權 | 原始快照、授權、Coverage、Canonical Feature |
| 預測 | ODay Plus | 是 | Input Snapshot、Model Version、Output、Explanation |
| 決策與核准 | ODay Plus | 是 | Actor、Policy、Reason、Override、Timestamp |
| 實際執行 | 執行系統＋ODay Plus | 依整合方式 | Requested／Actual Action、Status、Evidence |
| Outcome | 上游＋ODay Plus | 是 | 觀察窗口、成熟度、效果估計、標籤 |

所有歷史訓練資料必須符合 Point-in-time Correctness。任何模型不得使用在原決策時間之後才可知的資訊。

## 9. 角色與資料範圍

| 角色 | 主要能力 | 預設資料範圍 |
|---|---|---|
| Platform Admin | 系統、租戶、角色與設定 | 全租戶，但敏感操作需稽核 |
| AI／Data Team | 資料、模型、回測與發布 | 經授權的匿名或業務資料 |
| 展店業務 | 熱區、物件、勘查 | 指派區域／品牌 |
| 展店審查 | SiteScore 與核准 | 指派案件 |
| 營運主管 | 全網門市、警示、干預 | 負責品牌／區域 |
| 區域督導 | 門市處置與回報 | 轄區門市 |
| 行銷 | AdLift、活動與 Outcome | 授權品牌／店群 |
| 定價／產品 | PriceOps | 授權品牌／店群 |
| 財務／法務 | AVM、租約、交易 | 指定案件或全網 |
| 管理層 | NetPlan、資本配置 | 全網彙總及核准資料 |
| 加盟主 | 自身門市狀態與任務 | 自有門市；不得看到其他店敏感資料 |
| 稽核 | 唯讀 Audit、Decision、Release | 依稽核範圍 |

## 10. 強制業務與治理原則

1. 預測、建議、核准、執行、結果必須分開保存。
2. 所有模型輸出必須包含 `model_version`、`feature_snapshot_time`、`prediction_origin_time` 與 `prediction_horizon`。
3. 所有決策必須包含 Actor、政策版本、理由與 Override。
4. 所有干預必須有 Observation Window 與 Outcome Maturity。
5. 所有高風險動作必須可停止或回滾。
6. 模型 Rollback 與業務 Decision Rollback 必須分開。
7. Data Quality Gate 可阻擋模型訓練、評分或發布。
8. Solver 無可行解時必須回傳診斷，不得任意放寬硬限制。
9. 因果證據不足時不得以「造成」或「增量」描述相關性結果。
10. 每一決策與 Outcome 必須可追溯到資料、特徵與模型版本。

## 11. 核定承諾的驗收下限

| 模組 | 最低承諾／查核指標 | 本設計處理方式 |
|---|---|---|
| SiteScore | 回本期 MAPE ≤ 12%；報告 ≤ 24 小時；API P95 ≤ 3 秒 | 作為模組驗收 Gate，不代表每筆同步重算完整模型 |
| ForecastOps | 28 日預測；四類指標；平均提前 ≥ 7 日；Precision ≥ 90% | LSTM 必須實作與評估，可由更佳 Champion 組合輸出 |
| DealRoomAVM | MAPE ≤ 15%；區間 Coverage ≥ 80%；報告 ≤ 3 工作日 | 區間校準與實際成交回收必須進資料模型 |
| NetPlan | 三案／多案；≤ 48 小時；至少 5 指標比較 | 非同步 Job；必須輸出 Solver 狀態與可行性 |
| OpsBoard | 留痕 100%；SLA ≥ 99.5%；月度稽核與報表 | `Decision Log` 和 `Audit Event` 為不可省略的核心能力 |

> 「MAPE ≦ ±12%」在數學上應正規化為「MAPE ≤ 12%」。

## 12. 非功能需求基線

| 類別 | 基線 |
|---|---|
| 可用性 | OpsBoard 月可用率至少 99.5%；更高商用 SLA 另行 ADR |
| 效能 | 互動查詢 P95 依功能分級；SiteScore 已完成結果查詢 P95 ≤ 3 秒 |
| 批次 | 每日預測與四燈在營運日開始前完成；失敗可重跑且冪等 |
| 可恢復 | 重要資料需備份、還原演練及明確 RPO／RTO；最終數值由 NFR 文件核准 |
| 安全 | 最小權限、MFA、加密、Secret 管理、完整稽核 |
| 個資 | 目的限制、去識別、保留期限、下載／刪除流程 |
| 可追溯 | 100% 高風險決策可追到資料與模型版本 |
| 可攜 | CSV／JSON 匯出；API 契約與資料字典可提供 |
| 可維護 | 模組化邊界、Schema Migration、CI/CD、自動測試 |
| 可降級 | 外部資料、深度模型、因果或 Solver 失敗時有明確 fallback |

## 13. 主要依賴與假設

- 上游至少能提供每日交易與門市／機台主檔；即時事件不是所有模組的前置條件。
- 跨品牌資料具有可合法用於模型訓練的授權與用途範圍。
- ODay G2 店型定義可版本化，初始為 3 台大型＋3 台中型洗脫烘一體機。
- 物件、租金、POI、人口與競店來源需保存來源日期及授權。
- 價格、廣告與維修等干預能取得實際執行記錄，而非只保存建議。
- 財務可提供估值所需毛利、資產與折舊口徑。
- 管理層可定義 NetPlan 的資本、租約、人力及硬限制。

## 14. 明確不允許的捷徑

- 讓各模型直接查詢上游來源表。
- 只保存目前最新預測而覆蓋歷史版本。
- 將人員核准寫回模型輸出欄位。
- 未記錄實際執行即開始效果估計。
- 用活動前後差異直接宣稱廣告或調價因果效果。
- 將店鋪品牌與設備品牌合為同一欄位。
- 將洗脫烘一體機簡化成洗衣機＋烘衣機數量相加。
- API Request 內同步重算全台 HeatZone、完整訓練或多季 NetPlan。
- Solver 失敗後悄悄放寬硬限制。
- 在 Production 直接修改資料或模型而無版本及 Audit。

## 15. 待決事項

| ID | 待決事項 | 影響 | Owner 建議 |
|---|---|---|---|
| DEC-001 | 上游每一資料域的實際交付介面與頻率 | Integration、SLA | IoT/Data Owner |
| DEC-002 | ODay G2 店型是否存在多版本 | SiteScore、Capacity | Product／Operations |
| DEC-003 | 正式商用 SLA 是否高於 99.5% | 架構成本、DR | Business Owner |
| DEC-004 | 價格方案的實際執行 API | PriceOps 閉環 | Product／IoT |
| DEC-005 | 廣告渠道與 Campaign ID 規則 | AdLift | Marketing |
| DEC-006 | DealRoom 是否提供實際媒合功能 | 法務、權限、個資 | Finance／Legal |
| DEC-007 | NetPlan 決策層級與雙重核准門檻 | Workflow | Management |
| DEC-008 | 外部物件來源授權與爬取政策 | Listing | Legal／Expansion |
| DEC-009 | 會員資料是否進入本平台及去識別方式 | 個資、AdLift | DPO／Security |
| DEC-010 | Production 的 Orchestrator、Identity 與 Event Bus 最終選型 | 工程 | Architecture Owner |

## 16. 本文件驗收

本文件完成後，所有參與者應能清楚回答：

- 哪些系統由上游負責，哪些由 ODay Plus 負責？
- 每個產品模組的責任及禁止事項是什麼？
- 哪些核定 KPI 是最低驗收條件？
- 哪些決策必須人工核准？
- 任何資料、預測、決策與結果如何被追溯？
- 後續模組設計是否可在不修改共同邊界的前提下開始？


## 17. 完整實作完成定義

任一業務模組只有在下列八個面向均達成，才可宣告「已完整實作」；僅有 Notebook、模型檔或畫面 Mockup 均不算完成。

| 面向 | 完成條件 |
|---|---|
| 資料 | 來源契約、Canonical Mapping、品質規則、Lineage、Backfill 與 Model-ready View 可執行 |
| 後端 | API／Batch／Worker／Workflow／Job 狀態、錯誤處理、冪等與權限完成 |
| 模型／規則／Solver | Baseline、正式候選、驗證、版本、限制、解釋與回滾完成 |
| 前端 | 查詢、建立任務、方案比較、核准、執行回報、結果與錯誤狀態完成 |
| 流程 | Prediction → Recommendation → Approval → Execution → Outcome 全鏈路可走通 |
| 治理 | Model Card／Decision Card／Audit／Feature Flag／Release Gate 可用 |
| 測試 | Unit、Contract、Integration、E2E、Data、Model、Security 與 UAT 達標 |
| 維運 | SLO、Dashboard、Alert、Runbook、Backup／Restore、Rollback 與 Ownership 明確 |

### 17.1 平台完成邊界

平台整體完成時，至少應通過下列端到端驗證：

1. 外部資料進入 Integration Layer，與上游 IoT／內部資料在 Canonical 層對位。
2. HeatZone → Listing → SiteScore → 人工開店決策 → 開店實績回收可完整執行。
3. ForecastOps → 四燈 → InterventionOps → PriceOps／AdLift／維修清潔 → Outcome 可完整執行。
4. 長期風險門市 → DealRoomAVM → NetPlan → 核准 → 90／180／365 日結果可完整執行。
5. 任一模型可完成訓練、驗證、登錄、Shadow／Canary、發布、監控與回滾。
6. 任一高風險決策可從畫面追溯至來源資料、Feature Snapshot、模型、政策、核准人、實際執行與結果。

## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.2.0 | 2026-06-25 | C1 | 建立完整範圍、IoT 上游邊界、核定 KPI 與完整實作完成定義 | Product／Architecture | Pending |

