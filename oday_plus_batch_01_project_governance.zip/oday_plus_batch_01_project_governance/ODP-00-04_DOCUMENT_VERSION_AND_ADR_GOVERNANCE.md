---
doc_id: ODP-00-04
title: "文件版本、變更與 ADR 治理"
version: 0.1.0
status: draft-for-review
document_class: project-governance
batch: 1
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Architecture Owner / Program Manager"
approvers: "Technology Lead / Product Lead / Data Governance Owner"
content_format: markdown
---

# ODay Plus 文件版本、變更與 ADR 治理

## 1. 文件目的

本文件建立 ODay Plus 的文件即程式碼（Docs-as-Code）規範、72 份正式交付文件清冊、批次產出順序、來源權威層級、版本生命週期、審查核准、需求變更與 Architecture Decision Record（ADR）制度。

本文件是「文件怎麼產生、誰能核准、何時升版、衝突怎麼處理」的唯一治理基線。任何新增正式文件、改名、拆分或合併，都必須先更新本文件並同步更新 `ODP-00-05`。

## 2. 文件治理目標

- 讓人員與 LLM 都能以穩定 ID、明確語意和可追蹤版本讀取文件。
- 避免 Word／Google Doc／程式碼／API 規格各自成為不同版本的真相。
- 將需求、設計、程式、測試、發布與查核證據串成同一條可稽核鏈。
- 讓 72 份正式文件分批完成，但不因批次而遺漏全平台範圍。
- 對重大架構與技術選擇保留 Context、Alternatives、Consequences 與 Review Trigger。

## 3. 文件來源與權威層級

### 3.1 來源登錄

| Source ID | 來源 | 類型 | 使用方式 |
|---|---|---|---|
| `SRC-ODP-ARCH` | 《ODay Plus 展店管理系統》完整架構文件 | 目標架構 | 產品、資料、模型、決策、OSS 與完整流程的主要基礎 |
| `SRC-ODP-PLAN` | ODay Plus／自助洗衣店生命週期管理計畫書 | 核定／申請內容 | 對外承諾、KPI、驗證與 GCP 基線 |
| `SRC-ODP-REVIEW` | 審查意見、修正對照與查核文件 | 管考 | 需被納入的補強、查核口徑與證據要求 |
| `SRC-LEGACY-CLOUD` | 既有 AI 自助商店遠端雲服務與 AI 客服契約／計畫 | 既有資產參考 | 可重用 API、IoT、SLA、資安或營運經驗；非自動需求 |
| `SRC-WORKING-DECISIONS` | 專案工作決議 | 專案治理 | 例如 IoT 為上游資料供應者、全模組完整建置 |

### 3.2 衝突處理

不同類型的真相採不同優先序：

**法律、補助與對外義務：**

```text
已簽署契約／核定計畫與正式變更
> 審查或查核書面決議
> 本文件庫內的需求與設計
```

**產品與業務行為：**

```text
已核准 SA 與 Decision Policy
> 已核准模組設計
> 已核准 ADR
> 開發中草稿
```

**API、Event、資料庫與可執行契約：**

```text
已發布且由 CI 產生的 OpenAPI／AsyncAPI／Migration／dbt Contract
> 已核准 SD
> 模組設計草稿
```

**Production 實際狀態：**

Runtime 與已部署版本是事實來源，但若其與核准文件不一致，必須建立 Defect／Deviation，不得以「程式目前就是如此」取代變更核准。

## 4. 正式文件與輔助產物

### 4.1 正式文件

只有列入第 13 節清冊，且 `formal_deliverable: true` 的 72 份 Markdown 才計入正式文件數量。

### 4.2 不計入 72 份的輔助產物

以下可由工具自動產生，但不另計正式文件：

- `README.md`、批次 manifest、checksum、完整性報告。
- OpenAPI／AsyncAPI 輸出。
- ERD 圖檔、Mermaid／PlantUML render。
- dbt Docs、資料血緣圖。
- Model Card instance、Dataset Card instance。
- Test report、coverage、performance report。
- Release package、SBOM、container scan report。

輔助產物必須能追到對應正式文件與 Git commit。

## 5. 檔名與資料夾規範

### 5.1 檔名

```text
<DOC_ID>_<UPPER_SNAKE_CASE_TITLE>.md
```

例：

```text
ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md
ODP-MOD-04_FORECASTOPS.md
```

- `DOC_ID` 永久不重用。
- 文件改名不改 ID；拆分文件需建立新 ID。
- 檔名只使用 ASCII、數字、底線與連字號；標題可使用繁體中文。

### 5.2 建議目錄

```text
docs/
├── 00_project_governance/
├── 10_sa/
├── 20_data_integration/
├── 30_platform_sd/
├── 40_module_design/
├── 50_ml_causal_or/
├── 60_ux/
├── 70_qa_acceptance/
├── 80_operations/
├── 90_adr/
└── 99_generated/
```

## 6. YAML Front Matter

每份正式 Markdown 必須以 YAML front matter 開始：

```yaml
---
doc_id: ODP-SA-06
title: "功能需求規格書"
version: 0.1.0
status: draft-for-review
document_class: system-analysis
batch: 2
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Product Lead"
approvers: "Domain Business Owners / Architecture Owner"
content_format: markdown
---
```

必要欄位不得缺漏。`owner` 與 `approvers` 優先填角色或群組，不直接把個人姓名寫死在大量文件中。

## 7. LLM 可讀性規範

- 一個術語只對應一個概念，遵循 `ODP-00-02`。
- 一個 Requirement ID 只描述一項可測試行為。
- 不使用「上述」「如下」「它」「這個」等無法跨 chunk 解讀的代名詞；應重述實體名稱或 ID。
- 表格每列需可獨立理解；不可只在前一列定義語境。
- Mermaid 節點需有穩定代碼與完整標籤。
- 不把關鍵決策藏在圖片、註解或未結構化段落。
- 程式、欄位、API、Event、Enum 使用反引號。
- 未確定內容以 `[ASSIGNMENT_REQUIRED]`、`[DECISION_REQUIRED]`、`[DATA_REQUIRED]` 等機器可搜尋標記表示，不使用模糊的「待確認」。
- 文件中的規範性語句使用「必須／不得／應／可」，避免「可能、大概、原則上」未附條件。

## 8. 文件生命週期

| Status | 定義 | 可否作為開發基線 |
|---|---|---:|
| `draft` | 內容建立中，尚未送審 | 否 |
| `draft-for-review` | 已達可審查狀態 | 僅供原型，不得作正式驗收 |
| `in-review` | 正在進行指定審查 | 否 |
| `approved` | 由指定 Approver 核准 | 是 |
| `approved-with-actions` | 可使用，但有明確限期修正項 | 是，受條件限制 |
| `superseded` | 已被新版或新文件取代 | 否；僅供歷史追溯 |
| `archived` | 不再維護 | 否 |
| `rejected` | 未通過審查 | 否 |

狀態只能依下列方向轉移：

```mermaid
stateDiagram-v2
  [*] --> draft
  draft --> draft-for-review
  draft-for-review --> in-review
  in-review --> approved
  in-review --> approved-with-actions
  in-review --> rejected
  approved-with-actions --> approved
  approved --> draft-for-review: 變更提案
  approved --> superseded
  superseded --> archived
  rejected --> draft
```

## 9. 版本規則

採 Semantic Versioning：`MAJOR.MINOR.PATCH`。

| 變更 | 版本 | 例子 |
|---|---|---|
| Editorial | PATCH | 錯字、排版、無語意的連結修正 |
| Non-breaking | MINOR | 新增可選欄位、補充流程、增加不改變既有行為的需求 |
| Breaking／Semantic | MAJOR | 改變資料語意、刪除欄位、改變狀態機、責任邊界或驗收標準 |
| Contractual | MAJOR＋正式變更 | 變更核定 KPI、範圍、時程、對外 SLA 或法律義務 |

任何 `approved` 文件的內容變更都必須更新版本與 Change Log；不得覆蓋舊版而不留紀錄。

## 10. 變更分級與核准

| Change Class | 內容 | 最低核准 |
|---|---|---|
| C0 Editorial | 文字、格式、無語意修正 | Document Owner |
| C1 Clarification | 補充說明，不改行為 | Owner＋一位 Reviewer |
| C2 Non-breaking Design | 新增相容能力、流程或欄位 | Product／Architecture／QA |
| C3 Breaking | Schema、API、狀態、規則或角色破壞性改變 | Business Owner＋Architecture＋Data／Service Owner |
| C4 High-risk Decision | 調價、廣告、估值、NetPlan、模型發布 Guardrail 改變 | Decision Owner＋Risk／Validation＋Business Owner |
| C5 Contractual | 核定範圍、KPI、時程、經費、SLA | Executive Sponsor＋Program／Legal，並依外部程序申請 |

變更提案至少需包含：原因、受影響 Requirement IDs、替代方案、Migration／Backfill、相容期、測試、Rollback、Owner 與生效日。

## 11. Review 與 Merge 規則

1. 正式文件變更以 Pull Request／Change Request 進行。
2. PR 標題包含文件 ID 與 Change Class，例如 `[ODP-SD-06][C3] API v2 breaking change`。
3. 至少一位非作者 Reviewer；C3 以上不得由作者自核。
4. 自動檢查：front matter、ID 唯一、Markdown link、Mermaid syntax、Requirement ID、版本與 Change Log。
5. `approved` 文件只能由具有 Approver 權限的人員更新狀態。
6. Merge commit／tag 必須記錄文件版本，Release Package 必須保存 commit SHA。

## 12. ADR 制度

### 12.1 何時必須建立 ADR

- 雲端或 OSS 核心選型。
- Monorepo／Multirepo、同步／非同步、Batch／Streaming 邊界。
- 資料庫、Event Bus、Workflow Engine、Feature Store、Model Serving 選擇。
- 服務拆分或合併。
- 重大資安、租戶隔離、DR 或保留策略。
- Champion／Challenger 或 Solver 的正式主選。
- 會造成跨模組或 C2 以上變更的架構決策。

不需要 ADR：一般程式重構、Bug fix、單一函式庫小版本升級且不改外部契約。

### 12.2 ADR ID 與檔名

```text
ADR-0001_<SHORT_TITLE>.md
```

ADR 不計入 72 份正式文件，但必須被相關 SD／MOD 文件引用。

### 12.3 ADR 狀態

`proposed` → `accepted` → `deprecated`／`superseded`；也可為 `rejected`。

### 12.4 ADR 模板

```markdown
---
adr_id: ADR-0001
title: "選擇 Pub/Sub 作為主要事件通道"
status: proposed
decision_date: null
owners: [Architecture Owner]
related_requirements: [ODP-HLR-EVT-001]
review_trigger: "事件量或順序需求超過現行能力"
---

# Context

# Decision Drivers

# Considered Alternatives

# Decision

# Positive Consequences

# Negative Consequences / Risks

# Migration and Rollback

# Security / Cost / Operations Impact

# Related Documents
```

### 12.5 ADR Review Trigger

每份 accepted ADR 必須寫明何時重審，例如：資料量級、SLO、團隊數、成本、法規、GCP 服務終止或新需求出現。

## 13. 72 份正式文件清冊
| 批次 | 類別 | 數量 | 進入條件 | 完成判定 |
|---:|---|---:|---|---|
| 1 | 總控與治理 | 5 | 專案目標與來源文件可讀 | 5 份治理文件互相一致並完成初審 |
| 2 | SA 主文件 | 10 | 第 1 批可供引用 | 業務、流程、需求與 NFR 形成 SA 基線 |
| 3 | 資料與整合 | 7 | SA 的資料需求已識別 | 來源、Canonical、Mapping、View 與品質契約完整 |
| 4 | 平台 SD | 12 | SA 與 Data 基線可用 | 平台架構、部署、API、Event、Workflow 與安全可實作 |
| 5 | 模組詳細設計 | 12 | 平台 SD 邊界明確 | 12 模組前後端、資料、模型、流程與驗收完整 |
| 6 | AI、因果與最佳化 | 6 | 資料與模組輸入輸出明確 | 模型、因果、Solver、驗證與 Registry 規格完整 |
| 7 | UX | 5 | SA Use Case 與模組功能穩定 | 資訊架構、畫面、地圖與前端技術設計完整 |
| 8 | QA | 7 | 需求、SD、模組與 UX 可測 | 測試、UAT、效能、安全與查核證據完整 |
| 9 | 維運 | 8 | 部署與驗收方式確定 | 建置、發布、Runbook、DR、管理員與使用者手冊完整 |
| **合計** |  | **72** |  |  |

### 13.1 第 1 批：總控與治理（5 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-00-01` | `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍與邊界說明書 |
| `ODP-00-02` | `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 名詞表與共用業務語意 |
| `ODP-00-03` | `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | 利害關係人、Ownership 與 RACI |
| `ODP-00-04` | `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、變更與 ADR 治理 |
| `ODP-00-05` | `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | 需求追蹤矩陣 |

### 13.2 第 2 批：SA 主文件（10 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-SA-01` | `ODP-SA-01_BUSINESS_ARCHITECTURE_AND_LIFECYCLE.md` | 業務架構與加盟生命週期 |
| `ODP-SA-02` | `ODP-SA-02_AS_IS_TO_BE_BUSINESS_PROCESSES.md` | AS-IS／TO-BE 業務流程 |
| `ODP-SA-03` | `ODP-SA-03_CAPABILITY_MAP_AND_MODULE_BOUNDARIES.md` | 業務能力地圖與模組邊界 |
| `ODP-SA-04` | `ODP-SA-04_USERS_ROLES_AND_ACCESS_REQUIREMENTS.md` | 使用者、角色與權限需求 |
| `ODP-SA-05` | `ODP-SA-05_USE_CASES_AND_USER_JOURNEYS.md` | 使用案例與使用者旅程 |
| `ODP-SA-06` | `ODP-SA-06_FUNCTIONAL_REQUIREMENTS_SPECIFICATION.md` | 功能需求規格書 |
| `ODP-SA-07` | `ODP-SA-07_BUSINESS_RULES_AND_DECISION_POLICIES.md` | 業務規則與決策政策 |
| `ODP-SA-08` | `ODP-SA-08_NON_FUNCTIONAL_REQUIREMENTS.md` | 非功能需求規格 |
| `ODP-SA-09` | `ODP-SA-09_SYSTEM_INTEGRATION_REQUIREMENTS.md` | 系統整合需求書 |
| `ODP-SA-10` | `ODP-SA-10_KPI_REPORTING_AND_AUDIT_REQUIREMENTS.md` | KPI、報表與稽核需求 |

### 13.3 第 3 批：資料與整合（7 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-DATA-01` | `ODP-DATA-01_DATA_SOURCE_INVENTORY_AND_OWNERSHIP.md` | 資料來源盤點與資料責任表 |
| `ODP-DATA-02` | `ODP-DATA-02_IOT_INTERNAL_DATA_EXCHANGE_CONTRACT.md` | IoT／內部資料交換契約 |
| `ODP-DATA-03` | `ODP-DATA-03_EXTERNAL_DATA_CONNECTOR_SPECIFICATIONS.md` | 外部資料 Connector 規格 |
| `ODP-DATA-04` | `ODP-DATA-04_CANONICAL_DATA_MODEL.md` | Canonical Data Model |
| `ODP-DATA-05` | `ODP-DATA-05_SOURCE_TO_CANONICAL_MAPPING.md` | Source-to-Canonical Mapping |
| `ODP-DATA-06` | `ODP-DATA-06_MODEL_READY_VIEWS_SPECIFICATIONS.md` | Model-ready Views 規格 |
| `ODP-DATA-07` | `ODP-DATA-07_DATA_QUALITY_LINEAGE_AND_TIME_SEMANTICS.md` | 資料品質、血緣與時間語意 |

### 13.4 第 4 批：平台 SD（12 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-SD-01` | `ODP-SD-01_OVERALL_SYSTEM_ARCHITECTURE.md` | 系統總體架構設計 |
| `ODP-SD-02` | `ODP-SD-02_GCP_PHYSICAL_DEPLOYMENT_ARCHITECTURE.md` | GCP 實體部署架構 |
| `ODP-SD-03` | `ODP-SD-03_SERVICE_AND_COMPONENT_BOUNDARIES.md` | 服務與元件邊界設計 |
| `ODP-SD-04` | `ODP-SD-04_REPOSITORY_AND_CODE_MODULE_DESIGN.md` | Repository 與程式模組設計 |
| `ODP-SD-05` | `ODP-SD-05_DATABASE_AND_STORAGE_DESIGN.md` | 資料庫與儲存設計 |
| `ODP-SD-06` | `ODP-SD-06_API_DESIGN_SPECIFICATION.md` | API 設計規格 |
| `ODP-SD-07` | `ODP-SD-07_EVENT_AND_MESSAGING_CONTRACTS.md` | Event 與訊息契約 |
| `ODP-SD-08` | `ODP-SD-08_WORKFLOW_JOB_AND_STATE_MACHINE_DESIGN.md` | Workflow、Job 與狀態機設計 |
| `ODP-SD-09` | `ODP-SD-09_IDENTITY_AUTH_SECURITY_AND_PRIVACY_DESIGN.md` | 身分、權限、資安與個資設計 |
| `ODP-SD-10` | `ODP-SD-10_RELIABILITY_AND_EXCEPTION_HANDLING_DESIGN.md` | 例外處理與可靠性設計 |
| `ODP-SD-11` | `ODP-SD-11_OBSERVABILITY_AND_AUDIT_DESIGN.md` | 可觀測性與稽核設計 |
| `ODP-SD-12` | `ODP-SD-12_CICD_IAC_AND_ENVIRONMENT_DESIGN.md` | CI/CD、IaC 與環境設計 |

### 13.5 第 5 批：模組詳細設計（12 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-MOD-00` | `ODP-MOD-00_INTEGRATION_AND_EXTERNAL_DATA_PLATFORM.md` | Integration Layer／External Data Platform |
| `ODP-MOD-01` | `ODP-MOD-01_HEATZONE_RADAR.md` | HeatZone Radar |
| `ODP-MOD-02` | `ODP-MOD-02_LISTING_PIPELINE.md` | Listing Pipeline |
| `ODP-MOD-03` | `ODP-MOD-03_SITESCORE.md` | SiteScore |
| `ODP-MOD-04` | `ODP-MOD-04_FORECASTOPS.md` | ForecastOps |
| `ODP-MOD-05` | `ODP-MOD-05_INTERVENTIONOPS.md` | InterventionOps |
| `ODP-MOD-06` | `ODP-MOD-06_PRICEOPS.md` | PriceOps |
| `ODP-MOD-07` | `ODP-MOD-07_ADLIFT.md` | AdLift |
| `ODP-MOD-08` | `ODP-MOD-08_DEALROOM_AVM.md` | DealRoomAVM |
| `ODP-MOD-09` | `ODP-MOD-09_NETPLAN.md` | NetPlan |
| `ODP-MOD-10` | `ODP-MOD-10_LEARNING_HUB.md` | Learning Hub |
| `ODP-MOD-11` | `ODP-MOD-11_OPSBOARD.md` | OpsBoard |

### 13.6 第 6 批：AI、因果與最佳化（6 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-ML-01` | `ODP-ML-01_AI_ML_OVERALL_DESIGN.md` | AI／ML 總體設計 |
| `ODP-ML-02` | `ODP-ML-02_FEATURE_AND_LABEL_REGISTRY.md` | Feature 與 Label Registry |
| `ODP-ML-03` | `ODP-ML-03_MODEL_SPECIFICATIONS.md` | 模型規格書 |
| `ODP-ML-04` | `ODP-ML-04_MODEL_VALIDATION_AND_MODEL_CARDS.md` | 模型驗證與 Model Card |
| `ODP-ML-05` | `ODP-ML-05_CAUSAL_INFERENCE_AND_EXPERIMENT_DESIGN.md` | 因果推論與實驗設計 |
| `ODP-OR-01` | `ODP-OR-01_OPTIMIZATION_MODEL_DESIGN.md` | 最佳化模型設計 |

### 13.7 第 7 批：UX（5 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-UX-01` | `ODP-UX-01_INFORMATION_ARCHITECTURE_AND_NAVIGATION.md` | 資訊架構與導覽設計 |
| `ODP-UX-02` | `ODP-UX-02_DESIGN_SYSTEM.md` | Design System |
| `ODP-UX-03` | `ODP-UX-03_SCREEN_AND_INTERACTION_SPECIFICATIONS.md` | 畫面與互動規格 |
| `ODP-UX-04` | `ODP-UX-04_MAP_AND_DATA_VISUALIZATION_SPECIFICATIONS.md` | 地圖與資料視覺化規格 |
| `ODP-UX-05` | `ODP-UX-05_FRONTEND_TECHNICAL_DESIGN.md` | 前端技術設計 |

### 13.8 第 8 批：QA（7 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-QA-01` | `ODP-QA-01_MASTER_TEST_PLAN.md` | 測試總體計畫 |
| `ODP-QA-02` | `ODP-QA-02_TEST_DATA_AND_ENVIRONMENT_STRATEGY.md` | 測試資料與環境策略 |
| `ODP-QA-03` | `ODP-QA-03_END_TO_END_TEST_SCENARIOS.md` | 端到端測試情境 |
| `ODP-QA-04` | `ODP-QA-04_MODEL_AND_DECISION_ACCEPTANCE.md` | 模型與決策驗收規格 |
| `ODP-QA-05` | `ODP-QA-05_PERFORMANCE_SECURITY_AND_DR_TESTS.md` | 效能、資安與災難復原測試 |
| `ODP-QA-06` | `ODP-QA-06_UAT_AND_FORMAL_ACCEPTANCE_CHECKLIST.md` | UAT 與正式驗收清單 |
| `ODP-QA-07` | `ODP-QA-07_GRANT_EVIDENCE_TRACEABILITY_MATRIX.md` | 補助計畫查核證據矩陣 |

### 13.9 第 9 批：維運（8 份）

| Doc ID | 正式檔名 | 文件名稱 |
|---|---|---|
| `ODP-OPS-01` | `ODP-OPS-01_DEVELOPMENT_WBS_AND_RELEASE_PLAN.md` | 開發 WBS 與 Release Plan |
| `ODP-OPS-02` | `ODP-OPS-02_DATA_MIGRATION_BACKFILL_AND_RECOMPUTE.md` | 資料 Migration／Backfill／重算設計 |
| `ODP-OPS-03` | `ODP-OPS-03_DEPLOYMENT_AND_ENVIRONMENT_RUNBOOK.md` | 部署與環境建置手冊 |
| `ODP-OPS-04` | `ODP-OPS-04_OPERATIONS_RUNBOOK.md` | Runbook |
| `ODP-OPS-05` | `ODP-OPS-05_INCIDENT_BACKUP_AND_RECOVERY.md` | Incident、備份與復原手冊 |
| `ODP-OPS-06` | `ODP-OPS-06_MODEL_RELEASE_AND_ROLLBACK.md` | 模型發布與回滾手冊 |
| `ODP-OPS-07` | `ODP-OPS-07_SYSTEM_ADMINISTRATOR_MANUAL.md` | 系統管理員手冊 |
| `ODP-OPS-08` | `ODP-OPS-08_USER_OPERATION_MANUAL.md` | 使用者操作手冊 |


## 14. 批次產出與依賴規則

- 批次是文件產出與審查順序，不是產品範圍刪減順序。
- 後一批可在前一批 `draft-for-review` 後開始，但在前一批關鍵假設未核准前，不得將高風險設計標記為 `approved`。
- 平行撰寫必須引用穩定 Doc ID／Requirement ID，不以頁碼作為唯一引用。
- 發現前批文件缺口時，先提出變更並更新前批版本，不在後批文件中另造衝突定義。
- 每批 ZIP／Release Package 只包含該批正式文件與不計數的 manifest；不得混入其他批次正式文件。

## 15. 每批 Definition of Done

每一批正式完成必須同時符合：

1. 文件數量與第 13 節一致。
2. 每份文件 front matter 完整，Doc ID／檔名／標題一致。
3. 無重複 Requirement、API、Event、Entity 或 Enum ID。
4. 所有未決事項使用結構化標記並指定 Owner。
5. 交叉引用不存在斷鏈。
6. 內容已通過指定角色 Review。
7. `ODP-00-05` 已同步更新 traceability 與狀態。
8. 產出 SHA256 manifest 或 Git tag，可重現該批內容。

## 16. 自動產生與 Single Source of Truth

| 產物 | Source of Truth | 自動產生方向 |
|---|---|---|
| OpenAPI | API code／schema 或 approved contract repository | 產生 API 文件與 client |
| AsyncAPI | Event schema repository | 產生 Event catalog 與 validator |
| ERD | Migration／schema definitions | 產生圖與資料字典 |
| dbt Docs | dbt models／tests | 產生 View、Lineage、品質說明 |
| Model Card Instance | Training／validation metadata＋人工限制說明 | 產生版本化卡片 |
| Test Report | CI／QA pipeline | 回寫需求與驗收狀態 |
| Release Note | merged changes＋manual business impact | 發布給 OpsBoard 與使用者 |

不得手動維護兩份相同 Schema。若需要可讀摘要，摘要必須引用自動產物版本。

## 17. 文件 Change Log 模板

每份正式文件末尾應包含：

```markdown
## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.1.0 | 2026-06-25 | C1 | Initial draft | Role／Team | Pending |
```

## 18. 定期重審

| 文件類型 | 最低重審頻率 | 額外觸發條件 |
|---|---|---|
| Scope／RACI／Governance | 每季 | 組織、契約、主要模組或責任邊界變更 |
| SA／Data Contract | 每 Release Train | 新來源、新流程、Schema 或 KPI 改變 |
| Platform／Module SD | 每重大 Release | 服務、部署、API、Event、State Machine 改變 |
| Model／Decision | 每模型發布 | Drift、事故、政策或限制改變 |
| QA／Ops | 每半年 | P1/P2、DR 演練、SLO 或資安要求改變 |

## 19. 偏差管理

若實作無法即時符合 approved 文件，必須建立 Deviation Record：

- 偏差 ID。
- 受影響 Requirement／文件／版本。
- 原因與風險。
- 暫時補償控制。
- Owner 與截止日。
- 修正或正式變更路徑。

未登錄的文件－實作差異視為 Defect，不得在驗收時臨時解釋。

## 20. 本文件完成條件

本文件可進入 `approved` 的最低條件：

1. 9 批、72 份正式文件名稱與數量經確認。
2. Source hierarchy 與 Contract／Architecture 衝突處理方式經確認。
3. 文件狀態、版本、Change Class 與 Approver 權限經確認。
4. ADR、Deviation、Change Log 與自動產物規則可實際執行。
5. CI 或人工檢查可驗證 Doc ID、front matter、Requirement ID 與連結完整性。

## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.1.0 | 2026-06-25 | C1 | 建立 72 份正式文件清冊與 Docs-as-Code／ADR 治理 | Architecture／Program | Pending |
