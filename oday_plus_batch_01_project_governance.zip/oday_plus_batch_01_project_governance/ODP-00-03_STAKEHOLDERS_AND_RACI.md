---
doc_id: ODP-00-03
title: "利害關係人、Ownership 與 RACI"
version: 0.1.0
status: draft-for-review
document_class: project-governance
batch: 1
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Product Lead / Program Manager"
approvers: "Executive Sponsor / Technology Lead / Domain Business Owners"
content_format: markdown
---

# ODay Plus 利害關係人、Ownership 與 RACI

## 1. 文件目的

本文件定義 ODay Plus 全平台的利害關係人、責任類型、模組 Accountable Owner、跨團隊 RACI、治理會議與升級路徑。它回答四個問題：

1. 每一項能力由誰定義成功標準？
2. 每一項交付物由誰實際完成、誰最終負責？
3. 模型、服務與業務決策分別由誰核准？
4. 上線後若資料、模型、服務或決策出錯，由誰主導處理？

本文件只定義責任與治理，不取代人力排程、Sprint 分工或個人績效管理。

## 2. 治理原則

1. 每個重大交付物只能有一個 `A — Accountable`。
2. 每項工作至少有一個 `R — Responsible`。
3. `C — Consulted` 代表執行前需取得意見，不代表其有否決權。
4. `I — Informed` 代表需被通知，不代表需參與核准。
5. 模型開發、獨立驗證、正式發布與業務決策核准不得被視為同一責任。
6. Data Engineering 對管線負責，但資料的業務語意仍需由 Data Owner 負責。
7. Service Owner 對 API／Worker／SLO 負責，不代表其對模型有效性負責。
8. Model Owner 對模型技術品質負責，不代表其可單獨核准開店、調價、廣告或退出。
9. 高風險決策必須保留人工核准、Override 理由及後續 Outcome。
10. 小團隊可以合併執行角色，但不能消除獨立驗證與最終核准的分離。

## 3. Ownership 模型

| Ownership | 核心問題 | 主要責任 | 不負責的事項 |
|---|---|---|---|
| Business Owner | 為什麼做？成功標準是什麼？ | 定義業務 KPI、風險容忍度、上線價值與採用責任 | 演算法與基礎設施細節 |
| Product Owner | 系統如何被使用？ | 功能範圍、使用流程、Backlog、驗收條件與跨模組協調 | 單獨決定模型是否有效 |
| Data Owner | 資料代表什麼？是否可用？ | 業務語意、來源授權、品質、更新頻率、保留與修正規則 | 管線程式實作本身 |
| Model Owner | 模型學什麼、是否有效？ | Target、Baseline、訓練、回測、限制、Model Card、Champion／Challenger | 最終商業決策 |
| Decision Owner | 系統建議是否可轉為正式行動？ | 目標函數、政策、硬限制、人工核准與業務回滾 | 模型訓練與服務維運 |
| Service Owner | Production 是否可靠？ | API、Worker、Job、效能、SLO、部署、擴展與故障處理 | 業務 KPI 與模型準確性 |
| Production Owner | 事故發生時誰主導？ | On-call、Incident Commander、恢復、溝通與 Postmortem | 取代各領域 Root Cause Owner |
| Risk／Validation Owner | 是否達到發布與安全門檻？ | 獨立驗證、子群風險、Guardrail、發布簽核與稽核 | 自行修改 Production 模型 |
| Security／Privacy Owner | 誰可存取、資料如何保護？ | IAM、個資、Secret、稽核、第三方來源合規與資安事件 | 業務流程優先順序 |
| Architecture Owner | 系統邊界與重大技術選擇是否一致？ | 架構原則、ADR、跨服務契約與技術債治理 | 每個模組的日常需求排序 |

## 4. 利害關係人群組

### 4.1 治理與管理層

| 角色 | 核心關注 | 主要輸入 | 主要輸出 |
|---|---|---|---|
| Executive Sponsor | 投資效益、重大風險、跨部門資源 | KPI、風險、Roadmap、NetPlan | 策略方向、重大決策與資源核准 |
| Steering Committee | 全案優先順序與責任衝突 | 模組進度、Gate、事故與效益 | 跨模組決議、高風險自動化邊界 |
| Technology Lead | 技術品質、平台能力、工程風險 | 架構、SLO、資安、技術債 | 技術策略、平台投資與發布原則 |
| Finance／Risk／Legal | 資本、法規、估值與資料使用風險 | 財務假設、租約、資料來源與決策 | 財務可行性、保留價、法遵意見 |
| Program Manager | 跨工作流協調與交付狀態 | Roadmap、依賴、風險、需求變更 | 整合計畫、升級與交付報告 |

### 4.2 業務與產品

| 角色 | 主要模組 | 核心責任 |
|---|---|---|
| Expansion／Site Selection | HeatZone、Listing、SiteScore | 熱區、物件、現勘、GO／WAIT／REJECT 與新店 Outcome |
| Store Operations／Franchise Success | ForecastOps、InterventionOps | 營運健康定義、四燈、處置 SOP、執行與加盟主回饋 |
| Marketing／Pricing | PriceOps、AdLift、Promotion／CRM | 安全價格集合、渠道、預算、活動執行與效果解讀 |
| Finance／Asset Management | DealRoomAVM、NetPlan | 正常化毛利、資產、估值、Reserve Price 與資本限制 |
| Product Management | 全模組 | PRD、流程、驗收、Roadmap、Decision Policy 與 Release Note |
| Franchisee／Store Operator | OpsBoard、Intervention | 自身門市資料、任務執行、回報與共同決策 |

### 4.3 資料、AI 與最佳化

| 角色 | 核心責任 |
|---|---|
| Data Engineering | Connector、Canonical Layer、Model-ready Views、Lineage、Backfill |
| Data Governance | Data Contract、資料品質、權限、用途與保留政策 |
| Geo／Spatial | H3、Geocode、PostGIS、Trade Area、Isochrone、Cannibalization |
| Forecasting／General ML | HeatZone、SiteScore、ForecastOps、AVM 模型與回測 |
| Causal／Experimentation | Treatment、Control、DiD、Synthetic Control、Uplift、Evidence Level |
| Operations Research | PriceOps、NetPlan 目標函數、限制、Solver 與 Infeasibility |
| MLOps／Platform | Training、Registry、Release、Shadow／Canary、Drift 與 Rollback |
| Model Validation | 獨立回測、子群驗證、Calibration、Guardrail 與簽核 |

### 4.4 工程、UX 與維運

| 角色 | 核心責任 |
|---|---|
| Backend／API | API、Workflow、Job、Event、Decision Log、權限與冪等 |
| Frontend／UX | OpsBoard、地圖、軌跡、核准、方案比較、不確定性呈現 |
| QA／Test Engineering | Unit、Contract、Integration、E2E、Regression、UAT 支援 |
| SRE／Observability | SLI／SLO、On-call、Capacity、Backup／Restore、Runbook、Postmortem |
| Security／Privacy | IAM、ABAC、資料遮罩、Secret、Threat Model、Audit 與事件應變 |
| Architecture | 服務邊界、部署模式、資料與事件契約、ADR 與跨模組一致性 |

## 5. 模組 Ownership 矩陣

> 個人姓名由 `Owner Assignment Register` 綁定；此表先固定角色，避免人員異動造成責任消失。

| 模組 | Business Owner（A） | Product Owner | Data Owner | Model／Logic Owner | Service Owner | Decision Approver |
|---|---|---|---|---|---|---|
| Integration／External Data | Technology Lead | Data Platform Product | 各來源 Data Owner＋Data Governance | Data／Geo Lead | Data Platform／Backend | Technology Lead |
| HeatZone | Expansion Director | Expansion Product | Geo Data Owner | Geo／Demand ML Lead | Geo Platform | Expansion Strategy Head |
| Listing Pipeline | Expansion Operations Head | Listing Product | Listing Data Owner | Ranking／Rules Lead | Backend | Expansion Head |
| SiteScore | Site Review Head | SiteScore Product | Geo＋Finance＋Store Data Owners | Site ML Lead | Backend／MLOps | Site Review＋Finance |
| ForecastOps | Operations Head | Forecast Product | Operations Data Owner | Forecast ML Lead | Backend／MLOps | Operations Head |
| InterventionOps | Operations Head | Intervention Product | Intervention Data Owner | Decision／Causal Lead | Workflow／Backend | Operations／Relevant Domain |
| PriceOps | Pricing Head | Pricing Product | Pricing Data Owner | Causal＋OR Lead | OR Platform／Backend | Pricing＋Operations |
| AdLift | Marketing Head | Marketing Product | Campaign Data Owner | Causal Lead | Data Platform／Backend | Marketing＋Finance |
| DealRoomAVM | Finance Head | Asset Product | Finance／Asset Data Owner | AVM ML Lead | Backend／MLOps | Finance＋Legal |
| NetPlan | Executive／Network Council | Network Product | Finance＋Operations Data Owners | OR Lead | Solver Platform | Executive／Network Council |
| Learning Hub | Technology Lead | MLOps Product | Data Governance | MLOps／Model Governance Lead | Platform | Technology Lead |
| OpsBoard | Operations Governance Head | OpsBoard Product | 各 Domain Data Owners | Decision Policy Owners | Backend／Frontend | 各 Domain Business Owner |

## 6. RACI 符號與套用規則

| 符號 | 意義 | 要求 |
|---|---|---|
| R | Responsible，實際完成工作 | 可多個，但需明確拆分產出 |
| A | Accountable，對結果最終負責 | 每個交付物只能一個 |
| C | Consulted，執行前需諮詢 | 應限制必要角色，避免流程停滯 |
| I | Informed，需被通知 | 不代表需要簽核 |
| — | 無直接責任 | 不需參與 |

## 7. 專案治理與文件 RACI

| 工作／交付物 | Executive Sponsor | Program／Product | Architecture | Domain Business | Data／AI／OR | Engineering | QA／Validation | Security／Risk |
|---|---|---|---|---|---|---|---|---|
| 範圍與邊界基線 | I | R | R | C | C | C | C | C |
| 範圍核准 | A | R | C | C | I | I | I | C |
| 名詞與共用語意 | I | R | C | A | R | C | C | C |
| RACI 與治理制度 | A | R | C | C | I | I | C | C |
| 需求追蹤矩陣 | I | A/R | C | C | C | C | R | C |
| SA 文件 | I | A/R | C | C | C | C | R | C |
| 平台 SD | I | C | A/R | C | C | R | C | C |
| 模組詳細設計 | I | A | C | C | R | R | C | C |
| ADR | I | C | A/R | C | C | C | C | C |
| Contract／Compliance 變更 | A | R | C | C | I | I | C | R |
| Release Note | I | A/R | C | I | C | R | C | I |

## 8. 資料與整合 RACI

| 工作 | Source Data Owner | Data Governance | Data Engineering | Domain／Product | ML／OR | Security | QA |
|---|---|---|---|---|---|---|---|
| 業務語意定義 | A/R | R | C | C | C | I | I |
| 來源授權與用途 | A | R | I | C | I | R | I |
| Data Contract | A | R | R | C | C | C | C |
| Connector／Ingestion | C | C | A/R | I | I | C | R |
| Source-to-Canonical Mapping | A | R | R | C | C | I | C |
| Model-ready View | C | R | A/R | C | R | I | C |
| Feature Contract | C | A | R | C | R | I | C |
| 品質規則 | A | R | R | C | C | I | R |
| Point-in-time Correctness | C | A | R | I | R | I | R |
| Backfill／重算 | I | C | A/R | I | C | I | R |
| 權限與保留 | C | A | C | I | I | R | C |
| Data Quality Gate Override | C | A | R | C | C | C | R |

## 9. 模型生命週期 RACI

| 工作 | Business Owner | Product | Data Eng | Model Owner | Validation | MLOps | Risk／Security |
|---|---|---|---|---|---|---|---|
| 問題與 KPI 定義 | A | R | C | C | C | I | C |
| Target／Label 定義 | A | C | C | R | C | I | C |
| 資料可行性 | I | C | A/R | C | C | I | C |
| Baseline | I | I | C | A/R | C | I | I |
| Candidate 訓練 | I | I | C | A/R | C | C | I |
| 回測設計 | I | C | C | R | A/R | C | C |
| 子群與風險評估 | C | C | C | R | A/R | C | R |
| Model Card | I | C | C | A/R | C | C | C |
| Decision Card | A | R | I | C | C | C | R |
| 發布核准 | A | C | I | R | R | R | C |
| Shadow／Canary | I | I | I | C | C | A/R | C |
| 生產監控 | I | I | C | C | C | A/R | I |
| 模型回滾 | A | I | I | C | C | R | C |
| 業務 Action 回滾 | A/R | R | I | C | C | C | C |

## 10. 開發與發布 RACI

| 工作 | Product | Architecture | Backend／Frontend | Data／ML／OR | QA | MLOps／SRE | Security | Business Owner |
|---|---|---|---|---|---|---|---|---|
| Acceptance Criteria | A/R | C | C | C | R | I | C | C |
| API／Event Contract | C | A | R | C | R | C | C | I |
| Database Migration | I | C | R | C | R | A | C | I |
| Feature Implementation | A | C | R | R | C | C | C | I |
| Automated Test | C | I | R | R | A/R | C | C | I |
| Security Review | I | C | C | C | C | I | A/R | I |
| UAT | R | I | C | C | R | I | I | A |
| Production Release | C | C | R | C | C | A/R | C | I |
| Go／No-Go | R | C | C | C | R | R | C | A |
| Production Verification | I | I | R | C | C | A/R | I | I |

## 11. 高風險業務決策 RACI

| 決策 | 提案 R | 技術驗證 C/R | 財務／風險 C | 最終 A | 必要條件 |
|---|---|---|---|---|---|
| HeatZone 優先區域 | Expansion Strategy | Geo／Demand ML | Finance C | Expansion Director | 資料信心與剩餘需求 |
| SiteScore GO／REJECT | Site Review | Site ML／Geo | Finance C | Site Review Head | 現勘、P10/P50/P90、回本與硬規則 |
| 橙／紅燈處置 | Regional Operations | Forecast／Root Cause | Risk C | Operations Head | Evidence、SLA、Eligibility |
| 價格調整 | Pricing／Operations | Causal／OR | Finance／Brand C | Pricing Head | Safe Action Set、毛利底線、回滾 |
| 廣告加碼／停止 | Marketing | Causal | Finance C | Marketing Head | Control、Pre-trend、iROMI |
| Reserve Price | Asset／Finance | AVM | Legal C | Finance Head | 估值區間、資料室、法務意見 |
| MOVE／EXIT | Network Product | OR／Forecast／AVM | Finance／Legal C | Executive／Network Council | Alternative Plan、硬限制、時序 |
| Model Production Release | Model＋MLOps | Validation | Risk／Security C | Business Owner | Data Gate、Model Card、Rollback |

## 12. 事故責任與升級

### 12.1 事故類型

| 類型 | 例子 | Primary Owner |
|---|---|---|
| Data Incident | 上游缺漏、Schema 破壞、錯誤 Backfill | Data Platform／Data Owner |
| Model Incident | 嚴重 Bias、區間失準、漂移 | Model Owner＋Validation |
| Service Incident | API 中斷、Job 堆積、資料庫失效 | Service／Production Owner |
| Decision Incident | Guardrail 漏失、錯誤核准、負毛利策略 | Decision Owner＋Business Owner |
| Security Incident | 未授權存取、資料外洩、Secret 泄漏 | Security Owner |
| External Dependency Incident | Geocode、廣告、通知、上游資料中斷 | Integration Owner＋Vendor Owner |

### 12.2 嚴重度

| 等級 | 定義 | 指揮與溝通 |
|---|---|---|
| P1 | 大規模服務中斷、安全事件或高風險錯誤決策 | 指定 Incident Commander；立即通知 Executive、Business、Security |
| P2 | 重要模組失效、部分店群受影響或模型嚴重漂移 | Production Owner 主導；限時恢復與風險隔離 |
| P3 | 個別門市、非核心 Job 或已有降級方案 | Service Owner 處理；納入週報 |
| P4 | 輕微缺陷、報表或低風險問題 | 正常 Backlog |

### 12.3 Incident Commander 規則

- P1／P2 必須指定一位 Incident Commander。
- Incident Commander 負責協調，不等於所有根因都由其承擔。
- 技術恢復、模型停止、業務 Action 回滾可由不同 Owner 執行，但必須由同一 Incident Timeline 串聯。
- P1／P2 結束後必須完成無責備 Postmortem、修正 Action 與 Owner／Due Date。

## 13. 固定治理會議

| 會議 | 頻率 | 主持 A | 必要輸入 | 主要輸出 |
|---|---|---|---|---|
| Steering Committee | 每月／重大事件 | Executive Sponsor | KPI、風險、Roadmap、預算 | 策略、優先順序、高風險核准 |
| Architecture Review | 每週或 ADR 觸發 | Architecture Owner | ADR、服務邊界、NFR | 架構決議與技術債 |
| Data Contract Review | 每兩週／Schema 變更 | Data Governance | Contract、Mapping、品質 | 版本、相容期、Backfill 決議 |
| Model Review | 每模型發布 | Validation Owner | Model Card、回測、子群 | Release／Reject／Shadow |
| Intervention Review | 每週 | Operations Head | 四燈、Action、Outcome | 處置優先順序與效果判定 |
| Network Planning Council | 每季／紅燈例外 | Executive／Network Owner | AVM、NetPlan、租約、資本 | OPEN／KEEP／MOVE／EXIT 決議 |
| Release Readiness Review | 每 Release | Product／MLOps | 測試、Migration、Rollback | Go／No-Go |
| Incident Review | P1/P2 後 | Production Owner | Timeline、Impact、Root Cause | Postmortem 與改善項目 |

## 14. 小團隊合併規則

可以合併的能力：

- Backend＋MLOps。
- Geo＋Data Engineering。
- Forecasting＋General ML。
- Product＋Domain Analyst。
- QA＋部分 Model Validation 執行工作。

不得完全由同一人兼任：

- 高風險模型開發者與唯一最終 Model Validator。
- 業務需求提出者與高風險決策唯一核准者。
- Production 開發者與唯一事故結案核准者。
- 外部資料 Connector 開發者與唯一授權／合規核准者。
- NetPlan Solver 開發者與最終店網資本配置核准者。

若人力不足無法分離，必須採取替代控制：第二人 Review、完整 Audit、限縮啟用範圍、Canary、人工核准與事後抽查。

## 15. Owner Assignment Register

實際人員配置應維護下表；人員更替只更新此表，不修改 Ownership 定義。

| Role Key | Ownership／角色 | 姓名或群組 | 代理人 | 生效日 | 終止日 | 聯絡／On-call | 狀態 |
|---|---|---|---|---|---|---|---|
| `OWN-EXEC` | Executive Sponsor | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-ARCH` | Architecture Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-PRODUCT` | Product Lead | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-DATA-GOV` | Data Governance Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-MLOPS` | MLOps／Platform Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-SEC` | Security／Privacy Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-VALIDATION` | Model Validation Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-EXPANSION` | Expansion Business Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-OPS` | Operations Business Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-MARKETING` | Marketing／Pricing Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |
| `OWN-FINANCE` | Finance／Asset Owner | `[ASSIGNMENT_REQUIRED]` |  |  |  |  | OPEN |

## 16. 變更與例外

- Ownership 或 RACI 原則的重大變更須建立 ADR 或 Governance Decision Record。
- 單純人員異動只更新 Assignment Register，不升版責任模型。
- 若一項工作暫時存在兩個 `A`，該工作不得進入正式核准或發布，直到 Steering／Program Owner 指定唯一 Accountable。
- 緊急事件可先由 Incident Commander 指派臨時 Owner，但事後需補正式記錄。

## 17. 本文件完成條件

本文件可進入 `approved` 的最低條件：

1. 每個模組已有唯一 Business Accountable Owner 角色。
2. Architecture、Product、Data Governance、MLOps、Security 與 Validation 的實際人員或群組已指定。
3. 模型發布、業務決策、資料變更、Release 與 Incident RACI 已由相關負責人確認。
4. 固定治理會議已有主持人、頻率與輸入／輸出。
5. 小團隊合併方式未違反獨立驗證與高風險核准原則。

## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.1.0 | 2026-06-25 | C1 | 建立 Ownership、模組責任、RACI、治理會議與事故升級 | Program／Product | Pending |

