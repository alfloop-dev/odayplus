---
doc_id: ODP-00-02
title: "名詞表與共用業務語意"
version: 0.2.0
status: draft-for-review
document_class: project-governance
batch: 1
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Data Governance Owner / Product Lead"
approvers: "Domain Business Owners / Data Owner / Architecture Owner"
content_format: markdown
---

# ODay Plus 名詞表與共用業務語意

## 1. 目的

本文件是 ODay Plus 的語意契約。資料欄位、API、事件、前端標籤、模型文件、報表與測試案例均應使用本文件中的術語；同義詞只能作為顯示文字，不得成為不同資料概念。

## 2. 命名原則

- 產品名稱固定寫作 **ODay Plus**。
- 程式、資料表、API 與 Event 使用英文 `snake_case` 或明確的 enum code。
- UI 可顯示中文，但必須映射到唯一機器代碼。
- 店鋪品牌使用 `store_brand`；設備品牌使用 `equipment_brand`。
- 「預測」「建議」「核准」「執行」「結果」不得互換。
- 所有金額欄位必須同時有 `currency_code`；所有比率用 0–1 儲存，顯示時轉百分比。
- 所有時間儲存 UTC，並保存業務時區；預設業務時區為 `Asia/Taipei`。


## 組織、租戶與權限

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Tenant | 平台中的最高資料隔離單位；可代表阿法碼、品牌集團或外部客戶。 | 不得與 Brand 混用。 |
| Brand | 面向市場與加盟體系的店鋪品牌，例如 ODay。 | 必須與 Equipment Brand 分離。 |
| Store Brand | 門市對外營運所屬品牌。 | 同一 Tenant 可有多品牌。 |
| Equipment Brand | 機台製造商或設備品牌。 | 同一門市可混用多個設備品牌。 |
| Region | 管理與授權用區域，可與行政區不同。 | 需版本化區域邊界。 |
| Actor | 做出操作、決策、核准或執行的人員、服務帳號或外部系統。 | 每一高風險操作必須有 Actor。 |
| Role | 功能權限集合，例如展店業務、營運主管。 | Role 不直接等於資料範圍。 |
| Scope | 資料可見範圍，例如 Tenant／Brand／Region／Store。 | 與 Role 共同形成授權。 |
| RBAC | 以角色控制功能權限。 | 用於「可做什麼」。 |
| ABAC | 依屬性、資料範圍與情境控制存取。 | 用於「可看哪一筆」。 |
| Business Owner | 對業務結果與政策負最終責任者。 | 不同於 Product Owner。 |
| Product Owner | 對產品行為、流程與驗收負責者。 | 不得取代模型獨立驗證。 |
| Data Owner | 對來源語意、品質、授權與修正負責者。 | 來源系統需指定。 |
| Model Owner | 對模型有效性、監控與發布負責者。 | 不得同時兼任高風險最終核准者。 |
| Service Owner | 對 Production 服務、SLO 與事故負責者。 | 每個部署單元必須指定。 |


## 門市、店型與設備

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Store | 已開業或已納入營運管理的實體門市。 | 候選物件不是 Store。 |
| Site | 具經緯度與物理條件的地點，可為候選或既有門市所在地。 | 一個 Site 可關聯多次 Listing。 |
| Candidate Site | 尚未核准開店、正在評估的具體地點。 | SiteScore 的分析單位。 |
| Listing | 某來源在某時間發布的出租物件紀錄。 | 同一 Site 可有重複 Listing。 |
| Store Format | 標準化門市配置，例如 ODay G2。 | 需有版本與生效期間。 |
| ODay G2 | 目前目標店型；初始定義為 3 大＋3 中洗脫烘一體機。 | 如配置改變必須建立新版本。 |
| Machine | 可被唯一識別的實體機台。 | 必須有安裝與退役期間。 |
| Machine Family | 洗衣機、烘衣機、洗脫烘一體機等功能家族。 | 一體機不得拆成兩台。 |
| Capacity KG | 機台公斤數的原始連續值。 | 另可映射 small／medium／large／extra_large。 |
| Effective Capacity | 考慮台數、可用時間、可用率與 Throughput 的有效產能。 | 不可只以機台數代表。 |
| Availability Rate | 機台在應可服務時間內可正常使用的比例。 | 停機與維修需排除。 |
| Cycle | 一次設備服務週期。 | 需區分開始、完成、中止。 |
| Store Age | 從正式開幕日起算的店齡。 | 預測與 comparable 必須使用當時店齡。 |
| Ramp | 新店從開幕到成熟穩態的成長過程。 | 不是固定線性係數。 |
| Mature Store | 已跨過 Ramp 且進入穩定期的門市。 | 成熟門檻由版本化規則定義。 |
| Same-age Comparable | 與目標店相同或相近店齡的比較店。 | 用於成長驗證。 |
| Mature Comparable | 已成熟且條件相近的比較店。 | 用於穩態與估值。 |


## 地理、商圈與展店

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| H3 Cell | 由 H3 產生的階層式地理格網。 | 用於聚合與索引，不取代真實行政界線。 |
| Geo Cell Snapshot | 某 H3 Cell 在某 Snapshot Time 的特徵版本。 | 人口、POI、競店等需隨時間版本化。 |
| Trade Area | 門市實際可服務或吸引顧客的商圈。 | 不得一律用固定半徑。 |
| Isochrone | 依路網與時間形成的等時圈。 | 可分步行、騎車、開車。 |
| Accessibility | 道路、轉向、停車、臨停、步行與大眾運輸等可達性。 | 直線距離不等於可達性。 |
| External Demand | 區位本身可產生的潛在洗衣需求。 | 不含特定品牌捕獲能力。 |
| Brand Capture | 特定品牌能取得外部需求的比例。 | 不可使用全台永久單一倍率。 |
| Format Fit | 目標店型與當地需求的適配程度。 | 需考慮容量與服務組合。 |
| Competition Gap | 區域需求相對於競爭供給的缺口。 | 競店數量不等於競爭強度。 |
| Cannibalization | 新店對既有自家店需求與營收的稀釋。 | 可能具方向性與時段性。 |
| Demand Absorption | 新店開出後吸收原熱區需求的程度。 | 用於更新 HeatZone 狀態。 |
| HeatZone Score | 區域的展店機會綜合分數。 | 必須附 Component、版本與 Confidence。 |
| Priority Rank | 按政策與限制排序後的展店優先順序。 | 不是原始需求分數。 |
| Hard Rule | 一旦違反即不可通過的可行性規則。 | 不得由高模型分數抵銷。 |
| Field Survey | 需現場勘查補足的資訊或決策狀態。 | 不是 GO。 |


## 交易、營運與成本

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Transaction | 一次可追溯的支付或服務交易。 | 退款、作廢與更正不可覆蓋原始紀錄。 |
| Gross Revenue | 折扣與退款前的交易金額。 | 必須明確幣別與稅別。 |
| Net Revenue | 扣除折扣、退款與指定調整後的營收。 | 公式需版本化。 |
| Gross Margin | 營收扣除可歸屬變動成本後的毛利。 | 不可與營業利益混用。 |
| GM_TTM | 估值日往前 12 個月的正常化毛利。 | 需標記異常與干預調整。 |
| GM_FWD | 基於 ForecastOps 的未來毛利。 | 必須附預測區間。 |
| Unit Cost | 每交易、每 Cycle、每公斤或每營收單位的成本。 | 分母必須明確。 |
| Utility Usage | 水、電、瓦斯等用量與費用。 | 用量與帳單金額分開。 |
| Complaint | 顧客反饋或客訴事件。 | 主題、嚴重度、發生與結案時間需保存。 |
| Work Order | 維修、保養、清潔等可執行工單。 | 不得只保存文字備註。 |
| Outage | 設備或服務不可用事件。 | 需有開始、結束、影響範圍。 |
| Observed Demand | 受產能限制後實際服務到的需求。 | ObservedDemand = min(LatentDemand, Capacity)。 |
| Latent Demand | 若無產能限制時的潛在需求。 | 需由模型或代理指標估計。 |


## 預測、模型與不確定性

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Prediction | 模型對未知結果的估計。 | 不得與 Recommendation 或 Decision 混用。 |
| Prediction Origin Time | 預測成立的時間截點。 | 任何特徵不得晚於此時間。 |
| Feature Snapshot Time | 推論所使用特徵的有效快照時間。 | 必須可重建。 |
| Prediction Horizon | 預測涵蓋的未來期間。 | 例如 28 days、4 weeks。 |
| Target | 模型要學習的結果變數。 | 需定義觀察與成熟時間。 |
| Label | 經驗證、可供學習或評估的結果標記。 | 可多標籤。 |
| Label Maturity Time | 結果已穩定、可做訓練標籤的最早時間。 | 不得在成熟前進訓練集。 |
| Point-in-time Correctness | 歷史訓練只使用當時已可知資訊。 | 違反即為資料洩漏。 |
| P10／P50／P90 | 預測分布的第 10、50、90 百分位。 | 不是最佳／一般／最差的主觀標籤。 |
| Prediction Interval | 預測值可能落入的區間。 | 需做 Coverage 校準。 |
| Calibration | 名義機率與實際發生比例的一致程度。 | 與點預測誤差分開驗證。 |
| Conformal Calibration | 利用校準集形成具覆蓋保證的區間方法。 | 需避免時間洩漏。 |
| Baseline | 最簡單可比較方法，例如 Seasonal Naive。 | 任何複雜模型均需優於 Baseline。 |
| Champion | 目前 Production 採用模型。 | 由 Release Controller 指派。 |
| Challenger | 與 Champion 平行比較但未承接正式決策的模型。 | 可包含 LSTM／Deep Model。 |
| Shadow | 接收 Production 輸入但不影響正式輸出的模式。 | 用於安全驗證。 |
| Canary | 讓有限流量使用新版本。 | 須有自動停止條件。 |
| Drift | 資料、特徵、預測或效能分布改變。 | 需區分種類。 |
| Model Card | 模型目的、資料、指標、限制、風險與核准資訊。 | Production 模型必須有。 |


## 決策、干預與因果

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Recommendation | 由預測與政策形成的建議。 | 不代表已核准。 |
| Decision | 經權限與政策確認的正式選擇。 | 必須保存 Actor 與理由。 |
| Approval | 對候選決策的核准或拒絕。 | 可有多層級。 |
| Override | 人工改變系統建議。 | 必須填寫理由並回收 Outcome。 |
| Execution | 實際執行的行動與參數。 | 不得以 Recommendation 代替。 |
| Treatment | 可能改變 Outcome 的干預，例如調價或廣告。 | 在因果模型中需明確定義。 |
| Eligibility | 某門市／時段是否具備接受某干預的條件。 | 應在建立 Action 前檢查。 |
| Action Set | 在安全與政策下允許的候選行動集合。 | 不等於模型任意輸出。 |
| Safe Action Set | 通過硬限制與風險規則的行動集合。 | PriceOps 必須使用。 |
| Conflict | 同一觀察期間存在相互干擾的多個干預。 | 必須攔截或標記。 |
| Observation Window | 干預後用來觀察 Outcome 的時間範圍。 | 需有開始、結束與成熟日。 |
| Outcome | 實際觀察到的業務結果。 | 可為 Revenue、GM、Utilization 等。 |
| Counterfactual | 若未執行 Treatment 時可能發生的結果。 | 因果效果需比較 Counterfactual。 |
| Incremental Revenue | Treatment 相對 Counterfactual 增加的營收。 | 不得用活動後營收直接替代。 |
| Incremental Gross Margin | 扣除活動與變動成本後的增量毛利。 | AdLift 核心指標。 |
| iROMI | Incremental Return on Marketing Investment。 | 分子應使用增量毛利而非表面營收。 |
| Evidence Level | 對效果結論可信度的分級。 | 需由設計、樣本、Pre-trend、區間等決定。 |
| Propensity | 某情境下採取某 Treatment 的機率。 | Bandit／觀察性因果必須保存。 |
| Pre-trend | Treatment 前實驗組與對照組的趨勢可比性。 | DiD 上線門檻。 |
| DiD | Difference-in-Differences。 | 需檢查平行趨勢。 |
| Synthetic Control | 以多個對照單位加權形成反事實。 | 適合單店或少數 Treatment。 |
| Uplift／CATE | 不同對象的異質 Treatment Effect。 | 樣本不足時不得直接做個體策略。 |


## 資產、估值與店網

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Valuation Date | 估值成立的日期。 | 所有輸入需相對此日截點。 |
| Normalized Performance | 排除一次性、異常或不具可持續性的營運績效。 | 調整項須可稽核。 |
| Income Approach | 以未來現金流或毛利能力估值。 | 需附折現與情境假設。 |
| Asset Approach | 以設備與資產重置／折舊價值估值。 | 不等於市場成交價。 |
| Market Approach | 以可比交易或門市估值。 | Comparable 選取需透明。 |
| Fair Value | 依模型與假設估計的合理價值。 | 與 Reserve／Asking 分開。 |
| Reserve Price | 出售方可接受的最低參考價。 | 需經人工核准。 |
| Asking Price | 對外提出的價格。 | 可高於 Fair Value。 |
| Liquidity | 在特定價格與期限內成交的可能性。 | 應輸出時間分布或區間。 |
| Data Room | 估值與交易所需文件、資料與查核清單。 | 須有權限與下載 Audit。 |
| Scenario | NetPlan 的一組假設、限制與預測版本。 | 不可只保存最終方案。 |
| Hard Constraint | 任何可行解都不得違反的限制。 | 無解時輸出診斷。 |
| Soft Constraint | 可付出 Penalty 違反的偏好。 | 必須有權重與解釋。 |
| Binding Constraint | 限制最終解的關鍵約束。 | 需提供管理層理解。 |
| Infeasibility | 在所有硬限制下不存在可行解。 | 不得自動放寬。 |
| Rolling Horizon | 定期將計畫向前滾動並吸收新資訊。 | 需保存前版與差異。 |


## 治理、流程與技術

| 術語／代碼 | 正式定義 | 使用限制 |
|---|---|---|
| Decision Log | 保存建議、核准、Override、執行與 Outcome 的正式紀錄。 | OpsBoard 與 Learning Hub 共用。 |
| Audit Event | 不可變的系統或使用者操作事件。 | 與業務 Decision Log 分開。 |
| Correlation ID | 串聯同一端到端請求或流程的識別碼。 | 跨 API、Event、Job 必須傳遞。 |
| Idempotency Key | 避免相同請求或事件重複產生副作用的鍵。 | 建立 Job／Decision／Execution 時必須使用。 |
| Job | 非同步或批次工作的可追蹤執行單位。 | 狀態至少 QUEUED／RUNNING／SUCCEEDED／FAILED／CANCELLED／PARTIAL。 |
| Workflow | 跨時間、服務及人工核准的狀態流程。 | 可等待、重試、補償。 |
| Data Contract | 來源與消費方對 Schema、語意、SLA 與品質的契約。 | 不是單純欄位表。 |
| Feature Contract | Feature 的公式、來源、時間、Owner 與適用模型。 | 修改需版本化。 |
| Model-ready View | 原始／Canonical 資料與模型間的正式資料產品。 | 每個 View 有固定 Grain 與時間規則。 |
| Dataset Snapshot | 可重建模型 Run 的資料版本。 | 需保存 Query／Manifest／時間範圍。 |
| Data Quality Gate | 依規則阻擋資料發布、模型訓練或推論。 | 不可只告警。 |
| Feature Flag | 控制功能、模型或高風險策略是否啟用。 | 高階模型預設關閉。 |
| Rollback | 回復到先前模型、設定或業務決策狀態。 | 模型與業務 Rollback 分開。 |
| SLO | 內部服務水準目標。 | 可比對外 SLA 更嚴格。 |
| SLA | 對外承諾的服務水準。 | 目前 OpsBoard 最低 99.5%。 |
| RPO | 可接受的最大資料遺失時間。 | 需由 DR 文件核准。 |
| RTO | 服務恢復的時間目標。 | 需分級。 |


## 3. 共同公式

### 3.1 可服務需求

```text
served_demand = external_demand × brand_capture × format_fit
```

### 3.2 營收拆解

```text
revenue = external_demand
        × brand_capture
        × format_conversion
        × ramp_curve
        × seasonality
        + intervention_effects
        + error
```

此式為語意拆解，不代表所有模型必須以乘法形式直接實作。

### 3.3 有效產能

```text
effective_capacity = machine_count
                   × available_time
                   × availability_rate
                   × throughput_per_hour
```

### 3.4 需求截斷

```text
observed_demand = min(latent_demand, effective_capacity)
```

### 3.5 SiteScore 實現率

```text
realization_ratio(horizon) = actual_revenue(horizon) / predicted_revenue_p50(horizon)
```

分母為零或資料未成熟時不得計算；需同時呈現對 P10／P90 的位置。

### 3.6 MAPE

```text
MAPE = mean(abs(actual - forecast) / max(abs(actual), epsilon))
```

門市營收接近零時需另用 WAPE、MAE 或 sMAPE，避免 MAPE 爆炸。

### 3.7 增量毛利與 iROMI

```text
incremental_gross_margin = estimated_incremental_revenue
                         - incremental_variable_cost
                         - campaign_or_action_cost

iROMI = incremental_gross_margin / marketing_spend
```

## 4. 標準狀態代碼

### 4.1 HeatZone 狀態

```yaml
UNTOUCHED: 尚未進入，仍有潛在需求
PARTIALLY_ABSORBED: 已被部分吸收，仍可能支援擴店
SATURATED: 需求大致被吸收，不建議再開
UNDER_REALIZED: 新店實績低於原始預測，需檢查模型或執行
STILL_EXPANDABLE: 新店達標且仍有外溢需求
```

### 4.2 Listing 狀態

```yaml
NEW: 新取得
NORMALIZED: 已完成欄位與地址標準化
DUPLICATE: 判定為重複
INELIGIBLE: 違反硬規則
SHORTLISTED: 通過初篩
CONTACTING: 聯絡中
FIELD_SURVEY: 現勘中
READY_FOR_SITESCORE: 可評分
EXPIRED: 已失效
REJECTED: 人工拒絕
CONVERTED: 已轉為候選店址／評估案件
```

### 4.3 SiteScore 決策

```yaml
GO: 建議且核准進入開店流程
GO_WITH_CONDITION: 條件完成後可進入開店流程
WAIT: 暫緩，等待資料、條件或時點
REJECT: 不建議或不可行
FIELD_SURVEY: 需現場補充關鍵資訊
```

`recommendation_code` 與 `approved_decision_code` 必須分欄保存。

### 4.4 門市生命週期

```yaml
PLANNED: 已核准但尚未施工
BUILDING: 建置中
PRE_OPENING: 試營運／開幕準備
RAMPING: 新店爬坡
GROWING: 穩定成長
MATURE_PLATEAU: 成熟平台
DECLINING: 下降中
DISTRESSED: 結構性高風險
RELOCATION_PLANNED: 已決議遷點
EXIT_PLANNED: 已決議退出
CLOSED: 已關閉
TRANSFERRED: 已轉讓
```

### 4.5 四燈

```yaml
GREEN:
  meaning: 正常或在合理波動範圍
  default_action: 持續監控
YELLOW:
  meaning: 輕微偏離，需注意或補資料
  default_action: 建立觀察任務
ORANGE:
  meaning: 明顯異常或持續惡化
  default_action: 人工審查並建立干預候選
RED:
  meaning: 重大風險、結構性問題或安全事件
  default_action: 立即指派、限時處理，必要時啟動 AVM／NetPlan
```

燈號由 Decision Policy 產生，不得由單一預測模型直接寫死。

### 4.6 Alert 狀態

```yaml
OPEN: 已建立
ACKNOWLEDGED: 已確認收到
INVESTIGATING: 調查中
ACTION_REQUIRED: 需處置
ACTION_IN_PROGRESS: 處置中
MONITORING: 觀察中
RESOLVED: 已解決
DISMISSED: 誤報或不適用
ESCALATED: 已升級
```

### 4.7 Intervention 狀態

```yaml
DRAFT: 草稿
ELIGIBILITY_CHECKED: 已檢查適用性
PROPOSED: 已提出方案
PENDING_APPROVAL: 待核准
APPROVED: 已核准
REJECTED: 已拒絕
SCHEDULED: 已排程
EXECUTING: 執行中
EXECUTED: 已完成執行
OBSERVING: 觀察中
OUTCOME_MATURED: 結果成熟
EVALUATED: 已完成效果評估
STOPPED: 已停止
ROLLED_BACK: 已回滾
CANCELLED: 已取消
```

### 4.8 價格與廣告決策

```yaml
CONTINUE: 繼續
ADJUST: 修改參數
SCALE: 擴大範圍／預算
STOP: 停止
ROLLBACK: 回復原方案
CHANGE_CHANNEL: 改變廣告渠道
INSUFFICIENT_EVIDENCE: 證據不足，不做因果結論
```

### 4.9 NetPlan 行動

```yaml
OPEN: 新開店
KEEP: 維持現況
IMPROVE: 投入改善
MOVE: 遷點
EXIT: 退出
TRANSFER: 轉讓
```

### 4.10 Job 狀態

```yaml
QUEUED: 已排隊
RUNNING: 執行中
SUCCEEDED: 完成
FAILED: 失敗
CANCELLED: 取消
PARTIAL: 部分完成
RETRYING: 重試中
BLOCKED: 因資料、權限或依賴被阻擋
```

### 4.11 模型版本狀態

```yaml
DRAFT: 開發中
VALIDATING: 驗證中
REGISTERED: 已登錄
SHADOW: 影子運行
CANARY: 小流量運行
CHAMPION: 正式版本
CHALLENGER: 比較版本
DEPRECATED: 不再建議使用
ROLLED_BACK: 已回滾
ARCHIVED: 封存
REJECTED: 未通過發布
```

## 5. 時間語意

| 欄位 | 定義 | 例子 |
|---|---|---|
| `event_time` | 事件真實發生時間 | 顧客完成交易時間 |
| `observation_time` | ODay Plus 首次收到或觀察到資料的時間 | 交易同步到平台時間 |
| `source_updated_at` | 來源最後修改時間 | 上游退款修正時間 |
| `ingested_at` | Connector 寫入 Raw Zone 的時間 | 批次載入時間 |
| `decision_time` | 模型或人員正式做決策的時間 | SiteScore 核准時間 |
| `execution_time` | 動作真正執行的時間 | 新價格生效時間 |
| `outcome_time` | 可觀察到結果的時間 | 觀察窗口結束日 |
| `label_maturity_time` | 結果穩定可作標籤的時間 | 延遲退款完成後日期 |
| `valid_from／valid_to` | 業務事實有效期間 | 租約、店型、價格有效期 |
| `system_from／system_to` | 系統保存版本的期間 | SCD Type 2 系統時間 |

## 6. 結果與責任五分法

| 層級 | 典型欄位 | 可以被誰產生 | 是否可覆蓋 |
|---|---|---|---:|
| Prediction | `prediction_id`, `p50`, `model_version` | 模型服務 | 否；新版本新增紀錄 |
| Recommendation | `recommendation_code`, `policy_version` | Decision Service | 否；可被後續建議取代但保留歷史 |
| Approval／Decision | `approved_code`, `approver_id`, `reason` | 授權人員／政策 | 否 |
| Execution | `actual_action`, `executed_at`, `external_ref` | 執行系統／人員 | 狀態可更新，歷史不可刪 |
| Outcome | `metric`, `value`, `maturity`, `evidence_level` | Outcome Collector | 可追加修正版本，不覆蓋原始 |

## 7. ID 與鍵規則

- 所有 Canonical 主鍵使用不可推測的 UUID／ULID。
- 來源鍵以 `(source_system, source_entity, source_record_id)` 唯一識別。
- Store、Machine、Listing 等必須有獨立 `identity_map`，不得把來源 ID 當全域主鍵。
- Event ID、Job ID、Correlation ID、Idempotency Key 不得共用同一語意。
- 資料刪除採 tombstone／status，不得物理刪除仍受稽核或模型重建需要的紀錄。

## 8. 禁用或需澄清的模糊用語

| 禁用用語 | 問題 | 應改寫為 |
|---|---|---|
| 營收 | 未指明 Gross／Net、期間與幣別 | `net_revenue_twd_daily` 等明確口徑 |
| 預測準確率 | 回歸問題無單一 accuracy | MAPE、WAPE、MAE、Coverage 等 |
| 客流量 | 可能是人流、交易數或會員數 | 明確指定 footfall／transactions／unique_members |
| 異常 | 未說明閾值與類型 | revenue_residual_anomaly、equipment_outage 等 |
| AI 建議 | 不知道模型或規則 | 指定 Prediction、Policy、版本與 Evidence |
| 最佳價格 | 無限制與目標函數 | 在指定限制下最大化預期毛利的候選價格 |
| 店值多少 | 未指定估值日與價值類型 | valuation_date、fair／reserve／asking |
| 已處理 | 不知道是否執行與有效 | approved／executed／outcome_matured／resolved |
| 即時 | 未定義延遲 | 例如 60 秒內、5 分鐘內、每日 06:00 前 |

## 9. 語意變更流程

1. 提出變更及使用情境。
2. 分析受影響資料表、API、Event、模型與報表。
3. 建立版本與 Migration／Backfill 計畫。
4. 由 Business Owner、Data Owner、Model Owner 共同核准。
5. 同步更新本文件、Data Contract、Feature Contract 與測試。
6. 舊語意保留相容期，不得無通知直接覆蓋。

## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.2.0 | 2026-06-25 | C1 | 建立全平台名詞、狀態、時間、ID 與決策語意 | Data Governance／Product | Pending |

