---
doc_id: ODP-00-05
title: "需求追蹤矩陣"
version: 0.1.0
status: draft-for-review
document_class: project-governance
batch: 1
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-25
owner: "Product Lead / QA Lead"
approvers: "Domain Business Owners / Architecture Owner / Program Manager"
content_format: markdown
---

# ODay Plus 需求追蹤矩陣

## 1. 文件目的

本文件建立 ODay Plus 從來源承諾到需求、SA、資料契約、SD、模組設計、測試、發布與查核證據的追蹤骨架。本版先基線化跨全平台的 High-Level Requirements（HLR）；第 2 批 `ODP-SA-06` 將把 HLR 拆成可開發的 Functional Requirements，第 8 批再綁定 Test Case 與正式驗收證據。

本文件不是功能規格書，而是「任何需求不能失聯」的主索引。

## 2. 追蹤鏈

```mermaid
flowchart LR
  SRC[Source / Commitment] --> OBJ[Business Objective]
  OBJ --> HLR[High-Level Requirement]
  HLR --> UC[Use Case / Journey]
  HLR --> FR[Functional / Non-functional Requirement]
  FR --> DATA[Data / Feature / Label Contract]
  FR --> SD[Platform / Module Design]
  SD --> API[API / Event / Schema / Workflow]
  SD --> TEST[Test Case / Model Validation]
  TEST --> EVIDENCE[Result / Report / Audit Evidence]
  EVIDENCE --> ACCEPT[Acceptance / Release Gate]
```

## 3. ID 命名

| ID 類型 | 格式 | 例子 |
|---|---|---|
| Business Objective | `ODP-OBJ-<DOMAIN>-NNN` | `ODP-OBJ-EXP-001` |
| High-Level Requirement | `ODP-HLR-<DOMAIN>-NNN` | `ODP-HLR-SITE-002` |
| Use Case | `ODP-UC-<DOMAIN>-NNN` | `ODP-UC-OPS-004` |
| Functional Requirement | `ODP-FR-<DOMAIN>-NNN` | `ODP-FR-INTV-021` |
| Non-functional Requirement | `ODP-NFR-<DOMAIN>-NNN` | `ODP-NFR-API-003` |
| Business Rule | `ODP-BR-<DOMAIN>-NNN` | `ODP-BR-PRICE-008` |
| Data Contract | `ODP-DC-<DOMAIN>-NNN` | `ODP-DC-IOT-001` |
| API／Event | `ODP-API-*`／`ODP-EVT-*` | `ODP-EVT-INTERVENTION-APPROVED-V1` |
| Test／Acceptance | `ODP-TC-*`／`ODP-AC-*` | `ODP-AC-SITE-004` |
| Evidence | `ODP-EV-*` | `ODP-EV-FORECAST-BACKTEST-2026Q3` |

ID 一旦被外部文件或程式引用即不得重用。刪除需求時保留 ID 並標記 `RETIRED`。

## 4. Requirement Class

| Class | 定義 |
|---|---|
| `COMMITMENT` | 來自 ODay Plus 計畫書、查核或對外承諾的最低要求 |
| `TARGET` | 來自完整目標架構，屬最終平台範圍 |
| `TARGET+COMMITMENT` | 同時屬目標架構與對外承諾 |
| `BOUNDARY` | 系統／團隊責任邊界 |
| `GOVERNANCE` | 文件、責任、變更、驗證或稽核要求 |
| `CONDITIONAL` | 必須完成設計與接口，但正式啟用受資料／風險 Gate 控制 |

## 5. Priority 與 Status

| 值 | 定義 |
|---|---|
| `MUST` | 最終完整系統必須滿足；未滿足不得宣告完成 |
| `SHOULD` | 應滿足；若不做需有核准 Deviation |
| `CONDITIONAL` | 受 Readiness Gate 控制的正式啟用要求 |
| `BASELINED-DRAFT` | 已納入本批基線，待正式 Review |
| `APPROVED` | 已核准，成為開發／驗收基線 |
| `IMPLEMENTING` | 已進入實作 |
| `VERIFIED` | 已由測試或驗證證實 |
| `ACCEPTED` | 已完成業務／正式驗收 |
| `DEFERRED` | 經核准延後；需有期限與理由 |
| `RETIRED` | 已由新版需求取代或正式移除 |

## 6. Source Key

| Source ID | 內容 |
|---|---|
| `SRC-ODP-ARCH` | ODay Plus 完整目標架構與十篇設計文件 |
| `SRC-ODP-PLAN` | ODay Plus／自助洗衣生命週期計畫書中的模組、KPI 與 GCP 承諾 |
| `SRC-ODP-REVIEW` | 審查、修正、查核、資安、SLA、資料可攜與證據要求 |
| `SRC-WORKING-DECISIONS` | 已確認的全模組建置與 IoT 上游邊界 |

## 7. 驗證方法代碼

| 方法 | 說明 |
|---|---|
| Scope／Design Review | 由指定 Owner 核對範圍、流程、規則與責任 |
| Contract Test | Schema、API、Event 或上游接口自動測試 |
| E2E | 從輸入、決策、核准、執行到 Outcome 的端到端測試 |
| UAT | 業務角色實際操作與驗收 |
| Model Validation | Holdout、Rolling Backtest、Calibration、子群與風險驗證 |
| Performance／SLO | API、Batch、Job、可用率、RPO／RTO 等量測 |
| Audit／Evidence | 留痕、版本、責任、查核包與可重現性檢查 |
| Security／Privacy | 權限、弱點、資料保護與事件測試 |

## 8. High-Level Requirements 基線
### 8.1 覆蓋摘要

| Domain | HLR 數量 |
|---|---:|
| `GOV` | 10 |
| `INT` | 8 |
| `HZ` | 5 |
| `LST` | 5 |
| `SITE` | 8 |
| `FCT` | 7 |
| `INTV` | 7 |
| `PRICE` | 5 |
| `AD` | 5 |
| `AVM` | 6 |
| `NET` | 6 |
| `LH` | 7 |
| `OPS` | 7 |
| `NFR` | 10 |
| **合計** | **96** |

### 8.2 治理與責任

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-GOV-001` | ODay Plus 必須以全模組完整建置為目標；Stage／Phase 只能控制依賴、驗證與啟用順序，不得縮減最終範圍。 | `TARGET` | `SRC-WORKING-DECISIONS` | Executive Sponsor | Scope review＋RTM review | `ODP-00-01, ODP-SA-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-002` | 系統必須分離保存 Prediction、Recommendation、Approval／Decision、Execution 與 Outcome。 | `TARGET` | `SRC-ODP-ARCH` | Product Lead | Schema review＋E2E | `ODP-SA-06, ODP-DATA-04, ODP-SD-08` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-003` | 每項高風險決策必須記錄 Actor、角色、資料範圍、政策版本、理由、Override 與時間。 | `TARGET` | `SRC-ODP-ARCH` | Operations Governance Head | Audit test | `ODP-SA-07, ODP-SD-09, ODP-MOD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-004` | 每個重大交付物必須只有一個 Accountable Owner，且模型發布與業務決策核准必須分離。 | `GOVERNANCE` | `SRC-ODP-ARCH` | Executive Sponsor | RACI review | `ODP-00-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-005` | 所有正式需求必須具有穩定 Requirement ID，並可追溯到來源、設計、測試與驗收證據。 | `GOVERNANCE` | `SRC-WORKING-DECISIONS` | Product Lead | RTM integrity check | `ODP-00-04, ODP-QA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-006` | 重大架構、資料語意、服務邊界與高風險技術選擇必須透過 ADR 留存 Context、Alternatives、Decision、Consequences 與 Review Trigger。 | `GOVERNANCE` | `SRC-ODP-ARCH` | Architecture Owner | ADR audit | `ODP-00-04, ODP-SD-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-007` | 正式文件必須採 Markdown、YAML front matter、穩定 Doc ID、版本與狀態管理。 | `GOVERNANCE` | `SRC-WORKING-DECISIONS` | Program Manager | Document lint | `ODP-00-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-008` | 所有 Production 模型必須具有 Model Card；所有 Decision Service 必須具有 Decision Card。 | `TARGET` | `SRC-ODP-ARCH` | Technology Lead | Release gate | `ODP-ML-04, ODP-SA-07, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-009` | 高風險功能必須以 Feature Flag、人工核准、Canary 或等效控制限制啟用範圍。 | `TARGET` | `SRC-ODP-ARCH` | Risk／Validation Owner | Release test | `ODP-SD-12, ODP-ML-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-GOV-010` | IoT 與內部資料底座必須被視為上游資料供應者；ODay Plus 不得直接耦合其內部實作。 | `BOUNDARY` | `SRC-WORKING-DECISIONS` | Architecture Owner | Boundary review＋contract test | `ODP-SA-09, ODP-DATA-02, ODP-MOD-00` | `MUST` | `BASELINED-DRAFT` |

### 8.3 Integration／Data

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-INT-001` | Integration Layer 必須支援 Batch、CDC、API、檔案與 Event 的來源接入模式。 | `TARGET` | `SRC-ODP-ARCH` | Data Platform Owner | Connector integration tests | `ODP-DATA-02, ODP-DATA-03, ODP-MOD-00` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-002` | 每筆來源資料必須保存 source_system、source_record_id、event_time、observation_time、ingested_at 與來源版本。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Schema＋lineage test | `ODP-DATA-04, ODP-DATA-05, ODP-DATA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-003` | 來源主鍵不得直接作為全域主鍵；Store、Machine、Listing 等實體必須透過 Identity Mapping 對位。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Uniqueness＋mapping test | `ODP-DATA-04, ODP-DATA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-004` | 來源資料必須支援重送、Backfill、Quarantine、Retry 與可重現 Snapshot。 | `TARGET` | `SRC-ODP-ARCH` | Data Platform Owner | Recovery test | `ODP-DATA-02, ODP-DATA-03, ODP-SD-10, ODP-OPS-02` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-005` | 外部資料必須保存授權、來源日期、覆蓋率、新鮮度與 Confidence，不得只保存最新值。 | `TARGET` | `SRC-ODP-ARCH` | External Data Owner | Data quality audit | `ODP-DATA-01, ODP-DATA-03, ODP-DATA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-006` | 地址處理必須涵蓋正規化、Geocode、行政區、H3、道路可達性與人工校正。 | `TARGET` | `SRC-ODP-ARCH` | Geo Lead | Golden address set | `ODP-DATA-03, ODP-MOD-00` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-007` | 模型不得直接查詢未受控上游原始表；必須經 Canonical Layer 與 Model-ready Views。 | `TARGET` | `SRC-ODP-ARCH` | Architecture Owner | Architecture test＋access policy | `ODP-DATA-04, ODP-DATA-06, ODP-SD-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INT-008` | 所有歷史訓練與回測資料必須符合 Point-in-time Correctness，禁止使用決策時間後才可知資訊。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Leakage test | `ODP-DATA-07, ODP-ML-02, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |

### 8.4 HeatZone

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-HZ-001` | HeatZone 必須以全台可比較空間單元產生外部需求、ODay G2 適配、競爭缺口、自家稀釋、租金可行性與物件機會。 | `TARGET` | `SRC-ODP-ARCH` | Expansion Director | Feature coverage＋UAT | `ODP-MOD-01, ODP-DATA-06` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-HZ-002` | HeatZone 必須輸出 Score、Priority Rank、未滿足需求、建議租金、建議物件條件與 Confidence。 | `TARGET` | `SRC-ODP-ARCH` | Expansion Director | API／UI acceptance | `ODP-SA-06, ODP-MOD-01, ODP-UX-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-HZ-003` | HeatZone 必須支援 UNTOUCHED、PARTIALLY_ABSORBED、SATURATED、UNDER_REALIZED、STILL_EXPANDABLE 狀態。 | `TARGET` | `SRC-ODP-ARCH` | Expansion Product | State transition tests | `ODP-SA-07, ODP-MOD-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-HZ-004` | HeatZone 必須使用開店後實績更新 Demand Absorption 與剩餘需求。 | `TARGET` | `SRC-ODP-ARCH` | Expansion Director | E2E realization test | `ODP-MOD-01, ODP-MOD-03, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-HZ-005` | HeatZone 排序必須優於單純人口排序 Baseline，並可由展店團隊解釋。 | `TARGET` | `SRC-ODP-ARCH` | Geo／Demand Model Owner | Backtest＋business ranking review | `ODP-ML-03, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |

### 8.5 Listing Pipeline

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-LST-001` | Listing Pipeline 必須支援人工輸入、CSV／Excel、合作 Feed 與正式 API。 | `TARGET` | `SRC-ODP-ARCH` | Listing Product | Connector acceptance | `ODP-MOD-02, ODP-SA-09` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LST-002` | Listing 必須執行地址解析、Geocode、H3 對位、欄位正規化與來源版本保存。 | `TARGET` | `SRC-ODP-ARCH` | Listing Product | Data contract test | `ODP-DATA-05, ODP-MOD-02` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LST-003` | Listing 必須執行跨來源去重，保留重複群組、判定信心與人工合併／拆分能力。 | `TARGET` | `SRC-ODP-ARCH` | Listing Product | Precision／recall sample test | `ODP-MOD-02, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LST-004` | Listing 必須套用 Hard Rules、HeatZone Filter 與可解釋優先排序。 | `TARGET` | `SRC-ODP-ARCH` | Expansion Head | Rule＋ranking test | `ODP-SA-07, ODP-MOD-02` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LST-005` | Listing 必須管理 NEW、SHORTLISTED、CONTACTING、FIELD_SURVEY、EXPIRED、REJECTED、CONVERTED 等生命週期。 | `TARGET` | `SRC-ODP-ARCH` | Listing Product | Workflow E2E | `ODP-SD-08, ODP-MOD-02, ODP-UX-03` | `MUST` | `BASELINED-DRAFT` |

### 8.6 SiteScore

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-SITE-001` | SiteScore 必須將 External Demand、Brand Transfer、ODay G2 Format Conversion、Ramp 與 Seasonality 組合為新店營收路徑。 | `TARGET` | `SRC-ODP-ARCH` | Site Review Head | Model design review | `ODP-MOD-03, ODP-ML-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-002` | SiteScore 必須輸出 M1、M3、M6、M12 與成熟穩態的 P10／P50／P90。 | `COMMITMENT` | `SRC-ODP-PLAN` | Site Review Head | API＋report acceptance | `ODP-SA-06, ODP-MOD-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-003` | SiteScore 必須輸出回本期、租金合理性、自家稀釋、主要正負因子、Comparable Stores 與資料信心。 | `COMMITMENT` | `SRC-ODP-PLAN` | Site Review Head | Report UAT | `ODP-MOD-03, ODP-UX-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-004` | SiteScore 必須同時執行 Predictive Score 與 Feasibility Hard Rules；硬規則不得被高分抵銷。 | `TARGET` | `SRC-ODP-ARCH` | Site Review Head | Rule test | `ODP-SA-07, ODP-MOD-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-005` | SiteScore Recommendation 與人工 Approved Decision 必須分欄保存，支援 GO、GO_WITH_CONDITION、WAIT、REJECT、FIELD_SURVEY。 | `TARGET` | `SRC-ODP-ARCH` | Site Review Head | Workflow＋audit test | `ODP-SD-08, ODP-MOD-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-006` | SiteScore 正式決策時必須凍結 Input Snapshot、模型版本、政策版本與報告，供後續 Realization 驗證。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Snapshot reproduction test | `ODP-DATA-07, ODP-MOD-03, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-007` | SiteScore 回本期預測 MAPE 目標必須不高於 12%，並以明確樣本、期間與例外規則計算。 | `COMMITMENT` | `SRC-ODP-PLAN` | Site Model Owner | Holdout KPI | `ODP-ML-04, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-SITE-008` | SiteScore 報告必須在 24 小時內產出；已完成結果的互動 API P95 必須不高於 3 秒。 | `COMMITMENT` | `SRC-ODP-PLAN` | SiteScore Service Owner | SLA／performance test | `ODP-SD-06, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |

### 8.7 ForecastOps

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-FCT-001` | ForecastOps 必須產生每店 4、8、12、24 週成長軌跡，並支援核定的 28 日營收預測視窗。 | `TARGET+COMMITMENT` | `SRC-ODP-ARCH;SRC-ODP-PLAN` | Operations Head | Forecast API＋report test | `ODP-MOD-04, ODP-ML-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-002` | ForecastOps 必須至少整合營收、費用／單位成本、客服與維修／設備四類風險證據。 | `COMMITMENT` | `SRC-ODP-PLAN` | Operations Head | Feature coverage test | `ODP-DATA-06, ODP-MOD-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-003` | ForecastOps 必須比較實績與 SiteScore 原始預測，產生 Realization Ratio 與 SiteScore Gap。 | `TARGET` | `SRC-ODP-ARCH` | Forecast Product | E2E realization test | `ODP-MOD-03, ODP-MOD-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-004` | ForecastOps 必須輸出成長階段、轉折機率、異常證據、根因候選與四燈所需 Evidence Vector。 | `TARGET` | `SRC-ODP-ARCH` | Operations Head | Model＋policy acceptance | `ODP-MOD-04, ODP-SA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-005` | 四燈必須由 Decision Policy 產生，不得由單一預測模型直接決定。 | `TARGET` | `SRC-ODP-ARCH` | Operations Head | Decision policy test | `ODP-SA-07, ODP-MOD-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-006` | 營運異常平均提前預警目標必須至少 7 天，且預警 Precision 目標必須至少 90%。 | `COMMITMENT` | `SRC-ODP-PLAN` | Forecast Model Owner | Historical alert backtest | `ODP-ML-04, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-FCT-007` | 預警後 14 天內恢復率目標必須至少 70%，並區分是否實際完成處置。 | `COMMITMENT` | `SRC-ODP-PLAN` | Operations Head | Outcome KPI | `ODP-SA-10, ODP-MOD-05` | `MUST` | `BASELINED-DRAFT` |

### 8.8 InterventionOps

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-INTV-001` | InterventionOps 必須統一管理 Eligibility、Action Set、Conflict、Approval、Execution、Observation Window、Outcome 與 Effect Evaluation。 | `TARGET` | `SRC-ODP-ARCH` | Operations Head | Workflow E2E | `ODP-MOD-05, ODP-SD-08` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-002` | Price、Ad、Promotion、CRM、Maintenance、Cleaning 必須共用干預主流程，但保留各自規則與執行 Adapter。 | `TARGET` | `SRC-ODP-ARCH` | Intervention Product | Architecture＋E2E | `ODP-MOD-05, ODP-SD-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-003` | 系統必須偵測同一門市與觀察窗口內的重疊干預，並阻擋或標記混淆。 | `TARGET` | `SRC-ODP-ARCH` | Operations Head | Conflict test | `ODP-SA-07, ODP-MOD-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-004` | 每項干預必須保存 proposed_action 與 actual_action，未取得實際執行證據不得開始正式效果評估。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Audit＋causal data test | `ODP-DATA-04, ODP-MOD-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-005` | 每項干預必須具有 Observation Window、Outcome Maturity 與 Evidence Level。 | `TARGET` | `SRC-ODP-ARCH` | Causal Lead | Schema＋evaluation test | `ODP-ML-05, ODP-MOD-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-006` | 干預結果必須回寫 Label Registry，供 ForecastOps 保留並供 SiteScore 排除或正常化。 | `TARGET` | `SRC-ODP-ARCH` | Learning Hub Owner | Label lineage test | `ODP-ML-02, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-INTV-007` | 所有高風險干預必須支援 Continue、Adjust、Stop 或 Rollback，並保存原因。 | `TARGET` | `SRC-ODP-ARCH` | Decision Owner | Rollback E2E | `ODP-SD-08, ODP-MOD-05` | `MUST` | `BASELINED-DRAFT` |

### 8.9 PriceOps

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-PRICE-001` | PriceOps 必須估計價格彈性，並保存適用店群、時段、設備、價格區間與不確定性。 | `TARGET` | `SRC-ODP-ARCH` | Pricing Head | Model validation | `ODP-MOD-06, ODP-ML-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-PRICE-002` | PriceOps 必須建立 Safe Action Set，包含毛利底線、品牌政策、價差、設備與法規硬限制。 | `TARGET` | `SRC-ODP-ARCH` | Pricing Head | Constraint tests | `ODP-SA-07, ODP-OR-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-PRICE-003` | Pricing Optimizer 必須以需求／毛利模擬與受限制最佳化產生候選方案，不得只輸出單一黑箱價格。 | `TARGET` | `SRC-ODP-ARCH` | OR Lead | Optimization test | `ODP-MOD-06, ODP-OR-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-PRICE-004` | 價格 Hard Constraints 必須零違反；無可行方案時必須輸出原因而不是放寬限制。 | `TARGET` | `SRC-ODP-ARCH` | Pricing Head | Feasibility test | `ODP-QA-04, ODP-MOD-06` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-PRICE-005` | Contextual Bandit 必須完成接口與治理設計，但僅在 Propensity、Reward、Safe Exploration 與 Off-policy Evaluation 成熟後啟用。 | `CONDITIONAL` | `SRC-ODP-ARCH` | Technology Lead | Feature flag＋readiness gate | `ODP-ML-01, ODP-MOD-06` | `MUST` | `BASELINED-DRAFT` |

### 8.10 AdLift

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-AD-001` | AdLift 必須保存 Campaign、渠道、預算、店群、投放期間、受眾與實際執行資料。 | `TARGET` | `SRC-ODP-ARCH` | Marketing Head | Data contract test | `ODP-DATA-04, ODP-MOD-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AD-002` | AdLift 必須支援 Matched Controls 與 DiD，並在適用時支援 Synthetic Control 與 Uplift／HTE。 | `TARGET` | `SRC-ODP-ARCH` | Causal Lead | Causal validation | `ODP-ML-05, ODP-MOD-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AD-003` | DiD 結論必須檢查 Pre-trend；證據不足時輸出 INSUFFICIENT_EVIDENCE。 | `TARGET` | `SRC-ODP-ARCH` | Causal Lead | Pre-trend／placebo test | `ODP-ML-05, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AD-004` | AdLift 核心 Outcome 必須包含 Incremental Revenue、Incremental Gross Margin 與 iROMI，不得只看表面 ROAS。 | `TARGET` | `SRC-ODP-ARCH` | Marketing Head | Metric reconciliation | `ODP-MOD-07, ODP-SA-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AD-005` | AdLift 必須產生 Continue、Stop、Scale 或 Change Channel 建議，並經人工核准。 | `TARGET` | `SRC-ODP-ARCH` | Marketing Head | Workflow UAT | `ODP-MOD-07, ODP-SD-08` | `MUST` | `BASELINED-DRAFT` |

### 8.11 DealRoomAVM

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-AVM-001` | DealRoomAVM 必須整合 GM_TTM、GM_FWD、設備折舊、資產清單、租約與正常化調整。 | `COMMITMENT` | `SRC-ODP-PLAN` | Finance Head | Data reconciliation | `ODP-MOD-08, ODP-DATA-06` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AVM-002` | DealRoomAVM 必須分別產生 Income、Asset、Market／Comparable 三種估值鏡頭。 | `TARGET` | `SRC-ODP-ARCH` | Finance Head | Valuation review | `ODP-MOD-08, ODP-ML-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AVM-003` | DealRoomAVM 必須輸出 P10／P50／P90，並分離 Fair Value、Reserve Price 與 Asking Price。 | `TARGET` | `SRC-ODP-ARCH` | Finance Head | Report acceptance | `ODP-MOD-08, ODP-UX-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AVM-004` | 估值 MAPE 目標必須不高於 15%，實際成交價落於估值區間的 Coverage 目標必須至少 80%。 | `COMMITMENT` | `SRC-ODP-PLAN` | AVM Model Owner | Historical transaction validation | `ODP-ML-04, ODP-QA-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AVM-005` | 估值卡與資料室報告必須在 3 個工作日內產出。 | `COMMITMENT` | `SRC-ODP-PLAN` | AVM Service Owner | SLA test | `ODP-MOD-08, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-AVM-006` | DealRoomAVM 必須回收實際成交價、成交期間、未成交原因與交易條件以更新模型。 | `TARGET` | `SRC-ODP-ARCH` | Finance Head | Outcome E2E | `ODP-MOD-08, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |

### 8.12 NetPlan

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-NET-001` | NetPlan 必須支援 OPEN、KEEP、IMPROVE、MOVE、EXIT，並可擴充 TRANSFER。 | `TARGET` | `SRC-ODP-ARCH` | Network Council | Scenario UAT | `ODP-MOD-09, ODP-SA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NET-002` | NetPlan 必須考量資本、租約、施工、設備、人力、區域覆蓋、自家稀釋與時序硬限制。 | `TARGET` | `SRC-ODP-ARCH` | Network Council | Constraint tests | `ODP-OR-01, ODP-MOD-09` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NET-003` | NetPlan 第一正式模型必須提供 P50 Deterministic 方案，並支援 Downside／Base／Upside 與 Rolling Horizon 擴充。 | `TARGET` | `SRC-ODP-ARCH` | OR Lead | Solver validation | `ODP-MOD-09, ODP-OR-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NET-004` | NetPlan 必須輸出 Alternative Plans、Binding Constraints、Solver Status 與 Infeasibility 診斷。 | `TARGET` | `SRC-ODP-ARCH` | OR Lead | Explainability test | `ODP-MOD-09, ODP-UX-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NET-005` | NetPlan 每案必須至少比較 ROI、現金流、風險、稀釋與時程五項指標，提案回覆時間必須不超過 48 小時。 | `COMMITMENT` | `SRC-ODP-PLAN` | Network Council | Report＋SLA test | `ODP-SA-10, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NET-006` | 正式店網決策必須回收 90／180／365 日 Outcome，並由管理層核准而非 Solver 自動執行。 | `TARGET` | `SRC-ODP-ARCH` | Executive Sponsor | Audit＋outcome test | `ODP-MOD-09, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |

### 8.13 Learning Hub

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-LH-001` | Learning Hub 必須管理 Feature Contract、Label Registry、Outcome Maturity 與 Dataset Snapshot。 | `TARGET` | `SRC-ODP-ARCH` | Technology Lead | Registry acceptance | `ODP-MOD-10, ODP-ML-02` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-002` | Learning Hub 必須管理 Experiment Tracking、Model Registry、Model Alias 與版本狀態。 | `TARGET` | `SRC-ODP-ARCH` | MLOps Owner | Registry integration test | `ODP-MOD-10, ODP-ML-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-003` | Learning Hub 必須支援 Backtest、Champion／Challenger、Shadow、Canary 與 Rollback。 | `TARGET` | `SRC-ODP-ARCH` | MLOps Owner | Release E2E | `ODP-MOD-10, ODP-OPS-06` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-004` | Data Quality Fail 必須能阻擋資料發布、訓練、評分或模型發布，不得只發告警。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Gate failure test | `ODP-DATA-07, ODP-MOD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-005` | Learning Hub 必須監控 Data、Feature、Prediction 與 Performance Drift。 | `TARGET` | `SRC-ODP-ARCH` | Model Owner | Drift simulation | `ODP-ML-01, ODP-SD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-006` | 每次 Prediction 與 Decision 必須可追溯至 Feature Snapshot、Dataset、Model、Policy 與 Release 版本。 | `TARGET` | `SRC-ODP-ARCH` | Data Governance Owner | Lineage audit | `ODP-MOD-10, ODP-MOD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-LH-007` | 模型 Rollback 與業務 Decision／Action Rollback 必須為兩條獨立流程。 | `TARGET` | `SRC-ODP-ARCH` | Technology Lead | Rollback E2E | `ODP-SD-08, ODP-OPS-06` | `MUST` | `BASELINED-DRAFT` |

### 8.14 OpsBoard

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-OPS-001` | OpsBoard 必須提供 HeatZone、Listing、SiteScore、ForecastOps、Intervention、PriceOps、AdLift、AVM、NetPlan 與 Learning Hub 工作區。 | `TARGET` | `SRC-ODP-ARCH` | Operations Governance Head | Sitemap＋UAT | `ODP-MOD-11, ODP-UX-01` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-002` | OpsBoard 必須支援 Task、Assignment、Comment、Attachment、Approval、Escalation 與 Notification。 | `TARGET` | `SRC-ODP-ARCH` | OpsBoard Product | Workflow E2E | `ODP-SD-08, ODP-MOD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-003` | OpsBoard 必須依 Tenant、Brand、Region、Store 與 Role／Attribute 限制資料與操作。 | `TARGET` | `SRC-ODP-ARCH` | Security Owner | Authorization test | `ODP-SA-04, ODP-SD-09` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-004` | OpsBoard 決策留痕完整度必須達 100%，並支援月度稽核與報表匯出。 | `COMMITMENT` | `SRC-ODP-PLAN` | Operations Governance Head | Audit completeness report | `ODP-SA-10, ODP-QA-07` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-005` | OpsBoard 月可用率最低承諾必須達 99.5%；更高商用 SLA 必須另經核准。 | `COMMITMENT` | `SRC-ODP-PLAN` | Service Owner | SLO report | `ODP-SA-08, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-006` | OpsBoard 必須呈現模型版本、資料新鮮度、Confidence、Prediction Interval 與 Evidence Level，避免把建議誤解為確定答案。 | `TARGET` | `SRC-ODP-ARCH` | OpsBoard Product | UX comprehension test | `ODP-UX-03, ODP-UX-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-OPS-007` | OpsBoard 必須提供查核證據匯出，可串聯 Requirement、Decision、Execution、Outcome、測試與版本。 | `COMMITMENT` | `SRC-ODP-REVIEW` | Program Manager | Evidence package test | `ODP-QA-07, ODP-MOD-11` | `MUST` | `BASELINED-DRAFT` |

### 8.15 跨域非功能需求

| HLR ID | Requirement | Class | Source | Accountable | Verification | Downstream Documents | Priority | Status |
|---|---|---|---|---|---|---|---|---|
| `ODP-HLR-NFR-001` | 所有 API、Event、Job 與 Workflow 必須傳遞 Correlation ID，建立端到端 Trace。 | `TARGET` | `SRC-ODP-ARCH` | Architecture Owner | Trace test | `ODP-SD-06, ODP-SD-07, ODP-SD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-002` | 建立 Decision、Execution、Job 或 Event 副作用時必須使用 Idempotency Key 或等效去重機制。 | `TARGET` | `SRC-ODP-ARCH` | Service Owner | Duplicate delivery test | `ODP-SD-06, ODP-SD-07, ODP-SD-10` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-003` | 同步 API 不得直接執行全台 HeatZone、完整模型訓練、長時間 AVM／NetPlan 求解；長任務必須回傳 Job ID。 | `TARGET` | `SRC-ODP-ARCH` | Architecture Owner | API timeout＋job E2E | `ODP-SD-03, ODP-SD-06, ODP-SD-08` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-004` | 所有服務必須輸出 Metrics、Logs、Traces 與必要 Business Events。 | `TARGET` | `SRC-ODP-ARCH` | SRE Owner | Observability acceptance | `ODP-SD-11` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-005` | 系統必須採最小權限、MFA、Service Account、Secret 管理、傳輸與靜態加密及完整 Audit。 | `COMMITMENT` | `SRC-ODP-PLAN` | Security Owner | Security test | `ODP-SD-09, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-006` | 個資必須具有目的限制、資料最小化、遮罩／去識別、保留期限、下載與刪除流程。 | `COMMITMENT` | `SRC-ODP-REVIEW` | Privacy Owner | Privacy review | `ODP-SD-09, ODP-QA-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-007` | Production 必須支援 Dev、Staging、Production 環境分離、CI/CD、IaC、Migration、Canary 與 Rollback。 | `TARGET` | `SRC-ODP-ARCH` | MLOps／Platform Owner | Pipeline acceptance | `ODP-SD-12, ODP-OPS-03` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-008` | 重要資料與服務必須具備明確 RPO／RTO、備份、還原與 DR 演練；最終數值由 NFR 文件核准。 | `TARGET` | `SRC-ODP-ARCH` | SRE Owner | Restore／DR test | `ODP-SA-08, ODP-OPS-05` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-009` | 外部資料或模型失效時必須有 Stale 標記、Fallback、Degraded Mode 或阻擋策略，不得靜默使用不可信結果。 | `TARGET` | `SRC-ODP-ARCH` | Service Owner | Failure injection | `ODP-SD-10, ODP-OPS-04` | `MUST` | `BASELINED-DRAFT` |
| `ODP-HLR-NFR-010` | 系統必須提供 CSV／JSON 匯出與版本化 API／資料字典，支援資料可攜與後續整合。 | `COMMITMENT` | `SRC-ODP-REVIEW` | Product Lead | Export＋API test | `ODP-SA-09, ODP-SD-06` | `MUST` | `BASELINED-DRAFT` |


## 9. 後續分解規則

第 2 批文件建立後，每個 HLR 必須至少連到：

- 一個 Business Objective 或 Use Case。
- 一個 Functional／Non-functional Requirement。
- 一個 Business Rule 或 Decision Policy（如適用）。
- 一個主要資料／模型／流程輸入。
- 一個驗收方法。

第 3–8 批完成後，每個 `MUST` HLR 必須至少連到：

```text
HLR
→ FR/NFR
→ Data/API/Event/Workflow/Model/Module Design
→ Test Case
→ Test Result / Model Report / Audit Evidence
→ Acceptance Record
```

## 10. 需求變更規則

- 修改 `COMMITMENT` 必須依 C5 Contractual Change 處理。
- 修改 HLR 語意、範圍、KPI 或驗收方式至少為 C3 Breaking Change。
- 新增相容需求可採 C2，但仍需 Owner、Source 與 Verification。
- Requirement 被 Deferred 時，必須記錄原因、風險、替代控制、Owner 與期限。
- Requirement 被 Retired 時，必須指出 Replacement ID 或正式 Scope Change。
- 不得刪除歷史 Requirement Row。

## 11. 覆蓋與缺口查詢

後續 CI／檢查腳本至少應能回答：

1. 哪些 `MUST` Requirement 尚無設計文件？
2. 哪些 Requirement 尚無 Test Case 或驗收證據？
3. 哪些 API／Event／資料表沒有來源 Requirement？
4. 哪些 `COMMITMENT` 尚未驗證 KPI？
5. 哪些 Requirement 的 Accountable Owner 尚未指派？
6. 哪些 Production 功能與 approved 文件版本不一致？
7. 哪些 Deviation 已逾期？

## 12. 本批待處理項目

| ID | 項目 | Owner | 解除條件 |
|---|---|---|---|
| `RTM-ACT-001` | 指定每個 Ownership 的實際人員／群組 | Executive／Program | `ODP-00-03` Assignment Register 完成 |
| `RTM-ACT-002` | 確認 ODay Plus 核定計畫書與正式契約的最終版本 | Program／Legal | Source Register 鎖版 |
| `RTM-ACT-003` | 確認 OpsBoard 商用 SLA 是否維持 99.5% 或另有更高承諾 | Business／SRE | `ODP-SA-08` 核准 |
| `RTM-ACT-004` | 確認 ODay G2 店型與版本 | Product／Operations | `ODP-DATA-04`／`ODP-SA-07` 核准 |
| `RTM-ACT-005` | 取得 IoT／內部資料實際 Schema、頻率與 Backfill 能力 | Data Owner | `ODP-DATA-02` 核准 |
| `RTM-ACT-006` | 確認 DealRoom 是否含公開媒合／交易功能 | Finance／Legal | Scope 或 Module Design 決議 |

## 13. 本文件完成條件

本文件可進入 `approved` 的最低條件：

1. 所有 HLR 的 Source、Accountable、Verification 與 Downstream Documents 已確認。
2. `COMMITMENT` KPI 已與正式核定來源逐項核對。
3. 沒有重複 Requirement ID。
4. 所有模組與跨域平台能力至少有一組 HLR。
5. 第 2 批 SA 文件建立時可直接以本矩陣作為分解入口。

## Change Log

| Version | Date | Change Class | Summary | Author | Approver |
|---|---|---|---|---|---|
| 0.1.0 | 2026-06-25 | C1 | 建立全平台 High-Level Requirements 與追蹤規則 | Product／QA | Pending |
