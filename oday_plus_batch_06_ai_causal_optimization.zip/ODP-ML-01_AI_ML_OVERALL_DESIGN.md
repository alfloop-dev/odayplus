---
doc_id: ODP-ML-01
title: "AI／ML 總體設計"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "ML Platform Owner / MLOps Owner"
approvers: "Product Owner / Data Owner / Model Owner / Architecture Owner / Security Owner / SRE Owner"
content_format: markdown
---


# AI／ML 總體設計

## 1. 文件目的

本文件定義 ODay Plus 全平台 AI／ML 能力的總體設計，涵蓋模型盤點、特徵與標籤治理、訓練、驗證、模型註冊、發布、推論、監控、回訓、回滾與稽核。ODay Plus 的模型不是孤立的 Notebook，也不是單次報表，而是嵌入「預測 → 決策 → 執行 → 驗證 → 回訓」閉環的正式生產能力。

本文件回答以下問題：

- 哪些模型屬於 Production Model，哪些只是分析或實驗模型。
- 模型如何取得 point-in-time correct 的訓練資料。
- 模型訓練、驗證、註冊、發布與回滾如何治理。
- 模型輸出如何進入 Decision Layer，但不直接取代人工核准。
- 模型監控如何同時涵蓋資料漂移、模型表現、商業結果與安全風險。
- 不同模組的模型如何共享 Feature、Label、Dataset Snapshot 與 Model Registry。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. AI／ML 設計原則

### 2.1 模型服務於業務問題，不服務於演算法展示

每一個模型必須先對應明確的業務問題，例如：

| 業務問題 | 對應模型類型 |
|---|---|
| 哪些區域值得優先展店 | External Demand、Format Fit、HeatZone Scoring |
| 某物件是否適合 ODay G2 | Site Revenue Path、Brand Transfer、Ramp／Seasonality |
| 新店是否達成原始預測 | SiteScore Realization Monitor |
| 門市未來 4／8／12／24 週如何發展 | Store Growth Forecaster |
| 是否出現結構性轉折或異常 | Change-point／Anomaly Detector |
| 價格調整是否有機會增加毛利 | Price Elasticity、Demand Simulation |
| 廣告是否真的帶來增量 | Ad Incrementality Estimator |
| 門市合理價值區間是多少 | Valuation Predictor、Liquidity Model |

不得為了使用深度學習、Bandit、MMM 或其他高階方法而建立無明確決策用途的模型。

### 2.2 Prediction、Decision、Execution 必須分離

模型輸出只能是 Prediction 或 Evidence，不得直接等同於最終業務決策。系統必須區分：

```text
Prediction Output
→ Decision Policy
→ Human Approval / Auto-approval Rule
→ Execution
→ Outcome
→ Label / Learning Feedback
```

例如：

- SiteScore 可輸出 P10／P50／P90、回本期、自家稀釋與 GO／WAIT／REJECT 建議。
- 真正開店仍需人工核准、現勘結果、租約條件、工程可行性與管理層決策。
- PriceOps 可輸出候選價格方案與預期毛利，但正式調價必須通過安全限制與人工核准。
- NetPlan 可輸出 OPEN／KEEP／IMPROVE／MOVE／EXIT 方案，但不得自動關店、遷點或簽約。

### 2.3 Point-in-time Correctness 是硬性要求

所有訓練資料與回測資料必須保證在模擬的 Decision Time 當下，模型只能看到當時已知的資訊。

必要時間欄位：

| 欄位 | 說明 |
|---|---|
| `event_time` | 事件實際發生時間 |
| `observation_time` | 系統觀察或收到資料的時間 |
| `feature_snapshot_time` | 特徵快照時間 |
| `prediction_origin_time` | 預測起點 |
| `decision_time` | 模型或人員做決策的時間 |
| `outcome_time` | 結果被觀察的時間 |
| `label_maturity_time` | 結果成熟且可訓練的時間 |

任何模型若無法證明 point-in-time correctness，不得進入 Production。

### 2.4 模型版本與資料版本必須共同追溯

每次模型輸出都必須至少記錄：

```yaml
prediction_id: string
model_name: string
model_version: string
model_alias: champion | challenger | shadow | canary | archived
feature_view_version: string
dataset_snapshot_id: string
feature_snapshot_time: timestamp
prediction_origin_time: timestamp
prediction_horizon: string
input_hash: string
output_hash: string
created_by: service-account
created_at: timestamp
```

若缺少上述追溯資訊，該輸出只能作為暫存分析，不得進入正式決策流程。

## 3. 模型盤點與責任歸屬

| 模型代碼 | 模型名稱 | 主要模組 | 主要 View | 輸出 | Serving Mode | Model Owner |
|---|---|---|---|---|---|---|
| ML-EXP-01 | External Demand Predictor | HeatZone、SiteScore | `geo_grid_view`、`candidate_site_view` | 區域需求分數、P10／P50／P90 | Batch | Expansion Model Owner |
| ML-EXP-02 | ODay Format Fit Predictor | HeatZone、SiteScore | `candidate_site_view`、`brand_transfer_view` | G2 店型適配分數 | Batch／Sync | Expansion Model Owner |
| ML-EXP-03 | Brand Transfer Estimator | SiteScore | `brand_transfer_view` | 跨品牌轉換係數與信心 | Batch | SiteScore Model Owner |
| ML-EXP-04 | Ramp & Seasonality Estimator | SiteScore、ForecastOps | `ramp_curve_view` | 店齡曲線、季節因子 | Batch | Forecast Model Owner |
| ML-EXP-05 | Site Revenue Path Predictor | SiteScore | `candidate_site_view` | M1／M3／M6／M12、P10／P50／P90 | Sync／Async | SiteScore Model Owner |
| ML-OPS-01 | Store Growth Forecaster | ForecastOps | `store_machine_timeseries_view`、`forecast_training_view` | 4／8／12／24 週預測區間 | Batch | Forecast Model Owner |
| ML-OPS-02 | Trajectory State Classifier | ForecastOps | `forecast_training_view` | Ramp／Growth／Plateau／Decline | Batch | Forecast Model Owner |
| ML-OPS-03 | Change-point & Anomaly Detector | ForecastOps | `store_machine_timeseries_view` | 轉折、異常、Residual Evidence | Batch／Event | Forecast Model Owner |
| ML-INT-01 | Price Elasticity Estimator | PriceOps | `pricing_action_view`、`intervention_panel_view` | 彈性、需求曲線、風險區間 | Batch | Pricing Model Owner |
| ML-INT-02 | Ad Incrementality Estimator | AdLift | `matched_control_view` | Incremental GM、iROMI、Evidence Level | Batch | Causal Model Owner |
| ML-AVM-01 | Valuation Predictor | DealRoomAVM | `valuation_view` | Fair／Reserve／Asking 區間 | Batch／Async | AVM Model Owner |
| ML-AVM-02 | Liquidity Survival Model | DealRoomAVM | `valuation_view` | 成交機率、成交週期 | Batch | AVM Model Owner |
| ML-NET-01 | Scenario Input Predictor | NetPlan | `network_plan_view` | Downside／Base／Upside 情境輸入 | Batch | NetPlan Model Owner |

## 4. AI／ML 架構

```mermaid
flowchart TB
  SRC[Canonical / Model-ready Views] --> DQ[Data Quality Gate]
  DQ --> SNAP[Dataset Snapshot Builder]
  SNAP --> TRAIN[Training Orchestrator]
  TRAIN --> EVAL[Backtesting / Validation]
  EVAL --> CARD[Model Card Builder]
  CARD --> REG[MLflow Model Registry]
  REG --> REL[Release Controller]
  REL --> BATCH[Batch Scoring Jobs]
  REL --> API[Model-serving API / Domain API]
  REL --> SHADOW[Shadow / Canary Worker]
  BATCH --> OUT[Prediction Store]
  API --> OUT
  SHADOW --> OUT
  OUT --> DEC[Decision Services]
  DEC --> LOG[Decision / Intervention Log]
  LOG --> LABEL[Label Registry]
  LABEL --> SNAP
  OUT --> MON[Model / Data / Business Monitor]
  MON --> REL
```

### 4.1 主要元件

| 元件 | 責任 | 建議實作 |
|---|---|---|
| Data Quality Gate | 阻擋不可用資料進入訓練或推論 | dbt tests、Great Expectations、自訂 SQL checks |
| Dataset Snapshot Builder | 建立可重現訓練資料集 | BigQuery snapshot table、Cloud Storage parquet |
| Training Orchestrator | 排程、參數、資源與訓練流程 | Vertex AI Pipelines／Cloud Run Jobs／Airflow 或 Dagster |
| Experiment Tracker | 記錄 run、parameter、metric、artifact | MLflow Tracking |
| Model Registry | 管理模型版本、alias、狀態 | MLflow Registry／Vertex Model Registry 對照 |
| Release Controller | 控制 Shadow／Canary／Production／Rollback | 自建 release service + Feature Flag |
| Prediction Store | 保存正式模型輸出 | BigQuery／Cloud SQL read model |
| Monitoring | 監控資料、模型與業務結果 | Evidently、Cloud Monitoring、dbt reports、custom metrics |

## 5. 資料生命週期

### 5.1 Dataset Snapshot

每次訓練必須建立不可變更的 Dataset Snapshot。

必要欄位：

```yaml
dataset_snapshot_id: string
source_view_names: list[string]
source_view_versions: list[string]
snapshot_query_hash: string
point_in_time_policy_id: string
train_start_time: timestamp
train_end_time: timestamp
label_cutoff_time: timestamp
created_at: timestamp
created_by: service-account
storage_uri: gs://...
row_count: integer
entity_count: integer
feature_count: integer
label_count: integer
quality_status: PASSED | WARNING | FAILED
```

### 5.2 Feature Contract

Feature Contract 必須明確定義：

- Feature 名稱、型別、單位與粒度。
- 來源 Canonical table 或 Model-ready View。
- 是否為 Static、Time-varying、Treatment、Outcome、Post-treatment。
- 可使用的模型清單。
- 最早可用時間與更新頻率。
- 缺值處理與品質門檻。
- 是否含個資或敏感資訊。

### 5.3 Label Maturity

任何 Outcome 不能在剛產生時立即作為穩定標籤。Label 必須經過成熟期，例如：

| Label 類型 | 成熟條件 |
|---|---|
| 新店 M1／M3／M6／M12 實績 | 該月交易、退款、補登與設備資料完成結算 |
| 預警後 14 天恢復結果 | 觀察窗口結束且成本、維修、客服資料到齊 |
| 廣告增量 GM | 投放期、觀察期與交易延遲結算完成 |
| 估值成交價 | 交易完成或撤案原因確認 |
| NetPlan Outcome | 90／180／365 日結果成熟 |

## 6. 訓練設計

### 6.1 Training Job 類型

| 類型 | 用途 | 頻率 | 觸發條件 |
|---|---|---|---|
| Scheduled Retraining | 固定更新模型 | 月／季 | 排程 |
| Event-triggered Retraining | 資料或環境重大變化 | 不固定 | 漂移、模型退化、業務變更 |
| Backtest Run | 回測候選模型 | 每次候選模型發布前 | Pull Request／Model Review |
| Challenger Training | 建立新模型候選 | 依研發節奏 | Model Owner 提案 |
| Emergency Refit | 嚴重資料或模型錯誤修復 | 例外 | Incident Review 核准 |

### 6.2 訓練資源配置

| 模型族群 | 資源需求 | 執行環境 |
|---|---|---|
| Tabular GBDT | CPU、中記憶體 | Vertex AI Custom Job／Cloud Run Job |
| Forecast Baseline | CPU | Cloud Run Job |
| Deep Forecast Challenger | GPU 可選 | Vertex AI Custom Job |
| Causal Matching／DiD | CPU、高記憶體 | Cloud Run Job／Vertex AI |
| Bayesian MMM | CPU／高記憶體／長時間 | Vertex AI Custom Job |
| OR Solver | CPU、多核心、長時間 | Cloud Run Job／GKE Job |

### 6.3 訓練不得直接覆蓋 Production

訓練完成後，只能產生 `candidate` 版本。進入 Production 必須經過：

1. Data Quality Gate passed。
2. Backtesting passed。
3. Segment Performance passed。
4. Calibration passed。
5. Model Card completed。
6. Security／Privacy review passed。
7. Model Review Board approved。
8. Shadow 或 Canary passed。
9. Release Controller promote。

## 7. 模型發布與回滾

### 7.1 Model Alias

| Alias | 說明 |
|---|---|
| `dev` | 研發中，不可被正式流程呼叫 |
| `candidate` | 完成訓練但未完成驗證 |
| `validated` | 通過離線驗證，可進入 Shadow |
| `shadow` | 線上影子推論，不影響決策 |
| `canary` | 小範圍正式使用 |
| `champion` | 正式 Production 模型 |
| `challenger` | 與 Champion 並行比較 |
| `retired` | 已退役，不得新推論 |
| `blocked` | 因資料、風險或事故禁止使用 |

### 7.2 Release Policy

模型發布必須產生 `model_release_decision`：

```yaml
release_id: string
model_name: string
from_version: string
to_version: string
release_type: SHADOW | CANARY | FULL | ROLLBACK
reason: string
approval_id: string
rollback_plan: string
monitoring_window: string
success_criteria: list[string]
fail_criteria: list[string]
```

### 7.3 Rollback 條件

任一條件成立時，必須進入回滾評估：

- 線上資料品質失敗且影響 Production 推論。
- P95 延遲超過 SLO 且無法降級。
- 預測分布出現未解釋劇烈漂移。
- 模型建議導致高風險動作 Hard Constraint 違反。
- Canary 群組表現顯著劣於 Champion。
- 人工覆核發現嚴重不可解釋或違反業務常識。
- 個資、資安或資料授權疑慮。

## 8. 推論與輸出設計

### 8.1 推論模式

| 模式 | 適用模型 | 設計原則 |
|---|---|---|
| Batch Scoring | HeatZone、ForecastOps、AVM、NetPlan input | 排程產生結果，前端查詢已完成資料 |
| Sync API | 單點 SiteScore、單店快速查詢 | 必須低延遲，僅允許使用已建好的特徵 |
| Async Job | 報告、Comparable、估值卡、Scenario | API 建 job，Worker 執行，完成後通知 |
| Shadow Scoring | 新模型線上比較 | 不影響決策，只保存比較結果 |
| Canary Scoring | 小範圍正式決策 | 必須可隨時切回 Champion |

### 8.2 Prediction Output Envelope

所有模型輸出必須包裝為共用 Envelope：

```yaml
prediction_id: string
entity_type: STORE | SITE | GEO_CELL | CAMPAIGN | PRICE_ACTION | NETWORK_PLAN
entity_id: string
model_name: string
model_version: string
model_alias: string
feature_snapshot_time: timestamp
prediction_origin_time: timestamp
horizon: string
point_estimate: number | object
quantiles: object
confidence: number
explanations: list[object]
warnings: list[string]
policy_ready: boolean
created_at: timestamp
```

`policy_ready = false` 的輸出只能顯示給 AI／資料團隊，不得進入 Decision Policy。

## 9. 監控設計

### 9.1 監控面向

| 類別 | 指標 |
|---|---|
| Data Quality | completeness、freshness、validity、uniqueness、coverage、outlier rate |
| Data Drift | PSI、KS、embedding drift、geographic coverage drift |
| Prediction Drift | prediction distribution、quantile width、class ratio、alert volume |
| Model Performance | MAPE、MAE、RMSE、Coverage、Calibration、Precision／Recall、iROMI error |
| Decision Quality | adoption rate、override rate、hard constraint violation、approval rejection reason |
| Business Outcome | realization ratio、incremental GM、recovery rate、valuation coverage、NetPlan outcome |
| Technical | latency、error rate、job failure rate、resource cost、retries、dead letters |
| Governance | missing model card、missing approval、expired model、unmatured label usage |

### 9.2 監控分級

| 等級 | 說明 | 行動 |
|---|---|---|
| INFO | 正常波動 | 記錄 |
| WATCH | 有趨勢但未超門檻 | Model Owner 檢視 |
| WARNING | 影響部分輸出可信度 | 暫停高風險自動化或要求人工覆核 |
| CRITICAL | 影響正式決策安全 | Block model／Rollback／Incident |

## 10. 模型治理會議

### 10.1 Model Review Board

參與角色：

- Model Owner
- Data Owner
- Product Owner
- Domain Owner
- Security Owner
- SRE Owner
- Independent Reviewer

核准事項：

- 新模型進入 Shadow／Canary／Champion。
- 高風險模型參數或特徵大幅變更。
- 使用新資料來源或敏感資料。
- 啟用 Bandit、Uplift、MMM、Robust Optimization 等高階能力。
- Production 模型 Rollback 或 Block。

### 10.2 禁止同人兼任

同一人不得同時擔任：

- 高風險模型主要開發者。
- 該模型獨立驗證者。
- 該模型最終 Production 核准者。

若人力不足需例外，必須有 ADR 與 Deviation Approval。

## 11. 安全與隱私

AI／ML 流程必須遵守：

- 最小權限 Service Account。
- 訓練資料與模型 Artifact 分權管理。
- 個資欄位不得直接進模型，除非有明確合法目的、遮罩或轉換規則。
- 模型輸出不得洩漏單一會員、單一交易或不可公開之營運秘密。
- Prompt、LLM 或外部 API 不得接收未授權之敏感資料。
- 所有模型輸出與人工 Override 必須留痕。

## 12. 驗收條件

| 編號 | 驗收項目 | 驗收標準 |
|---|---|---|
| ML-GATE-001 | 模型盤點完整 | 所有 Production candidate 模型列入 Registry 與 Ownership |
| ML-GATE-002 | Dataset 可重現 | 任一 Production 模型可重建訓練資料與查詢 hash |
| ML-GATE-003 | Point-in-time correctness | 回測資料不得含 decision_time 後資訊 |
| ML-GATE-004 | Model Card | Production 模型 100% 有 Model Card |
| ML-GATE-005 | Release Flow | Shadow／Canary／Rollback 流程可演練 |
| ML-GATE-006 | Prediction Trace | 100% 正式 prediction 可追溯 model、feature、dataset、時間與輸入 |
| ML-GATE-007 | Monitoring | Data／Model／Business／Technical 指標可於 OpsBoard 或監控介面查詢 |
| ML-GATE-008 | Governance | 高風險模型發布具人工核准與稽核紀錄 |

## 13. 待決策事項

| 編號 | 議題 | 預設決策 | 需核准角色 |
|---|---|---|---|
| ADR-ML-001 | Vertex AI Registry 與 MLflow Registry 是否雙軌 | 以 MLflow 為邏輯 Registry，Vertex AI 做部署對照 | Architecture Owner |
| ADR-ML-002 | Feast 是否第一版導入 | 暫不導入，保留 Feature Store 介面 | Data Owner |
| ADR-ML-003 | Deep Forecast 是否可上 Production | 僅作 Challenger，需穩定優於 MLForecast Champion | Model Review Board |
| ADR-ML-004 | Bandit 啟用條件 | Propensity、Reward、Safety、OPE 完整後才啟用 | Product + Model Review Board |
