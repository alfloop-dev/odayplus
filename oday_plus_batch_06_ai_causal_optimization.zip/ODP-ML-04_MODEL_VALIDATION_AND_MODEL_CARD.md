---
doc_id: ODP-ML-04
title: "模型驗證與 Model Card 設計"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Model Validation Owner / Independent Reviewer"
approvers: "Product Owner / Data Owner / Model Owner / Architecture Owner / Security Owner / SRE Owner"
content_format: markdown
---


# 模型驗證與 Model Card 設計

## 1. 文件目的

本文件定義 ODay Plus 的模型驗證方法、上線門檻、Model Card 格式、模型風險分級、回測規則、區間校準、Segment 檢查、決策驗證、發布核准與回滾條件。ODay Plus 的風險不只在「模型準不準」，也在「模型輸出是否被安全地轉成決策」。因此本文件同時規範 Model Validation 與 Decision Validation。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 驗證原則

### 2.1 模型準確不等於決策正確

例如：

- SiteScore M6 MAPE 很低，但若高估回本期安全性，仍可能導致不良展店。
- ForecastOps 預測營收準確，但若四燈政策造成大量誤報，營運團隊無法承擔。
- AdLift ROAS 看起來高，但若沒有對照組，可能只是自然旺季。
- AVM MAPE 合格，但 Reserve Price 不合理，仍會造成交易失敗。
- NetPlan objective 高，但若違反租約、人力或施工限制，方案不可執行。

因此驗證必須分成：

```text
Data Validation
→ Model Validation
→ Calibration Validation
→ Segment Validation
→ Decision Policy Validation
→ Human Review Validation
→ Online Outcome Validation
```

### 2.2 所有驗證必須可重現

每次驗證必須保存：

- Dataset Snapshot ID。
- Feature Set ID。
- Label Set ID。
- Model Version。
- Validation Code Version。
- Metrics。
- 圖表與報告。
- Reviewer。
- Approval Decision。

## 3. 模型風險分級

| 風險等級 | 說明 | 範例 | 治理要求 |
|---|---|---|---|
| R1 低風險 | 僅供分析，不直接影響決策 | 地圖輔助標示 | Basic Model Card |
| R2 中風險 | 影響排序或提示，但需人工判斷 | Listing Rank、Root Cause Candidate | Backtest + Owner Approval |
| R3 高風險 | 影響投資、調價、廣告、估值或退出建議 | SiteScore、ForecastOps、PriceOps、AdLift、AVM、NetPlan input | Full Validation + Model Review Board |
| R4 極高風險 | 可能自動觸發財務或客戶影響動作 | 自動調價、Bandit、自動停投、自動退出建議 | Independent Review + Canary + Kill Switch |

第一版所有涉及調價、廣告加碼、退店、估值與 NetPlan 的模型均至少視為 R3。

## 4. 資料驗證

### 4.1 Data Validation Checklist

| 項目 | 檢查方式 | 阻擋條件 |
|---|---|---|
| Schema | 欄位、型別、必要欄位 | 缺必要欄位 |
| Freshness | 最新 `observation_time` | 超過模型容忍延遲 |
| Completeness | 缺值率 | 高於 Feature Contract 門檻 |
| Uniqueness | Entity key 唯一性 | 主鍵重複 |
| Validity | 值域、單位、負值、異常 | 違反硬規則 |
| Coverage | 地區、門市、時間覆蓋 | 低於訓練最低要求 |
| Time Leakage | 是否使用 decision_time 後資料 | 任何洩漏即阻擋 |
| Treatment Marking | 干預是否標記 | 高風險模型中未標記即阻擋 |

### 4.2 Data Validation Output

```yaml
validation_run_id: string
dataset_snapshot_id: string
status: PASSED | WARNING | FAILED
failed_rules: list[object]
affected_entities: list[string]
blocked_models: list[string]
created_at: timestamp
```

## 5. 回測設計

### 5.1 Backtesting 方法

| 模型類型 | 回測方式 |
|---|---|
| SiteScore | 以歷史開店 decision_time 模擬當時評分，再比對 M1／M3／M6／M12 |
| ForecastOps | Rolling-origin backtest by store and horizon |
| Trajectory Classifier | Historical incident replay and human-labeled state comparison |
| Change-point | Known incident replay and false alert burden analysis |
| PriceOps | Historical price change panel and pilot replay |
| AdLift | Historical campaign with matched controls and pre-trend test |
| AVM | Historical valuation vs sale price／withdrawn case comparison |
| NetPlan | Historical planning simulation vs status quo／greedy baseline |

### 5.2 Rolling-Origin 設計

Forecast 類模型必須使用 rolling-origin，而不是單一 train/test split：

```text
Train: T0 ~ T1 → Validate: T1+1 ~ T1+H
Train: T0 ~ T2 → Validate: T2+1 ~ T2+H
Train: T0 ~ T3 → Validate: T3+1 ~ T3+H
```

每個 horizon 需分別計算指標。

## 6. 指標規格

### 6.1 Regression／Revenue Prediction

| 指標 | 用途 |
|---|---|
| MAE | 絕對誤差 |
| MAPE／sMAPE | 相對誤差 |
| RMSE | 大誤差懲罰 |
| Bias | 系統性高估或低估 |
| Segment MAPE | 分群表現 |
| Realization Ratio | 預測 vs 實績比例 |

### 6.2 Quantile／Interval

| 指標 | 用途 |
|---|---|
| P80 Coverage | 80% 區間是否包含實際值 |
| P90 Coverage | 90% 區間是否包含實際值 |
| Interval Width | 區間是否過寬或過窄 |
| Pinball Loss | 分位數預測品質 |
| Calibration Curve | 分位數校準 |

### 6.3 Classification／Alert

| 指標 | 用途 |
|---|---|
| Precision | 警示準確度 |
| Recall | 異常捕捉能力 |
| F1 | 平衡指標 |
| Lead Time | 提前預警時間 |
| Alert Burden | 每日／每週警示量 |
| False Positive Cost | 誤報造成的人力成本 |
| False Negative Cost | 漏報造成的營運損失 |

### 6.4 Causal／Intervention

| 指標 | 用途 |
|---|---|
| Pre-trend Test | 對照組合理性 |
| Balance Metrics | 實驗店與對照店是否可比 |
| Incremental Revenue | 增量營收 |
| Incremental GM | 增量毛利 |
| iROMI | 增量毛利／廣告成本 |
| Confidence Interval | 效果不確定性 |
| Evidence Level | 因果證據等級 |

### 6.5 Optimization

| 指標 | 用途 |
|---|---|
| Objective Value | 方案目標值 |
| Feasibility | 是否滿足硬限制 |
| Constraint Violation Count | 違反限制數 |
| Solve Time | 求解時間 |
| Gap | 最佳化 gap |
| Status | OPTIMAL／FEASIBLE／INFEASIBLE／TIME_LIMIT |
| Outcome Lift | 方案實施後改善 |

## 7. Segment Validation

所有 Production 模型都必須按 Segment 檢查。

### 7.1 基本 Segment

- 區域：北／中／南／東／離島。
- 商圈型態：住宅、學區、科技園區、商辦、市場、新興重劃區。
- 店齡：0–1 月、2–3 月、4–6 月、7–12 月、成熟店。
- 品牌：ODay、洗多屋、其他跨品牌。
- 店型：G2、非 G2、其他配置。
- 設備：大機、中機、設備品牌、容量。
- 資料品質：高／中／低信心。

### 7.2 Segment Fail Handling

若整體指標達標但某重要 Segment 失敗，必須採取以下之一：

1. 限制模型適用範圍。
2. 對該 Segment 使用 Baseline 或上一版模型。
3. 降低輸出 confidence。
4. 要求人工覆核。
5. 延後上線並補充資料。

不得以整體平均掩蓋關鍵 Segment 退化。

## 8. Decision Validation

### 8.1 SiteScore Decision Validation

| 項目 | 驗證方式 |
|---|---|
| GO 決策品質 | GO 店 M3／M6 Realization Ratio |
| REJECT 決策合理性 | 抽樣檢查是否錯失高潛力點 |
| WAIT 決策後續 | WAIT 原因是否可被後續資料解除 |
| Feasibility | 硬性條件違反率 = 0 |
| 人工覆核 | Override 原因與最終結果 |

### 8.2 ForecastOps Alert Validation

| 項目 | 驗證方式 |
|---|---|
| 橙／紅燈 Precision | 實際異常或營運問題比率 |
| Recall | 已知事故是否被提前捕捉 |
| Lead Time | 預警比人工發現提前天數 |
| Alert Burden | 營運團隊每日可承擔量 |
| Recovery Link | 警示後處置是否改善 |

### 8.3 PriceOps Decision Validation

| 項目 | 驗證方式 |
|---|---|
| Hard Constraint | 不得低於毛利底線、不得超出價格安全區間 |
| Pilot Result | 小範圍調價後 GM 是否未顯著惡化 |
| Customer Impact | 客訴、回訪、使用率是否異常 |
| Rollback | 調價方案可回復 |

### 8.4 NetPlan Decision Validation

| 項目 | 驗證方式 |
|---|---|
| Feasibility | 硬限制 100% 滿足 |
| Alternative Plan | 至少輸出可比較替代方案 |
| Infeasibility Diagnosis | 無可行解時必須說明衝突限制 |
| Outcome | 90／180／365 日結果回收 |

## 9. Model Card 格式

### 9.1 Model Card 必填欄位

```yaml
model_card_id: string
model_name: string
model_version: string
model_owner: string
business_owner: string
risk_level: R1 | R2 | R3 | R4
intended_use: string
not_intended_use: string
entity_grain: string
prediction_horizon: string
training_dataset_snapshot_id: string
feature_set_id: string
label_set_id: string
training_period: string
validation_period: string
algorithm: string
baseline: string
metrics_summary: object
segment_metrics: list[object]
calibration_summary: object
explainability_method: string
limitations: list[string]
known_biases: list[string]
privacy_review: PASSED | WARNING | FAILED
security_review: PASSED | WARNING | FAILED
release_status: DEV | SHADOW | CANARY | CHAMPION | RETIRED | BLOCKED
rollback_condition: list[string]
approvals: list[object]
created_at: timestamp
```

### 9.2 Model Card 範例摘要

```yaml
model_name: store_growth_forecaster
model_version: 1.4.0
risk_level: R3
intended_use: "產生 ODay 門市未來 4/8/12/24 週營收區間與四燈輸入"
not_intended_use: "不得直接作為關店、調價或廣告投放的最終決策"
baseline: seasonal_naive_v1
metrics_summary:
  w4_smape: 0.118
  w8_smape: 0.142
  p80_coverage: 0.812
release_status: canary
rollback_condition:
  - "p80_coverage < 0.75 for 2 consecutive monitoring windows"
  - "red_alert_precision drops below approved threshold"
```

## 10. Model Review 流程

```mermaid
flowchart LR
  DEV[Model Owner submits candidate] --> DQ[Data Validation]
  DQ --> BT[Backtest]
  BT --> SEG[Segment Validation]
  SEG --> CAL[Calibration]
  CAL --> CARD[Model Card]
  CARD --> SEC[Security / Privacy Review]
  SEC --> MRB[Model Review Board]
  MRB --> SHADOW[Shadow]
  SHADOW --> CANARY[Canary]
  CANARY --> PROD[Champion]
```

## 11. 回滾與封鎖

### 11.1 Rollback

Rollback 是切回前一個已核准 Production 模型。

觸發條件：

- 線上指標連續兩個監控窗口低於門檻。
- Data Quality Fail 影響推論。
- Canary 造成高風險決策異常。
- 模型輸出明顯不可解釋。
- 事故會議要求回滾。

### 11.2 Block

Block 是禁止某模型版本被任何正式流程使用。

Block 條件：

- 發現資料洩漏。
- 發現使用未授權資料或個資。
- 模型 artifact 被污染或不可信。
- 模型違反 Hard Constraint 或法規要求。
- Model Card 或核准紀錄造假或缺漏。

## 12. 驗證 Artifact

每次模型驗證必須產生：

- `validation_report.md`
- metrics JSON
- segment metrics CSV／Parquet
- calibration plot
- feature importance／SHAP artifact
- model card YAML／MD
- approval record
- rollback plan

所有 Artifact 必須保存於：

```text
gs://<project-artifacts>/models/<model_name>/<model_version>/validation/
```

## 13. 驗收條件

| 編號 | 驗收項目 | 標準 |
|---|---|---|
| MV-001 | Model Card 完整 | Production 模型 100% 有完整 Model Card |
| MV-002 | Backtest 可重現 | 任一 Production model 可重跑回測 |
| MV-003 | Segment Validation | 高風險模型皆完成 Segment 檢查 |
| MV-004 | Calibration | 所有輸出區間模型皆有 coverage 報告 |
| MV-005 | Decision Validation | 高風險模型有 Decision Policy 驗證 |
| MV-006 | Review Board | R3／R4 模型皆有核准紀錄 |
| MV-007 | Rollback Drill | 至少完成一次模型回滾演練 |
| MV-008 | Evidence Archive | 驗證報告與 Artifact 可由 Audit 查詢 |
