---
doc_id: ODP-ML-03
title: "模型規格書"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Model Owners Council"
approvers: "Product Owner / Data Owner / Model Owner / Architecture Owner / Security Owner / SRE Owner"
content_format: markdown
---


# 模型規格書

## 1. 文件目的

本文件定義 ODay Plus 全平台主要模型的規格，包含模型目標、輸入、Target、輸出、候選演算法、Baseline、訓練頻率、推論模式、評估指標、限制與驗收條件。本文件不是模型研究報告，而是供工程、資料、產品、QA、治理與實作 LLM 使用的模型契約。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 模型規格共用模板

每個模型必須至少定義：

| 欄位 | 說明 |
|---|---|
| Model ID | 全平台唯一代碼 |
| Model Name | 模型名稱 |
| Business Question | 回答的業務問題 |
| Owner | 模型責任人 |
| Entity Grain | 模型分析粒度 |
| Prediction Horizon | 預測期間 |
| Input Views | 使用的 Model-ready Views |
| Feature Set | Feature Set ID |
| Target／Label | Label Set ID 或目標定義 |
| Output | 模型輸出結構 |
| Baseline | 必須打敗的基準模型 |
| Candidate Algorithms | 候選方法 |
| Metrics | 驗證指標 |
| Serving Mode | Batch／Sync／Async／Shadow |
| Retraining | 回訓頻率與觸發條件 |
| Known Risks | 已知風險 |
| Acceptance Gate | 進 Production 條件 |

## 3. ML-EXP-01 External Demand Predictor

### 3.1 業務問題

估計每個 H3 格網、生活圈或候選點附近的外部洗衣需求底盤，不直接等同於 ODay 可取得營收。

### 3.2 分析粒度

| 項目 | 設定 |
|---|---|
| Entity | `geo_cell` 或 `candidate_site` |
| Horizon | 月度需求／成熟需求潛力 |
| Serving | Batch，以週或月為主 |

### 3.3 Input Views

- `geo_grid_view`
- `candidate_site_view`
- `store_machine_timeseries_view` 的去品牌化歷史需求摘要

### 3.4 Feature 類型

- 人口、戶數、租屋、學生、白天／夜間人口。
- POI 組成、商圈類型、道路與可達性。
- 競店數、競店距離、競店容量。
- 區域租金、租金分位。
- 天氣、季節、學期、節假日等區域性條件。
- 資料品質、覆蓋率與信心。

### 3.5 Target

可使用跨品牌歷史門市營收、設備容量、店齡與品牌條件反推 Latent External Demand。Target 必須排除或控制品牌捕獲、店型配置與干預效果。

### 3.6 Output

```yaml
external_demand_score: number
external_demand_p10: number
external_demand_p50: number
external_demand_p90: number
demand_drivers: list[object]
coverage_confidence: number
applicable_radius: string
```

### 3.7 Baseline 與候選演算法

| 類型 | 方法 |
|---|---|
| Baseline | 透明加權分數、人口密度排序、POI 加權 |
| Champion Candidate | CatBoost／LightGBM |
| Challenger | Spatial regression、Hierarchical Bayesian、Graph features |

### 3.8 Metrics

- Holdout MAPE／MAE。
- Top-K 熱區命中率。
- 排序 NDCG／Spearman。
- 分區 Segment Performance。
- P80／P90 Coverage。
- 業務可解釋性評分。

### 3.9 驗收條件

- Top-K 熱區排序必須優於人口排序與人工 Baseline。
- 不得把 ODay 品牌能力誤當作區域外部需求。
- 每個分數必須附 confidence、source coverage 與主要因子。

## 4. ML-EXP-02 ODay Format Fit Predictor

### 4.1 業務問題

判斷 ODay G2 固定配置（3 大 3 中洗脫烘一體機）是否適合該區位與物件條件。

### 4.2 Input Views

- `candidate_site_view`
- `brand_transfer_view`
- `store_machine_timeseries_view`

### 4.3 Feature 類型

- 物件坪數、面寬、深度、樓層、角間、停車、臨停。
- 電力、排水、瓦斯、通風、建築限制。
- 區位需求型態，例如學生租屋、家庭住宅、商辦、科技園區。
- 設備容量需求分布。

### 4.4 Output

```yaml
format_fit_score: number
format_fit_class: HIGH | MEDIUM | LOW | INFEASIBLE
capacity_match_score: number
feasibility_warnings: list[string]
```

### 4.5 演算法

- Hard rules + GBDT 分數。
- 初期以規則與透明加權為主。
- 後續使用相似店型與容量利用率建立模型。

### 4.6 驗收條件

- 電力、排水、坪數等硬性條件不符合時，必須輸出 `INFEASIBLE`，不得因預測營收高而輸出 GO。
- Fit Score 必須可拆解為 Capacity、Access、Visibility、Utility、Demand Match。

## 5. ML-EXP-03 Brand Transfer Estimator

### 5.1 業務問題

將跨品牌歷史營收轉換為 ODay 品牌在相同區位、店型、設備與店齡下可實現的營收能力。

### 5.2 分析單位

```text
source_brand × target_brand × location_type × format_type × store_age_bucket × time_version
```

### 5.3 Input Views

- `brand_transfer_view`
- `ramp_curve_view`
- `store_machine_timeseries_view`

### 5.4 Target

品牌轉換係數：

```text
TransferRatio = ODay_Normalized_Revenue / SourceBrand_Normalized_Revenue
```

必須先控制設備配置、店齡、季節、干預與容量上限。

### 5.5 Output

```yaml
transfer_ratio_p10: number
transfer_ratio_p50: number
transfer_ratio_p90: number
sample_size: integer
shrinkage_level: string
confidence: number
applicable_conditions: object
```

### 5.6 演算法

- v1：固定 ODay calibration ratio + segment adjustment。
- v2：Hierarchical partial pooling。
- v3：Bayesian hierarchical model。

### 5.7 Metrics

- ODay holdout error。
- Segment calibration。
- Small sample stability。
- Realization Ratio improvement。

### 5.8 驗收條件

- 不得使用全台單一永久倍率作為 Production 長期方案。
- 樣本不足時必須回退到上層 segment，不得輸出過度極端係數。

## 6. ML-EXP-04 Ramp & Seasonality Estimator

### 6.1 業務問題

估計新店從開幕到成熟的爬坡曲線，以及月份、天氣、學期與節假日對營收的影響。

### 6.2 Input Views

- `ramp_curve_view`
- `store_machine_timeseries_view`
- `forecast_training_view`

### 6.3 Output

```yaml
ramp_curve: list[object]
month_factor: object
holiday_factor: object
weather_factor: object
mature_month_estimate: integer
confidence: number
```

### 6.4 演算法

- Cohort average baseline。
- GAM／GBDT。
- Hierarchical curve by location type and format。
- Forecast model derived seasonal decomposition。

### 6.5 驗收條件

- 必須區分新店爬坡與成熟店季節性。
- 不得把開幕促銷造成的短期高峰當作自然 Ramp。

## 7. ML-EXP-05 Site Revenue Path Predictor

### 7.1 業務問題

預測候選物件若開 ODay G2，M1／M3／M6／M12 與成熟期營收路徑、預測區間與回本期。

### 7.2 Input Views

- `candidate_site_view`
- `geo_grid_view`
- `brand_transfer_view`
- `ramp_curve_view`

### 7.3 Output

```yaml
revenue_path:
  m1: {p10: number, p50: number, p90: number}
  m3: {p10: number, p50: number, p90: number}
  m6: {p10: number, p50: number, p90: number}
  m12: {p10: number, p50: number, p90: number}
  mature: {p10: number, p50: number, p90: number}
payback_months_p50: number
rent_affordability: PASS | WATCH | FAIL
cannibalization_risk: LOW | MEDIUM | HIGH
recommendation_candidate: GO | WAIT | REJECT | INVESTIGATE
explanations: list[object]
```

### 7.4 Baseline 與候選演算法

| 階段 | 方法 |
|---|---|
| v1 | External Demand × Fixed ODay Ratio × Simplified Ramp |
| v2 | CatBoost／LightGBM quantile model + conformal calibration |
| v3 | Ensemble with comparable stores and hierarchical transfer |

### 7.5 Metrics

- M3／M6／M12 MAPE。
- P80／P90 Coverage。
- Calibration curve。
- GO 決策實現率。
- Realization Ratio 分布。

### 7.6 驗收條件

- 必須輸出區間，不得只輸出單點營收。
- 必須提供租金合理性、Feasibility、稀釋與主要因子。
- 新店實績必須回收，形成 Realization Feedback。

## 8. ML-OPS-01 Store Growth Forecaster

### 8.1 業務問題

預測每家 ODay 門市未來 4／8／12／24 週的營收、毛利與成長軌跡。

### 8.2 Input Views

- `store_machine_timeseries_view`
- `forecast_training_view`
- `sitescore_realization_view`

### 8.3 Feature 類型

- Lag 1／7／14／28。
- Rolling mean／median／volatility。
- 店齡與 Ramp。
- 價格、廣告、促銷、故障、維修、清潔。
- 天氣、假日、學期、競店。
- SiteScore predicted path。

### 8.4 Output

```yaml
forecast_horizons:
  w4: {p10: number, p50: number, p90: number}
  w8: {p10: number, p50: number, p90: number}
  w12: {p10: number, p50: number, p90: number}
  w24: {p10: number, p50: number, p90: number}
site_score_gap: number
forecast_confidence: number
```

### 8.5 演算法

- Seasonal Naive。
- StatsForecast AutoARIMA／AutoETS／MSTL。
- MLForecast + CatBoost／LightGBM。
- Deep Challenger：TFT／N-BEATSx／LSTM，僅在資料成熟後挑戰。
- Quantile／Conformal calibration。

### 8.6 Metrics

- sMAPE／MAE by horizon。
- Weighted interval score。
- Coverage。
- New store segment 與 mature store segment 表現。
- Alert lead time。

### 8.7 驗收條件

- 核心 horizon 必須優於 Seasonal Naive。
- 區間 Coverage 必須達標。
- 不得因追求整體準確而犧牲新店與紅燈門市識別。

## 9. ML-OPS-02 Trajectory State Classifier

### 9.1 業務問題

判斷門市目前處於爬坡、成長、成熟平台、緩慢轉弱或結構性衰退。

### 9.2 Output

```yaml
trajectory_class: RAMPING | ACCELERATING | STABLE_GROWTH | PLATEAU | SOFT_DECLINE | STRUCTURAL_DECLINE
class_probabilities: object
plateau_probability: number
decline_probability: number
transition_evidence: list[object]
```

### 9.3 演算法

- Rule-based baseline：Growth slope、acceleration、SiteScore realization。
- GBDT classifier。
- Sequence classifier。
- Hidden state／HMM challenger。

### 9.4 Metrics

- Macro F1。
- Precision／Recall for decline classes。
- Early detection lead time。
- Human review agreement。

### 9.5 驗收條件

- 橙／紅燈相關類別 Precision 與 Recall 必須達到營運團隊可承擔水準。
- 模型需輸出 Evidence，不得只輸出分類。

## 10. ML-OPS-03 Change-point & Anomaly Detector

### 10.1 業務問題

偵測營收、毛利、成本、設備與客服指標是否出現結構性轉折或異常。

### 10.2 Output

```yaml
anomaly_score: number
change_point_probability: number
anomaly_type: REVENUE | COST | EQUIPMENT | CUSTOMER_EXPERIENCE | EXTERNAL | MIXED
evidence_window: string
root_cause_candidates: list[object]
```

### 10.3 演算法

- CUSUM／EWMA。
- ruptures offline change-point。
- Residual-based anomaly。
- Multivariate anomaly detection。

### 10.4 Metrics

- Alert precision。
- Recall for known incidents。
- Median lead time。
- False alert burden。
- Post-feedback improvement。

### 10.5 驗收條件

- 警示量必須符合營運團隊處理容量。
- 每個紅／橙燈必須保留 Evidence Vector。

## 11. ML-INT-01 Price Elasticity Estimator

### 11.1 業務問題

估計不同門市、設備、時段與客群對價格變動的需求反應，供 PriceOps 模擬與最佳化。

### 11.2 Input Views

- `pricing_action_view`
- `intervention_panel_view`
- `store_machine_timeseries_view`

### 11.3 Output

```yaml
elasticity_estimate: number
elasticity_p10: number
elasticity_p50: number
elasticity_p90: number
demand_curve: list[object]
valid_price_range: object
risk_flags: list[string]
```

### 11.4 方法

- Log-log demand baseline。
- Panel regression with fixed effects。
- Double ML／causal forest challenger。
- Bayesian hierarchical elasticity for small samples。

### 11.5 Metrics

- Out-of-sample demand prediction。
- Price pilot realized GM。
- Constraint violation = 0。
- Negative impact detection。

### 11.6 驗收條件

- 未通過安全限制的價格方案不得進入 Optimizer。
- 小樣本或重疊干預時必須降低 Evidence Level。

## 12. ML-INT-02 Ad Incrementality Estimator

### 12.1 業務問題

估計廣告是否帶來增量營收與增量毛利，而不是只看投放前後差異或 ROAS。

### 12.2 Input Views

- `matched_control_view`
- `intervention_panel_view`
- `forecast_training_view`

### 12.3 Output

```yaml
incremental_revenue: number
incremental_gross_margin: number
iromi: number
effect_p10: number
effect_p50: number
effect_p90: number
evidence_level: L0 | L1 | L2 | L3 | L4 | L5
pretrend_status: PASS | FAIL | INCONCLUSIVE
recommendation: CONTINUE | STOP | SCALE | CHANGE_CHANNEL | INCONCLUSIVE
```

### 12.4 方法

- Matched Controls。
- Difference-in-Differences。
- Synthetic Control。
- Uplift／CATE challenger。
- Bayesian MMM 於多渠道、長時間資料成熟後導入。

### 12.5 驗收條件

- Pre-trend 未通過時不得宣稱因果。
- 必須以 Incremental GM 與 iROMI 作為核心輸出。

## 13. ML-AVM-01 Valuation Predictor

### 13.1 業務問題

估計門市合理價值區間，用於轉手、回購、資產評估與 NetPlan。

### 13.2 Input Views

- `valuation_view`
- `forecast_training_view`
- `intervention_panel_view`

### 13.3 Output

```yaml
fair_value_p10: number
fair_value_p50: number
fair_value_p90: number
reserve_price: number
asking_price_reference: number
valuation_drivers: list[object]
normalization_adjustments: list[object]
```

### 13.4 方法

- Income Approach。
- Asset Approach。
- Manual Comparable baseline。
- Quantile GBDT。
- Conformal interval calibration。

### 13.5 Metrics

- 成交價區間覆蓋率。
- MAPE。
- Reserve price reasonableness。
- Finance review acceptance。

### 13.6 驗收條件

- Fair／Reserve／Asking 必須分開。
- 正常化調整必須可被財務核准。

## 14. ML-AVM-02 Liquidity Survival Model

### 14.1 業務問題

估計門市以特定價格進入市場後的成交機率與成交週期。

### 14.2 Output

```yaml
sale_probability_30d: number
sale_probability_90d: number
expected_days_to_close: number
liquidity_class: HIGH | MEDIUM | LOW
price_liquidity_curve: list[object]
```

### 14.3 方法

- Survival analysis。
- Logistic regression by time window。
- Gradient boosting survival challenger。

### 14.4 驗收條件

- 不得在交易樣本不足時輸出過度精確結果。
- 必須提供樣本量與信心。

## 15. ML-NET-01 Scenario Input Predictor

### 15.1 業務問題

為 NetPlan 提供 Downside／Base／Upside 的營收、毛利、估值、需求與稀釋輸入。

### 15.2 Output

```yaml
scenario_set_id: string
store_or_site_id: string
base_case: object
downside_case: object
upside_case: object
confidence: number
input_sources: list[string]
```

### 15.3 方法

- ForecastOps P10／P50／P90。
- SiteScore P10／P50／P90。
- AVM valuation quantiles。
- Cannibalization simulation。

### 15.4 驗收條件

- Scenario 不得使用未校準區間。
- NetPlan v1 可先使用 P50 deterministic；Robust v2 必須等 P10／P50／P90 校準。

## 16. 模型共同風險

| 風險 | 影響 | 控制 |
|---|---|---|
| 跨品牌資料污染 | SiteScore 高估或低估 ODay | Brand Transfer、Feature Contract、Holdout |
| Treatment 未標記 | ForecastOps 與 SiteScore 學到錯誤自然趨勢 | Label Registry、Intervention Log |
| 小樣本過度擬合 | Segment 輸出極端 | Hierarchical shrinkage、confidence gating |
| 區間未校準 | NetPlan 與 AVM 風險低估 | Conformal calibration、coverage monitoring |
| 容量截斷 | 潛在需求低估 | Effective capacity、censored demand handling |
| 資料更新延遲 | 預測不可信 | Freshness gate、stale data warning |
| 因果誤判 | 廣告或價格錯誤加碼 | Pre-trend、matched controls、evidence level |

## 17. Production Gate

任一模型進入 Production 前必須完成：

- Model Spec 完整。
- Feature Set 與 Label Set 核准。
- Dataset Snapshot 可重現。
- Backtest 完成。
- Segment metrics 達標。
- Calibration 檢查。
- Model Card 完成。
- Shadow／Canary 計畫。
- Rollback 計畫。
- Model Review Board 核准。
