---
doc_id: ODP-OR-01
title: "最佳化模型設計"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Optimization Owner / OR Model Owner"
approvers: "Product Owner / Data Owner / OR Model Owner / Architecture Owner / Finance Owner / Operations Owner"
content_format: markdown
---


# 最佳化模型設計

## 1. 文件目的

本文件定義 ODay Plus 的最佳化模型設計，涵蓋 PriceOps 價格最佳化、AdLift 預算與活動選擇輔助、RoutePlan 展店時序、NetPlan 開／留／改／遷／退店網規劃，以及 Solver 執行、限制條件、可行性診斷、替代方案、版本、稽核與驗收。最佳化模型的責任是產生「可比較、可解釋、可執行、可回滾」的方案，不得直接取代人工決策。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 設計原則

### 2.1 Solver 不是決策者

Solver 只輸出候選方案與證據：

```text
Forecast / Demand / Valuation / Constraints
→ Optimization Model
→ Candidate Plan / Objective / Binding Constraints / Trade-off
→ Human Approval
→ Execution
→ Outcome Tracking
```

不得讓 Solver 自動調價、關店、遷點、簽約、投放或停止活動。

### 2.2 硬限制不可任意放寬

若無可行解，系統必須回報 Infeasibility Diagnosis，不得自動放寬：

- 毛利底線。
- 法務租約條件。
- 資本預算上限。
- 施工與裝機時程。
- 人力容量。
- 價格安全區間。
- 服務覆蓋與自家稀釋限制。

### 2.3 P50 Deterministic 先行，Robust／Stochastic 後續啟用

第一版 NetPlan 與 PriceOps 以 P50 deterministic 模型建立可用閉環；當 P10／P50／P90 校準、情境輸入可信、管理層理解風險目標後，再啟用 robust 或 stochastic optimization。

## 3. 最佳化問題盤點

| Model ID | 名稱 | 模組 | 目標 | Solver |
|---|---|---|---|---|
| OR-PRICE-01 | Pricing Optimizer | PriceOps | 最大化增量毛利且滿足安全限制 | OR-Tools／CVXPY |
| OR-AD-01 | Ad Campaign Selector | AdLift | 在預算與處理容量下選擇投放門市 | Greedy／MILP |
| OR-ROUTE-01 | Expansion RoutePlan | HeatZone／SiteScore | 在資本與人力限制下安排展店時序 | CP-SAT／MILP |
| OR-NET-01 | NetPlan Deterministic | NetPlan | OPEN／KEEP／IMPROVE／MOVE／EXIT 組合最佳化 | OR-Tools CP-SAT |
| OR-NET-02 | Robust／Scenario NetPlan | NetPlan | 多情境下控制 downside risk | Pyomo／MILP／CP-SAT |
| OR-SCHED-01 | Intervention Capacity Scheduler | InterventionOps | 安排督導、維修、清潔與觀察窗口 | CP-SAT |

## 4. 共用輸入

### 4.1 預測輸入

| 輸入 | 來源 |
|---|---|
| External Demand | HeatZone／External Demand Predictor |
| Site Revenue Path | SiteScore |
| Growth Forecast | ForecastOps |
| Price Elasticity | PriceOps model |
| Ad Incrementality | AdLift model |
| Valuation | DealRoomAVM |
| Liquidity | DealRoomAVM |
| Cannibalization | HeatZone／SiteScore／NetPlan simulation |

### 4.2 限制輸入

| 限制 | 說明 |
|---|---|
| Budget | 總資本、季度預算、促銷預算、廣告預算 |
| Lease | 租約到期、提前解約成本、續約期限 |
| Construction | 裝修工期、施工容量、工程可行性 |
| Equipment | 設備可取得性、裝機時程、折舊與移機限制 |
| Labor | 督導、維修、清潔、開店支援人力 |
| Margin | 毛利底線、價格底線 |
| Capacity | 店內設備容量、尖峰利用率 |
| Geography | 自家稀釋、服務覆蓋、區域優先順序 |
| Legal | 合約、法務、加盟條款 |
| Approval | 高風險動作人工核准 |

## 5. OR-PRICE-01 Pricing Optimizer

### 5.1 問題定義

針對門市、設備、時段與價格候選集合，在安全限制下選擇價格方案，使預期毛利最大化。

### 5.2 決策變數

```text
x[s, m, t, p] ∈ {0,1}
```

代表門市 `s`、設備類型 `m`、時段 `t` 是否選擇價格候選 `p`。

### 5.3 Objective

```text
Maximize Σ expected_gross_margin[s,m,t,p] * x[s,m,t,p]
```

其中：

```text
expected_gross_margin = predicted_demand(price) * (price - variable_cost)
```

### 5.4 硬限制

| 限制 | 公式概念 |
|---|---|
| 單一候選 | `Σ_p x[s,m,t,p] = 1` |
| 價格上下限 | `price_min <= price <= price_max` |
| 毛利底線 | `price - variable_cost >= minimum_margin` |
| 調幅限制 | `abs(new_price - current_price) <= max_delta` |
| 頻率限制 | 一段期間內不得多次調價 |
| 法規／合約限制 | 不得違反已公告或合約價格條件 |
| 人工核准 | 高幅度或高風險方案必須 approval |

### 5.5 軟限制

- 避免同區域店價格差異過大。
- 避免尖峰價格過度上升。
- 避免一次調整太多門市造成客服負荷。
- 優先選擇低風險高信心方案。

### 5.6 輸出

```yaml
pricing_plan_id: string
store_id: string
candidate_actions:
  - machine_type: string
    time_bucket: string
    current_price: number
    recommended_price: number
    expected_demand_change: number
    expected_incremental_gm: number
    risk_level: LOW | MEDIUM | HIGH
binding_constraints: list[string]
requires_approval: boolean
rollback_plan: object
```

### 5.7 驗收條件

- Hard Constraint violation = 0。
- 每個價格方案有 demand simulation 與 GM simulation。
- 高風險方案不得自動執行。
- Pilot 結果可回收並估計實際效果。

## 6. OR-AD-01 Ad Campaign Selector

### 6.1 問題定義

在有限廣告預算與營運處理容量下，選擇最值得投放的門市、渠道與預算範圍。

### 6.2 決策變數

```text
y[s,c,b] ∈ {0,1}
```

代表門市 `s` 是否在渠道 `c` 使用預算 bucket `b`。

### 6.3 Objective

```text
Maximize Σ expected_incremental_gm[s,c,b] * y[s,c,b]
```

可加入風險調整：

```text
risk_adjusted_value = p50_incremental_gm - λ * downside_risk
```

### 6.4 限制

- 總預算上限。
- 每店每期間最多一個主要活動。
- 與促銷、調價、維修等干預不得未標記重疊。
- 對照組需求：若要 L3 以上證據，必須保留足夠 control stores。
- 行銷團隊執行容量。
- 廣告素材與法務限制。

### 6.5 輸出

```yaml
campaign_selection_id: string
selected_stores: list[object]
not_selected_reason: list[object]
budget_allocation: object
expected_incremental_gm: number
required_controls: list[string]
evidence_plan: string
```

## 7. OR-ROUTE-01 Expansion RoutePlan

### 7.1 問題定義

根據 HeatZone 與 SiteScore 結果，在資本、人力、施工、租約與區域策略限制下，安排未來 8–12 季展店順序。

### 7.2 決策變數

```text
open[i,q] ∈ {0,1}
```

代表候選點或區域 `i` 是否在季度 `q` 開店。

### 7.3 Objective

```text
Maximize Σ expected_npv[i,q] * open[i,q] - cannibalization_penalty - execution_risk_penalty
```

### 7.4 硬限制

- 季度資本預算。
- 開店支援人力。
- 工程施工容量。
- 候選物件可用期間。
- 自家稀釋上限。
- 同區域開店間隔。
- 管理層指定策略區域最低／最高開店數。

### 7.5 輸出

- 8–12 季展店甘特圖。
- 每季開店清單。
- 未採用候選點與原因。
- Binding Constraints。
- Alternative RoutePlan。

## 8. OR-NET-01 NetPlan Deterministic

### 8.1 問題定義

針對既有門市與候選新址，在 P50 情境下選擇 OPEN／KEEP／IMPROVE／MOVE／EXIT 組合，使整體店網價值最大化。

### 8.2 Action Set

| Action | 說明 |
|---|---|
| `OPEN` | 新開候選點 |
| `KEEP` | 維持現況 |
| `IMPROVE` | 投入改善，例如設備、清潔、行銷、價格策略 |
| `MOVE` | 關閉原址並遷至候選新址 |
| `EXIT` | 退出、轉手、回購或結束 |

### 8.3 決策變數

```text
keep[s,q] ∈ {0,1}
improve[s,q] ∈ {0,1}
exit[s,q] ∈ {0,1}
move[s,i,q] ∈ {0,1}
open[i,q] ∈ {0,1}
```

### 8.4 Objective

```text
Maximize total_network_value
= Σ future_gm
+ Σ terminal_value
- Σ investment_cost
- Σ exit_cost
- Σ move_cost
- Σ cannibalization_penalty
- Σ risk_penalty
```

### 8.5 硬限制

| 限制 | 說明 |
|---|---|
| Action exclusivity | 同一店同一季度只能選一種主要 action |
| Budget | 各季度資本與營運預算上限 |
| Lease | 租約未到期退出需成本或禁止 |
| Construction | 每季裝修與移機容量 |
| Equipment | 設備可用量與移機限制 |
| Labor | 營運、督導、維修、開店人力 |
| Cannibalization | 同區域自家稀釋上限 |
| Service Coverage | 策略區域最低覆蓋 |
| Legal Approval | 特定行動需法務或管理層核准 |
| Sequencing | MOVE 必須先有新址可用或銜接計畫 |

### 8.6 軟限制

- 避免同區域短期大量變動。
- 優先改善可恢復門市，而不是過早退出。
- 優先處理長期紅燈且租約即將到期門市。
- 避免過度集中資本於單一區域。

### 8.7 輸出

```yaml
network_plan_id: string
scenario: P50_BASE
solver_status: OPTIMAL | FEASIBLE | INFEASIBLE | TIME_LIMIT
objective_value: number
actions:
  - store_id: string
    quarter: string
    action: KEEP | IMPROVE | MOVE | EXIT | OPEN
    target_site_id: string | null
    expected_gm_delta: number
    investment_required: number
    valuation_effect: number
    rationale: list[string]
binding_constraints: list[object]
alternative_plans: list[object]
requires_approval: boolean
```

## 9. OR-NET-02 Robust／Scenario NetPlan

### 9.1 啟用條件

Robust／Scenario NetPlan 需滿足：

- ForecastOps 與 SiteScore 的 P10／P50／P90 已校準。
- 管理層確認風險偏好。
- 情境輸入可信。
- Solver 可在可接受時間內完成。
- 有 Alternative Plan 與 Infeasibility 解釋。

### 9.2 Scenario

| 情境 | 定義 |
|---|---|
| Downside | P10 營收、較高成本、較低估值、較高施工延遲 |
| Base | P50 預測 |
| Upside | P90 營收、較高估值、較低延遲 |

### 9.3 Objective 選項

| 目標 | 說明 |
|---|---|
| Max Expected Value | 最大化期望值 |
| Max Min Value | 最大化最壞情境 |
| CVaR | 控制下尾風險 |
| Regret Minimization | 降低相對最佳方案後悔值 |
| Weighted Scenario | 管理層指定情境權重 |

### 9.4 輸出

- 每情境 Objective。
- Downside risk。
- Action stability。
- 哪些行動在所有情境都建議。
- 哪些行動只在 upside 情境成立。
- 管理層風險選項比較。

## 10. OR-SCHED-01 Intervention Capacity Scheduler

### 10.1 問題定義

當 ForecastOps 產生大量警示與干預任務時，安排督導、維修、清潔、行銷與觀察窗口，避免超出團隊處理容量。

### 10.2 決策變數

```text
assign[task, resource, time_slot] ∈ {0,1}
```

### 10.3 限制

- 每個任務需要特定能力。
- 每位人員每日處理容量。
- 紅燈任務 SLA。
- 地理移動時間。
- 任務優先級。
- 同店同時不得安排互相衝突干預。

### 10.4 輸出

- 任務排程。
- 未排入任務與原因。
- SLA 風險。
- 人力瓶頸。

## 11. Solver Service 設計

### 11.1 Job Lifecycle

```text
CREATED
→ VALIDATING_INPUTS
→ BUILDING_MODEL
→ SOLVING
→ POST_PROCESSING
→ SUCCEEDED / INFEASIBLE / FAILED / CANCELLED / TIME_LIMIT
```

### 11.2 API

| Method | Path | 用途 |
|---|---|---|
| `POST` | `/optimization/pricing/jobs` | 建立價格最佳化工作 |
| `POST` | `/optimization/netplan/jobs` | 建立 NetPlan 求解工作 |
| `GET` | `/optimization/jobs/{job_id}` | 查詢工作狀態 |
| `GET` | `/optimization/jobs/{job_id}/result` | 查詢求解結果 |
| `POST` | `/optimization/jobs/{job_id}/cancel` | 取消工作 |
| `POST` | `/optimization/jobs/{job_id}/explain` | 產生解釋與限制診斷 |

### 11.3 Job Payload

```yaml
job_id: string
optimization_type: PRICE | AD | ROUTE | NETPLAN | SCHEDULER
input_snapshot_id: string
scenario_set_id: string
solver_config_id: string
requested_by: string
requested_at: timestamp
status: string
```

## 12. Infeasibility Diagnosis

無可行解時，系統必須輸出：

```yaml
infeasibility_report:
  conflicting_constraints:
    - constraint_id: string
      description: string
      involved_entities: list[string]
      severity: HARD | SOFT
  suggested_human_actions:
    - "increase quarterly construction capacity"
    - "move store action to later quarter"
    - "add candidate site"
  forbidden_auto_relaxations:
    - "minimum_margin"
    - "legal_lease_constraint"
```

不得自動放寬硬限制。

## 13. Explainability

### 13.1 PriceOps 解釋

- 為何選擇該價格。
- 預期需求如何變化。
- 預期毛利如何變化。
- 哪些限制被綁住。
- 若維持原價會怎樣。
- 回滾條件。

### 13.2 NetPlan 解釋

- 每家店 action 的原因。
- 替代 action 為何未選。
- 資本、人力、租約、稀釋哪些限制最關鍵。
- 方案相對 Status Quo 與 Greedy 的差異。
- Downside 情境下最大風險。

## 14. 版本與稽核

每次求解必須保存：

```yaml
solver_run_id: string
optimization_model_name: string
optimization_model_version: string
solver_name: OR_TOOLS_CP_SAT | PYOMO | CVXPY
solver_version: string
input_snapshot_id: string
constraint_set_id: string
objective_version: string
scenario_set_id: string
status: string
objective_value: number
solve_time_seconds: number
gap: number
created_by: service-account
approved_by: string | null
```

## 15. 驗證方法

### 15.1 PriceOps

- Historical replay。
- Small pilot。
- Constraint violation check。
- Customer complaint monitoring。
- GM impact validation。

### 15.2 NetPlan

- Status quo baseline。
- Greedy baseline。
- Historical network replay。
- Constraint feasibility check。
- Management review。
- 90／180／365 day outcome。

### 15.3 Solver Regression Test

每次更動 solver code 或 objective，必須跑固定 golden cases：

- 正常可行。
- 預算不足。
- 租約衝突。
- 人力不足。
- 候選點不足。
- 自家稀釋過高。
- 多個替代方案同分。
- Time limit。

## 16. 安全與降級

| 風險 | 降級方式 |
|---|---|
| Solver timeout | 回傳 best feasible 或要求縮小範圍 |
| Solver infeasible | 回傳診斷，不自動放寬硬限制 |
| Forecast input stale | 禁止正式求解，只允許 simulation |
| Valuation missing | NetPlan 排除 EXIT／MOVE 財務輸出或要求人工補值 |
| Price elasticity low confidence | PriceOps 只顯示分析，不產生推薦調價 |
| System unavailable | 使用上次核准方案或維持現況 |

## 17. 驗收條件

| 編號 | 驗收項目 | 標準 |
|---|---|---|
| OR-001 | Hard Constraint | Production 求解結果 Hard Constraint violation = 0 |
| OR-002 | Solver Trace | 100% 求解結果可追溯 input、constraint、objective、solver version |
| OR-003 | Infeasibility | 無可行解時必須輸出診斷 |
| OR-004 | Alternative Plan | NetPlan 必須提供至少一個可比較 Alternative 或說明不可得原因 |
| OR-005 | Human Approval | 高風險方案必須人工核准後才可執行 |
| OR-006 | Status Quo Comparison | NetPlan 必須與維持現況比較 |
| OR-007 | Rollback | PriceOps 調價方案必須有回滾條件 |
| OR-008 | Outcome Tracking | PriceOps／NetPlan 實施結果必須回收並進入 Learning Hub |
