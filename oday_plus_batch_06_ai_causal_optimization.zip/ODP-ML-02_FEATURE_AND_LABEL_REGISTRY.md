---
doc_id: ODP-ML-02
title: "Feature 與 Label Registry 設計"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Feature Platform Owner / Label Registry Owner"
approvers: "Product Owner / Data Owner / Model Owner / Architecture Owner / Security Owner / SRE Owner"
content_format: markdown
---


# Feature 與 Label Registry 設計

## 1. 文件目的

本文件定義 ODay Plus 的 Feature Registry 與 Label Registry。ODay Plus 的模型橫跨展店、選址、營運預測、干預、估值與店網規劃；若每個模型各自定義欄位、標籤與資料時間點，將導致資料污染、模型不可重現、因果效果誤判與決策無法稽核。因此，本文件將 Feature 與 Label 視為正式資料產品，規範其命名、欄位、生命週期、使用限制、品質門檻、血緣、成熟時間與跨模組共享規則。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. Registry 目標

Feature／Label Registry 必須達成以下目標：

1. 所有 Production 模型使用的 Feature 都可追溯來源、版本與時間。
2. 所有 Label 都有明確 Outcome 定義、成熟條件與可使用模型範圍。
3. 價格、廣告、促銷、維修、清潔等干預必須標成 Treatment，不得混入一般特徵而污染預測。
4. 任何模型訓練可重建當時使用的 Feature Set 與 Label Set。
5. 同一筆資料在不同模型中可有不同語意，但必須經 Registry 明確定義。
6. Feature 與 Label 的新增、修改、棄用必須走 Data Contract Review。

## 3. 核心概念

### 3.1 Feature

Feature 是模型在特定時間點可使用的輸入訊號。Feature 不等於資料表欄位；它必須有業務語意、粒度、時間語意與品質規則。

範例：

| Feature | 說明 |
|---|---|
| `geo.population_resident_500m` | 候選點 500m 內常住人口 |
| `store.age_days` | 門市在 prediction_origin_time 的店齡天數 |
| `machine.availability_rate_7d` | 機台近 7 日可用率 |
| `intervention.price_change_pct` | 調價幅度，Treatment Feature |
| `weather.rain_hours_7d` | 近 7 日降雨時數 |

### 3.2 Label

Label 是模型要學習或驗證的目標結果。Label 必須等到結果成熟後才能訓練。

範例：

| Label | 說明 |
|---|---|
| `site.actual_revenue_m3` | 新店開幕第 3 月實際營收 |
| `forecast.actual_revenue_28d` | 預測起點後 28 天實際營收 |
| `intervention.incremental_gm_14d` | 干預後 14 天增量毛利 |
| `avm.realized_sale_price` | 實際成交價 |
| `netplan.outcome_180d` | NetPlan 決策後 180 天結果 |

### 3.3 Treatment

Treatment 是公司或外部環境對門市造成的干預或處置，例如：

- 價格調整。
- 廣告投放。
- 促銷券。
- CRM 召回。
- 設備維修。
- 清潔加強。
- 營業時間調整。
- 競店進場。

Treatment 可能是模型輸入，但不得在不做識別的情況下混入「自然趨勢」模型。

## 4. Feature Registry Schema

### 4.1 Feature Definition

```yaml
feature_id: string
feature_name: string
version: string
status: DRAFT | ACTIVE | DEPRECATED | BLOCKED
owner: string
domain: GEO | STORE | MACHINE | MEMBER | TRANSACTION | INTERVENTION | WEATHER | FINANCE | NETWORK
entity_type: STORE | MACHINE | SITE | GEO_CELL | CAMPAIGN | PRICE_ACTION | NETWORK_PLAN
entity_key: list[string]
grain: string
value_type: INTEGER | FLOAT | STRING | BOOLEAN | CATEGORY | ARRAY | JSON | GEOMETRY
unit: string
semantic_type: STATIC | TIME_VARYING | TREATMENT | OUTCOME_PROXY | POST_TREATMENT | CONSTRAINT
source_table: string
source_view: string
source_system: string
calculation_sql_uri: string
feature_available_time_rule: string
refresh_frequency: HOURLY | DAILY | WEEKLY | MONTHLY | ON_DEMAND
allowed_model_names: list[string]
forbidden_model_names: list[string]
quality_rules: list[string]
null_policy: ERROR | IMPUTE | UNKNOWN_CATEGORY | ALLOW
pii_classification: NONE | LOW | SENSITIVE | PERSONAL
lineage: list[string]
created_at: timestamp
updated_at: timestamp
approved_by: string
```

### 4.2 命名規則

Feature 名稱採用：

```text
<domain>.<entity_or_concept>.<metric>_<window_or_radius>_<unit_or_transform>
```

範例：

| Feature | 解釋 |
|---|---|
| `geo.poi_laundry_count_1000m` | 候選點 1000m 內洗衣競店數 |
| `geo.rent_p50_district_monthly` | 行政區月租金中位數 |
| `store.revenue_gross_28d_sum` | 門市近 28 日總營收 |
| `store.revenue_gross_28d_zscore_peer` | 門市近 28 日營收相對同群 z-score |
| `machine.downtime_minutes_7d_sum` | 機台近 7 日停機分鐘數 |
| `intervention.ad_spend_14d_sum` | 近 14 日廣告花費 |
| `weather.rain_hours_7d_sum` | 近 7 日降雨時數 |

禁止命名：

- `score1`、`feature_a`、`amount_new` 等無語意名稱。
- 只有中文口語但無機器可解析結構的名稱。
- 同一名稱不同定義。

## 5. Label Registry Schema

### 5.1 Label Definition

```yaml
label_id: string
label_name: string
version: string
status: DRAFT | ACTIVE | DEPRECATED | BLOCKED
owner: string
entity_type: STORE | SITE | CAMPAIGN | PRICE_ACTION | NETWORK_PLAN | VALUATION
entity_key: list[string]
outcome_definition: string
outcome_unit: string
label_window_start_rule: string
label_window_end_rule: string
label_maturity_rule: string
source_table: string
calculation_sql_uri: string
allowed_models: list[string]
forbidden_models: list[string]
quality_rules: list[string]
treatment_dependency: NONE | REQUIRED | EXCLUDED | CONDITIONED
contamination_risk: LOW | MEDIUM | HIGH
created_at: timestamp
approved_by: string
```

### 5.2 Label 狀態

| 狀態 | 說明 | 可否訓練 |
|---|---|---|
| `OBSERVED` | 結果已部分觀察但尚未完整結算 | 不可 |
| `PROVISIONAL` | 初步結果，可做監控但不可正式訓練 | 不可 |
| `MATURE` | 達到成熟條件 | 可 |
| `VALIDATED` | 經品質與業務檢查通過 | 可 |
| `REJECTED` | 被判定污染或錯誤 | 不可 |
| `DEPRECATED` | 舊定義，不再新增使用 | 不可新增 |

## 6. 共用 Entity Key

| Entity | 主鍵 | 說明 |
|---|---|---|
| Tenant | `tenant_id` | 系統租戶或集團 |
| Brand | `brand_id` | 店鋪品牌 |
| Store | `store_id` | 門市 |
| Machine | `machine_id` | 機台 |
| Site | `candidate_site_id` | 候選物件 |
| Geo Cell | `h3_index`, `h3_resolution` | H3 空間單元 |
| Listing | `listing_id` | 出租物件資料 |
| Intervention | `intervention_id` | 干預事件 |
| Price Action | `price_action_id` | 調價方案 |
| Campaign | `campaign_id` | 廣告或促銷活動 |
| Valuation | `valuation_id` | 估值任務 |
| Network Plan | `network_plan_id` | 店網規劃方案 |

所有 Feature 與 Label 必須明確對應 Entity Key 與粒度。

## 7. 時間語意與可使用性

### 7.1 Feature Available Time

每個 Feature 必須定義 `feature_available_time`，而不是只定義 `event_time`。

例如：

```text
transaction.event_time = 2026-06-01 21:30
transaction.observation_time = 2026-06-01 21:31
refund.adjustment_time = 2026-06-03 10:00
finalized_available_time = 2026-06-05 00:00
```

若模型在 2026-06-02 進行預測，不得使用 2026-06-03 才發生的退款調整。

### 7.2 Feature Window

Feature window 必須相對於 `prediction_origin_time` 計算：

```text
revenue_28d_sum = sum(revenue where event_time >= prediction_origin_time - 28d and event_time < prediction_origin_time)
```

不得以資料查詢執行當天作為隱含結束時間。

## 8. Model-ready Views 與 Feature Set 對應

| View | 主要模型 | Feature 類型 |
|---|---|---|
| `geo_grid_view` | HeatZone | 區位、人口、POI、租金、競店、自家稀釋、信心 |
| `candidate_site_view` | SiteScore | 物件條件、區位、租金、競店、可達性、G2 可行性 |
| `brand_transfer_view` | SiteScore | 品牌、店型、設備、店齡、區位類型、轉換倍率 |
| `ramp_curve_view` | SiteScore、ForecastOps | 店齡、月份、季節、Ramp cohort |
| `store_machine_timeseries_view` | ForecastOps | 店級與設備級時間序列、Lag、Rolling、稼動率 |
| `forecast_training_view` | ForecastOps | 監督式預測訓練特徵與 Label |
| `intervention_panel_view` | InterventionOps、PriceOps | Treatment、Eligibility、Outcome、Observation Window |
| `matched_control_view` | AdLift | 實驗店、對照店、pre-trend、控制變數 |
| `valuation_view` | DealRoomAVM | 正常化 GM、資產、折舊、流動性與交易資料 |
| `network_plan_view` | NetPlan | 門市狀態、候選行動、限制、預測、估值、情境 |

## 9. Feature Set 定義

Feature Set 是某模型版本所使用的一組 Feature。Feature Set 必須可版本化。

```yaml
feature_set_id: fs_sitescore_v1_2026q3
model_name: site_revenue_path_predictor
version: 1.0.0
features:
  - geo.population_resident_500m@1.2.0
  - geo.poi_laundry_count_1000m@1.0.0
  - site.rent_monthly@1.0.0
  - site.floor_area_ping@1.0.0
  - store.same_brand_distance_min_m@1.0.0
point_in_time_policy_id: pit_sitescore_v1
approved_by: Data Contract Review
```

## 10. Label Set 定義

Label Set 是某模型訓練目標或評估目標的一組 Label。

```yaml
label_set_id: ls_sitescore_revenue_path_v1
labels:
  - site.actual_revenue_m1@1.0.0
  - site.actual_revenue_m3@1.0.0
  - site.actual_revenue_m6@1.0.0
  - site.actual_revenue_m12@1.0.0
maturity_policy: site_revenue_monthly_close_plus_7d
excluded_conditions:
  - opening_month_invalid
  - store_closed_before_label_maturity
  - missing_transaction_coverage
```

## 11. Treatment 與資料污染規則

### 11.1 Treatment Feature 規則

Treatment 必須記錄：

```yaml
treatment_id: string
treatment_type: PRICE | AD | PROMOTION | CRM | MAINTENANCE | CLEANING | COMPETITOR | EXTERNAL_SHOCK
entity_id: string
start_time: timestamp
end_time: timestamp
intensity: number
actor: SYSTEM | HUMAN | EXTERNAL
approved_by: string
propensity_available: boolean
observation_window_id: string
```

### 11.2 模型使用限制

| 模型 | Treatment 使用方式 |
|---|---|
| HeatZone | 通常不使用短期營運 Treatment；若使用需聚合與標記 |
| SiteScore | 開店前不可使用開店後 Treatment；訓練時需排除或正常化重大干預 |
| ForecastOps | 可作為 Dynamic Exogenous Feature，但要區分自然趨勢與干預效果 |
| PriceOps | 價格 Treatment 是核心輸入，必須有 propensity 與安全限制 |
| AdLift | 廣告 Treatment 是核心識別對象，不得與其他重疊干預未標記 |
| DealRoomAVM | 需正常化短期一次性干預，避免高估或低估資產價值 |
| NetPlan | 使用已驗證干預效果，不得把未驗證效果當成確定收益 |

## 12. Feature Quality Rules

每個 Feature 至少需定義以下品質規則：

| 規則 | 說明 |
|---|---|
| Completeness | 缺值率上限 |
| Freshness | 最晚更新時間 |
| Validity | 值域、型別、單位 |
| Uniqueness | 主鍵唯一性 |
| Consistency | 跨來源一致性 |
| Coverage | 覆蓋區域、店數、時間範圍 |
| Drift | 與歷史分布差異 |
| Confidence | 來源可信度與樣本量 |

品質規則失敗時，必須回傳：

```yaml
quality_status: PASSED | WARNING | FAILED
failed_rules: list[string]
allowed_usage: TRAINING | SCORING | MONITORING_ONLY | BLOCKED
```

## 13. Label Quality Rules

Label 必須檢查：

- Outcome window 是否完整。
- 是否達到成熟時間。
- 是否有交易延遲、退款、補登未處理。
- 是否重疊重大干預。
- 樣本是否足夠。
- 是否與業務事件矛盾，例如門市已停業但仍有營收。
- 是否被人工標註為異常、不可用或資料錯誤。

## 14. Registry API

### 14.1 Feature API

| Method | Path | 用途 |
|---|---|---|
| `GET` | `/features` | 查詢 Feature 清單 |
| `GET` | `/features/{feature_name}` | 查詢 Feature 定義 |
| `POST` | `/features` | 建立 Feature 草稿 |
| `POST` | `/features/{feature_name}/approve` | 核准 Feature |
| `POST` | `/feature-sets` | 建立 Feature Set |
| `GET` | `/feature-sets/{feature_set_id}` | 查詢 Feature Set |

### 14.2 Label API

| Method | Path | 用途 |
|---|---|---|
| `GET` | `/labels` | 查詢 Label 定義 |
| `POST` | `/labels` | 建立 Label 草稿 |
| `POST` | `/labels/{label_name}/approve` | 核准 Label |
| `POST` | `/label-instances/{id}/mature` | 標記 Label 成熟 |
| `POST` | `/label-instances/{id}/reject` | 標記 Label 不可用 |
| `GET` | `/label-sets/{label_set_id}` | 查詢 Label Set |

## 15. Registry Events

| Event | 說明 |
|---|---|
| `feature.definition.created` | Feature 草稿建立 |
| `feature.definition.approved` | Feature 通過治理 |
| `feature.definition.deprecated` | Feature 棄用 |
| `feature.quality.failed` | Feature 品質失敗 |
| `label.definition.created` | Label 草稿建立 |
| `label.definition.approved` | Label 通過治理 |
| `label.instance.matured` | 某筆 Label 成熟 |
| `label.instance.rejected` | 某筆 Label 被拒絕 |
| `feature_set.approved` | Feature Set 可用於模型訓練 |
| `label_set.approved` | Label Set 可用於模型訓練 |

## 16. 權限

| 操作 | 可執行角色 |
|---|---|
| 查看 Feature／Label 定義 | Product、Data、Model、Engineering |
| 建立草稿 | Data Owner、Model Owner |
| 核准 Feature Contract | Data Owner + Product Owner |
| 核准高風險 Label | Data Owner + Model Owner + Domain Owner |
| 封鎖 Feature | Data Owner／Security Owner |
| 使用敏感 Feature | 需 Security Owner 核准 |

## 17. 驗收條件

| 編號 | 驗收項目 | 標準 |
|---|---|---|
| FLR-001 | Feature Registry 可查詢 | Production Feature 100% 有定義 |
| FLR-002 | Label Registry 可查詢 | Production Label 100% 有定義與成熟規則 |
| FLR-003 | Feature Set 可重現 | 任一 Production 模型可查到 Feature Set 版本 |
| FLR-004 | Label Set 可重現 | 任一 Production 模型可查到 Label Set 版本 |
| FLR-005 | Treatment 可識別 | 價格、廣告、促銷、維修、清潔 100% 有 Treatment 標記 |
| FLR-006 | 污染防止 | SiteScore／ForecastOps 訓練不得使用未成熟或未標記干預 Label |
| FLR-007 | 品質阻擋 | Quality FAILED 的 Feature／Label 不得進入訓練或 Production 推論 |
| FLR-008 | Audit | Feature／Label 新增、修改、封鎖、棄用 100% 留痕 |
