---
doc_id: ODP-ML-05
title: "因果推論與實驗設計"
version: 0.1.0
status: draft-for-review
document_class: ai-causal-optimization
batch: 6
formal_deliverable: true
project: ODay Plus
language: zh-TW
updated_at: 2026-06-26
owner: "Causal Inference Owner / Experiment Owner"
approvers: "Product Owner / Data Owner / Model Owner / Architecture Owner / Security Owner / SRE Owner"
content_format: markdown
---


# 因果推論與實驗設計

## 1. 文件目的

本文件定義 ODay Plus 對價格、廣告、促銷、CRM 召回、維修與清潔等營運干預的因果推論與實驗設計。ODay Plus 不能只回答「活動後營收有沒有變高」，而必須回答「若沒有做這個動作，原本會如何；做了之後真正增加多少營收與毛利」。因此，本文件規範 Treatment、Control、Propensity、Observation Window、Outcome、Pre-trend、Evidence Level、因果模型與實驗治理。


## 0. 文件基線與引用規則

本文件屬於第 6 批「AI／因果／最佳化設計」正式交付文件，必須與前五批文件共同使用：

| 參照文件 | 用途 |
|---|---|
| `ODP-00-01_SCOPE_AND_BOUNDARIES.md` | 系統範圍、完整目標架構、上游 IoT／內部資料底座責任邊界 |
| `ODP-00-02_GLOSSARY_AND_SEMANTICS.md` | 全平台名詞、狀態、代碼與共用業務語意 |
| `ODP-00-03_STAKEHOLDERS_AND_RACI.md` | Ownership、RACI、責任分離與治理會議 |
| `ODP-00-04_DOCUMENT_VERSION_AND_ADR_GOVERNANCE.md` | 文件版本、ADR、Deviation、變更與核准流程 |
| `ODP-00-05_REQUIREMENTS_TRACEABILITY_MATRIX.md` | HLR、FR、SD、Test、Evidence 的追蹤骨架 |
| `ODP-SA-01` 至 `ODP-SA-10` | 業務架構、流程、角色、FR、NFR、整合與 KPI 基線 |
| `ODP-DATA-01` 至 `ODP-DATA-07` | 資料來源、IoT／內部資料契約、Canonical Model、Model-ready Views、資料品質與時間語意 |
| `ODP-SD-01` 至 `ODP-SD-12` | 平台架構、部署、服務邊界、DB、API、Event、Workflow、安全、可靠性、觀測與 CI/CD |
| `ODP-MOD-00` 至 `ODP-MOD-11` | 各業務模組詳細設計、API、Event、Batch／Worker、畫面與驗收條件 |

來源基線：`SRC-ODP-ARCH`、`SRC-ODP-PLAN`、`SRC-ODP-REVIEW`、`SRC-LEGACY-CLOUD`、`SRC-WORKING-DECISIONS`。若本文件與第 1 批治理文件衝突，以第 1 批治理文件及已核准 ADR 為準。

規範用語：本文中的「必須」表示驗收必要條件；「不得」表示禁止；「應」表示預設要求，若不採用必須有核准 Deviation；「可」表示可選或延伸能力。


## 2. 基本原則

### 2.1 Before／After 不等於因果

以下情境不得直接宣稱因果：

- 廣告後營收上升，但同時進入旺季。
- 調價後毛利上升，但競店剛好停業。
- 維修後使用率恢復，但本來就是週末高峰。
- 促銷後新客增加，但同時有會員召回與廣告投放。

因果推論必須建立反事實：

```text
Observed outcome with treatment
− Expected outcome without treatment
= Incremental effect
```

### 2.2 Treatment 必須先被設計，不能事後補猜

每個干預在執行前必須建立：

- Treatment type。
- Eligibility rule。
- Action set。
- Target stores／machines／segments。
- Start／end time。
- Observation window。
- Expected outcome。
- Conflict rules。
- Propensity 或選擇原因。
- Approval record。

若事後才發現有干預但未記錄，該事件只能作為低證據等級分析。

### 2.3 增量毛利優先於表面營收

廣告、促銷與調價的核心驗證指標是：

```text
Incremental Gross Margin = Incremental Revenue - Incremental Variable Cost - Campaign / Discount / Operating Cost
```

不得只用 ROAS、曝光、點擊或活動前後營收變化作為成功判斷。

## 3. Treatment Taxonomy

| Treatment Type | 說明 | 核心 Outcome |
|---|---|---|
| `PRICE_CHANGE` | 價格調整、時段價、設備價 | Incremental GM、利用率、客訴 |
| `AD_CAMPAIGN` | Meta／Google／LINE／Local Ads | Incremental GM、iROMI、新客 |
| `PROMOTION` | 折扣券、滿額、時段優惠 | Incremental GM、核銷、回訪 |
| `CRM_RECALL` | 會員召回、沉睡會員推播 | 回訪率、Incremental GM |
| `MAINTENANCE` | 維修、保養、故障修復 | 可用率、營收恢復、客訴下降 |
| `CLEANING` | 清潔加強、環境改善 | 客訴率、回訪、評價 |
| `OPENING_CAMPAIGN` | 開幕促銷 | Ramp 正常化、初期認知 |
| `EXTERNAL_SHOCK` | 競店進場、道路施工、天氣事件 | 不作公司干預，但需標記控制 |

## 4. Estimand 定義

每個干預必須明確定義估計目標。

| Estimand | 定義 | 適用 |
|---|---|---|
| ATE | 平均處置效果 | 全體活動平均效果 |
| ATT | 對實際被處置店的平均效果 | 廣告、維修、調價 |
| CATE | 條件式處置效果 | 不同區位、店齡、客群效果 |
| ITT | 指派效果 | 有隨機指派但未完全遵從 |
| Incremental GM | 增量毛利 | 所有財務型干預 |
| iROMI | Incremental GM / Ad Spend | 廣告 |

## 5. Evidence Level

| Level | 名稱 | 條件 | 可用說法 |
|---|---|---|---|
| L0 | Anecdotal | 只有人工觀察或個案描述 | 「觀察到可能變化」 |
| L1 | Before/After | 有前後比較，無控制組 | 「活動後有變化」 |
| L2 | Matched Descriptive | 有相似對照但 pre-trend 未完全通過 | 「具參考性的增量估計」 |
| L3 | DiD Validated | 對照組、pre-trend 與平衡檢查通過 | 「可作為中等信心因果估計」 |
| L4 | Randomized／Staggered | 有實驗設計或接近隨機 | 「高信心因果估計」 |
| L5 | Replicated／Policy Ready | 多次重複、跨區域穩定、通過安全門檻 | 「可用於政策或自動化規則」 |

系統前端必須顯示 Evidence Level，Evidence 不足時不得以「造成」、「提升」等確定語氣描述。

## 6. Observation Window

### 6.1 Window 類型

| Window | 說明 |
|---|---|
| Pre-window | 干預前基線期間 |
| Treatment Window | 實際干預期間 |
| Cooldown Window | 干預結束後短期殘留期 |
| Outcome Window | 評估結果期間 |
| Maturity Window | 等待交易、退款、成本、客服資料成熟 |

### 6.2 預設 Window

| Treatment | Pre-window | Outcome Window | Maturity |
|---|---:|---:|---:|
| Price Change | 28–56 日 | 14–28 日 | +7 日 |
| Ad Campaign | 28–56 日 | 投放期 + 7–14 日 | +7 日 |
| Promotion | 14–28 日 | 活動期 + 7 日 | +7 日 |
| CRM Recall | 28 日 | 14–30 日 | +7 日 |
| Maintenance | 14–28 日 | 7–14 日 | +3 日 |
| Cleaning | 28 日 | 14–28 日 | +7 日 |

Window 可依模型與場景調整，但必須寫入 Intervention Log。

## 7. Confounding 與控制變數

主要混淆因素：

- 店齡與 Ramp。
- 季節、天氣、假日、學期。
- 競店進場或停業。
- 多個干預重疊。
- 設備故障或維修。
- 區域事件、道路施工、商圈變動。
- 自家店稀釋。
- 價格與促銷同時變動。
- 廣告選店本身偏向高潛力店。

控制變數應來自 Model-ready Views，且必須具備 point-in-time correctness。

## 8. Matching Design

### 8.1 Matched Control 候選條件

對照店必須在干預前與實驗店相似：

- 店齡。
- 區位型態。
- 店型與設備配置。
- 歷史營收水準與趨勢。
- 客群與會員結構。
- 季節與天氣暴露。
- 無重疊干預。
- 未受自家店稀釋或重大外部衝擊。

### 8.2 Matching 方法

| 方法 | 用途 |
|---|---|
| Exact Matching | 區域、店齡、店型等硬條件 |
| Propensity Score Matching | 選店偏誤控制 |
| Nearest Neighbor | 找相似營運曲線 |
| Synthetic Control | 單店或少數店高價值活動 |
| Coarsened Exact Matching | 小樣本穩定配對 |

### 8.3 Balance 檢查

- Standardized Mean Difference。
- Pre-period revenue level difference。
- Pre-period trend difference。
- Seasonality pattern similarity。
- Intervention overlap check。

Pre-trend 未通過時，Evidence Level 最高不得超過 L2。

## 9. Difference-in-Differences 設計

### 9.1 基本公式

```text
Effect = (Treated_Post - Treated_Pre) - (Control_Post - Control_Pre)
```

### 9.2 Panel Model

```text
outcome_it = alpha_i + gamma_t + beta * treatment_it + X_it * theta + error_it
```

| 項目 | 說明 |
|---|---|
| `alpha_i` | 門市固定效果 |
| `gamma_t` | 日期／週固定效果 |
| `treatment_it` | 干預指標或強度 |
| `X_it` | 天氣、節假日、競店、故障等控制變數 |
| `beta` | 平均干預效果 |

### 9.3 輸出

```yaml
effect_estimate: number
effect_ci_low: number
effect_ci_high: number
p_value: number
incremental_revenue: number
incremental_gm: number
evidence_level: L3
pretrend_status: PASS
```

## 10. Synthetic Control 設計

適用場景：

- 單店廣告。
- 高價值門市改裝或清潔改善。
- 特定區域大型促銷。
- 樣本少但歷史資料長。

必要條件：

- 足夠長 pre-period。
- 有一組未受干預候選店。
- Pre-fit 誤差可接受。
- 同期無重大重疊干預。

## 11. Uplift／HTE 設計

### 11.1 啟用條件

Uplift／HTE 不應第一版直接上 Production。啟用條件：

- 有足夠不同 Treatment。
- 店群差異可觀察。
- 平均效果已可靠。
- CATE 可在 holdout 或新活動中驗證。
- 有防止小樣本極端策略的收縮機制。

### 11.2 輸出

```yaml
cate_estimate: number
uplift_score: number
recommended_segment: boolean
confidence: number
minimum_sample_warning: boolean
```

## 12. Bayesian MMM 設計

### 12.1 啟用條件

- 足夠長時間序列。
- 多渠道投放。
- 預算變化足夠。
- 渠道可識別。
- 不與大量其他干預完全共線。
- 管理層理解 MMM 是 aggregate channel effect，不是單店真實因果。

### 12.2 輸出

- Channel contribution。
- Diminishing return curve。
- Carryover／Adstock。
- Budget allocation suggestion。
- Uncertainty interval。

MMM 不取代 AdLift 的單店或活動級增量分析。

## 13. Contextual Bandit 設計

### 13.1 啟用條件

Bandit 只有在以下條件都成立後才可啟用：

- Action Set 穩定。
- Propensity 完整記錄。
- Reward 成熟且可即時或近即時取得。
- Safety constraints 完整。
- Off-policy Evaluation 可用。
- 人工核准已定義可自動化邊界。
- Kill Switch 可用。

### 13.2 不得啟用場景

- 價格會造成毛利底線違反。
- Reward 尚未成熟或會被延遲退款大幅修正。
- 干預重疊嚴重。
- 小樣本區域造成過度探索。
- 管理層未核准安全探索政策。

## 14. PriceOps 因果設計

### 14.1 實驗設計

| 設計 | 說明 |
|---|---|
| Small-range price pilot | 小幅、短期、可回滾調價 |
| Staggered rollout | 分批調價，形成自然對照 |
| Matched control stores | 找相似但未調價門市 |
| Safe action set | 價格調整限定在核准區間 |

### 14.2 Outcome

- Incremental GM。
- Demand change。
- Utilization change。
- Customer complaints。
- Repeat usage。
- Cannibalization。

### 14.3 安全規則

- 不得低於毛利底線。
- 不得超過核准價格變動幅度。
- 不得在重大故障或服務品質問題期間做價格效果判斷。
- 價格 Pilot 必須可快速 rollback。

## 15. AdLift 因果設計

### 15.1 流程

```text
Ad Need Score
→ Eligibility
→ Candidate Stores
→ Control Matching
→ Pre-trend Test
→ Campaign Approval
→ Execution
→ Observation Window
→ Incremental GM / iROMI
→ Continue / Stop / Scale
```

### 15.2 輸出

```yaml
campaign_id: string
treated_stores: list[string]
control_stores: list[string]
pretrend_status: PASS | FAIL | INCONCLUSIVE
incremental_revenue: number
incremental_gm: number
iromi: number
effect_interval: object
evidence_level: string
recommendation: CONTINUE | STOP | SCALE | CHANGE_CHANNEL | INCONCLUSIVE
```

### 15.3 Stop Rule

活動應停止或調整的條件：

- Incremental GM 連續不達標。
- iROMI 低於門檻。
- 對照組檢查失效。
- 重疊干預導致效果不可識別。
- 客訴或營運負荷異常上升。

## 16. Maintenance／Cleaning 因果設計

維修與清潔通常不是為了測試效果，而是必要營運行為；仍應估計其恢復效果。

估計方式：

- 以故障前穩態與同群店作為基準。
- 使用 interruption analysis。
- 分開估計「停機損失」與「修復恢復」。
- 不得將維修恢復效果誤當成促銷或廣告效果。

## 17. Event 與資料要求

每次干預事件必須產生：

| Event | 說明 |
|---|---|
| `intervention.proposed` | 干預被提出 |
| `intervention.approved` | 干預核准 |
| `intervention.started` | 干預開始 |
| `intervention.ended` | 干預結束 |
| `observation_window.created` | 觀察窗口建立 |
| `effect_evaluation.started` | 效果評估開始 |
| `effect_evaluation.completed` | 效果評估完成 |
| `effect_evaluation.inconclusive` | 效果不可識別 |

## 18. 因果結果儲存

```yaml
effect_evaluation_id: string
intervention_id: string
treatment_type: string
estimand: ATT | ATE | CATE | ITT
evaluation_method: DID | SYNTHETIC_CONTROL | MATCHED_BEFORE_AFTER | RCT | UPLIFT | MMM
pretrend_status: PASS | FAIL | INCONCLUSIVE
control_group_id: string
outcome_window_id: string
incremental_revenue: number
incremental_gm: number
effect_ci_low: number
effect_ci_high: number
evidence_level: string
recommendation: string
limitations: list[string]
created_at: timestamp
approved_by: string
```

## 19. 驗收條件

| 編號 | 驗收項目 | 標準 |
|---|---|---|
| CI-001 | Treatment Log | 所有正式干預 100% 有 Treatment 記錄 |
| CI-002 | Observation Window | 所有正式干預 100% 有觀察窗口 |
| CI-003 | Conflict Check | 重疊干預可識別與標記 |
| CI-004 | Evidence Level | 效果報告 100% 顯示 Evidence Level |
| CI-005 | Pre-trend | AdLift L3 以上報告必須通過 pre-trend |
| CI-006 | Incremental GM | 廣告與促銷報告必須計算 Incremental GM |
| CI-007 | Stop Rule | AdLift／PriceOps 必須有 Stop／Rollback 條件 |
| CI-008 | 不誤稱因果 | Evidence 不足時前端與報告不得宣稱確定因果 |
